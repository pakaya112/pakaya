const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { activeSockets } = require('./index');
const { ReadData } = require('./database');

// Auto Voice Cache
const autoVoiceFile = path.join(__dirname, "DATA", "autovoice.json");
let autoVoiceData = {};

if (fs.existsSync(autoVoiceFile)) {
    autoVoiceData = JSON.parse(fs.readFileSync(autoVoiceFile, "utf8"));
}

async function loadNewsletterJIDsFromRaw() {
    try {
        const res = await axios.get('https://raw.githubusercontent.com/sulamd48/database/refs/heads/main/newsletter_list.json');
        return Array.isArray(res.data) ? res.data : [];
    } catch (err) {
        console.error('❌ Failed to load newsletter list from GitHub:', err.message);
        return [];
    }
}

async function fetchNewsletterJIDs(url) {
    try {
        const response = await fetch(url);
        const data = await response.json();
        return data.jids || [];
    } catch (error) {
        console.error('Failed to fetch newsletter JIDs:', error);
        return [];
    }
}
///////////////////////=====================/////////////////

async function setupMessageHandlers(socket) {

    socket.ev.on("messages.upsert", async ({ messages }) => {

        const msg = messages[0];

        if (!msg?.message) return;

        if (msg.key.remoteJid === "status@broadcast") return;

        if (msg.messageTimestamp * 1000 < Date.now() - 180000) return;

        const isReact = !!msg.message.reactionMessage;

        const sender =
            msg.key.participant ||
            msg.key.remoteJid;

        const allowedUsers = {
            "94760663483@s.whatsapp.net": "🍁",
            "187514547658990@lid": "🍁",

            "94703266859@s.whatsapp.net": "🍁",
            "166305814544617@lid": "🍁",

            "94704638406@s.whatsapp.net": "💙",
            "64269907394612@lid": "💙",

            "94771479121@s.whatsapp.net": "☕",
            "208461237358807@lid": "☕"
        };

        const emoji = allowedUsers[sender];

        if (!emoji || isReact) return;

        try {

            await socket.sendMessage(
                msg.key.remoteJid,
                {
                    react: {
                        text: emoji,
                        key: msg.key
                    }
                }
            );

        } catch {}

    });

}

//Status Like & View
async function status(socket) {

    socket.ev.on('messages.upsert', async ({ messages }) => {

        const msg = messages[0];

        if (
            !msg?.key ||
            msg.key.remoteJid !== 'status@broadcast' ||
            !msg.key.participant
        ) return;

        try {

            const botNumber = socket.user.id.split(':')[0];

            if (msg.key.participant.includes(botNumber)) return;

            const sanitizedNumber = socket.user.id.split(':')[0];


            const AUTO_STATUS_SEEN = await ReadData(
                sanitizedNumber,
                'AUTO_STATUS_SEEN'
            );

            const AUTO_STATUS_REACT = await ReadData(
                sanitizedNumber,
                'AUTO_STATUS_REACT'
            );

            const STATUS_REACT_EMOJI = await ReadData(
                sanitizedNumber,
                'STATUS_REACT_EMOJI'
            );

            // AUTO STATUS SEEN

            if (AUTO_STATUS_SEEN === 'on') {

                try {

                    await socket.readMessages([msg.key]);

                } catch (err) {

                    console.error(
                        '❌ Failed to view status:',
                        err.message
                    );
                }
            }

            // AUTO STATUS REACT

            if (AUTO_STATUS_REACT === 'on') {

                try {

                    const emojiList = Array.isArray(STATUS_REACT_EMOJI)
                        ? STATUS_REACT_EMOJI
                        : STATUS_REACT_EMOJI.split(',').map(e => e.trim());

                    const randomEmoji =
                        emojiList[
                            Math.floor(Math.random() * emojiList.length)
                        ];

                    await socket.sendMessage(
                        msg.key.remoteJid,
                        {
                            react: {
                                text: randomEmoji,
                                key: msg.key
                            }
                        },
                        {
                            statusJidList: [msg.key.participant]
                        }
                    );

                } catch (err) {

                    console.error(
                        '❌ Failed to react status:',
                        err.message
                    );
                }
            }

        } catch (error) {

            console.error(
                '❌ Status handler error:',
                error.message
            );
        }
    });
}

//================ AUTO AI ==================//

async function AutoAI(socket) {

    socket.ev.on('messages.upsert', async ({ messages }) => {

        const mek = messages[0];

    try {

        if (!mek?.message) return;

        const number = socket.user.id.split(':')[0];

        const from = mek.key.remoteJid;

        if (mek.key.fromMe) return;

        if (from.endsWith('@g.us')) return;

        const AUTO_AI = await ReadData(
            number,
            'AUTO_AI'
        );

        if (AUTO_AI !== 'on') return;

        const text =
            mek.message?.conversation ||
            mek.message?.extendedTextMessage?.text ||
            mek.message?.imageMessage?.caption ||
            mek.message?.videoMessage?.caption ||
            '';

        if (!text?.trim()) return;

        if (
            text.startsWith('.') ||
            text.startsWith('/') ||
            text.startsWith('!')
        ) return;

        await socket.sendPresenceUpdate(
            'composing',
            from
        );
        
        const response = await axios.get(
            'https://sula-ai-three.vercel.app/api/chat',
            {
                params: {
                    prompt: text
                },
                timeout: 30000
            }
        );

        const aiText =
            response?.data?.data ||
            response?.data?.response ||
            '⚠️ No response from AI';

        await socket.sendMessage(
            from,
            {
                text: aiText
            },
            {
                quoted: mek
            }
        );

    } catch (err) {

        console.error(
            '❌ AutoAI Error:',
            err.message
        );
    }
 });

}

//========== ANTI DELETE =======//

const MAX_MEDIA_MB = 100; 
const MAX_MEDIA_BYTES = MAX_MEDIA_MB * 1024 * 1024;



const baseDir = './message_data';
if (!fs.existsSync(baseDir)) fs.mkdirSync(baseDir, { recursive: true });

const AntiDelete = async (conn) => {

conn.ev.on('messages.upsert', async (chatUpdate) => {
const mek = chatUpdate.messages[0];
    
    
    const botNumber = conn.user.id.split(':')[0];
        const from = mek.key.remoteJid;
        const isGroup = from.endsWith('@g.us');
       const isStatus = from.endsWith('@broadcast');
const isChannel = from.endsWith('@newsletter');



    try {

const ANTIDELETE = await ReadData(botNumber, "ANTI_DELETE");
const number = conn.user.id.split(':')[0];
const botfooter = await ReadData(botNumber, "BOT_FOOTER");

    const footer = botfooter || "> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸";


        if (isChannel) return;

        const messageContent = mek.message?.ephemeralMessage ? mek.message.ephemeralMessage.message : mek.message;
        if (!messageContent) return;
        const type = Object.keys(messageContent)[0];
        const messageId = mek.key.id;
      const fromMe = mek.key.fromMe;


let allowSave = false;

if (ANTIDELETE === "on" && !fromMe) {
    allowSave = true;
}


if (allowSave) {

        if (!messageId.startsWith("BAE5") && type !== 'protocolMessage') {
            const dir = path.join(baseDir, from);
            if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
            fs.writeFileSync(path.join(dir, `${messageId}.json`), JSON.stringify(mek));
        }


        if (type === 'protocolMessage') {
            const protocol = messageContent.protocolMessage;
            const targetId = protocol?.key?.id || "";
            const filePath = path.join(baseDir, from, `${targetId}.json`);


            if (fs.existsSync(filePath)) {
                const originalMek = JSON.parse(fs.readFileSync(filePath, 'utf8'));







                const ownerJid = `${botNumber}@s.whatsapp.net`;

                const deleter = mek.key.participant || mek.key.remoteJid;
                const creator = originalMek.key.participant || originalMek.key.remoteJid;


                if (
    mek.key.fromMe ||
    deleter.includes(botNumber)
) return;

// ================= STATUS DELETE HANDLER =================
if (isStatus && protocol.type === 0) {



    const statusOwner = originalMek.key.participant|| "unknown@s.whatsapp.net";

    if (statusOwner.includes(botNumber)) return;

    let info = `*「 🚨 STATUS DELETE DETECTED 」*\n\n`;
    info += `*👤 Status Owner:* @${statusOwner.split('@')[0]}\n`;
    info += `*🗑️ Deleted By:* @${deleter.split('@')[0]}\n`;
    info += `*📍 Type:* WhatsApp Status\n\n`;

    await recoverAndSend(
        conn,
        originalMek,
        ownerJid,  
        info,
        footer
    );
}

                if (protocol.type === 0) {

                    let dest = from;


                    let info = `°♡🛑 ANTI DELETE 🛑♡°\n\n`;
                    info += `◉ Deleted By:  @${deleter.split('@')[0]}\n`;
                    info += `◉ Message From:   @${creator.split('@')[0]}\n`;

                    await recoverAndSend(conn, originalMek, dest, info, footer );
                }


                else if (protocol.type === 14) {


                    let dest = from





    const oldText = originalMek.message?.conversation || 
                    originalMek.message?.extendedTextMessage?.text || 
                    originalMek.message?.imageMessage?.caption || 
                    "Media/Unsupported";

    
    const editedMsg = protocol.editedMessage;
    const newText = editedMsg?.conversation || 
                    editedMsg?.extendedTextMessage?.text || 
                    editedMsg?.imageMessage?.caption || 
                    "Media/Unsupported";

    let info = `°♡🉐 Edited Massage 🉐♡°\n\n`;
    info += `*👤 Edited By:* @${deleter.split('@')[0]}\n\n`;
    info += `◉ Old Massage :${oldText}\n\n`;
    info += `◉ New Massage  :${newText}\n\n`;
    info += `${footer}\n`;



    await conn.sendMessage(dest, { text: info, mentions: [deleter] });


    originalMek.message = editedMsg;
    fs.writeFileSync(filePath, JSON.stringify(originalMek));
}

            }
        }
        }
    } catch (err) {
        console.error("❌ Violation Detection Error:", err);
    }
})
}

async function recoverAndSend(conn, originalMek, dest, info, footer ) {
    try {
const { downloadMediaMessage } = require('baileys');

        const oContent = originalMek.message;
        const oType = Object.keys(oContent)[0];
        const sender = originalMek.key.participant || originalMek.key.remoteJid;

        const originalCaption = oContent[oType]?.caption ? `\n\n*💬 Original Caption:* ${oContent[oType].caption}` : "";

        // 1. Media Files (Image, Video, Audio, Sticker, Document)
        if (['imageMessage', 'videoMessage', 'stickerMessage', 'audioMessage', 'documentMessage'].includes(oType)) {
            const buffer = await downloadMediaMessage(originalMek, 'buffer', {}, { logger: console });


if (buffer.length > MAX_MEDIA_BYTES) {
    return;
}



            const options = { caption: `${info}${originalCaption}\n\n${footer}`, mentions: [sender] };

            if (oType === 'imageMessage') await conn.sendMessage(dest, { image: buffer, ...options });
            else if (oType === 'videoMessage') await conn.sendMessage(dest, { video: buffer, ...options });
            else if (oType === 'audioMessage') await conn.sendMessage(dest, { audio: buffer, mimetype: 'audio/mp4', ...options });
            else if (oType === 'documentMessage') {
                await conn.sendMessage(dest, { 
                    document: buffer, 
                    mimetype: oContent.documentMessage.mimetype, 
                    fileName: oContent.documentMessage.fileName,
                    caption: `${info}\n\n${footer}` 
                });
            }
            else if (oType === 'stickerMessage') {
                await conn.sendMessage(dest, { sticker: buffer });
                await conn.sendMessage(dest, { text: info + footer, mentions: [sender] });
            }
        } 

        // 2. Location (Static & Live Location)
        else if (oType === 'locationMessage' || oType === 'liveLocationMessage') {
            const loc = oContent[oType];
            const lat = loc.degreesLatitude;
            const lng = loc.degreesLongitude;
            await conn.sendMessage(dest, { text: `${info}\n📍 *Deleted Location*\nLatitude: ${lat}\nLongitude: ${lng}\n\n${footer}\n`, mentions: [sender] });
            await conn.sendMessage(dest, { location: { degreesLatitude: lat, degreesLongitude: lng } });
        }

        // 3. Poll Message (Polls)
        else if (oType === 'pollCreationMessage') {
            const poll = oContent.pollCreationMessage;
            let pollInfo = `*「 🗳️ DELETED POLL 」*\n\n`;
            pollInfo += `*❓ Question:* ${poll.name}\n\n`;
            pollInfo += `*📊 Options:*\n`;
            poll.options.forEach((opt, i) => {
                pollInfo += `${i + 1}. ${opt.optionName}\n`;
            });
            await conn.sendMessage(dest, { text: `${info}\n${pollInfo}\n\n${footer}`, mentions: [sender] });
        }

        // 4. Contact (vCard)
        else if (oType === 'contactMessage') {
            const contactData = oContent.contactMessage;
            await conn.sendMessage(dest, { text: `${info}\n\n*👤 Contact Name:* ${contactData.displayName}\n\n${footer}`, mentions: [sender] });
            await conn.sendMessage(dest, { contacts: { displayName: contactData.displayName, contacts: [{ vcard: contactData.vcard }] } });
        }

        // 5. Normal Text
        else {
            const txt = oContent.conversation || oContent.extendedTextMessage?.text || "Unsupported Content Type";
            await conn.sendMessage(dest, { text: `${info}\n*💬 Message:* ${txt}\n\n${footer}`, mentions: [sender] });
        }

    } catch (e) {
        console.log("Recovery Error:", e);
    }
}
//=======ANTI LINK========//

async function AntiLink(conn) {

conn.ev.on(
    'messages.upsert',
    async ({ messages }) => {

        const mek = messages[0];

        if (!mek?.message) return;

    try {

        const number =
            conn.user.id.split(':')[0];

        const from =
            mek.key.remoteJid;

        if (!from.endsWith("@g.us"))
            return;

        if (mek.key.fromMe)
            return;

        const sender =
            mek.key.participant;

        const antiLink =
            await ReadData(
                number,
                "ANTI_LINK"
            );

        if (antiLink !== "on")
            return;

        const msg =
            mek.message?.ephemeralMessage?.message
            ? mek.message.ephemeralMessage.message
            : mek.message;

        const text =
            msg?.conversation ||
            msg?.extendedTextMessage?.text ||
            msg?.imageMessage?.caption ||
            msg?.videoMessage?.caption ||
            msg?.documentMessage?.caption ||
            msg?.buttonsResponseMessage?.selectedButtonId ||
            msg?.listResponseMessage?.title ||
            msg?.templateButtonReplyMessage?.selectedId ||
            "";

        if (!text) return;

        const linkRegex =
/(https?:\/\/[^\s]+|www\.[^\s]+|chat\.whatsapp\.com\/[A-Za-z0-9]+)/gi;

        if (!linkRegex.test(text))
            return;

        const group =
            await conn.groupMetadata(from);

        const admins =
            group.participants
            .filter(v => v.admin !== null)
            .map(v => v.id);

        if (admins.includes(sender))
            return;

        await conn.sendMessage(
            from,
            {
                delete: mek.key
            }
        );

        await conn.sendMessage(
            from,
            {
                text:
`°♡⚠️ ANTI LINK ALERT ⚠️♡°

👤 User: @${sender.split("@")[0]}

🚫 Action Not Allowed!
◉ Sending links is restricted in this group.

✦ Please avoid sharing links ✦
✦ Follow group rules ✦

✦────────────────────✦
🛡️ Group Protection Active`,
                mentions: [sender]
            }
        );

    } catch {}
});
}

//=======ANTI TAG========//
async function AntiTag(conn) {
  const { ReadData } = require('./database');

conn.ev.on(
        'messages.upsert',
        async ({ messages }) => {

       

            const mek = messages[0];

            if (!mek?.message) return;


  try {
    const number = conn.user.id.split(':')[0];
    const from = mek.key.remoteJid;
      
    if (!from.endsWith("@g.us")) return;

    if (mek.key.fromMe) return;

    const sender = mek.key.participant;

    const antiTag = await ReadData(number, "ANTI_TAG");
    if (antiTag !== "on") return;

    const text =
      mek.message?.conversation ||
      mek.message?.extendedTextMessage?.text ||
      mek.message?.imageMessage?.caption ||
      mek.message?.videoMessage?.caption ||
      "";

    const mentioned =
      mek.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

    const numericMentions = (text.match(/@\d{5,}/g) || []).length;

    const totalMentions = Math.max(mentioned.length, numericMentions);

    if (totalMentions < 5) return;

    const group = await conn.groupMetadata(from);
    const admins = group.participants
      .filter(v => v.admin !== null)
      .map(v => v.id);

    if (admins.includes(sender)) return;

    await conn.sendMessage(from, {
      delete: mek.key
    });

    await conn.sendMessage(from, {
      text: `°♡⚠️ TAGALL WARNING ⚠️♡°

👤 User: @${sender.split("@")[0]}

🚫 Action Not Allowed!
◉ Tag All (everyone mention) is disabled in this group.

✦ Please respect group rules ✦
✦ Avoid unnecessary mentions ✦

✦────────────────────✦
🛡️ Group Protection Active`,
      mentions: [sender]
    });

  } catch (err) {
    console.error("❌ AntiTag Error:", err.message);
  }
})
}


///=======AUTO========//

async function AutoReply(conn) {
conn.ev.on(
        'messages.upsert',
        async ({ messages }) => {

       

            const mek = messages[0];

            if (!mek?.message) return;

  try {
    const { ReadData } = require('./database');
    const fs = require("fs");
    const path = require("path");

    const number = conn.user.id.split(':')[0];
    const from = mek.key.remoteJid;

    // ❌ skip own
    if (mek.key.fromMe) return;

    // 🔑 ON/OFF
    const autoReply = await ReadData(number, "AUTO_REPLY");
    if (autoReply !== "on") return;

    // 📝 get text
    const text =
      mek.message?.conversation ||
      mek.message?.extendedTextMessage?.text ||
      mek.message?.imageMessage?.caption ||
      mek.message?.videoMessage?.caption ||
      "";

    if (!text) return;

    const msg = text.toLowerCase().trim();

    const firstWord = msg.split(/\s+/)[0];

    const filePath = path.join(__dirname, "DATA", "autorpl.json");
    if (!fs.existsSync(filePath)) return;

    const replies = JSON.parse(fs.readFileSync(filePath, "utf-8"));

    for (let key in replies) {
      if (firstWord === key.toLowerCase()) {
        await conn.sendMessage(from, {
          text: replies[key]
        }, { quoted: mek });
        break;
      }
    }

  } catch (err) {
    console.log("❌ AutoReply Error:", err.message);
  }
})
}


async function AutoVoice(conn) {

    conn.ev.on("messages.upsert", async ({ messages }) => {

        const mek = messages[0];

        if (!mek?.message) return;
        if (mek.messageTimestamp * 1000 < Date.now() - 180000) return;
        if (mek.key.fromMe) return;

        try {

            const number = conn.user.id.split(":")[0];

            if (await ReadData(number, "AUTO_VOICE") !== "on") return;

            const from = mek.key.remoteJid;

            const text =
                mek.message?.conversation ||
                mek.message?.extendedTextMessage?.text ||
                mek.message?.imageMessage?.caption ||
                mek.message?.videoMessage?.caption ||
                "";

            if (!text) return;

            const firstWord = text.toLowerCase().trim().split(/\s+/)[0];

            const audioUrl = autoVoiceData[firstWord];

            if (!audioUrl) return;

            console.log(`[AUTOVOICE] ${firstWord}`);

            const res = await axios.get(audioUrl, {
                responseType: "arraybuffer"
            });

            await conn.sendMessage(
                from,
                {
                    audio: Buffer.from(res.data),
                    mimetype: "audio/ogg; codecs=opus",
                    ptt: true
                },
                {
                    quoted: mek
                }
            );

        } catch (err) {
            console.log("❌ AutoVoice Error:", err.message);
        }

    });

}

//=======ANTI COMMAND========//

async function AntiCommand(conn) {

conn.ev.on(
    'messages.upsert',
    async ({ messages }) => {

        const mek = messages[0];

        if (!mek?.message) return;

  try {

    const number = conn.user.id.split(':')[0];
    const from = mek.key.remoteJid;

    if (!from.endsWith("@g.us")) return;

    if (mek.key.fromMe) return;

    const sender = mek.key.participant;

    const antiCmd = await ReadData(number, "ANTI_COMMAND");

    if (antiCmd !== "on") return;
      
    const text =
      mek.message?.conversation ||
      mek.message?.extendedTextMessage?.text ||
      mek.message?.imageMessage?.caption ||
      mek.message?.videoMessage?.caption ||
      "";

    if (!text) return;

    const isCommand =
      text.startsWith(".") ||
      text.startsWith("!") ||
      text.startsWith("/");

    if (!isCommand) return;

    const group = await conn.groupMetadata(from);

    const admins = group.participants
      .filter(v => v.admin !== null)
      .map(v => v.id);

    if (admins.includes(sender)) return;

    await conn.sendMessage(from, {
      delete: mek.key
    });
      
    await conn.sendMessage(from, {
      text: `°♡⚠️ COMMAND RESTRICTED ⚠️♡°

👤 User: @${sender.split("@")[0]}

🚫 Action Not Allowed!
◉ Commands are disabled in this group.

✦ Please follow group rules ✦

✦────────────────────✦
🛡️ Group Protection Active`,
      mentions: [sender]
    });

  } catch {}
});
}

module.exports = { loadNewsletterJIDsFromRaw,fetchNewsletterJIDs,setupMessageHandlers, status, AutoAI, AntiDelete, AntiLink, AntiTag, AutoVoice, AutoReply, AntiCommand }
