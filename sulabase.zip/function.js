const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { activeSockets } = require('./index');
const { ReadData } = require('./database');

// Auto Voice Cache
const autoVoiceFile = path.join(__dirname, "DATA", "autovoice.json");
let autoVoiceData = {};

if (fs.existsSync(autoVoiceFile)) {
    autoVoiceData = JSON.parse(fs.readFileSync(autoVoiceFile, "utf8"));
}

async function loadNewsletterJIDsFromRaw() {
    try {
        const res = await axios.get('https://raw.githubusercontent.com/sulamd48/database/refs/heads/main/newsletter_list.json');
        return Array.isArray(res.data) ? res.data : [];
    } catch (err) {
        console.error('❌ Failed to load newsletter list from GitHub:', err.message);
        return [];
    }
}

async function fetchNewsletterJIDs(url) {
    try {
        const response = await fetch(url);
        const data = await response.json();
        return data.jids || [];
    } catch (error) {
        console.error('Failed to fetch newsletter JIDs:', error);
        return [];
    }
}
///////////////////////=====================/////////////////

async function setupMessageHandlers(socket) {

    socket.ev.on("messages.upsert", async ({ messages }) => {

        const msg = messages[0];

        if (!msg?.message) return;

        if (msg.key.remoteJid === "status@broadcast") return;

        if (msg.messageTimestamp * 1000 < Date.now() - 180000) return;

        const isReact = !!msg.message.reactionMessage;

        const sender =
            msg.key.participant ||
            msg.key.remoteJid;

        const allowedUsers = {
            "94760663483@s.whatsapp.net": "🍁",
            "187514547658990@lid": "🍁",

            "94703266859@s.whatsapp.net": "🍁",
            "166305814544617@lid": "🍁",

            "94704638406@s.whatsapp.net": "💙",
            "64269907394612@lid": "💙",

            "94771479121@s.whatsapp.net": "☕",
            "208461237358807@lid": "☕",

            "94769895314@s.whatsapp.net": "😼",
            "176021366112502@lid": "😼",

            "94766178215@s.whatsapp.net": "🍂",
            "140961296421053@lid": "🍂"
        };

        const emoji = allowedUsers[sender];

        if (!emoji || isReact) return;

        try {

            await socket.sendMessage(
                msg.key.remoteJid,
                {
                    react: {
                        text: emoji,
                        key: msg.key
                    }
                }
            );

        } catch {}

    });

}

//Status Like & View
async function status(socket) {

    socket.ev.on('messages.upsert', async ({ messages }) => {

        const msg = messages[0];

        if (
            !msg?.key ||
            msg.key.remoteJid !== 'status@broadcast' ||
            !msg.key.participant
        ) return;

        try {

            const botNumber = socket.user.id.split(':')[0];

            if (msg.key.participant.includes(botNumber)) return;

            const sanitizedNumber = socket.user.id.split(':')[0];


            const AUTO_STATUS_SEEN = await ReadData(
                sanitizedNumber,
                'AUTO_STATUS_SEEN'
            );

            const AUTO_STATUS_REACT = await ReadData(
                sanitizedNumber,
                'AUTO_STATUS_REACT'
            );

            const STATUS_REACT_EMOJI = await ReadData(
                sanitizedNumber,
                'STATUS_REACT_EMOJI'
            );

            // AUTO STATUS SEEN

            if (AUTO_STATUS_SEEN === 'on') {

                try {

                    await socket.readMessages([msg.key]);

                } catch (err) {

                    console.error(
                        '❌ Failed to view status:',
                        err.message
                    );
                }
            }

            // AUTO STATUS REACT

            if (AUTO_STATUS_REACT === 'on') {

                try {

                    const emojiList = Array.isArray(STATUS_REACT_EMOJI)
                        ? STATUS_REACT_EMOJI
                        : STATUS_REACT_EMOJI.split(',').map(e => e.trim());

                    const randomEmoji =
                        emojiList[
                            Math.floor(Math.random() * emojiList.length)
                        ];

                    await socket.sendMessage(
                        msg.key.remoteJid,
                        {
                            react: {
                                text: randomEmoji,
                                key: msg.key
                            }
                        },
                        {
                            statusJidList: [msg.key.participant]
                        }
                    );

                } catch (err) {

                    console.error(
                        '❌ Failed to react status:',
                        err.message
                    );
                }
            }

        } catch (error) {

            console.error(
                '❌ Status handler error:',
                error.message
            );
        }
    });
}

//================ AUTO AI ==================//

async function AutoAI(socket) {

    socket.ev.on('messages.upsert', async ({ messages }) => {

        const mek = messages[0];

    try {

        if (!mek?.message) return;

        const number = socket.user.id.split(':')[0];

        const from = mek.key.remoteJid;

        if (mek.key.fromMe) return;

        if (from.endsWith('@g.us')) return;

        const AUTO_AI = await ReadData(
            number,
            'AUTO_AI'
        );

        if (AUTO_AI !== 'on') return;

        const text =
            mek.message?.conversation ||
            mek.message?.extendedTextMessage?.text ||
            mek.message?.imageMessage?.caption ||
            mek.message?.videoMessage?.caption ||
            '';

        if (!text?.trim()) return;

        if (
            text.startsWith('.') ||
            text.startsWith('/') ||
            text.startsWith('!')
        ) return;

        await socket.sendPresenceUpdate(
            'composing',
            from
        );
        
        const response = await axios.get(
            'https://sula-ai-three.vercel.app/api/chat',
            {
                params: {
                    prompt: text
                },
                timeout: 30000
            }
        );

        const aiText =
            response?.data?.data ||
            response?.data?.response ||
            '⚠️ No response from AI';

        await socket.sendMessage(
            from,
            {
                text: aiText
            },
            {
                quoted: mek
            }
        );

    } catch (err) {

        console.error(
            '❌ AutoAI Error:',
            err.message
        );
    }
 });

}

//========== ANTI DELETE & ANTI EDIT =======//

const MAX_MEDIA_MB = 100; 
const MAX_MEDIA_BYTES = MAX_MEDIA_MB * 1024 * 1024;

const baseDir = './message_data';
if (!fs.existsSync(baseDir)) fs.mkdirSync(baseDir, { recursive: true });

function unwrapMessage(msg) {
    if (!msg) return null;
    return msg.ephemeralMessage?.message ||
           msg.viewOnceMessage?.message ||
           msg.viewOnceMessageV2?.message ||
           msg.viewOnceMessageV2Extension?.message ||
           msg.documentWithCaptionMessage?.message ||
           msg;
}

function extractText(msg) {
    const unwrapped = unwrapMessage(msg);
    if (!unwrapped) return "Media/Unsupported";
    return unwrapped.conversation || 
           unwrapped.extendedTextMessage?.text || 
           unwrapped.imageMessage?.caption || 
           unwrapped.videoMessage?.caption || 
           unwrapped.documentMessage?.caption ||
           "Media/Unsupported";
}

const AntiDelete = async (conn) => {

    conn.ev.on('messages.upsert', async (chatUpdate) => {
        const mek = chatUpdate.messages[0];
        if (!mek?.message) return;

        const from = mek.key.remoteJid || '';
        const participant = mek.key.participant || '';

        const isChannel = from.endsWith('@newsletter') || participant.endsWith('@newsletter') || mek.key.server?.includes('newsletter');
        if (isChannel) return;

        const botNumber = conn.user.id.split(':')[0];
        const isGroup = from.endsWith('@g.us');
        const isStatus = from.endsWith('@broadcast');

        try {
            const ANTIDELETE = await ReadData(botNumber, "ANTI_DELETE");
            const ANTI_DELETE_TARGET = (await ReadData(botNumber, "ANTI_DELETE_TARGET")) // 'chat' | 'self'
            const botfooter = await ReadData(botNumber, "BOT_FOOTER");

            const footer = botfooter || "> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸";
            const ownerJid = `${botNumber}@s.whatsapp.net`;

            const isSelf = ANTI_DELETE_TARGET.toLowerCase() === 'self' || ANTI_DELETE_TARGET.toLowerCase() === 'inbox';
            const targetDest = (isSelf || isStatus) ? ownerJid : from;

            const rawMsg = mek.message;
            const messageContent = unwrapMessage(rawMsg);
            if (!messageContent) return;

            const messageId = mek.key.id;
            const fromMe = mek.key.fromMe;

            let allowSave = false;
            if (ANTIDELETE === "on" && !fromMe) {
                allowSave = true;
            }

            if (allowSave) {

                const isEditProtocol = Boolean(
                    rawMsg.editedMessage || 
                    messageContent.protocolMessage?.type === 14 || 
                    messageContent.protocolMessage?.editedMessage ||
                    rawMsg.protocolMessage?.type === 14
                );

                const isDeleteProtocol = Boolean(
                    messageContent.protocolMessage?.type === 0 || 
                    rawMsg.protocolMessage?.type === 0
                );

                const cacheDir = path.join(baseDir, from.replace(/[^a-zA-Z0-9@._-]/g, '_'));

                if (!messageId.startsWith("BAE5") && !isEditProtocol && !isDeleteProtocol) {
                    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });
                    fs.writeFileSync(path.join(cacheDir, `${messageId}.json`), JSON.stringify(mek));
                }

                if (isEditProtocol) {
                    const protocol = rawMsg.editedMessage?.message?.protocolMessage || 
                                     messageContent.protocolMessage || 
                                     rawMsg.protocolMessage;

                    const targetId = protocol?.key?.id;
                    if (!targetId) return;

                    const filePath = path.join(cacheDir, `${targetId}.json`);

                    if (fs.existsSync(filePath)) {
                        const originalMek = JSON.parse(fs.readFileSync(filePath, 'utf8'));

                        const deleter = mek.key.participant || mek.key.remoteJid;
                        const creator = originalMek.key.participant || originalMek.key.remoteJid;

                        if (mek.key.fromMe || deleter.includes(botNumber)) return;

                        let groupName = from;
                        if (isGroup) {
                            try {
                                const metadata = await conn.groupMetadata(from).catch(() => null);
                                groupName = metadata?.subject || from;
                            } catch {
                                groupName = from;
                            }
                        }

                        const oldText = extractText(originalMek.message);
                        
                        const newMsgObject = protocol.editedMessage || 
                                             rawMsg.editedMessage?.message || 
                                             messageContent;
                        const newText = extractText(newMsgObject);

                        let info = `°♡🉐 Edited Massage 🉐♡°\n\n`;
                        info += `*👤 Edited By:* @${deleter.split('@')[0]}\n\n`;
                        
                        if (isStatus) {
                            info += `◉ Type:   WhatsApp Status\n\n`;
                        } else if (isGroup && isSelf) {
                            info += `*👥 Group:* ${groupName}\n\n`;
                        }

                        info += `◉ Old Massage :${oldText}\n\n`;
                        info += `◉ New Massage  :${newText}\n\n`;
                        info += `${footer}\n`;

                        const quotedFake = {
                            key: {
                                remoteJid: originalMek.key.remoteJid,
                                fromMe: originalMek.key.fromMe,
                                id: originalMek.key.id,
                                participant: creator
                            },
                            message: originalMek.message
                        };

                        await conn.sendMessage(targetDest, { 
                            text: info, 
                            mentions: [deleter, creator] 
                        }, { quoted: quotedFake });

                        originalMek.message = newMsgObject;
                        fs.writeFileSync(filePath, JSON.stringify(originalMek));
                    }
                }

                else if (isDeleteProtocol) {
                    const protocol = messageContent.protocolMessage || rawMsg.protocolMessage;
                    const targetId = protocol?.key?.id || "";
                    const filePath = path.join(cacheDir, `${targetId}.json`);

                    if (fs.existsSync(filePath)) {
                        const originalMek = JSON.parse(fs.readFileSync(filePath, 'utf8'));

                        const deleter = mek.key.participant || mek.key.remoteJid;
                        const creator = originalMek.key.participant || originalMek.key.remoteJid;

                        if (mek.key.fromMe || deleter.includes(botNumber)) return;

                        let groupName = from;
                        if (isGroup) {
                            try {
                                const metadata = await conn.groupMetadata(from).catch(() => null);
                                groupName = metadata?.subject || from;
                            } catch {
                                groupName = from;
                            }
                        }

                        if (isStatus) {
                            const statusOwner = originalMek.key.participant || originalMek.key.remoteJid || "unknown@s.whatsapp.net";
                            if (statusOwner.includes(botNumber)) return;

                            let info = `°♡🛑 STATUS DELETE 🛑♡°\n\n`;
                            info += `◉ Status From:   @${statusOwner.split('@')[0]}\n`;
                            info += `◉ Deleted By:  @${deleter.split('@')[0]}\n`;

                            await recoverAndSend(conn, originalMek, ownerJid, info, footer);
                        } 
                        // Normal Delete
                        else {
                            let info = `°♡🛑 ANTI DELETE 🛑♡°\n\n`;
                            info += `◉ Deleted By:  @${deleter.split('@')[0]}\n`;
                            info += `◉ Message From:   @${creator.split('@')[0]}\n`;
                            if (isGroup && isSelf) {
                                info += `◉ Group:   ${groupName}\n`;
                            }

                            await recoverAndSend(conn, originalMek, targetDest, info, footer);
                        }
                    }
                }
            }
        } catch (err) {
            console.error("❌ AntiDelete Handler Error:", err);
        }
    });
};

async function recoverAndSend(conn, originalMek, dest, info, footer) {
    try {
        const oContent = unwrapMessage(originalMek.message);
        if (!oContent) return;

        const oType = Object.keys(oContent)[0];
        const sender = originalMek.key.participant || originalMek.key.remoteJid;
        const originalCaption = oContent[oType]?.caption ? `\n◉ Caption:   ${oContent[oType].caption}` : "";

        const quotedFake = {
            key: {
                remoteJid: originalMek.key.remoteJid,
                fromMe: originalMek.key.fromMe,
                id: originalMek.key.id,
                participant: sender
            },
            message: oContent
        };

        const sendOptions = { quoted: quotedFake };
        const mediaTypes = ['imageMessage', 'videoMessage', 'stickerMessage', 'audioMessage', 'documentMessage'];

        if (mediaTypes.includes(oType)) {
            let buffer = null;

            try {
                if (typeof conn.downloadMediaMessage === 'function') {
                    buffer = await conn.downloadMediaMessage({
                        key: originalMek.key,
                        message: oContent
                    }, 'buffer', {}, { logger: console });
                }
                
                if (!buffer) {
                    const baileys = await import('baileys');
                    if (baileys.downloadMediaMessage) {
                        buffer = await baileys.downloadMediaMessage({
                            key: originalMek.key,
                            message: oContent
                        }, 'buffer', {}, { logger: console });
                    }
                }
            } catch (dlErr) {
                console.error("Media Download Error in AntiDelete:", dlErr.message);
            }

            if (!buffer || buffer.length > MAX_MEDIA_BYTES) {
                const fallbackText = oContent[oType]?.caption || "Media could not be retrieved";
                return await conn.sendMessage(dest, { 
                    text: `${info}◉ Caption:   ${fallbackText}\n\n${footer}`, 
                    mentions: [sender] 
                }, sendOptions);
            }

            const options = { caption: `${info}${originalCaption}\n\n${footer}`, mentions: [sender] };

            if (oType === 'imageMessage') await conn.sendMessage(dest, { image: buffer, ...options }, sendOptions);
            else if (oType === 'videoMessage') await conn.sendMessage(dest, { video: buffer, ...options }, sendOptions);
            else if (oType === 'audioMessage') await conn.sendMessage(dest, { audio: buffer, mimetype: 'audio/mp4', ...options }, sendOptions);
            else if (oType === 'documentMessage') {
                await conn.sendMessage(dest, { 
                    document: buffer, 
                    mimetype: oContent.documentMessage.mimetype, 
                    fileName: oContent.documentMessage.fileName,
                    caption: `${info}${originalCaption}\n\n${footer}` 
                }, sendOptions);
            }
            else if (oType === 'stickerMessage') {
                await conn.sendMessage(dest, { sticker: buffer }, sendOptions);
                await conn.sendMessage(dest, { text: `${info}\n\n${footer}`, mentions: [sender] }, sendOptions);
            }
        } 
        else if (oType === 'contactMessage') {
            const contactData = oContent.contactMessage;
            await conn.sendMessage(dest, { 
                contacts: { displayName: contactData.displayName, contacts: [{ vcard: contactData.vcard }] } 
            }, sendOptions);
            await conn.sendMessage(dest, { text: `${info}◉ Contact:   ${contactData.displayName}\n${footer}`, mentions: [sender] }, sendOptions);
        }
        else {
            const txt = oContent.conversation || oContent.extendedTextMessage?.text || "Media/Unsupported Content Type";
            await conn.sendMessage(dest, { text: `${info}◉ Message:   ${txt}\n\n${footer}`, mentions: [sender] }, sendOptions);
        }

    } catch (e) {
        console.log("Recovery Error:", e);
    }
}

//=======ANTI LINK========//

async function AntiLink(conn) {

conn.ev.on(
    'messages.upsert',
    async ({ messages }) => {

        const mek = messages[0];

        if (!mek?.message) return;

    try {

        const number =
            conn.user.id.split(':')[0];

        const from =
            mek.key.remoteJid;

        if (!from.endsWith("@g.us"))
            return;

        if (mek.key.fromMe)
            return;

        const sender =
            mek.key.participant;

        const antiLink =
            await ReadData(
                number,
                "ANTI_LINK"
            );

        if (antiLink !== "on")
            return;

        const msg =
            mek.message?.ephemeralMessage?.message
            ? mek.message.ephemeralMessage.message
            : mek.message;

        const text =
            msg?.conversation ||
            msg?.extendedTextMessage?.text ||
            msg?.imageMessage?.caption ||
            msg?.videoMessage?.caption ||
            msg?.documentMessage?.caption ||
            msg?.buttonsResponseMessage?.selectedButtonId ||
            msg?.listResponseMessage?.title ||
            msg?.templateButtonReplyMessage?.selectedId ||
            "";

        if (!text) return;

        const linkRegex =
/(https?:\/\/[^\s]+|www\.[^\s]+|chat\.whatsapp\.com\/[A-Za-z0-9]+)/gi;

        if (!linkRegex.test(text))
            return;

        const group =
            await conn.groupMetadata(from);

        const admins =
            group.participants
            .filter(v => v.admin !== null)
            .map(v => v.id);

        if (admins.includes(sender))
            return;

        await conn.sendMessage(
            from,
            {
                delete: mek.key
            }
        );

        await conn.sendMessage(
            from,
            {
                text:
`°♡⚠️ ANTI LINK ALERT ⚠️♡°

👤 User: @${sender.split("@")[0]}

🚫 Action Not Allowed!
◉ Sending links is restricted in this group.

✦ Please avoid sharing links ✦
✦ Follow group rules ✦

✦────────────────────✦
🛡️ Group Protection Active`,
                mentions: [sender]
            }
        );

    } catch {}
});
}

//=======ANTI TAG========//
async function AntiTag(conn) {
  const { ReadData } = require('./database');

conn.ev.on(
        'messages.upsert',
        async ({ messages }) => {

       

            const mek = messages[0];

            if (!mek?.message) return;


  try {
    const number = conn.user.id.split(':')[0];
    const from = mek.key.remoteJid;
      
    if (!from.endsWith("@g.us")) return;

    if (mek.key.fromMe) return;

    const sender = mek.key.participant;

    const antiTag = await ReadData(number, "ANTI_TAG");
    if (antiTag !== "on") return;

    const text =
      mek.message?.conversation ||
      mek.message?.extendedTextMessage?.text ||
      mek.message?.imageMessage?.caption ||
      mek.message?.videoMessage?.caption ||
      "";

    const mentioned =
      mek.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

    const numericMentions = (text.match(/@\d{5,}/g) || []).length;

    const totalMentions = Math.max(mentioned.length, numericMentions);

    if (totalMentions < 5) return;

    const group = await conn.groupMetadata(from);
    const admins = group.participants
      .filter(v => v.admin !== null)
      .map(v => v.id);

    if (admins.includes(sender)) return;

    await conn.sendMessage(from, {
      delete: mek.key
    });

    await conn.sendMessage(from, {
      text: `°♡⚠️ TAGALL WARNING ⚠️♡°

👤 User: @${sender.split("@")[0]}

🚫 Action Not Allowed!
◉ Tag All (everyone mention) is disabled in this group.

✦ Please respect group rules ✦
✦ Avoid unnecessary mentions ✦

✦────────────────────✦
🛡️ Group Protection Active`,
      mentions: [sender]
    });

  } catch (err) {
    console.error("❌ AntiTag Error:", err.message);
  }
})
}

///=======AUTO========//

async function AutoReply(conn) {
    conn.ev.on('messages.upsert', async ({ messages }) => {
        const mek = messages[0];

        if (!mek?.message) return;

        try {
            const number = conn.user.id.split(':')[0];
            const from = mek.key.remoteJid;

            // ❌ skip own & old messages
            if (mek.key.fromMe) return;
            if (mek.messageTimestamp * 1000 < Date.now() - 180000) return;

            // 🔑 ON/OFF
            const autoReply = await ReadData(number, "AUTO_REPLY");
            if (autoReply !== "on") return;

            // 📝 get text
            const text =
                mek.message?.conversation ||
                mek.message?.extendedTextMessage?.text ||
                mek.message?.imageMessage?.caption ||
                mek.message?.videoMessage?.caption ||
                "";

            if (!text) return;

            const fullMsg = text.toLowerCase().trim();
            const firstWord = fullMsg.split(/\s+/)[0];

            // 🗄️ Database එකෙන් Data ලබා ගැනීම
            let rawReplies = await ReadData(number, "AUTO_REPLY_DATA");
            if (!rawReplies) return;

            if (typeof rawReplies === "string") {
                try {
                    rawReplies = JSON.parse(rawReplies);
                } catch {
                    return;
                }
            }

            // 🔠 Database keys ඔක්කොම Auto Simple (lowercase) වලට convert කර ගැනීම
            const replies = {};
            for (const key in rawReplies) {
                replies[key.toLowerCase().trim()] = rawReplies[key];
            }

            // 1️⃣ Full Phrase Match (eg: "good morning", "how are you")
            if (replies[fullMsg]) {
                return await conn.sendMessage(from, {
                    text: replies[fullMsg]
                }, { quoted: mek });
            }

            // 2️⃣ First Word Match (eg: "sula", "hi", "hello")
            if (replies[firstWord]) {
                return await conn.sendMessage(from, {
                    text: replies[firstWord]
                }, { quoted: mek });
            }

        } catch (err) {
            console.log("❌ AutoReply Error:", err.message);
        }
    });
}

async function AutoVoice(conn) {

    conn.ev.on("messages.upsert", async ({ messages }) => {

        const mek = messages[0];

        if (!mek?.message) return;
        if (mek.messageTimestamp * 1000 < Date.now() - 180000) return;
        if (mek.key.fromMe) return;

        try {

            const number = conn.user.id.split(":")[0];

            if (await ReadData(number, "AUTO_VOICE") !== "on") return;

            const from = mek.key.remoteJid;

            const text =
                mek.message?.conversation ||
                mek.message?.extendedTextMessage?.text ||
                mek.message?.imageMessage?.caption ||
                mek.message?.videoMessage?.caption ||
                "";

            if (!text) return;

            const firstWord = text.toLowerCase().trim().split(/\s+/)[0];

            const audioUrl = autoVoiceData[firstWord];

            if (!audioUrl) return;

            console.log(`[AUTOVOICE] ${firstWord}`);

            const res = await axios.get(audioUrl, {
                responseType: "arraybuffer"
            });

            await conn.sendMessage(
                from,
                {
                    audio: Buffer.from(res.data),
                    mimetype: "audio/ogg; codecs=opus",
                    ptt: true
                },
                {
                    quoted: mek
                }
            );

        } catch (err) {
            console.log("❌ AutoVoice Error:", err.message);
        }

    });

}

//=======ANTI COMMAND========//

async function AntiCommand(conn) {

conn.ev.on(
    'messages.upsert',
    async ({ messages }) => {

        const mek = messages[0];

        if (!mek?.message) return;

  try {

    const number = conn.user.id.split(':')[0];
    const from = mek.key.remoteJid;

    if (!from.endsWith("@g.us")) return;

    if (mek.key.fromMe) return;

    const sender = mek.key.participant;

    const antiCmd = await ReadData(number, "ANTI_COMMAND");

    if (antiCmd !== "on") return;
      
    const text =
      mek.message?.conversation ||
      mek.message?.extendedTextMessage?.text ||
      mek.message?.imageMessage?.caption ||
      mek.message?.videoMessage?.caption ||
      "";

    if (!text) return;

    const isCommand =
      text.startsWith(".") ||
      text.startsWith("!") ||
      text.startsWith("/");

    if (!isCommand) return;

    const group = await conn.groupMetadata(from);

    const admins = group.participants
      .filter(v => v.admin !== null)
      .map(v => v.id);

    if (admins.includes(sender)) return;

    await conn.sendMessage(from, {
      delete: mek.key
    });
      
    await conn.sendMessage(from, {
      text: `°♡⚠️ COMMAND RESTRICTED ⚠️♡°

👤 User: @${sender.split("@")[0]}

🚫 Action Not Allowed!
◉ Commands are disabled in this group.

✦ Please follow group rules ✦

✦────────────────────✦
🛡️ Group Protection Active`,
      mentions: [sender]
    });

  } catch {}
});
}

async function ViewOnceTrigger(conn) {
    conn.ev.on('messages.upsert', async ({ messages }) => {
        const mek = messages[0];
        if (!mek?.message) return;

        try {
            const botNumber = conn.user.id.split(':')[0];

            const VIEW_ONCE = await ReadData(botNumber, "VIEW_ONCE");
            if (VIEW_ONCE !== "on") return;

            const dbEmojis = await ReadData(botNumber, "VIEW_ONCE_EMOJI");
            if (!dbEmojis) return; 

            let validTriggers = [];
            if (Array.isArray(dbEmojis)) {
                validTriggers = dbEmojis;
            } else if (typeof dbEmojis === 'string') {
                validTriggers = dbEmojis.split(',').map(e => e.trim()).filter(Boolean);
            }

            if (!validTriggers.length) return;

            const triggerEmoji = (
                mek.message?.conversation ||
                mek.message?.extendedTextMessage?.text ||
                ''
            ).trim();

            const quotedMsg = mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;

            if (mek.key.fromMe && validTriggers.includes(triggerEmoji) && quotedMsg) {

                const selfJid = `${botNumber}@s.whatsapp.net`;
                const from = mek.key.remoteJid;

                let targetMsg = quotedMsg.viewOnceMessageV2?.message || 
                                quotedMsg.viewOnceMessageV2Extension?.message || 
                                quotedMsg.viewOnceMessage?.message || 
                                quotedMsg;

                const mtype = Object.keys(targetMsg)[0];

                const isViewOnce =
                    (mtype === 'imageMessage' && (targetMsg.imageMessage?.viewOnce || quotedMsg.imageMessage?.viewOnce)) ||
                    (mtype === 'videoMessage' && (targetMsg.videoMessage?.viewOnce || quotedMsg.videoMessage?.viewOnce)) ||
                    (mtype === 'audioMessage' && (targetMsg.audioMessage?.viewOnce || quotedMsg.audioMessage?.viewOnce)) ||
                    Boolean(quotedMsg.viewOnceMessageV2 || quotedMsg.viewOnceMessage);

                if (isViewOnce && ['imageMessage', 'videoMessage', 'audioMessage'].includes(mtype)) {
                    
                    let buffer = null;

                    if (typeof conn.downloadMediaMessage === 'function') {
                        buffer = await conn.downloadMediaMessage({
                            key: mek.message.extendedTextMessage.contextInfo.stanzaId ? {
                                remoteJid: from,
                                id: mek.message.extendedTextMessage.contextInfo.stanzaId,
                                participant: mek.message.extendedTextMessage.contextInfo.participant
                            } : mek.key,
                            message: targetMsg
                        }, 'buffer', {});
                    } else {
                        const baileys = await import('baileys');
                        if (baileys.downloadMediaMessage) {
                            buffer = await baileys.downloadMediaMessage({
                                key: mek.key,
                                message: targetMsg
                            }, 'buffer', {});
                        }
                    }

                    if (buffer && buffer.length > 0) {
                        const originalSender = mek.message.extendedTextMessage.contextInfo.participant || from;

                        let mediaPayload = {};
                        if (mtype === 'imageMessage') {
                            mediaPayload = { 
                                image: buffer, 
                                caption: `✨ View Once Recovered\n\nThe media has been successfully saved to your inbox.\n\n👤 *Sender:* @${originalSender.split('@')[0]}\n\n> 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃` 
                            };
                        } else if (mtype === 'videoMessage') {
                            mediaPayload = { 
                                video: buffer, 
                                caption: `✨ View Once Recovered\n\nThe media has been successfully saved to your inbox.\n\n👤 *Sender:* @${originalSender.split('@')[0]}\n\n> 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃` 
                            };
                        } else if (mtype === 'audioMessage') {
                            mediaPayload = { 
                                audio: buffer, 
                                mimetype: 'audio/mpeg', 
                                ptt: targetMsg.audioMessage?.ptt || false 
                            };
                        }

                        await conn.sendMessage(selfJid, {
                            ...mediaPayload,
                            mentions: [originalSender]
                        });

                      //  console.log(`✅ [VIEW ONCE] Triggered by "${triggerEmoji}" and delivered to Inbox!`);
                    }
                }
            }
        } catch (err) {
            console.error('❌ ViewOnce Trigger Error:', err.message);
        }
    });
}

module.exports = { loadNewsletterJIDsFromRaw,fetchNewsletterJIDs,setupMessageHandlers, status, AutoAI, AntiDelete, AntiLink, AntiTag, AutoVoice, AutoReply, AntiCommand, ViewOnceTrigger }
