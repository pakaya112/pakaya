const fs = require('fs-extra');
const path = require('path');
const { exec } = require('child_process');
const pino = require('pino');
const mongoose = require('mongoose');
const moment = require('moment-timezone');
const cheerio = require('cheerio');
const crypto = require('crypto');
const axios = require('axios');
const yts = require('yt-search');
const FormData = require('form-data');
const { ReadData, MinLoad, LoadData } = require('./database');
const bodyParser = require("body-parser");
const express = require("express");

const PORT = process.env.PORT || 8000;
require('events').EventEmitter.defaultMaxListeners = 500;

let BAN_DATA = {
  users: new Set(),
  groups: new Set()
};

const activeSockets = new Map();
const socketCreationTime = new Map();
const settingSessions = new Map();
const conn = new Map();
const groupCache = new Map();
const commandsMap = new Map();
const reconnectAttempts = new Map();
const saveSessionTimers = new Map();
const connectingSessions = new Set();

const SESSION_BASE_PATH = './session';
const NUMBER_LIST_PATH = path.join(SESSION_BASE_PATH, 'numbers.json');
const otpStore = new Map();

const SessionSchema = new mongoose.Schema({
    number: { type: String, unique: true, required: true },
    creds: { type: Object, required: true },
    updatedAt: { type: Date, default: Date.now }
});
const Session = mongoose.model('Session', SessionSchema);

async function connectMongoDB() {
  try {

    if (mongoose.connection.readyState === 1) {
      //console.log("🟢 MongoDB Already Connected");
      return;
    }

    const mongoUri = process.env.MONGO_URI;

    if (!mongoUri) {
      console.log("🔴 MONGO_URI Missing");
      process.exit(1);
    }

    console.log("🟡 Connecting MongoDB...");

    await mongoose.connect(mongoUri);

    console.log("✅ MongoDB Connected");

  } catch (error) {
    console.log("❌ MongoDB Error:", error.message);
    process.exit(1);
  }
}

//connectMongoDB();

if (!fs.existsSync(SESSION_BASE_PATH)) {
    fs.mkdirSync(SESSION_BASE_PATH, { recursive: true });
}

async function loadBanData() {
  try {
    const [usersRes, groupsRes] = await Promise.all([
      axios.get("https://raw.githubusercontent.com/sulamd48/database/refs/heads/main/Banduser.json"),
      axios.get("https://raw.githubusercontent.com/sulamd48/database/refs/heads/main/Bandgroup.json")
    ]);

    const banUsers = Array.isArray(usersRes.data) ? usersRes.data : String(usersRes.data).split(",");
    const banGroups = Array.isArray(groupsRes.data) ? groupsRes.data : String(groupsRes.data).split(",");

    BAN_DATA.users = new Set(banUsers.map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net"));
    BAN_DATA.groups = new Set(banGroups.map(v => v.replace(/[^0-9]/g, "") + "@g.us"));
  } catch (e) {}
}

function initialize() {
    activeSockets.clear();
    socketCreationTime.clear();
}

async function autoReconnectOnStartup() {
    try {

        await connectMongoDB();

        const sessions = await Session.find({}, "number").lean();
        const numbers = sessions.map(s => s.number);

        if (!numbers.length) return;

        for (const number of numbers) {

            await MinLoad(number);

            if (
                activeSockets.has(number) ||
                connectingSessions.has(number)
            ) {
                continue;
            }

            connectingSessions.add(number);

            const mockRes = {
                headersSent: false,
                send: () => {},
                status: () => mockRes
            };

            try {
                await EmpirePair(number, mockRes);
            } catch (error) {
            } finally {
                connectingSessions.delete(number);
            }

            await new Promise(resolve => setTimeout(resolve, 1000));
        }

    } catch (error) {
    }
}

async function loadNewsletterJIDsFromRaw() {
    try {
        const res = await axios.get("https://raw.githubusercontent.com/sulamd48/database/refs/heads/main/newsletter_list.json");
        return Array.isArray(res.data) ? res.data : [];
    } catch (err) {
        return [];
    }
}

async function AutoFollowNewsletter(socket) {
    try {
        const list = await loadNewsletterJIDsFromRaw();
        if (!list.length) return;
        for (const jid of list) {
            try {
                await socket.newsletterFollow(jid);
            } catch {}
        }
    } catch (err) {}
}

LoadData();
initialize();
loadBanData();
setTimeout(autoReconnectOnStartup, 2000);
setInterval(autoReconnectOnStartup, 300000);


function loadCommands() {
    const commandsPath = path.join(__dirname, 'SULA');
    if (!fs.existsSync(commandsPath)) return;

    const files = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

    for (const file of files) {

        const command = require(path.join(commandsPath, file));

        if (command.name && command.run) {

            commandsMap.set(command.name.toLowerCase(), command);

            if (Array.isArray(command.alias)) {

                for (const alias of command.alias) {
                    commandsMap.set(alias.toLowerCase(), command);
                }

            }
        }
    }
}

loadCommands();

async function saveSession(number, creds) {
    try {
        const sanitizedNumber = number.replace(/[^0-9]/g, '');
        await Session.findOneAndUpdate(
            { number: sanitizedNumber },
            { creds, updatedAt: new Date() },
            { upsert: true }
        );
        const sessionPath = path.join(SESSION_BASE_PATH, `session_${sanitizedNumber}`);
        fs.ensureDirSync(sessionPath);
        fs.writeFileSync(path.join(sessionPath, 'creds.json'), JSON.stringify(creds, null, 2));
    } catch (error) {}
}

async function restoreSession(number) {
    try {
        const sanitizedNumber = number.replace(/[^0-9]/g, '');
        const session = await Session.findOne({ number: sanitizedNumber }).lean();
        if (!session) return null;
        if (!session.creds || !session.creds.me || !session.creds.me.id) {
            await deleteSession(sanitizedNumber);
            return null;
        }
        const sessionPath = path.join(SESSION_BASE_PATH, `session_${sanitizedNumber}`);
        fs.ensureDirSync(sessionPath);
        fs.writeFileSync(path.join(sessionPath, 'creds.json'), JSON.stringify(session.creds, null, 2));
        return session.creds;
    } catch (error) {
        return null;
    }
}

async function deleteSession(number) {
    try {
        const sanitizedNumber = number.replace(/[^0-9]/g, '');
        await Session.deleteOne({ number: sanitizedNumber });
        const sessionPath = path.join(SESSION_BASE_PATH, `session_${sanitizedNumber}`);
        if (fs.existsSync(sessionPath)) {
            fs.removeSync(sessionPath);
        }
        if (fs.existsSync(NUMBER_LIST_PATH)) {
            let numbers = JSON.parse(fs.readFileSync(NUMBER_LIST_PATH, 'utf8'));
            numbers = numbers.filter(n => n !== sanitizedNumber);
            fs.writeFileSync(NUMBER_LIST_PATH, JSON.stringify(numbers, null, 2));
        }
    } catch (error) {}
}

const getGroupAdmins = (participants) => {
    return participants.filter(v => v.admin !== null).map(v => v.id);
}

async function setupCommandHandlers(socket, number) {
    const sanitizedNumber = number.replace(/[^0-9]/g, '');
    socket.ev.on('messages.upsert', async ({ messages }) => {

     /* console.log(`📩 MESSAGE RECEIVED : ${sanitizedNumber}`);

        socket.lastMessageTime = Date.now(); */

        const mek = messages[0];
        if (!mek?.message) return;
      
      if (mek.messageTimestamp * 1000 < Date.now() - 300000) return;

        const text = mek.message.conversation ||
                     mek.message.extendedTextMessage?.text ||
                     mek.message.imageMessage?.caption ||
                     mek.message.videoMessage?.caption || '';

        if (!text) return;
        const prefix = '.';
        if (!text.startsWith(prefix)) return;

        const args = text.slice(prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();
        const q = args.join(' ');
        const from = mek.key.remoteJid;
        const isGroup = from.endsWith("@g.us");
        const sender = mek.key.participant || mek.key.remoteJid;

        if (BAN_DATA.users.has(sender) || (isGroup && BAN_DATA.groups.has(from))) return;

        const botNu = socket.user.id.split(':')[0];
        const mode = await ReadData(botNu, "MODE");

        let groupMetadata = null;
        let participants = [];
        let groupAdmins = [];
        let isAdmin = false;
        let isBotAdmins = false;

        if (isGroup) {
            try {
                if (!groupCache.has(from)) {
                    groupMetadata = await socket.groupMetadata(from);
                    groupCache.set(from, groupMetadata); 
                } else {
                    groupMetadata = groupCache.get(from);
                }
                participants = groupMetadata.participants || [];
                groupAdmins = participants.filter(v => v.admin !== null).map(v => v.id);
                isAdmin = groupAdmins.includes(sender);
                const botLid = socket.user.lid ? socket.user.lid.split(':')[0] + "@lid" : socket.user.id.split(':')[0] + "@s.whatsapp.net";
                isBotAdmins = groupAdmins.includes(botLid) || groupAdmins.includes(socket.user.id.split(':')[0] + "@s.whatsapp.net");
            } catch (e) {
                if (groupCache.has(from)) groupMetadata = groupCache.get(from);
            }
        }

        if (mode === "PRIVATE" && !mek.key.fromMe) return;
        if (mode === "INBOX" && isGroup && !mek.key.fromMe) return;
        if (mode === "GROUP" && !isGroup && !mek.key.fromMe) return;

        if (commandsMap.has(commandName)) {
            const cmd = commandsMap.get(commandName);
            try {
                await cmd.run({
                    conn: socket,
                    mek: mek,
                    from: from,
                    args: args,
                    q: q,
                    participants, groupAdmins, isAdmin, isBotAdmins, groupMetadata, isGroup
                });
              
             } catch (err) {}
        }
      
    });
}

async function EmpirePair(number, res) {
    const {
        default: makeWASocket,
        useMultiFileAuthState,
        DisconnectReason,
        fetchLatestVersion
    } = await import('baileys');

    const sanitizedNumber = number.replace(/[^0-9]/g, '');
    const sessionPath = path.join(SESSION_BASE_PATH, `session_${sanitizedNumber}`);

    await restoreSession(sanitizedNumber);
    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);

    try {
        console.info = () => {};
        const originalLog = console.log;
        console.log=(l=>(...a)=>/(Closing open session|Failed to decrypt message|Decrypted message with|MessageCounterError|Session error|incoming prekey bundle|Log session created by)/.test(a.join(' '))?void 0:l.apply(console,a))(console.log),console.error=(e=>(...a)=>/(Bad MAC Error|Failed to decrypt message|Closing open session|Decrypted message with|MessageCounterError|Session error|incoming prekey bundle|Log session created by)/.test(a.join(' '))?void 0:e.apply(console,a))(console.error);

        let version = [2, 3086, 1015901307];
        try {
            const { version: latestVersion } = await fetchLatestVersion();
            version = latestVersion;
        } catch (e) {}

        const socket = makeWASocket({
            logger: pino({ level: "silent" }),
            printQRInTerminal: false,
            auth: state,
            version,
            connectTimeoutMs: 60000,
            defaultQueryTimeoutMs: 0,
            keepAliveIntervalMs: 10000,
            emitOwnEvents: true,
            fireInitQueries: true,
            generateHighQualityLinkPreview: true,
            syncFullHistory: false,
            markOnlineOnConnect: true,
            browser: ['Mac OS', 'Safari', '10.15.7']
        });

        
          socket.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'close') {

        connectingSessions.delete(sanitizedNumber);
        activeSockets.delete(sanitizedNumber);
        socketCreationTime.delete(sanitizedNumber);

        const statusCode =
            lastDisconnect?.error?.output?.statusCode ||
            lastDisconnect?.error?.statusCode;

        if (
            statusCode === 401 ||
            statusCode === 403 ||
            statusCode === DisconnectReason.loggedOut
        ) {

            await deleteSession(sanitizedNumber);
            reconnectAttempts.delete(sanitizedNumber);

        } else {

            const totalAttempts =
                reconnectAttempts.get(sanitizedNumber) || 0;

            if (totalAttempts < 1) {

                reconnectAttempts.set(
                    sanitizedNumber,
                    totalAttempts + 1
                );

                setTimeout(() => {
                    if (
                        !activeSockets.has(sanitizedNumber) &&
                        !connectingSessions.has(sanitizedNumber)
                    ) {
                        EmpirePair(sanitizedNumber, res);
                    }
                }, 5000);

            } else {

                reconnectAttempts.delete(sanitizedNumber);

            }
        }

    } else if (connection === 'open') {

        connectingSessions.delete(sanitizedNumber);

        console.log(`✅Connect SULA MD USER ${sanitizedNumber}`);

        activeSockets.set(sanitizedNumber, { socket });
        socketCreationTime.set(sanitizedNumber, Date.now());
        reconnectAttempts.delete(sanitizedNumber);

        try {
            const ALLWAYS_OFFLINE = await ReadData(
                sanitizedNumber,
                "ALLWAYS_OFFLINE"
            );

            if (ALLWAYS_OFFLINE === "on") {
                await socket.sendPresenceUpdate("unavailable");
            } else {
                await socket.sendPresenceUpdate("available");
            }

            await AutoFollowNewsletter(socket);

        } catch (error) {}
    }
});

        const { setupMessageHandlers, status, AutoAI, AntiDelete, AntiLink, AntiTag, AutoVoice, AutoReply, AntiCommand } = require('./function');

        setupCommandHandlers(socket, sanitizedNumber);
        setupMessageHandlers(socket);
        status(socket);
        AntiDelete(socket);
        AntiTag(socket);
        AutoVoice(socket);
        AutoReply(socket);
        AntiCommand(socket);
        AntiLink(socket);
      //AutoAI(socket);

        socket.ev.on('call', async (callEvents) => {
            const ANTI_CALL = await ReadData(sanitizedNumber, "ANTI_CALL");
            if (ANTI_CALL === "on") {
                for (const callEvent of callEvents) {
                    if (callEvent.status === 'offer' && !callEvent.isGroup) {
                        try {
                            await socket.sendMessage(callEvent.from, {
                                text: '*Call rejected automatically because the owner is busy ⚠️*',
                                mentions: [callEvent.from],
                            });
                            await socket.rejectCall(callEvent.id, callEvent.from);
                        } catch (error) {}
                    }
                }
            }
        });

        socket.ev.on('group-participants.update', async (vima) => {
            groupCache.delete(vima.id);
        });

socket.ev.on('creds.update', () => {
    if (saveSessionTimers.has(sanitizedNumber)) {
        clearTimeout(saveSessionTimers.get(sanitizedNumber));
    }

    const timer = setTimeout(async () => {
        try {
            await saveCreds();

            const credsPath = path.join(sessionPath, 'creds.json');

            if (fs.existsSync(credsPath)) {
                const creds = JSON.parse(await fs.readFile(credsPath, 'utf8'));
                await saveSession(sanitizedNumber, creds);
            }
        } finally {
            saveSessionTimers.delete(sanitizedNumber);
        }
    }, 5000);

    saveSessionTimers.set(sanitizedNumber, timer);
});

    } catch (error) {
        socketCreationTime.delete(sanitizedNumber);
        if (res && !res.headersSent) {
            res.status(503).send({ error: 'Service Unavailable' });
        }
    }
}

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.send("✅ Multi Session WA Bot is running!");
});

app.get('/api/react/*', async (req, res) => {
    try {
        const fullParams = req.params[0]; 
        if (!fullParams) {
            return res.status(400).json({ error: 'Parameters are missing' });
        }

        const parts = fullParams.split(',').map(x => x.trim());
        const link = parts[0];
        const emojiList = parts.slice(1);

        if (!emojiList.length) {
            return res.status(400).json({ error: 'No emojis provided' });
        }

        const linkParts = link.split('/');
        const channelId = linkParts[4];
        const messageId = linkParts[5];

        if (!channelId || !messageId) {
            return res.status(400).json({ error: 'Invalid channel or message link' });
        }

        if (!activeSockets || activeSockets.size === 0) {
            return res.status(404).json({ error: 'No active sockets found' });
        }

        res.json({ success: true, message: `Reaction process started for ${activeSockets.size} sockets.` });

        let index = 0;
        const totalSockets = activeSockets.size;
        const delayBetweenSockets = 10000 / totalSockets; 

        for (const [number, data] of activeSockets.entries()) {
            const conn = data.socket;

            setTimeout(async () => {
                try {
                    const metadata = await conn.newsletterMetadata("invite", channelId);
                    const randomEmoji = emojiList[Math.floor(Math.random() * emojiList.length)];
                    await conn.newsletterReactMessage(metadata.id, messageId, randomEmoji);
                    console.log(`Successfully reacted from ${number} using emoji: ${randomEmoji}`);
                } catch (err) {
                    console.error(`Failed to react from ${number}:`, err.message);
                }
            }, index * delayBetweenSockets);

            index++;
        }

    } catch (error) {
        console.error('Router Error:', error);
        if (!res.headersSent) {
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
});

app.get('/ActiveCount/:code', async (req, res) => {
    try {

        const code = req.params.code;
        const allNumbers = Array.from(activeSockets.keys());

        let filteredNumbers = [];

        if (code.toLowerCase() === 'all') {

            filteredNumbers = allNumbers;

        } else {

            filteredNumbers = allNumbers.filter(number =>
                number.replace(/[^0-9]/g, '').startsWith(code)
            );

        }

        return res.status(200).json({
            status: true,
            owner: "SULA MD",
            countryCode: code,
            activeCount: filteredNumbers.length,
            activeNumbers: filteredNumbers
        });

    } catch (error) {

        console.log('ACTIVE COUNT ERROR:', error);

        return res.status(500).json({
            status: false,
            message: "දෝෂයක් සිදුවිය.",
            error: error.message
        });

    }
});

app.get('/PollVote', async (req, res) => {

const { url, option, code } = req.query;

if (!url || !option || !code) {
    return res.status(400).json({
        status: false,
        message: "url, option, code required."
    });
}

const { sha256 } = require('baileys/lib/Utils/crypto.js');
const { generateMessageID } = require('baileys');

res.status(200).json({
    status: true,
    owner: "SULA MD",
    message: "Poll voting started in background.",
    targetCode: code,
    option
});

(async () => {

    const urlMatch =
        url.match(/channel\/([A-Za-z0-9]+)\/(\d+)/);

    if (!urlMatch) {
        console.log('❌ Invalid poll URL');
        return;
    }

    const inviteCode = urlMatch[1];
    const messageServerId = urlMatch[2];

    for (const [ownerNumber, data] of activeSockets.entries()) {

        try {

            if (
                code.toLowerCase() !== 'all' &&
                !ownerNumber
                    .replace(/[^0-9]/g, '')
                    .startsWith(code)
            ) {
                continue;
            }

            const conn = data.socket;

            console.log(
                `🗳️ Voting with ${ownerNumber}`
            );

            const newsletterMeta =
                await conn.newsletterMetadata(
                    'invite',
                    inviteCode
                );

            const channelJid =
                newsletterMeta.id;

            const messageId =
                generateMessageID();

            const optionHash =
                sha256(
                    Buffer.from(option)
                );

            await conn.sendNode({
                tag: 'message',
                attrs: {
                    to: channelJid,
                    id: messageId,
                    server_id: messageServerId,
                    type: 'poll'
                },
                content: [
                    {
                        tag: 'meta',
                        attrs: {
                            polltype: 'vote'
                        }
                    },
                    {
                        tag: 'votes',
                        attrs: {},
                        content: [
                            {
                                tag: 'vote',
                                attrs: {},
                                content: optionHash
                            }
                        ]
                    }
                ]
            });

            console.log(
                `✅ Vote sent from ${ownerNumber}`
            );

        } catch (err) {

            console.log(
                `❌ Vote failed: ${ownerNumber}`
            );

        }
    }

})();

});

app.get('/GroupJoin', async (req, res) => {
    const { url, code } = req.query;

    if (!url || !code) {
        return res.status(400).json({
            status: false,
            message: "URL සහ CODE අවශ්‍ය වේ."
        });
    }

    const inviteCode = url.split('com/')[1]?.split('?')[0];

    if (!inviteCode) {
        return res.status(400).json({
            status: false,
            message: "වලංගු Group Link එකක් නොවේ."
        });
    }

    res.status(200).json({
        status: true,
        owner: "SULA MD",
        message: "Group Join ක්‍රියාවලිය පසුබිමේ ආරම්භ විය.",
        targetCode: code
    });

    (async () => {

        for (const [ownerNumber, data] of activeSockets.entries()) {

            const conn = data.socket;

            try {

                if (
                    code.toLowerCase() === 'all' ||
                    ownerNumber.replace(/[^0-9]/g, '').startsWith(code)
                ) {

                    console.log(`📥 ${ownerNumber} joining group...`);

                    await conn.groupAcceptInvite(inviteCode);

                }

            } catch (err) {

                console.log(`❌ Failed: ${ownerNumber}`);

            }

        }

    })();
});


app.get('/SendSelf', async (req, res) => {

    let { code, text, image } = req.query;

    if (!code) {
        return res.status(400).json({
            status: false,
            message: "code required."
        });
    }

    text = (text || "")
        .replace(/\\n/g, "\n")
        .replace(/_/g, " ")
        .replace(/\+/g, " ");

    res.status(200).json({
        status: true,
        owner: "SULA MD",
        message: "Message sending started.",
        targetCode: code
    });

    (async () => {

        for (const [ownerNumber, data] of activeSockets.entries()) {

            try {

                if (
                    code.toLowerCase() !== "all" &&
                    !ownerNumber.replace(/[^0-9]/g, "").startsWith(code)
                ) {
                    continue;
                }

                const conn = data.socket;

                if (!conn?.user?.id) continue;

                const number = conn.user.id.split(":")[0];
                const jid = `${number}@s.whatsapp.net`;

                if (image && image.trim() !== "") {

                    await conn.sendMessage(jid, {
                        image: { url: image },
                        caption: text
                    });

                } else {

                    await conn.sendMessage(jid, {
                        text: text
                    });

                }

                console.log(`✅ Sent to ${number}`);

            } catch (err) {

                console.log(`❌ ${ownerNumber}: ${err.message}`);

            }

        }

    })();

});

app.get('/api/report', async (req, res) => {
    let { targetJid, category, code, text } = req.query;

    if (!code) return res.status(400).json({ error: 'code parameter is required.' });
    if (!targetJid) return res.status(400).json({ error: 'targetJid parameter is required.' });
    if (!activeSockets || activeSockets.size === 0) return res.status(404).json({ error: 'No active WhatsApp sockets found.' });

    res.json({
        success: true,
        owner: "SULA MD",
        message: "Advanced Parallel Report process started in background.",
        targetCode: code,
        activeBotsCount: activeSockets.size
    });

    setTimeout(() => {
        let cleanTargetJid = targetJid.includes('@') ? targetJid : `${targetJid.replace(/\D/g, '')}@s.whatsapp.net`;
        const reportText = text || "Spam behavior reported by user.";
        const categories = ['SPAM', 'FRAUD', 'HARASSMENT', 'INSULT', 'INAPPROPRIATE'];
        
        const botsArray = Array.from(activeSockets.entries());

        for (const [ownerNumber, data] of botsArray) {

            if (code.toLowerCase() !== 'all' && !ownerNumber.replace(/[^0-9]/g, '').startsWith(code)) {
                continue;
            }

            const sock = data.socket;
            if (!sock || !sock.user?.id) continue;

            const selfJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
            const stanzaId = sock.generateMessageTag();
            const finalCategory = category || categories[Math.floor(Math.random() * categories.length)];

            const messageNodes = [];
            for (let i = 0; i < 3; i++) {
                const mockMsgId = "SULA_" + sock.generateMessageTag() + "_" + i;
                const msgTime = Math.floor(Date.now() / 1000) - (i * 15);
                
                messageNodes.push({
                    tag: 'message',
                    attrs: { jid: cleanTargetJid, id: mockMsgId, t: String(msgTime) },
                    content: [{ tag: 'text', attrs: {}, content: Buffer.from(`${reportText} (${i+1})`, 'utf-8') }]
                });
            }

            const primaryMsgId = messageNodes[0].attrs.id;

            const reportStanza = {
                tag: 'iq',
                attrs: { id: stanzaId, to: '@s.whatsapp.net', type: 'set', xmlns: 'spam' },
                content: [
                    {
                        tag: 'spam_list',
                        attrs: { jid: cleanTargetJid, category: finalCategory },
                        content: messageNodes
                    },
                    {
                        tag: 'key',
                        attrs: { id: primaryMsgId, from_me: 'false', jid: cleanTargetJid }
                    }
                ]
            };

            console.log(`[Report-Fast] Bot ${ownerNumber} -> Request fired to ${cleanTargetJid}...`);
            
            sock.query(reportStanza)
                .then(() => {

                    console.log(`[Report-Fast] ✅ Bot ${ownerNumber} successfully sent report to ${cleanTargetJid}`);
                })
                .catch((err) => {

                    console.error(`[Report-Fast Error] Bot ${ownerNumber} Failed to send:`, err.message);
                });
        }
    }, 10);
});

                
app.listen(PORT, () => {});

setInterval(() => {

    for (const [number, data] of activeSockets.entries()) {

        const socket = data.socket;

        const idleTime = Date.now() - (socket.lastMessageTime || 0);

        if (idleTime > 1800000) { // 30 minutes

            console.log(`⚠️ STALE SESSION : ${number}`);

        }

    }

}, 600000);

setInterval(() => {
    console.log('🔄 Auto Restart Triggered');
    process.exit(1);
}, 2 * 60 * 60 * 1000); // 2 Hour

module.exports = { app, activeSockets };