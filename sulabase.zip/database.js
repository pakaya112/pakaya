const { MongoClient } = require('mongodb');
const fs = require('fs');
const path = require('path');

const client = new MongoClient('mongodb+srv://sulasetting:Sulast01@cluster0.ycxpa8f.mongodb.net/minisula', { maxPoolSize: 4, serverSelectionTimeoutMS: 50000 });

const passClient = new MongoClient('mongodb+srv://sulaofc-web:sulaofcweb0112@cluster0.zzx21xb.mongodb.net/minisula', { maxPoolSize: 4, serverSelectionTimeoutMS: 50000 });

async function MinLoad() {

    await client.connect();
    const folderPath = path.join(process.cwd(), 'SETTINGS');
    const tempFilePath = path.join(folderPath, 'temp.json');

    try {
        if (!fs.existsSync(folderPath)) {
            fs.mkdirSync(folderPath, { recursive: true });
        }

        const appId = process.env.APP_ID || '';
        const collectionName = `SULAAPP${appId}`; 

        const database = client.db("minisula");
        const collection = database.collection(collectionName);

        const allDocs = await collection.find({}).toArray();

        fs.writeFileSync(tempFilePath, JSON.stringify(allDocs, null, 2), 'utf-8');

    } catch (err) {
        console.error("[❌] Mongo Fetch Error (MinLoad):", err.message);
        return;
    } finally {

        try {
            await client.close();
        } catch (closeErr) {
            console.error("[❌] Mongo Close Error:", closeErr.message);
        }
    }

    try {
        if (!fs.existsSync(tempFilePath)) return;

        const rawTemp = fs.readFileSync(tempFilePath, 'utf-8');
        const docs = JSON.parse(rawTemp);

        for (const doc of docs) {
            const docNumber = doc.id || doc.number;
            if (!docNumber) continue;

            const targetFilePath = path.join(folderPath, `${docNumber}.json`);

            let existingData = {};
            if (fs.existsSync(targetFilePath)) {
                try {
                    const rawData = fs.readFileSync(targetFilePath, 'utf-8');
                    existingData = JSON.parse(rawData);
                } catch {}
            }

            const updatedData = { ...existingData, ...doc };
            fs.writeFileSync(targetFilePath, JSON.stringify(updatedData, null, 2), 'utf-8');
        }

    } catch (err) {
        console.error("[❌] File Sync Error (MinLoad):", err.message);
    } finally {
        if (fs.existsSync(tempFilePath)) {
            try {
                fs.unlinkSync(tempFilePath);
            } catch (unlinkErr) {
                console.error("[❌] Temp File Delete Error:", unlinkErr.message);
            }
        }
    }
}


async function ReadData(number, key) {
    const fsp = require('fs').promises;
    const path = require('path');

    const defaultSettings = {
        "ANTI_CALL": "off",
        "AUTO_STATUS_SEEN": "on",
        "AUTO_STATUS_REACT": "on",
        "AUTO_AI": "off",
        "MODE": "PUBLIC",
        "ANTI_DELETE": "off",
        "AUTO_REPLY": "off",
        "AUTO_VOICE": "off",
        "ANTI_LINK": "off",
        "ANTI_TAG": "off",
        "ANTI_COMMAND": "off",
        "ALLWAYS_OFFLINE": "off",
        "BOT_NAME": "𝐒𝚄𝙻𝙰 𝐌𝙳 𝐌𝙸𝙽𝙸",
        "BOT_FOOTER": "> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃",
        "ANTI_DELETE_TARGET": "chat",
        "VIEW_ONCE": "on",
        "VIEW_ONCE_EMOJI": "🙃,❤️,😁,😂,👍,😘",
        "STATUS_REACT_EMOJI": "😁,💞,😍,😚,💕,💐,💫,💋,🍓",
        "AUTO_REACT_EMOJI": "😶,💋,🤤,🤣,🥹,♥️,😁,🙃,🍓,🤭,👻,🩷,😉,💦,👀",
        "SULA_IMAGE_PATH": "https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg",
        "CUSTOM_CAPTION": `📃 ᴛɪᴛʟᴇ : {title} \n\n▌│█║▌║▌║ 🎧 ║▌║▌║█│▌\n\n⏱️ ᴅᴜʀᴀᴛɪᴏɴ : {time}\n\n.ılılılllıılıll ⟲ ılılıllllıılıll ⟲ ılılılllıll\n\n🎧 Use headphones for best experience… 😌\n\n⏳ 00:00 ▷▶▷ ━━━⊚━━━ ◁◀◁ {time}\n\n🎶 “Feel it… don’t just listen.” 🫀✨\n\n━━━━━━━━━━━━━━━━━━\n\n❤️  ʀᴇᴀᴄᴛ  •••    ⤓  sᴀᴠᴇ  •••    ⤴  sʜᴀʀᴇ\n\n─── ↻ ◁ ❚❚ ▷ ↺ ───\n\n> {channel}`,
        "AUTO_REPLY_DATA": {
                    "hi": "heyy babe 🙂 i was just thinking about you",
                    "hello": "hello my love 💞 how are you feeling now",
                    "good morning": "good morning baby ☀️ did you sleep well",
                    "good night": "good night sweetheart 🌙 think about me before you sleep",
                    "bye": "okay go... but come back to me soon 🥺"
        }
    };

    try {
        const filePath = path.join(process.cwd(), 'SETTINGS', `${number}.json`);
        let settings = {};

        try {
            await fsp.access(filePath);
            const fileData = await fsp.readFile(filePath, 'utf-8');
            settings = JSON.parse(fileData);
        } catch {}

        const value = settings[key];
        if (value !== undefined && value !== null && value !== "") {
            return value;
        }

        return defaultSettings[key] !== undefined ? defaultSettings[key] : null;
    } catch (err) {
        console.error("[❌] Read Setting Error:", err.message);
        return defaultSettings[key] !== undefined ? defaultSettings[key] : null;
    }
}

module.exports = { ReadData, MinLoad, client, passClient };
