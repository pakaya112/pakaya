const { MongoClient } = require('mongodb');
const fs = require('fs');
const path = require('path');

// MongoDB Connection URL
const url = "mongodb+srv://sulasetting:Sulast01@cluster0.ycxpa8f.mongodb.net/?appName=Cluster0";
const client = new MongoClient(url);


async function MinLoad(number) {
    try {
        await client.connect();

        const database = client.db("minisula");
        const collection = database.collection("settings");

        const query = { id: number };
        const result = await collection.findOne(query);

        if (!result) {
            return;
        }

        const folderPath = path.join(process.cwd(), 'SETTINGS');
        if (!fs.existsSync(folderPath)) {
            fs.mkdirSync(folderPath, { recursive: true });
        }

        const filePath = path.join(folderPath, `${number}.json`);

        let existingData = {};
        if (fs.existsSync(filePath)) {
            const rawData = fs.readFileSync(filePath, 'utf-8');
            existingData = JSON.parse(rawData);
        }

        // merge old data with new values (update only keys that exist in Mongo)
        const updatedData = { ...existingData, ...result };

        fs.writeFileSync(filePath, JSON.stringify(updatedData, null, 2), 'utf-8');

    } catch (err) {
        console.error("[❌] Mongo Sync Error:", err.message);
    } finally {
        await client.close();
    }
}


async function LoadData(number) {
    try {
        
        await client.connect();
       
        const database = client.db("minisula");
        const collection = database.collection("settings");

       
        const query = { id: number };
        const result = await collection.findOne(query);

        if (!result) {
          //  console.log(`[!] No settings found for: ${number}`);
            return;
        }

        
        const folderPath = path.join(process.cwd(), 'SETTINGS');
        if (!fs.existsSync(folderPath)) {
            fs.mkdirSync(folderPath, { recursive: true });
        }

        
        const filePath = path.join(folderPath, `${number}.json`);
        
       
        fs.writeFileSync(filePath, JSON.stringify(result, null, 2), 'utf-8');

       // console.log(`[✅] Settings updated for ${number} in SETTINGS/${number}.json`);

    } catch (err) {
        console.error("[❌] Mongo Sync Error:", err.message);
    } finally {
        await client.close();
    }
}




async function ReadData(number, key) {
    const fs = require('fs').promises;
    const path = require('path');

    
    const defaultSettings = {
        "ANTI_CALL": "off",
        "AUTO_STATUS_SEEN": "on",
        "AUTO_STATUS_REACT": "on",
        "AUTO_AI": "off",
        "AUTO_TYPING": "off",
        "MODE": "PUBLIC",
        "AUTO_RECORDING": "off",
        "AUTO_REACT": "off",
        "ANTI_DELETE": "off",
        "AUTO_REPLY": "off",
        "AUTO_VOICE": "off",
        "ANTI_LINK": "off",
        "ANTI_TAG": "ofg",
        "ANTI_COMMAND": "off",
        "ALLWAYS_OFFLINE": "off",
        "BOT_NAME": "𝐒𝚄𝙻𝙰 𝐌𝙳 𝐌𝙸𝙽𝙸",
        "BOT_FOOTER": "> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃",
        "STATUS_REACT_EMOJI": "😁,💞,😍,😚,💕,💐,💫,💋,🍓",
        "AUTO_REACT_EMOJI": "😶,💋,🤤,🤣,🥹,♥️,😁,🙃,🍓,🤭,👻,🩷,😉,💦,👀",
        "SULA_IMAGE_PATH": "https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg",
        "CUSTOM_CAPTION": `📃 ᴛɪᴛʟᴇ : {title} 

▌│█║▌║▌║ 🎧 ║▌║▌║█│▌

⏱️ ᴅᴜʀᴀᴛɪᴏɴ : {time}

.ılılılllıılıll ⟲ ılılıllllıılıll ⟲ ılılılllıll

🎧 Use headphones for best experience… 😌

⏳ 00:00 ▷▶▷ ━━━⊚━━━ ◁◀◁ {time}

🎶 “Feel it… don’t just listen.” 🫀✨

━━━━━━━━━━━━━━━━━━

❤️  ʀᴇᴀᴄᴛ  •••    ⤓  sᴀᴠᴇ  •••    ⤴  sʜᴀʀᴇ

─── ↻ ◁ ❚❚ ▷ ↺ ───

> {channel}`
    };

    try {
        const filePath = path.join(process.cwd(), 'SETTINGS', `${number}.json`);
        let settings = {};

        try {
            await fs.access(filePath);
            const fileData = await fs.readFile(filePath, 'utf-8');
            settings = JSON.parse(fileData);
        } catch {
           
        }

        
        const value = settings[key];

        if (value !== undefined && value !== null && value !== "") {
            return value;
        }

       
        return defaultSettings[key] !== undefined ? defaultSettings[key] : null;

    } catch (err) {
        console.error("[❌] Read Setting Error:", err.message);
        
        return defaultSettings[key] !== undefined ? defaultSettings[key] : null;
    }
}


//////////=================/////

module.exports = { ReadData, LoadData, MinLoad }
