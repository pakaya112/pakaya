const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'ytsum',
    alias: ['ytsummary', 'youtubesummary', 'yts'],
    category: 'tools',
    description: 'Generates an AI-powered summary and key takeaways from any YouTube video URL.',

    run: async ({ conn, client, mek, from, q }) => {
        const botClient = conn || client;
        const number = (botClient.user?.id || '').split(':')[0];

        // 1. Fetch Dynamic Bot Configuration from Database
        let botname = '𝐒𝚄𝙻𝙰 𝐌𝙳 𝐌𝙸𝙽𝙸';
        let botfooter = '> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃';

        try {
            const dbBotName = await ReadData(number, 'BOT_NAME');
            if (dbBotName) botname = dbBotName;

            const dbBotFooter = await ReadData(number, 'BOT_FOOTER');
            if (dbBotFooter) botfooter = dbBotFooter;
        } catch (e) {
            console.warn('Database Read Error for bot branding:', e.message);
        }

        const API_KEY = 'freeApikey';

        try {
            // 2. Extract YouTube URL from arguments or quoted message
            let videoUrl = q ? q.trim() : '';

            const quotedText = mek.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation ||
                             mek.message?.extendedTextMessage?.contextInfo?.quotedMessage?.extendedTextMessage?.text || '';

            if (!videoUrl && quotedText) {
                const match = quotedText.match(/https?:\/\/(?:www\.)?(?:youtube\.com\/(?:watch\?v=|shorts\/|live\/)|youtu\.be\/)[\w-]+[^\s]*/i);
                if (match) videoUrl = match[0];
            }

            // 3. Validate URL
            const ytRegex = /^(https?:\/\/)?(www\.)?(youtube\.com\/(watch\?v=|shorts\/|live\/)|youtu\.be\/)[\w-]+/i;
            if (!videoUrl || !ytRegex.test(videoUrl)) {
                return botClient.sendMessage(from, {
                    text: `╭───────────♡◉◉◉♡───────────⌬
📌 *${botname} YOUTUBE SUMMARY*
╰───────────♡◉◉◉♡───────────⌬

❌ *Please provide a valid YouTube URL!*

*Usage:*
• \`.ytsum <youtube_url>\`
• Reply to a message with a YouTube link using \`.ytsum\`

*Example:*
\`.ytsum https://www.youtube.com/watch?v=qb4eDDUse4o\`

${botfooter}`
                }, { quoted: mek });
            }

            // 4. Send reaction & wait notice
            await botClient.sendMessage(from, { react: { text: '⏳', key: mek.key } });

            const waitNotice = `╭───────────♡◉◉◉♡───────────⌬
🎬 *${botname} AI ASSISTANT*
╰───────────♡◉◉◉♡───────────⌬

🔍 *Analyzing video transcript & generating key takeaways...*
⏳ *Please wait a moment.*

${botfooter}`;

            await botClient.sendMessage(from, { text: waitNotice }, { quoted: mek });

            // 5. Query YouTube Summary API
            const apiUrl = `https://anabot.my.id/api/tools/youtubeSummary?url=${encodeURIComponent(videoUrl)}&apikey=${API_KEY}`;
            const response = await axios.get(apiUrl, {
                headers: {
                    'accept': 'application/json'
                },
                timeout: 90000
            });

            if (!response.data || !response.data.success || !response.data.data?.result) {
                throw new Error(response.data?.message || 'Failed to extract transcript or generate summary from this video.');
            }

            const summaryResult = response.data.data.result.trim();

            // 6. Send Final Formatted Summary Result
            const resultCaption = `╭───────────♡◉◉◉♡───────────⌬
🎬 *${botname} VIDEO SUMMARY*
╰───────────♡◉◉◉♡───────────⌬

🔗 *Source:* ${videoUrl}

${summaryResult}

──────────────────────
${botfooter}`;

            await botClient.sendMessage(from, { text: resultCaption }, { quoted: mek });
            await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });

        } catch (err) {
            console.error('❌ [YouTube Summary Error]:', err.message);
            await botClient.sendMessage(from, { react: { text: '❌', key: mek.key } });

            let errorMsg = err.message;
            if (err.response?.data?.message) errorMsg = err.response.data.message;

            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
❌ *YOUTUBE SUMMARY FAILED*
╰───────────♡◉◉◉♡───────────⌬

📌 *Reason:* ${errorMsg}

💡 *Note:*
• Ensure the YouTube video has accessible captions/transcripts enabled.
• The video must be public.

${botfooter}`
            }, { quoted: mek });
        }
    }
};
