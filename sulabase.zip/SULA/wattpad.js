const axios = require('axios');
const { ReadData } = require('../database');

// Helper: API Call with Retry
async function apiCallWithRetry(url, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await axios.get(url, { timeout: 20000 });
            if (!response.data) throw new Error('API returned empty response');
            return response.data;
        } catch (error) {
            console.log(`[API ATTEMPT ${i + 1} FAILED] ${url} - ${error.message}`);
            if (i === retries - 1) throw error;
            await new Promise(res => setTimeout(res, 2000));
        }
    }
}

module.exports = {
    name: 'wattpad',
    alias: ['watt', 'wp'],
    category: 'downloads',
    description: 'Search and Download Wattpad Stories & PDFs',

    run: async ({ conn, mek, from, q, prefix }) => {
        try {
            // 🔒 1. OWNER ONLY CHECK (අවශ්‍ය නම් ඉවත් කරන්න)
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.

Want access to this feature?

Create your own bot:
🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || '𝐒𝚄𝙻𝙰 𝐌𝙳 𝐌𝙸𝙽𝙸';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃';

            if (!q || !q.trim()) {
                return await conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬
📚 *WATTPAD STORY SEARCH*
╰────♡◉◉◉♡────⌬

*Usage:*
➤ ${prefix || '.'}wattpad <story name / query>

*Example:*
➤ ${prefix || '.'}wattpad Romance
➤ ${prefix || '.'}wattpad Mafia

${botfooter}`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, { react: { text: '🔍', key: mek.key } });

            // 1. Search via Wattpad API
            const apiKey = "chama_api_c4352392c75ea7c9ef640b0c79d1d174";
            const searchApiUrl = `https://api.chamindu.site/api/v1/wattpad/search?q=${encodeURIComponent(q.trim())}&api_key=${apiKey}`;
            
            let searchData;
            try {
                searchData = await apiCallWithRetry(searchApiUrl, 3);
            } catch (err) {
                return await conn.sendMessage(from, { text: `❌ *Search API Error:* ${err.message}` }, { quoted: mek });
            }

            const rawResults = searchData?.data || [];

            if (!rawResults || rawResults.length === 0) {
                return await conn.sendMessage(from, { text: `❌ *No Wattpad stories found for:* ${q}` }, { quoted: mek });
            }

            const top = rawResults.slice(0, 5);
            const resultList = top.map((r, i) => `❰ ${i + 1} ❱ *${r.title}*\n   ✍️ Author: ${r.author} | ⭐ Votes: ${r.vote_count}`).join('\n\n');

            const caption = `╭────♡◉◉◉♡────⌬
📚 *${botname} | WATTPAD SEARCH*
╰────♡◉◉◉♡────⌬

🔍 *Query:* ${q}

${resultList}

───────────────
Reply: 1 - ${top.length}

${botfooter}`;

            const firstImage = top[0]?.cover;
            let sentMsg;
            if (firstImage) {
                sentMsg = await conn.sendMessage(from, { image: { url: firstImage }, caption }, { quoted: mek });
            } else {
                sentMsg = await conn.sendMessage(from, { text: caption }, { quoted: mek });
            }

            const searchMsgId = sentMsg.key.id;

            // 2. Story Selection Handler
            const searchHandler = async (msgUpdate) => {
                const reply = msgUpdate.messages[0];
                if (!reply?.message || !reply.key.fromMe) return;

                const isReply = reply.message?.extendedTextMessage?.contextInfo?.stanzaId === searchMsgId;
                if (!isReply) return;

                const replyText = (reply.message.conversation || reply.message.extendedTextMessage?.text || '').trim();
                const selNum = parseInt(replyText);

                if (isNaN(selNum) || selNum < 1 || selNum > top.length) {
                    return await conn.sendMessage(from, { text: `❌ *Invalid choice!* Reply between 1 and ${top.length}` }, { quoted: reply });
                }

                conn.ev.off('messages.upsert', searchHandler);
                const selected = top[selNum - 1];
                const storyUrl = selected.url;

                await conn.sendMessage(from, { react: { text: '⏳', key: reply.key } });

                // 3. Info API Call
                const infoApiUrl = `https://api.chamindu.site/api/v1/wattpad/info?url=${encodeURIComponent(storyUrl)}&api_key=${apiKey}`;
                let infoData;
                try {
                    infoData = await apiCallWithRetry(infoApiUrl, 3);
                } catch (err) {
                    return await conn.sendMessage(from, { text: `❌ *Failed to fetch story details!*` }, { quoted: reply });
                }

                const storyTitle = infoData.title || selected.title;
                const storyAuthor = infoData.author || selected.author;
                const partsCount = infoData.parts_count || selected.parts_count || 0;
                const reads = infoData.read_count || selected.read_count || 0;
                const votes = infoData.vote_count || selected.vote_count || 0;
                const completed = infoData.completed ? '✅ Completed' : '🔄 Ongoing';

                const infoCaption = `╭────♡◉◉◉♡────⌬
📖 *${botname} | STORY INFO*
╰────♡◉◉◉♡────⌬

📌 *Title:* ${storyTitle}
✍️ *Author:* ${storyAuthor}
📊 *Reads:* ${reads.toLocaleString()}
⭐ *Votes:* ${votes.toLocaleString()}
📑 *Parts:* ${partsCount}
status: ${completed}

───────────────
📥 Reply *1* to Download Full Story PDF

${botfooter}`;

                const coverImage = infoData.cover || selected.cover;
                let infoMsg;
                if (coverImage) {
                    infoMsg = await conn.sendMessage(from, { image: { url: coverImage }, caption: infoCaption }, { quoted: reply });
                } else {
                    infoMsg = await conn.sendMessage(from, { text: infoCaption }, { quoted: reply });
                }

                const infoMsgId = infoMsg.key.id;

                // 4. PDF Download Handler
                const pdfHandler = async (pdfUpdate) => {
                    const pdfReply = pdfUpdate.messages[0];
                    if (!pdfReply?.message || !pdfReply.key.fromMe) return;

                    const isIt = pdfReply.message?.extendedTextMessage?.contextInfo?.stanzaId === infoMsgId;
                    if (!isIt) return;

                    const pdfText = (pdfReply.message.conversation || pdfReply.message.extendedTextMessage?.text || '').trim();

                    if (pdfText !== '1') {
                        return await conn.sendMessage(from, { text: `❌ *Invalid choice!* Please reply with 1 to download the PDF.` }, { quoted: pdfReply });
                    }

                    conn.ev.off('messages.upsert', pdfHandler);
                    await conn.sendMessage(from, { react: { text: '⬇️', key: pdfReply.key } });

                    // 5. PDF API Call
                    const pdfApiUrl = `https://api.chamindu.site/api/v1/wattpad/pdf/full?id=${encodeURIComponent(storyUrl)}&api_key=${apiKey}`;
                    let pdfData;
                    try {
                        pdfData = await apiCallWithRetry(pdfApiUrl, 3);
                    } catch (err) {
                        return await conn.sendMessage(from, { text: `❌ *Failed to generate PDF link!*` }, { quoted: pdfReply });
                    }

                    const downloadLink = pdfData?.download_link;
                    if (!downloadLink) {
                        return await conn.sendMessage(from, { text: `❌ *PDF download link not available right now.*` }, { quoted: pdfReply });
                    }

                    let cleanTitle = storyTitle.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 40);
                    let fileName = `${cleanTitle}.pdf`;

                    const doneCaption = `
╭──〔 📚 Wattpad PDF Delivery 🌸 〕──⬣

૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა Your story PDF is ready~ 💕

📖 Title ➜ ${storyTitle}
✍️ Author ➜ ${storyAuthor}

━━━━━━━━━━━━━━━

🍿 Enjoy your reading!

🌸 Thanks for using ${botname}

♡ Powered By 🌐 https://sulaofc.store

━━━━━━━━━━━━━━━`;

                    try {
                        await conn.sendMessage(from, {
                            document: { url: downloadLink },
                            mimetype: 'application/pdf',
                            fileName: fileName,
                            caption: doneCaption
                        }, { quoted: pdfReply });

                        await conn.sendMessage(from, { react: { text: '✅', key: pdfReply.key } });

                    } catch (e) {
                        console.error('Wattpad PDF Send Error:', e);
                        await conn.sendMessage(from, { react: { text: '❌', key: pdfReply.key } });
                        await conn.sendMessage(from, { text: `❌ *PDF Send Failed:* ${e.message}` }, { quoted: pdfReply });
                    }
                };

                conn.ev.on('messages.upsert', pdfHandler);
                setTimeout(() => conn.ev.off('messages.upsert', pdfHandler), 10 * 60 * 1000);
            };

            conn.ev.on('messages.upsert', searchHandler);
            setTimeout(() => conn.ev.off('messages.upsert', searchHandler), 5 * 60 * 1000);

        } catch (err) {
            console.error('Wattpad Plugin Error:', err.message);
            await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
            await conn.sendMessage(from, { text: `❌ *System Error:* ${err.message}` }, { quoted: mek });
        }
    }
};
