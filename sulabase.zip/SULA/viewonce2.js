//const { downloadContentFromMessage } = require('baileys');

module.exports = {
    name: 'vv2',
    alias: ["❤️", "😚"],
    run: async ({ conn, mek, from }) => {

const {
    default: makeWASocket,
    useMultiFileAuthState,
    delay,
    makeCacheableSignalKeyStore,
    Browsers,
    downloadContentFromMessage,
    jidNormalizedUser,
    proto,
    prepareWAMessageMedia,
    downloadMediaMessage,
    generateForwardMessageContent,
    generateWAMessageFromContent
} = await import('baileys');

        try {
            const quoted = mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;

const umber = conn.user.id.split(':')[0];

            const selfJid = `${umber}@s.whatsapp.net`;

            if (!quoted) return;

            const mtype = Object.keys(quoted)[0];

            const isViewOnce =
                (mtype === 'imageMessage' && quoted.imageMessage?.viewOnce) ||
                (mtype === 'videoMessage' && quoted.videoMessage?.viewOnce) ||
                (mtype === 'audioMessage' && quoted.audioMessage?.viewOnce);

            if (!isViewOnce) return;

            const stream = await downloadContentFromMessage(
                quoted[mtype],
                mtype.replace('Message', '')
            );

            const chunks = [];
            for await (const chunk of stream) {
                chunks.push(chunk);
            }

            const buffer = Buffer.concat(chunks);

            let media = {};

            if (mtype === 'imageMessage') {
                media = { image: buffer };
            }

            if (mtype === 'videoMessage') {
                media = { video: buffer };
            }

            if (mtype === 'audioMessage') {
                media = {
                    audio: buffer,
                    mimetype: 'audio/mpeg',
                    ptt: quoted.audioMessage?.ptt || false
                };
            }

            await conn.sendMessage(selfJid, {
                ...media,
                caption: '👁️ ViewOnce saved to your private chat 💖'
            });

            await conn.sendMessage(from, {
                delete: {
                    remoteJid: from,
                    fromMe: true,
                    id: mek.key.id
                }
            });

        } catch (err) {
            console.log("vv2 error:", err.message);
        }
    }
};
