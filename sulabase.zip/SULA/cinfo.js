module.exports = {
    name: 'cinfo',
    alias: ["cid"],
    run: async ({ conn, mek, from, q }) => {

        try {
            if (!q) {
                return conn.sendMessage(from, {
                    text: '❎ Please provide a WhatsApp Channel link.\n\nExample:\n.cinfo https://whatsapp.com/channel/xxxx'
                }, { quoted: mek });
            }

            const match = q.match(/whatsapp\.com\/channel\/([\w-]+)/);

            if (!match) {
                return conn.sendMessage(from, {
                    text: '⚠️ Invalid channel link!\n\nUse:\nhttps://whatsapp.com/channel/xxxx'
                }, { quoted: mek });
            }

            const inviteId = match[1];

            await conn.sendMessage(from, {
                text: `🔎 Fetching channel info...`
            }, { quoted: mek });

            let metadata;

            try {
                metadata = await conn.newsletterMetadata("invite", inviteId);
            } catch {
                metadata = await conn.newsletterMetadata(inviteId);
            }

            if (!metadata || !metadata.id) {
                return conn.sendMessage(from, {
                    text: '❌ Channel not found!'
                }, { quoted: mek });
            }

            const data = metadata.thread_metadata || metadata;

            const name = data.name?.text || data.name || "Unknown";
            const desc = data.description?.text || data.description || "No description";
            const subs = data.subscribers_count
                ? data.subscribers_count.toLocaleString()
                : "0";

            const created = data.creation_time
                ? new Date(Number(data.creation_time) * 1000).toLocaleString()
                : "Unknown";

            let previewUrl = metadata.preview;
            if (previewUrl && !previewUrl.startsWith('https://')) {
                previewUrl = `https://pps.whatsapp.net${previewUrl}`;
            }

            const caption = `
       📡 *WhatsApp Channel Info*

📌 Name:      : ${name}

👥 Followers  : ${subs}

📅 Created on : ${created}

💌 Channel ID  : ${metadata.id}

📝 About:
${desc}

> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃
`.trim();

            if (previewUrl) {
                await conn.sendMessage(from, {
                    image: { url: previewUrl },
                    caption
                }, { quoted: mek });
            } else {
                await conn.sendMessage(from, {
                    text: caption
                }, { quoted: mek });
            }

        } catch (err) {
            // console.error("cinfo error:", err);

            await conn.sendMessage(from, {
                text: '❌ Error fetching channel info!'
            }, { quoted: mek });
        }
    }
};
