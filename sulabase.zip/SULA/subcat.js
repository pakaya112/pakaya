const axios = require('axios');
const { ReadData } = require('../database');

const SEARCH_API = 'https://subcatofc-thenux.netlify.app/.netlify/functions/subtitles/search';
const DOWNLOAD_API = 'https://subcatofc-thenux.netlify.app/.netlify/functions/subtitles/download';

module.exports = {
    name: 'subcat',
    alias: ['subtitle', 'subcatdl', 'sub'],

    run: async ({ conn, mek, from, q }) => {

        const number = conn.user.id.split(':')[0];

        const botname =
            await ReadData(number, 'BOT_NAME') || 'SULA MD';

        const botfooter =
            await ReadData(number, 'BOT_FOOTER') || '© SULA MD';

        if (!q) {
            return conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
🌸 *Subtitle Search*
╰────♡◉◉◉♡────⌬

Example:
.subcat iron man

.subcat 9476xxxxxxx@s.whatsapp.net iron man

${botfooter}`
            }, { quoted: mek });
        }

        const args = q.trim().split(' ');
        let targetJid = null;
        let searchQuery = q;
        let isCustomTarget = false;

        if (
            args[0]?.includes('@s.whatsapp.net') ||
            args[0]?.includes('@g.us') ||
            args[0]?.includes('@lid')
        ) {
            targetJid = args[0];
            searchQuery = args.slice(1).join(' ');
            isCustomTarget = true;
        }

        await conn.sendMessage(from, {
            react: {
                text: '⏳',
                key: mek.key
            }
        });

        try {

            const { data } = await axios.get(
                `${SEARCH_API}?q=${encodeURIComponent(searchQuery)}`
            );

            if (!data.results || !data.results.length) {
                throw new Error('No subtitles found for your query');
            }

            // Get top 10 results
            const results = data.results.slice(0, 10);

            const list = results.map((x, i) => 
                `❰ ${i + 1} ❱ *${x.title}*
📦 Size: ${x.size} | 📥 ${x.downloads}`
            ).join('\n\n');

            const sentMsg = await conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
🌸 *Subtitle Search Results*
╰────♡◉◉◉♡────⌬

${list}

───────────────

Reply: 1 - ${results.length}

> Subtitles System • subcatofc 🌌

${botfooter}`
            }, { quoted: mek });

            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];
                if (!msg.message) return;

                const text =
                    msg.message.conversation ||
                    msg.message.extendedTextMessage?.text;

                const isReply =
                    msg.message?.extendedTextMessage
                        ?.contextInfo?.stanzaId === sentMsg.key.id;

                if (!isReply) return;

                const index = parseInt(text) - 1;

                if (isNaN(index) || !results[index]) {
                    return conn.sendMessage(from, {
                        text: '❌ Invalid Selection'
                    }, { quoted: msg });
                }

                // Stop listening once valid choice is recorded
                conn.ev.off('messages.upsert', listener);

                await conn.sendMessage(from, {
                    react: { text: '📥', key: msg.key }
                });

                const selectedFile = results[index];

                // Call the helper to fetch languages & let user select
                await showLanguageOptions(
                    conn, 
                    msg, 
                    from, 
                    targetJid, 
                    isCustomTarget, 
                    selectedFile.apiUrlToGetDownloadLinks, 
                    selectedFile.title,
                    botname, 
                    botfooter
                );
            };

            conn.ev.on('messages.upsert', listener);

            setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (err) {
            return conn.sendMessage(from, {
                text: `❌ ${err.message}`
            }, { quoted: mek });
        }
    }
};


       async function showLanguageOptions(
    conn, 
    quotedMsg, 
    from, 
    targetJid, 
    isCustomTarget, 
    apiPath, 
    subTitle,
    botname, 
    botfooter
) {
    try {
        const urlParams = apiPath.split('?')[1]; 
        const targetUrl = `https://subcatofc-thenux.netlify.app/.netlify/functions/subtitles/download?${urlParams}`;

        const { data } = await axios.get(targetUrl);

        if (!data.available_downloads || !data.available_downloads.length) {
            throw new Error('No download languages available for this file.');
        }

        // MODIFIED: Get ALL languages from the API array now (No filtering out unavailable ones)
        const allLanguages = data.available_downloads;

        // Map through all of them to build the message list
        const list = allLanguages.map((x, i) => {
            const statusIcon = x.status === 'Available' ? '✅' : '⏳';
            return `❰ ${i + 1} ❱ ${statusIcon} *${x.language}*`;
        }).join('\n');

        const sentMsg = await conn.sendMessage(from, {
            text: `╭────♡◉◉◉♡────⌬
📥 *Select Subtitle Language*
╰────♡◉◉◉♡────⌬

📄 *File:* ${subTitle}

${list}

───────────────

💡 *Note:* ✅ Ready | ⏳ Needs Processing

Reply: 1 - ${allLanguages.length}

${botfooter}`
        }, { quoted: quotedMsg });

        const listener = async (msgUpdate) => {
            const msg = msgUpdate.messages[0];
            if (!msg.message) return;

            const text =
                msg.message.conversation ||
                msg.message.extendedTextMessage?.text;

            const isReply =
                msg.message?.extendedTextMessage
                    ?.contextInfo?.stanzaId === sentMsg.key.id;

            if (!isReply) return;

            const index = parseInt(text) - 1;

            if (isNaN(index) || !allLanguages[index]) {
                return conn.sendMessage(from, {
                    text: '❌ Invalid Language Selection'
                }, { quoted: msg });
            }

            // Stop listener execution
            conn.ev.off('messages.upsert', listener);

            const chosenLang = allLanguages[index];

            // VALIDATION: If user picks a language that doesn't have a download url yet
            if (!chosenLang.downloadUrl) {
                await conn.sendMessage(from, {
                    react: { text: '❌', key: msg.key }
                });
                return conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬
❌ *Language Not Ready*
╰────♡◉◉◉♡────⌬

🌐 *Language:* ${chosenLang.language}
⚠️ *Status:* This language requires a translation trigger on the original portal. It cannot be downloaded automatically right now.

Please try selecting a language marked with ✅.`
                }, { quoted: msg });
            }

            await conn.sendMessage(from, {
                react: { text: '⬇️', key: msg.key }
            });
            
            // Generate clean filename
            const outFileName = subTitle
                .replace(/[\\/:*?"<>|]/g, '')
                .trim() + ` (${chosenLang.language}).srt`;

            const doneCaption = `╭──〔 🌸 Subtitle Delivery 🌸 〕──⬣

૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა Subtitle file successfully processed~ 💕

📄 Title ➜ ${subTitle}
🌐 Lang  ➜ ${chosenLang.language}

━━━━━━━━━━━━━━━
🌸 Thanks for using ${botname}
━━━━━━━━━━━━━━━`;

            // Deliver .srt file document text
            await conn.sendMessage(targetJid || from, {
                document: { url: chosenLang.downloadUrl },
                mimetype: 'text/plain',
                fileName: outFileName,
                caption: doneCaption
            }, { quoted: msg });

            if (isCustomTarget && targetJid) {
                await conn.sendMessage(from, {
                    text: `✅ Successfully Sent Subtitle!\n\n📤 Sent to target thread: ${targetJid}`
                }, { quoted: msg });
            }

            await conn.sendMessage(from, {
                react: { text: '✅', key: msg.key }
            });
        };

        conn.ev.on('messages.upsert', listener);

        setTimeout(() => {
            conn.ev.off('messages.upsert', listener);
        }, 60000);

    } catch (err) {
        await conn.sendMessage(from, {
            text: `❌ Error downloading subtitle package: ${err.message}`
        }, { quoted: quotedMsg });
    }
}
