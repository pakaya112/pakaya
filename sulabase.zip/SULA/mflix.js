const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { ReadData } = require('../database');

// --- Temp Folder Configuration ---
const TEMP_DIR = path.join(__dirname, 'temp_mflix');
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// --- API Endpoints ---
const SEARCH_API = 'https://api.chamindu.site/api/v1/movies/mflix/search';
const LATEST_API = 'https://api.chamindu.site/api/v1/movies/mflix/latest';
const KDRAMA_API = 'https://api.chamindu.site/api/v1/movies/mflix/kdramas';
const INFO_API = 'https://api.chamindu.site/api/v1/movies/mflix/infodl';

const API_KEY = 'chama_api_c4352392c75ea7c9ef640b0c79d1d174';
const DEFAULT_IMAGE = 'https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg';

// Helper: Convert KB/Bytes to Clean Formatted MB/GB
function formatFileSize(sizeStr) {
    if (!sizeStr || sizeStr === 'N/A') return 'N/A';
    const str = String(sizeStr).trim();
    if (/kb$/i.test(str)) {
        const kb = parseFloat(str.replace(/kb/i, '').trim());
        if (isNaN(kb)) return sizeStr;
        const mb = kb / 1024;
        return mb >= 1024 ? `${(mb / 1024).toFixed(2)} GB` : `${mb.toFixed(2)} MB`;
    }
    if (/^\d+$/.test(str)) {
        const bytes = parseInt(str);
        const mb = bytes / (1024 * 1024);
        return mb >= 1024 ? `${(mb / 1024).toFixed(2)} GB` : `${mb.toFixed(2)} MB`;
    }
    return sizeStr;
}

// 1. API Call Function (With Retries)
async function apiCallWithRetry(url, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await axios.get(url, { timeout: 25000 });
            if (!response.data) throw new Error('API returned empty response');
            return response.data;
        } catch (error) {
            if (i === retries - 1) throw error;
            await new Promise(res => setTimeout(res, 2000));
        }
    }
}

// 2. Stream File Download Function (RAM Overflow Prevention)
async function downloadWithRetry(url, destPath, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            const { data } = await axios({
                url: url,
                method: 'GET',
                responseType: 'stream',
                timeout: 300000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
                }
            });

            const writer = fs.createWriteStream(destPath);
            data.pipe(writer);

            await new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', (err) => {
                    writer.close();
                    reject(err);
                });
                data.on('error', (err) => {
                    writer.close();
                    reject(err);
                });
            });

            return true;
        } catch (error) {
            if (fs.existsSync(destPath)) {
                try { fs.unlinkSync(destPath); } catch (e) {}
            }
            if (i === retries - 1) throw error;
            await new Promise(res => setTimeout(res, 2000));
        }
    }
}

// 3. Direct Link Resolver (GDrive & Mediafire Bypass)
async function resolveDirectDownloadLink(rawUrl) {
    if (rawUrl.includes('drive.google.com') || rawUrl.includes('docs.google.com')) {
        const gdApi = await apiCallWithRetry(`https://apis.davidcyriltech.my.id/gdrive?url=${encodeURIComponent(rawUrl)}`, 3);
        const directLink = gdApi.download_link || gdApi.api_download;
        if (!directLink) throw new Error('Google Drive resolver failed');
        return {
            directLink,
            fileName: gdApi.name || null,
            fileSize: formatFileSize(gdApi.size) || 'N/A'
        };
    } else if (rawUrl.includes('mediafire.com')) {
        const mfApi = await apiCallWithRetry(`https://apis.davidcyriltech.my.id/mediafire?url=${encodeURIComponent(rawUrl)}`, 3);
        const directLink = mfApi.downloadLink || mfApi.download_link;
        if (!directLink) throw new Error('Mediafire resolver failed');
        return {
            directLink,
            fileName: mfApi.fileName || mfApi.name || null,
            fileSize: formatFileSize(mfApi.size) || 'N/A'
        };
    }
    return { directLink: rawUrl, fileName: null, fileSize: 'N/A' };
}

module.exports = {
    name: 'mflix',
    alias: ['mflixlk', 'kdrama', 'mf'],

    run: async ({ conn, mek, from, q }) => {
        try {
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.\n\nWant access to this feature?\n\nCreate your own bot:\n🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'SULA MD';

            if (!q) {
                return await conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬\n🎬 *MflixLK & K-Drama Downloader*\n╰────♡◉◉◉♡────⌬\n\n📌 *Examples:* \n.mflix Dream to You\n.mflix 9476xxxxxxx@s.whatsapp.net Twelve\n\n💡 *Categories:*\n.mflix --latest (Latest Releases)\n.mflix --kdrama (Top K-Dramas)`
                }, { quoted: mek });
            }

            const args = q.trim().split(' ');
            let targetJid = null;
            let searchQuery = q.trim();
            let isCustomTarget = false;

            if (args[0]?.includes('@s.whatsapp.net') || args[0]?.includes('@g.us') || args[0]?.includes('@lid')) {
                targetJid = args[0];
                searchQuery = args.slice(1).join(' ').trim();
                isCustomTarget = true;
            }

            await conn.sendMessage(from, { react: { text: '⏳', key: mek.key } });

            let results = [];
            let listHeader = `🔍 *Query:* ${searchQuery}`;

            if (searchQuery.toLowerCase() === '--latest') {
                const { data } = await axios.get(`${LATEST_API}?page=1&api_key=${API_KEY}`);
                if (!data.status || !data.data?.length) throw new Error('No latest updates found.');
                results = data.data.slice(0, 10);
                listHeader = '📌 *Latest Releases (Page 1):*';
            } else if (searchQuery.toLowerCase() === '--kdrama') {
                const { data } = await axios.get(`${KDRAMA_API}?q=1&api_key=${API_KEY}`);
                if (!data.status || !data.data?.length) throw new Error('No K-Drama releases found.');
                results = data.data.slice(0, 10);
                listHeader = '🎭 *K-Drama Releases (Page 1):*';
            } else {
                const { data } = await axios.get(`${SEARCH_API}?q=${encodeURIComponent(searchQuery)}&api_key=${API_KEY}`);
                if (!data.status || !data.data?.length) throw new Error(`No results found for "${searchQuery}".`);
                results = data.data.slice(0, 10);
            }

            const list = results.map((x, i) =>
                `❰ ${i + 1} ❱ *${x.title}*\n🎬 Type: ${x.type === 'tvshows' ? 'TV Series / Drama' : 'Movie'}`
            ).join('\n\n');

            const caption = `╭────♡◉◉◉♡────⌬\n🎬 *MflixLK Results*\n✨ *${botname} Ready*\n╰────♡◉◉◉♡────⌬\n\n${listHeader}\n\n${list}\n\n───────────────\n\nReply with a number: 1 - ${results.length}`;

            const sentMsg = await conn.sendMessage(from, {
                image: { url: results[0].image?.trim() || DEFAULT_IMAGE },
                caption
            }, { quoted: mek });

            const timeoutTimer = setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];
                if (!msg.message) return;

                const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                if (!isReply) return;

                const index = parseInt(text?.trim()) - 1;
                if (isNaN(index) || !results[index]) {
                    clearTimeout(timeoutTimer);
                    conn.ev.off('messages.upsert', listener);
                    return conn.sendMessage(from, { text: '❌ Invalid Selection. Please run the command again.' }, { quoted: msg });
                }

                clearTimeout(timeoutTimer);
                conn.ev.off('messages.upsert', listener);
                await conn.sendMessage(from, { react: { text: '📥', key: msg.key } });

                const selected = results[index];
                return await showMediaDetails(conn, msg, from, targetJid, isCustomTarget, selected.link, selected.title, botname);
            };

            conn.ev.on('messages.upsert', listener);

        } catch (err) {
            return conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬\n❌ *MflixLK Error*\n╰────♡◉◉◉♡────⌬\n\n⚠️ ${err.message}`
            }, { quoted: mek });
        }
    }
};

// ==========================================
// 🎬 MEDIA DETAILS & EPISODES/DOWNLOAD FLOW
// ==========================================
async function showMediaDetails(conn, quotedMsg, from, targetJid, isCustomTarget, itemUrl, fallbackTitle, botname) {
    try {
        const { data } = await axios.get(`${INFO_API}?q=${encodeURIComponent(itemUrl)}&api_key=${API_KEY}`);
        if (!data.status || !data.data) {
            throw new Error('Media details not found.');
        }

        const item = data.data;
        // Telegram Links Filter
        const downloads = (item.downloads || []).filter(
            (d) => !/telegram/i.test(d.name || d.quality) && !/t\.me\//i.test(d.link)
        );

        if (!downloads.length) {
            throw new Error('No direct download links found for this title (Only Telegram links available).');
        }

        const realTitle = item.title || fallbackTitle || 'Movie / Series';
        const cleanStory = item.story ? (item.story.length > 250 ? item.story.slice(0, 250) + '...' : item.story) : 'No description available.';

        const displayLimit = Math.min(downloads.length, 25);
        const list = downloads.slice(0, displayLimit).map((x, i) =>
            `❰ ${i + 1} ❱ *${x.name || x.quality || 'Download Link'}* - (${formatFileSize(x.size)})`
        ).join('\n');

        const caption = `╭────♡◉◉◉♡────⌬\n🎥 *${realTitle}*\n╰────♡◉◉◉♡────⌬\n\n⭐ IMDb: ${item.imdb || 'N/A'}\n🎭 Genres: ${item.genres?.join(', ') || 'N/A'}\n🎬 Director: ${item.director || 'N/A'}\n\n📖 *Story:*\n${cleanStory}\n\n*Available Downloads / Episodes:*\n${list}\n\n───────────────\n\nReply with Option Number: 1 - ${displayLimit}`;

        const sentMsg = await conn.sendMessage(from, {
            image: { url: item.image?.trim() || item.gallery?.[0] || DEFAULT_IMAGE },
            caption
        }, { quoted: quotedMsg });

        const timeoutTimer = setTimeout(() => {
            conn.ev.off('messages.upsert', listener);
        }, 60000);

        const listener = async (msgUpdate) => {
            const msg = msgUpdate.messages[0];
            if (!msg.message) return;

            const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
            const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

            if (!isReply) return;

            const index = parseInt(text?.trim()) - 1;
            if (isNaN(index) || !downloads[index]) {
                clearTimeout(timeoutTimer);
                conn.ev.off('messages.upsert', listener);
                return conn.sendMessage(from, { text: '❌ Invalid Selection.' }, { quoted: msg });
            }

            clearTimeout(timeoutTimer);
            conn.ev.off('messages.upsert', listener);
            await conn.sendMessage(from, { react: { text: '⬇️', key: msg.key } });

            const selectedDl = downloads[index];
            await showDownloadOptionMenu(conn, msg, from, targetJid, isCustomTarget, {
                title: selectedDl.name || realTitle,
                image: item.image?.trim() || item.gallery?.[0] || DEFAULT_IMAGE,
                quality: selectedDl.quality || 'HD',
                size: formatFileSize(selectedDl.size),
                link: selectedDl.link,
                botname
            });
        };

        conn.ev.on('messages.upsert', listener);

    } catch (err) {
        return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: quotedMsg });
    }
}

// ==========================================
// 🚀 DOWNLOAD & FILE SEND MENU
// ==========================================
async function showDownloadOptionMenu(conn, quotedMsg, from, targetJid, isCustomTarget, info) {
    const caption = `╭────♡◉◉◉♡────⌬\n📥 *Download Options*\n✨ *${info.botname}*\n╰────♡◉◉◉♡────⌬\n\n🎬 *Title:* ${info.title}\n💎 *Quality:* ${info.quality}\n📦 *Size:* ${info.size}\n\n───────────────\n\n📁 ❶ Send as File\n🔗 ❷ Direct Download Link\n\n───────────────\n\nReply: 1 / 2`;

    const sentMsg = await conn.sendMessage(from, {
        image: { url: info.image || DEFAULT_IMAGE },
        caption
    }, { quoted: quotedMsg });

    const timeoutTimer = setTimeout(() => {
        conn.ev.off('messages.upsert', listener);
    }, 60000);

    const listener = async (msgUpdate) => {
        const msg = msgUpdate.messages[0];
        if (!msg.message) return;

        const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
        const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        clearTimeout(timeoutTimer);
        conn.ev.off('messages.upsert', listener);

        const chosenOption = text?.trim();

        if (!['1', '2'].includes(chosenOption)) {
            return conn.sendMessage(from, { text: '❌ Invalid Option. Please choose 1 or 2.' }, { quoted: msg });
        }

        await conn.sendMessage(from, { react: { text: '⏳', key: msg.key } });

        let tempFilePath = null;

        try {
            const resolved = await resolveDirectDownloadLink(info.link);
            const directDownloadUrl = resolved.directLink;
            const fileSize = resolved.fileSize !== 'N/A' ? resolved.fileSize : formatFileSize(info.size);

            let fileName = resolved.fileName || `${(info.title || 'Media').replace(/[^a-zA-Z0-9.\-_]/g, '_')}.mp4`;
            if (!fileName.endsWith('.mp4') && !fileName.endsWith('.mkv')) fileName += '.mp4';

            // 🛡️ 2GB File Size Limit Check
            const rawSize = String(fileSize).toUpperCase();
            const sizeNum = parseFloat(rawSize);
            const isOver2GB = rawSize.includes('GB') && sizeNum >= 2.0;

            if (chosenOption === '1' && isOver2GB) {
                await conn.sendMessage(from, { react: { text: '⚠️', key: msg.key } });
                return await conn.sendMessage(from, {
                    text: `⚠️ *File Size Limit Exceeded! (2GB+)*\n\nThe file size is *${fileSize}*. Due to WhatsApp file size limitations, files over 2GB cannot be sent directly as documents.\n\n🔗 *Direct Download Link:*\n${directDownloadUrl}`
                }, { quoted: msg });
            }

            // Clean Delivery Caption Style
            const doneCaption = `╭──〔 🎬 MflixLK Delivery 🎬 〕──⬣\n\n` +
                                `૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა Your movie is ready~ 💕\n\n` +
                                `🎬 Title ➜ ${info.title}\n\n` +
                                `━━━━━━━━━━━━━━━\n\n` +
                                `🍿 Enjoy your watch time!\n\n` +
                                `🌸 Thanks for using ${info.botname}\n\n` +
                                `♡ Powered By 🌐 https://sulaofc.store\n\n` +
                                `movies • series • updates\n\n` +
                                `━━━━━━━━━━━━━━━`;

            if (chosenOption === '1') {
                tempFilePath = path.join(TEMP_DIR, `${Date.now()}_${fileName}`);

                await conn.sendMessage(from, {
                    text: `⏳ *Downloading file to server...*\n\n📄 *File:* ${fileName}\n📦 *Size:* ${fileSize}\n\n*(Please wait, sending file shortly...)*`
                }, { quoted: msg });

                await downloadWithRetry(directDownloadUrl, tempFilePath, 3);

                await conn.sendMessage(from, { react: { text: '📤', key: msg.key } });

                const mimetype = fileName.endsWith('.mkv') ? 'video/x-matroska' : 'video/mp4';

                await conn.sendMessage(targetJid || from, {
                    document: { stream: fs.createReadStream(tempFilePath) },
                    mimetype: mimetype,
                    fileName: fileName,
                    caption: doneCaption
                }, { quoted: msg });

                if (isCustomTarget && targetJid) {
                    await conn.sendMessage(from, {
                        text: `✅ Successfully Delivered!\n\n📤 To: ${targetJid}`
                    }, { quoted: msg });
                }

                await conn.sendMessage(from, { react: { text: '✅', key: msg.key } });

            } else {
                await conn.sendMessage(from, {
                    text: `${doneCaption}\n\n🔗 *Direct Download Link:*\n${directDownloadUrl}`
                }, { quoted: msg });
                await conn.sendMessage(from, { react: { text: '✅', key: msg.key } });
            }

        } catch (err) {
            console.error('Download Error:', err);
            await conn.sendMessage(from, { react: { text: '❌', key: msg.key } });
            await conn.sendMessage(from, {
                text: `❌ *Download Failed:*\n${err.message}\n\n🔗 *Original Link:*\n${info.link}`
            }, { quoted: msg });
        } finally {
            try {
                if (tempFilePath && fs.existsSync(tempFilePath)) {
                    fs.unlinkSync(tempFilePath);
                }
            } catch (cleanupErr) {
                console.error('Temp cleanup error:', cleanupErr);
            }
        }
    };

    conn.ev.on('messages.upsert', listener);
}
