const { ReadData } = require('../database');

module.exports = {
    name: 'grouplist',
    alias: ['gclist'],

    run: async ({ conn, mek, from }) => {

        try {

const ownerNumber = conn.user.id.split(':')[0];

const senderNumber =
    (mek.key.participant || mek.key.remoteJid)
    .split('@')[0];

if (senderNumber !== ownerNumber && !mek.key.fromMe) {
    return await conn.sendMessage(from, {
        text: "❌ Owner only command!"
    }, { quoted: mek });
}

            const number = conn.user.id.split(':')[0];
            
            const BOT_NAME =
                await ReadData(number, 'BOT_NAME');

            const BOT_FOOTER =
                await ReadData(number, 'BOT_FOOTER');

            await conn.sendMessage(from, {
                react: { text: '📡', key: mek.key }
            });

            const groups =
                await conn.groupFetchAllParticipating();

            const list =
                Object.values(groups);

            if (!list.length) {

                return conn.sendMessage(from, {
                    text: '❌ No groups found!'
                }, { quoted: mek });
            }

            let text = `
╭────♡◉◉◉♡────⌬
👥 *GROUP LIST PANEL*
🌸 *${BOT_NAME} Group System*
╰────♡◉◉◉♡────⌬

📌 *Total Groups:* ${list.length}

───────────────

`;

            list.forEach((group, i) => {

                text += `*${i + 1}️⃣ ${group.subject}*\n`;
                text += `👥 ${group.participants.length} Members\n`;
                text += `🆔 ${group.id}\n\n`;
            });

            text += `───────────────
💌 *Reply With Group Number*

${BOT_FOOTER}`;

            const sent = await conn.sendMessage(from, {
                text
            }, { quoted: mek });

            const listener = async (msgUpdate) => {

                try {

                    const msg = msgUpdate.messages[0];

                    if (!msg.message) return;

                    const replyText =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message.extendedTextMessage?.contextInfo?.stanzaId === sent.key.id;

                    if (!isReply) return;

                    const index = parseInt(replyText);

                    if (isNaN(index) || index < 1 || index > list.length) {

                        return conn.sendMessage(from, {
                            text: '❌ Invalid Group Number!'
                        }, { quoted: msg });
                    }

                    conn.ev.off('messages.upsert', listener);

                    const data = list[index - 1];

                    const metadata =
                        await conn.groupMetadata(data.id);

                    let pp = null;

                    try {
                        pp = await conn.profilePictureUrl(data.id, 'image');
                    } catch {}

                    const admins =
                        metadata.participants.filter(v => v.admin !== null).length;

                    const created =
                        metadata.creation
                            ? new Date(metadata.creation * 1000).toLocaleString()
                            : 'Unknown';

                    const caption = `
╭────♡◉◉◉♡────⌬
👥 *GROUP DETAILS*
╰────♡◉◉◉♡────⌬

📛 *Name:*  
${metadata.subject}

👥 *Members:*  
${metadata.participants.length}

👑 *Admins:*  
${admins}

🆔 *Group ID:*  
${metadata.id}

📅 *Created:*  
${created}

📝 *Description:*  
${metadata.desc || 'No Description'}

───────────────

${BOT_FOOTER}
`;

                    if (pp) {

                        await conn.sendMessage(from, {
                            image: { url: pp },
                            caption
                        }, { quoted: msg });

                    } else {

                        await conn.sendMessage(from, {
                            text: caption
                        }, { quoted: msg });
                    }

                } catch (err) {

                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        text: `❌ Error:\n${err.message}`
                    }, { quoted: mek });
                }
            };

            conn.ev.on('messages.upsert', listener);

            setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (err) {

            await conn.sendMessage(from, {
                text: `❌ Error:\n${err.message}`
            }, { quoted: mek });
        }
    }
};
