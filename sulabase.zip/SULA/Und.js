const axios = require('axios');
const { downloadContentFromMessage } = require('baileys');
const { MongoClient } = require('mongodb');
const moment = require('moment-timezone');

const MONGO_URL = "mongodb+srv://UD-API:UD-API01@cluster0.dmuffgi.mongodb.net/Cluster0?retryWrites=true&w=majority";
const mongoClient = new MongoClient(MONGO_URL);

// 🔢 දවසේ උපරිම ලිමිට් එක (අවශ්‍ය නම් මෙතනින් වෙනස් කරන්න)
const DAILY_LIMIT = 10;

module.exports = {
    name: "undress",
    alias: ["sf", "swapface", "und"],
    category: "ai",
    description: "SwapFaces / RevealAI photo remodeler command for Premium Bot Owner with Daily Limit",
    run: async ({ conn, mek, from, args }) => {
        try {
            // 🔒 1. OWNER ONLY CHECK
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.

Want access to this feature?

Create your own bot:
🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            // 👑 2. BOT OWNER NUMBER PREMIUM CHECK
            const botOwnerNumber = conn.user.id.split(':')[0].replace(/[^0-9]/g, '');
            const PREMIUM_JSON_URL = "https://github.com/sulamd48/database/raw/refs/heads/main/premium.json";

            let isPremium = false;
            try {
                const premRes = await axios.get(`${PREMIUM_JSON_URL}?t=${Date.now()}`, {
                    headers: { 'Cache-Control': 'no-cache' }
                });

                if (premRes.data && Array.isArray(premRes.data.premium)) {
                    const cleanPremList = premRes.data.premium.map(num => String(num).trim().replace(/[^0-9]/g, ''));
                    isPremium = cleanPremList.some(num => num && (botOwnerNumber.includes(num) || num.includes(botOwnerNumber)));
                }
            } catch (e) {
                console.error("[Premium Check Error]:", e.message);
            }

            if (!isPremium) {
                return await conn.sendMessage(from, { 
                    text: `♡🛑 PREMIUM ONLY 🛑♡

🚫 *ACCESS DENIED* 🚫

👤 Owner Number : ${botOwnerNumber}

╰┈➤ Premium Users Only!

📩 Want Premium Access?

♡ Type *.owner* To Contact
  The Developer & Get Premium ♡

> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃`
                }, { quoted: mek });
            }

            // ⏰ 3. SRI LANKA TIME & DAILY LIMIT CHECK (BEFORE PROCESSING)
            const todaySL = moment().tz("Asia/Colombo").format("YYYY-MM-DD");

            await mongoClient.connect();
            const db = mongoClient.db("Cluster0");
            const usageCol = db.collection("daily_limits");

            const userUsage = await usageCol.findOne({ id: botOwnerNumber, date: todaySL });
            const currentCount = userUsage ? userUsage.count : 0;

            if (currentCount >= DAILY_LIMIT) {
                return await conn.sendMessage(from, {
                    text: `⚠️ *DAILY LIMIT REACHED!* ⚠️\n\n👤 *Owner Number:* ${botOwnerNumber}\n📅 *Date (SL):* ${todaySL}\n📊 *Used Today:* ${currentCount}/${DAILY_LIMIT}\n\nඔබගේ අද දිනට නියමිත නොමිලේ ලිමිට් එක (${DAILY_LIMIT}) අවසන් වී ඇත. කරුණාකර හෙට නැවත උත්සාහ කරන්න.`
                }, { quoted: mek });
            }

            // 📸 4. IMAGE CHECK
            const isQuotedImage = mek.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage;
            const isImage = mek.message?.imageMessage;

            if (!isImage && !isQuotedImage) {
                let helpText = `╭━━━❀ 𝓢𝓤𝓛𝓐-𝓜𝓓 𝓐𝓘 ❀━━━╮\n`;
                helpText += `🎀🩷 *SULA REVEAL AI PANEL* 🩷🎀\n`;
                helpText += `╰━━━━━━━━━━━━━━━━━━╯\n\n`;
                helpText += `⚠️ *Please reply to an image or send an image with caption!*\n\n`;
                helpText += `📊 *Daily Limit Usage:* ${currentCount}/${DAILY_LIMIT}\n\n`;
                helpText += `✨ *AVAILABLE STYLES:* ✨\n`;
                helpText += ` 🌸 ❯ \`undress\` (Default)\n`;
                helpText += ` 🌸 ❯ \`pose_doggy\`\n`;
                helpText += ` 🌸 ❯ \`pose_kneeling\`\n`;
                helpText += ` 🌸 ❯ \`pose_lying_spread\`\n`;
                helpText += ` 🌸 ❯ \`pose_squat\`\n\n`;
                helpText += `💡 *Usage Example:* \`.undress pose_doggy\`\n`;
                helpText += `╰━━━━━━━━━━━━━━━━━━╯`;

                return await conn.sendMessage(from, { text: helpText }, { quoted: mek });
            }

            await conn.sendMessage(from, { react: { text: "⏳", key: mek.key } });

            // ⬇️ 5. DOWNLOAD MEDIA
            const targetMessage = isQuotedImage 
                ? mek.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage 
                : mek.message.imageMessage;

            const stream = await downloadContentFromMessage(targetMessage, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            // 🎨 6. STYLE SELECTION
            let style = (args[0] || "undress").toLowerCase();
            const validStyles = ["undress", "pose_doggy", "pose_kneeling", "pose_lying_spread", "pose_squat"];
            
            if (!validStyles.includes(style)) {
                style = "undress";
            }

            // 🔄 7. PROCESSING MESSAGE
            let processMsg = `╭━━━❀ 𝓢𝓤𝓛𝓐-𝓜𝓓 𝓐𝓘 ❀━━━╮\n`;
            processMsg += `⚙️ *PROCESSING YOUR IMAGE...*\n\n`;
            processMsg += `🎨 *Style:* \`${style}\`\n`;
            processMsg += `📊 *Remaining Limit:* ${DAILY_LIMIT - currentCount} tries\n`;
            processMsg += `👑 *Status:* _Premium Bot User_\n`;
            processMsg += `⏳ *Please wait a moment...*\n`;
            processMsg += `╰━━━━━━━━━━━━━━━━━━╯`;

            await conn.sendMessage(from, { text: processMsg }, { quoted: mek });

            // 🔑 8. BASE64 CONVERSION
            const base64Image = `data:image/jpeg;base64,${buffer.toString('base64')}`;

            // 🌐 9. API REQUEST
            const API_URL = "https://sula-reveal-api.udmodz-2ab.workers.dev/undress";
            
            const payload = {
                key: "sula",
                image: base64Image,
                style: style,
                poll: true,
                poll_interval_ms: 3000,
                poll_max_attempts: 60
            };

            const res = await axios.post(API_URL, payload, {
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                    'Accept': 'application/json, text/plain, */*'
                },
                timeout: 180000
            });

            if (!res.data || !res.data.success) {
                throw new Error(res.data?.error || 'Worker processing failed.');
            }

            let resultUrl = res.data.imageUrl;

            if (!resultUrl) {
                throw new Error("Failed to retrieve final image URL from API.");
            }

            if (resultUrl.includes('files.swapfaces.ai') || resultUrl.includes('cdn.swapfaces.ai')) {
                resultUrl = `https://sula-reveal-api.udmodz-2ab.workers.dev/proxy?url=${encodeURIComponent(resultUrl)}`;
            }

            // 📈 10. INCREMENT COUNT IN MONGODB (ONLY ON SUCCESS)
            await usageCol.updateOne(
                { id: botOwnerNumber, date: todaySL },
                { $inc: { count: 1 } },
                { upsert: true }
            );

            const newUsedCount = currentCount + 1;

            // 🎉 11. SUCCESS MESSAGE
            let successCaption = `╭━━━❀ 𝓢𝓤𝓛𝓐-𝓜𝓓 𝓐𝓘 ❀━━━╮\n`;
            successCaption += `✨ *PROCESSING COMPLETED!* ✨\n\n`;
            successCaption += `📌 *Style Applied:* _${style}_\n`;
            successCaption += `📊 *Today Usage:* ${newUsedCount}/${DAILY_LIMIT}\n`;
            successCaption += `👑 *User:* _Premium Bot User_\n`;
            successCaption += `─────────────── 🌸\n`;
            successCaption += `💞 *Enjoy babe...* ✨\n`;
            successCaption += `╰━━━━━━━━━━━━━━━━━━╯`;

            await conn.sendMessage(from, { react: { text: "✅", key: mek.key } });

            await conn.sendMessage(from, {
                image: { url: resultUrl },
                caption: successCaption
            }, { quoted: mek });

        } catch (err) {
            console.error("[SULA API Command Error]:", err);
            await conn.sendMessage(from, { react: { text: "❌", key: mek.key } });
            
            const errMsg = err.response?.data?.error || err.message || "Failed to process image!";
            await conn.sendMessage(from, { 
                text: `╭━━━❀ 𝓔𝓦𝓦𝓞𝓦 ❀━━━╮\n❌ *Error:* ${errMsg}\n╰━━━━━━━━━━━━━━━━━━╯` 
            }, { quoted: mek });
        }
    }
};
