const axios = require("axios");

module.exports = {
    name: "animeimg",

    run: async ({ conn, mek, from, args }) => {

        const q = args[0]?.toLowerCase();

        const endpoints = {
            neko: 'https://nekos.life/api/v2/img/neko',
            waifu: 'https://nekos.life/api/v2/img/waifu',
            fox_girl: 'https://nekos.life/api/v2/img/fox_girl',
            hug: 'https://nekos.life/api/v2/img/hug',
            kiss: 'https://nekos.life/api/v2/img/kiss',
            pat: 'https://nekos.life/api/v2/img/pat'
        };

        if (!q || !endpoints[q]) {
            return conn.sendMessage(from, {
                text: `❌ Choose one:\n\n${Object.keys(endpoints).join(", ")}\n\nExample: .animeimg neko`
            }, { quoted: mek });
        }

        try {

            await conn.sendMessage(from, {
                react: { text: "⏳", key: mek.key }
            });

            const res = await axios.get(endpoints[q], { timeout: 10000 });
            const imageUrl = res.data.url;

            await conn.sendMessage(from, {
                image: { url: imageUrl },
                caption: `🖼️ *${q.toUpperCase()}*\n\n© SULA MD`
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: "✅", key: mek.key }
            });

        } catch (err) {
          //  console.error("ANIME ERROR:", err);

            await conn.sendMessage(from, {
                text: `❌ Failed to fetch ${q}`
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: "❌", key: mek.key }
            });
        }
    }
};
