module.exports = {
    name: "demote",
    description: "Demote an admin to member.",
    category: "group",

    run: async ({ conn, mek, from, args, isGroup, isAdmin, isBotAdmins }) => {
        try {
            if (!isGroup) return conn.sendMessage(from, { text: "❌ This command can only be used in groups!" }, { quoted: mek });
            if (!isBotAdmins) return conn.sendMessage(from, { text: "❌ I need Admin privileges to demote users!" }, { quoted: mek });
            if (!isAdmin) return conn.sendMessage(from, { text: "❌ Only group admins can use this command!" }, { quoted: mek });

            let user = mek.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || 
                       mek.message?.extendedTextMessage?.contextInfo?.participant || 
                       (args[0] ? args[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : null);

            if (!user) return conn.sendMessage(from, { text: "⚠️ Please tag or reply to the user you want to demote!" }, { quoted: mek });

            await conn.groupParticipantsUpdate(from, [user], "demote");

            return conn.sendMessage(from, { 
                text: `✅ Successfully demoted @${user.split("@")[0]} to Member!`,
                mentions: [user] 
            }, { quoted: mek });

        } catch (err) {
            //console.error("DEMOTE ERROR:", err);
            await conn.sendMessage(from, { text: "❌ Error occurred while demoting user." }, { quoted: mek });
        }
    }
};
