const axios = require("axios");
const { ReadData } = require("../database");

module.exports = {
  name: "lyrics",
  alias: ["slyric", "sllyrics", "songlyrics"],

  run: async ({ conn, mek, from, args, q }) => {
    try {
      const query = args?.length ? args.join(" ") : q;

      if (!query) {
        return await conn.sendMessage(from, {
          text: `╭─❌ *LYRICS SEARCH*
│
│ Please provide a song name.
│
│ Example:
│ .lyrics pandama
╰───────────────`
        }, { quoted: mek });
      }

      await conn.sendMessage(from, {
        react: { text: "🔎", key: mek.key }
      });

      const number = conn.user.id.split(":")[0];
      const botname = await ReadData(number, "BOT_NAME");
      const botfooter = await ReadData(number, "BOT_FOOTER");

      const searchRes = await axios.get(
        `https://lyric-api.netlify.app/.netlify/functions/lyrics?q=${encodeURIComponent(query)}`
      );

      const results = searchRes.data?.results;

      if (!results || results.length === 0) {
        return conn.sendMessage(from, {
          text: `╭─❌ *NO RESULTS FOUND*
│
│ Search: ${query}
╰───────────────`
        }, { quoted: mek });
      }

      const list = results.slice(0, 5);

      let listText = `
╭━━━━━〔 *SINHALA LYRICS FINDER* 〕━━━━━⬣
┃
┃ 🤖 *Bot:* ${botname}
┃ 🔎 *Search:* ${query}
┃ 🎵 *Results:* ${searchRes.data?.total || list.length}
┃ 👑 *Creator:* ${searchRes.data?.creator || "THENUX"}
┃
┣━━━━━━━━━━━━━━━━━━━━⬣
┃        *SELECT YOUR SONG*
┣━━━━━━━━━━━━━━━━━━━━⬣
`;

      list.forEach((v, i) => {
        listText += `┃
┃ ${i + 1}. 🎶 *${v.title}*
┃    👤 ${v.category || "Unknown"}
┃    📅 ${v.date || "Unknown"}
`;
      });

      listText += `┃
┣━━━━━━━━━━━━━━━━━━━━⬣
┃ 💬 Reply with number: *1 - ${list.length}*
┃ ⏱️ Timeout: *60 seconds*
╰━━━━━━━━━━━━━━━━━━━━⬣

${botfooter}`;

      const sentMsg = await conn.sendMessage(from, {
        text: listText
      }, { quoted: mek });

      let finished = false;

      const listener = async (update) => {
        const m = update.messages[0];
        if (!m?.message) return;

        const text =
          m.message.conversation ||
          m.message.extendedTextMessage?.text;

        const isReply =
          m.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id &&
          m.key.remoteJid === from;

        if (!isReply) return;

        if (!/^\d+$/.test(text)) {
          return conn.sendMessage(from, {
            text: `╭─❌ *INVALID REPLY*
│
│ Please reply with number:
│ 1 - ${list.length}
╰───────────────`
          }, { quoted: m });
        }

        const choice = parseInt(text);
        if (choice < 1 || choice > list.length) {
          return conn.sendMessage(from, {
            text: `╭─❌ *WRONG OPTION*
│
│ Choose number between:
│ 1 - ${list.length}
╰───────────────`
          }, { quoted: m });
        }

        finished = true;
        conn.ev.off("messages.upsert", listener);

        await conn.sendMessage(from, {
          react: { text: "📥", key: m.key }
        });

        const selected = list[choice - 1];

        try {
          const lyricRes = await axios.get(
            `https://lyric-api.netlify.app/.netlify/functions/lyrics?url=${encodeURIComponent(selected.url)}`
          );

          const data = lyricRes.data;

          if (!data?.lyrics) {
            throw new Error("Lyrics not found!");
          }

          const lyricsText = `
╭━━━━━〔 *LYRICS PANEL* 〕━━━━━⬣
┃
┃ 🎵 *Title:* ${data.title || selected.title}
┃ 👤 *Artist:* ${data.category || selected.category || "Unknown"}
┃ ✍️ *Author:* ${data.author || "Unknown"}
┃ 📅 *Date:* ${data.date || selected.date || "Unknown"}
┃ 🤖 *Bot:* ${botname}
┃ 👑 *Creator:* ${data.creator || "THENUX"}
┃
┣━━━━━━━━━━━━━━━━━━━━⬣
┃              *LYRICS*
╰━━━━━━━━━━━━━━━━━━━━⬣

${data.lyrics.slice(0, 4000)}

━━━━━━━━━━━━━━━━━━━━
🔗 *Source:* ${data.source || selected.url}

${botfooter}`;

          await conn.sendMessage(from, {
            text: lyricsText
          }, { quoted: m });

          await conn.sendMessage(from, {
            react: { text: "✅", key: m.key }
          });

        } catch (err) {
          await conn.sendMessage(from, {
            text: `╭─❌ *LYRICS ERROR*
│
│ ${err.message}
╰───────────────`
          }, { quoted: m });
        }
      };

      conn.ev.on("messages.upsert", listener);

      setTimeout(() => {
        if (!finished) {
          conn.ev.off("messages.upsert", listener);
          finished = true;
        }
      }, 60000);

    } catch (err) {
      await conn.sendMessage(from, {
        text: `╭─❌ *ERROR*
│
│ ${err.message}
╰───────────────`
      }, { quoted: mek });
    }
  }
};
