const axios = require('axios');
const { ReadData } = require('../database');

const styles = [
    {
        name: 'Reflected Neon',
        url: 'https://textpro.me/create-online-reflected-neon-text-effect-1157.html'
    },
    {
        name: 'Neon Light',
        url: 'https://textpro.me/neon-light-text-effect-online-882.html'
    },
    {
        name: 'Glitch Text',
        url: 'https://textpro.me/create-impressive-glitch-text-effects-online-1027.html'
    },
    {
        name: 'Blackpink',
        url: 'https://textpro.me/create-blackpink-logo-style-online-1001.html'
    },
    {
        name: 'Avengers',
        url: 'https://textpro.me/create-3d-avengers-logo-online-974.html'
    },
    {
        name: 'Thunder',
        url: 'https://textpro.me/online-thunder-text-effect-generator-1031.html'
    },
    {
        name: 'Magma Hot',
        url: 'https://textpro.me/create-a-magma-hot-text-effect-online-1030.html'
    },
    {
        name: '3D Stone',
        url: 'https://textpro.me/3d-stone-cracked-cool-text-effect-1029.html'
    },
    {
        name: 'Matrix',
        url: 'https://textpro.me/matrix-style-text-effect-online-884.html'
    },
    {
        name: 'Firework Sparkle',
        url: 'https://textpro.me/firework-sparkle-text-effect-930.html'
    },
    {
        name: 'Sand Writing',
        url: 'https://textpro.me/write-in-sand-summer-beach-free-online-991.html'
    },
    {
        name: 'Luxury Gold',
        url: 'https://textpro.me/gold-text-effect-in-3d-online-1003.html'
    },
    {
        name: 'Horror Blood',
        url: 'https://textpro.me/horror-blood-text-effect-online-883.html'
    },
    {
        name: 'Rainbow Shine',
        url: 'https://textpro.me/3d-rainbow-color-calligraphy-text-effect-1049.html'
    },
    {
        name: 'Blue Neon',
        url: 'https://textpro.me/create-blue-neon-light-text-effect-online-1041.html'
    }
];

module.exports = {
    name: 'logo',
    alias: ['textpro', 'maker', 'logomaker'],
    run: async ({ conn, mek, from, q }) => {

        if (!q) {
            return conn.sendMessage(from, {
                text: `╭─❌ *MISSING TEXT*
│
│ Example:
│ .logo Thenux
╰───────────────`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '🎨', key: mek.key }
        });

        try {
            const number = conn.user.id.split(':')[0];

            const botname =
                await ReadData(number, 'BOT_NAME') || 'THENUX BOT';

            const botfooter =
                await ReadData(number, 'BOT_FOOTER') || '© THENUX';

            const list = styles.map((s, i) => {
                return `❰ ${i + 1} ❱ *${s.name}*`;
            }).join('\n');

            const caption = `
╭────♡◉◉◉♡────⌬
🎨 *TEXT LOGO MAKER*
╰────♡◉◉◉♡────⌬

📝 *Text:* ${q}

───────────────

${list}

───────────────

💌 *Reply:* 1 - ${styles.length}

${botfooter}
`;

            const sentMsg = await conn.sendMessage(from, {
                text: caption
            }, { quoted: mek });

            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];

                try {
                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                    if (!isReply) return;

                    const index = parseInt(text) - 1;

                    if (isNaN(index) || !styles[index]) {
                        return conn.sendMessage(from, {
                            text: `❌ Reply with a valid number: 1 - ${styles.length}`
                        }, { quoted: msg });
                    }

                    conn.ev.off('messages.upsert', listener);

                    const selected = styles[index];

                    await conn.sendMessage(from, {
                        react: { text: '⏳', key: msg.key }
                    });

                    const apiUrl =
                        `https://api.bk9.dev/maker/textpro-1?text=${encodeURIComponent(q)}&url=${encodeURIComponent(selected.url)}`;

                    const { data } = await axios.get(apiUrl, {
                        timeout: 120000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0'
                        }
                    });

                    if (!data?.status || !data?.BK9) {
                        throw new Error('Logo generation failed');
                    }

                    const imgRes = await axios.get(data.BK9, {
                        responseType: 'arraybuffer',
                        timeout: 60000,
                        headers: {
                            'User-Agent':
                                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36',
                            'Accept':
                                'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
                            'Referer': 'https://textpro.me/'
                        }
                    });

                    const imgBuffer = Buffer.from(imgRes.data);

                    await conn.sendMessage(from, {
                        image: imgBuffer,
                        caption: `╭────♡◉◉◉♡────⌬
✅ *LOGO CREATED*
🎨 *${selected.name}*
╰────♡◉◉◉♡────⌬

📝 *Text:* ${q}
🤖 *Bot:* ${botname}

${botfooter}`
                    }, { quoted: msg });

                    await conn.sendMessage(from, {
                        react: { text: '✅', key: msg.key }
                    });

                } catch (err) {
                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        text: `╭─❌ *LOGO ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
                    }, { quoted: msg });
                }
            };

            conn.ev.on('messages.upsert', listener);

            setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (err) {
            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });

            await conn.sendMessage(from, {
                text: `╭─❌ *TEXTPRO ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
            }, { quoted: mek });
        }
    }
};
