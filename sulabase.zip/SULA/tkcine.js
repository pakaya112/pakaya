const axios = require("axios");
const { ReadData } = require("../database");

const API_URL = 'https://tkcine.udmodz-2ab.workers.dev/';

module.exports = {
    name: "movie",
    alias: ["tkcine", "film"],
    category: "movie",
    description: "Search and download movies via direct stream.",

    run: async ({ conn, mek, from, q }) => {
        try {
            const number = conn.user.id.split(':')[0];

            const botname = await ReadData(number, "BOT_NAME");
            const botfooter = await ReadData(number, "BOT_FOOTER");

            if (!q) {
                return await conn.sendMessage(from, {
                    text: `
╭────♡◉◉◉♡────⌬
🎬 *MOVIE SEARCH PANEL*  
🌸 *${botname} Movie Downloader* ✨  
╰────♡◉◉◉♡────⌬

❌ *Please provide movie name*

📌 *Example:*  
➤ .movie deadpool

💖 Search and download movies easily.

${botfooter}
`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, {
                react: { text: "🎬", key: mek.key }
            });

            const searchRes = await axios.get(`${API_URL}/search?q=${encodeURIComponent(q)}`);
            const results = searchRes.data?.results;

            if (!results || results.length === 0) {
                return await conn.sendMessage(from, {
                    text: `❌ No movies found for "${q}"!\n\n${botfooter}`
                }, { quoted: mek });
            }

            let movieListText = "";
            results.slice(0, 10).forEach((movie, index) => {
                const rating = movie.imdbRating ? ` ⭐ ${movie.imdbRating}` : "";
                movieListText += `*${index + 1}.* ${movie.title} (${movie.year || 'N/A'})\n➤ Category: ${movie.category || 'N/A'}${rating}\n\n`;
            });

            const caption = `
╭────♡◉◉◉♡────⌬
🎬 *MOVIE SEARCH RESULTS*  
🌸 *${botname} found your movies ✨*  
╰────♡◉◉◉♡────⌬

${movieListText}───────────────

💌 *Reply with the number (1-${results.slice(0, 10).length}) of the movie you want to download.*

${botfooter}
`;

            const sentMessage = await conn.sendMessage(from, {
                image: { url: results[0].thumbnail || 'https://i.imgur.com/example.jpg' },
                caption
            }, { quoted: mek });

            const messageID = sentMessage.key.id;

            const timeout = setTimeout(() => {
                conn.ev.off("messages.upsert", handler);
            }, 60000);

            const handler = async (msgUpdate) => {
                try {
                    const msg = msgUpdate.messages[0];

                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message?.extendedTextMessage?.contextInfo?.stanzaId === messageID;

                    if (!isReply) return;

                    const selectedIndex = parseInt(text.trim()) - 1;

                    if (isNaN(selectedIndex) || selectedIndex < 0 || selectedIndex >= results.length) {
                        return await conn.sendMessage(from, {
                            text: "❌ Invalid selection. Please reply with a valid number."
                        }, { quoted: msg });
                    }

                    await conn.sendMessage(from, {
                        react: { text: "⬇️", key: msg.key }
                    });

                    clearTimeout(timeout);

                    const selectedMovie = results[selectedIndex];
                    const movieId = selectedMovie.id;
                    const streamUrl = `${API_URL}/stream?id=${movieId}&q=480p`;

                    await conn.sendMessage(from, {
                        document: { url: streamUrl },
                        mimetype: "video/mp4",
                        fileName: `${selectedMovie.title} (480p).mp4`,
                        caption: `
╭────♡◉◉◉♡────⌬
🎬 *MOVIE DOWNLOADED*  
✨ *${botname} delivered your movie*  
╰────♡◉◉◉♡────⌬

📌 ${selectedMovie.title}
⚡ Category: ${selectedMovie.category || 'N/A'}

💖 Enjoy your movie ✨

${botfooter}
`
                    }, { quoted: msg });

                    await conn.sendMessage(from, {
                        react: { text: "✅", key: msg.key }
                    });

                    conn.ev.off("messages.upsert", handler);

                } catch (err) {
                    conn.ev.off("messages.upsert", handler);

                    await conn.sendMessage(from, {
                        text: `❌ Error: ${err.message}`
                    }, { quoted: mek });
                }
            };

            conn.ev.on("messages.upsert", handler);

        } catch (err) {
            await conn.sendMessage(from, {
                text: `
❌ *Movie Search Failed*

📌 Reason: ${err.message}

${botfooter || ""}
`
            }, { quoted: mek });
        }
    }
};
