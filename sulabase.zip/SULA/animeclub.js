const axios = require('axios');
const { ReadData } = require('../database');

const SEARCH_API = 'https://api-site-hkmw.vercel.app/api/search';
const MOVIE_API = 'https://api-site-hkmw.vercel.app/api/movie';
const TV_API = 'https://api-site-hkmw.vercel.app/api/tv';
const EPISODE_API = 'https://api-site-hkmw.vercel.app/api/episode';

const DEFAULT_IMAGE =
'https://raw.githubusercontent.com/sulamadara1147/data/main/file_00000000097071fabaedacd96b9efefc.png';

module.exports = {
    name: 'anime',
    alias: ['animeclub', 'aclub'],

    run: async ({ conn, mek, from, q }) => {

        if (!mek.key.fromMe) {
            return await conn.sendMessage(from, {
                text: `❌ You are not allowed to use this command.

Want access to this feature?

Create your own bot:
🌐 https://sulaofc.store/bots`
            }, { quoted: mek });
        }

        const number =
            conn.user.id.split(':')[0];

        const botname =
            await ReadData(
                number,
                'BOT_NAME'
            ) || 'SULA MD';

        const botfooter =
            await ReadData(
                number,
                'BOT_FOOTER'
            ) || '© SULA MD';

        if (!q) {
            return conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
🎌 *Anime Search*
╰────♡◉◉◉♡────⌬

Example:

.anime demon

.anime 9476xxxxxxx@s.whatsapp.net demon

${botfooter}`
            }, { quoted: mek });
        }

        const args =
            q.trim().split(' ');

        let targetJid = null;
        let searchQuery = q;
        let isCustomTarget = false;

        if (
            args[0]?.includes('@s.whatsapp.net') ||
            args[0]?.includes('@g.us') ||
            args[0]?.includes('@lid')
        ) {

            targetJid = args[0];
            searchQuery =
                args.slice(1).join(' ');

            isCustomTarget = true;
        }

        await conn.sendMessage(from, {
            react: {
                text: '⏳',
                key: mek.key
            }
        });

        try {

            const { data } =
                await axios.get(
                    `${SEARCH_API}?q=${encodeURIComponent(searchQuery)}`
                );

            if (
                !data.success ||
                !data.data?.length
            ) {
                throw new Error(
                    'No results found'
                );
            }

            const results =
                data.data.slice(0, 10);

            const list =
                results.map((x, i) =>
                    `❰ ${i + 1} ❱ *${x.title}*
📺 ${x.type}`
                ).join('\n\n');

            const sentMsg =
                await conn.sendMessage(
                    from,
                    {
                        image: {
                            url: DEFAULT_IMAGE
                        },
                        caption: `╭────♡◉◉◉♡────⌬
🎌 *Anime Search Results*
╰────♡◉◉◉♡────⌬

${list}

───────────────

Reply: 1 - ${results.length}

> AnImEs By || MiZtY AnImEs || mizty.site 🌌

${botfooter}`
                    },
                    { quoted: mek }
                );

            await conn.sendMessage(from, {
    audio: {
        url: 'https://raw.githubusercontent.com/sulamadara1147/data/main/suzume.opus'
    },
    mimetype: 'audio/ogg; codecs=opus',
    ptt: true
}, { quoted: mek });

            const listener =
                async (msgUpdate) => {

                const msg =
                    msgUpdate.messages[0];

                if (!msg.message) return;

                const text =
                    msg.message.conversation ||
                    msg.message.extendedTextMessage?.text;

                const isReply =
                    msg.message
                        ?.extendedTextMessage
                        ?.contextInfo
                        ?.stanzaId === sentMsg.key.id;

                if (!isReply) return;

                const index =
                    parseInt(text) - 1;

                if (
                    isNaN(index) ||
                    !results[index]
                ) {
                    return conn.sendMessage(
                        from,
                        {
                            text: '❌ Invalid Selection'
                        },
                        { quoted: msg }
                    );
                }

                conn.ev.off(
                    'messages.upsert',
                    listener
                );

                const selected =
                    results[index];

                await conn.sendMessage(from, {
                    react: {
                        text: '📥',
                        key: msg.key
                    }
                });

                if (
                    selected.type
                        .toLowerCase()
                        .includes('movie')
                ) {

                    return await showMovieInfo(
                        conn,
                        msg,
                        from,
                        targetJid,
                        isCustomTarget,
                        selected.url,
                        botname,
                        botfooter
                    );
                }

                return await showTVInfo(
                    conn,
                    msg,
                    from,
                    targetJid,
                    isCustomTarget,
                    selected.url,
                    botname,
                    botfooter
                );

            };

            conn.ev.on(
                'messages.upsert',
                listener
            );

            setTimeout(() => {

                conn.ev.off(
                    'messages.upsert',
                    listener
                );

            }, 60000);

        } catch (err) {

            return conn.sendMessage(from, {
                text: `❌ ${err.message}`
            }, { quoted: mek });

        }

    }
};

async function showMovieInfo(
    conn,
    quotedMsg,
    from,
    targetJid,
    isCustomTarget,
    movieUrl,
    botname,
    botfooter
) {

    const { data } =
        await axios.get(
            `${MOVIE_API}?info=${encodeURIComponent(movieUrl)}`
        );

    if (!data.success) {
        throw new Error(
            'Movie details not found'
        );
    }

    const movie = data;
    const downloads =
        movie.downloads || [];

    const list =
        downloads.map((x, i) =>
            `❰ ${i + 1} ❱ ${x.quality}`
        ).join('\n');

    const sentMsg =
        await conn.sendMessage(
            from,
            {
                image: {
                    url: movie.poster
                },
                caption: `╭────♡◉◉◉♡────⌬
🎬 *${movie.title}*
╰────♡◉◉◉♡────⌬

⭐ ${movie.date}
⏳ ${movie.duration}

${list}

───────────────

Reply: 1 - ${downloads.length}

> AnImEs By || MiZtY AnImEs || mizty.site 🌌

${botfooter}`
            },
            { quoted: quotedMsg }
        );

    const listener =
        async (msgUpdate) => {

        const msg =
            msgUpdate.messages[0];

        if (!msg.message) return;

        const text =
            msg.message.conversation ||
            msg.message.extendedTextMessage?.text;

        const isReply =
            msg.message
                ?.extendedTextMessage
                ?.contextInfo
                ?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        const index =
            parseInt(text) - 1;

        if (
            isNaN(index) ||
            !downloads[index]
        ) {
            return conn.sendMessage(
                from,
                {
                    text: '❌ Invalid Quality'
                },
                { quoted: msg }
            );
        }

        conn.ev.off(
            'messages.upsert',
            listener
        );

        await conn.sendMessage(from, {
            react: {
                text: '⬇️',
                key: msg.key
            }
        });

        await showMovieDownloadMenu(
            conn,
            msg,
            from,
            targetJid,
            isCustomTarget,
            {
                title: movie.title,
                poster: movie.poster,
                quality:
                    downloads[index].quality,
                link:
                    downloads[index].link,
                botname,
                botfooter
            }
        );

    };

    conn.ev.on(
        'messages.upsert',
        listener
    );

    setTimeout(() => {
        conn.ev.off(
            'messages.upsert',
            listener
        );
    }, 60000);
}

async function showMovieDownloadMenu(
    conn,
    quotedMsg,
    from,
    targetJid,
    isCustomTarget,
    info
) {

    const caption = `╭────♡◉◉◉♡────⌬
📥 *Movie Options*
✨ *${info.botname}*
╰────♡◉◉◉♡────⌬

🎬 *Title*
➤ ${info.title}

💎 *Quality*
➤ ${info.quality}

───────────────

📁 ❶ Send Movie

🔗 ❷ Direct Link

───────────────

Reply: 1 / 2

> AnImEs By || MiZtY AnImEs || mizty.site 🌌

${info.botfooter}`;

    const sentMsg =
        await conn.sendMessage(
            from,
            {
                image: {
                    url: info.poster
                },
                caption
            },
            { quoted: quotedMsg }
        );

    const listener =
        async (msgUpdate) => {

        const msg =
            msgUpdate.messages[0];

        if (!msg.message) return;

        const text =
            msg.message.conversation ||
            msg.message.extendedTextMessage?.text;

        const isReply =
            msg.message
                ?.extendedTextMessage
                ?.contextInfo
                ?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        conn.ev.off(
            'messages.upsert',
            listener
        );

        const doneCaption = `
╭──〔 🌸 Anime Movie Delivery 🌸 〕──⬣

૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა Your anime is ready~ 💕

🎬 Title ➜ ${info.title}

━━━━━━━━━━━━━━━

🍿 Enjoy your watch time!

🌸 Thanks for using ${info.botname}

♡ Powered By 🌐 https://sulaofc.store

anime • movies • series • updates

━━━━━━━━━━━━━━━`;

        if (text === '1') {

            const fileName =
                info.title
                    .replace(/[\\/:*?"<>|]/g, '')
                    .trim() + '.mp4';

            await conn.sendMessage(
    targetJid || from,
    {
        document: {
            url: info.link
        },
        mimetype: 'video/mp4',
        fileName,
        caption: doneCaption
    },
    { quoted: msg }
);

            if (
                isCustomTarget &&
                targetJid
            ) {

                await conn.sendMessage(
                    from,
                    {
                        text: `✅ Successfully Sent

📤 To:
${targetJid}`
                    },
                    { quoted: msg }
                );

            }

        } else {

            await conn.sendMessage(
                from,
                {
                    text: `${doneCaption}

🔗 Direct Download Link

${info.link}`
                },
                { quoted: msg }
            );

        }

        await conn.sendMessage(from, {
            react: {
                text: '✅',
                key: msg.key
            }
        });

    };

    conn.ev.on(
        'messages.upsert',
        listener
    );

    setTimeout(() => {
        conn.ev.off(
            'messages.upsert',
            listener
        );
    }, 60000);
}

async function showTVInfo(
    conn,
    quotedMsg,
    from,
    targetJid,
    isCustomTarget,
    tvUrl,
    botname,
    botfooter
) {

    const { data } =
        await axios.get(
            `${TV_API}?info=${encodeURIComponent(tvUrl)}`
        );

    if (!data.success) {
        throw new Error(
            'TV Series not found'
        );
    }

    const tv = data;
    const seasons =
        tv.seasons || [];

    const list =
        seasons.map((x, i) =>
            `❰ ${i + 1} ❱ ${x.title}
📦 ${x.total_episodes} Episodes`
        ).join('\n\n');

    const sentMsg =
        await conn.sendMessage(
            from,
            {
                image: {
                    url: tv.poster
                },
                caption: `╭────♡◉◉◉♡────⌬
📺 *${tv.show_title}*
╰────♡◉◉◉♡────⌬

${list}

───────────────

Reply: 1 - ${seasons.length}

> AnImEs By || MiZtY AnImEs || mizty.site 🌌

${botfooter}`
            },
            { quoted: quotedMsg }
        );

    const listener =
        async (msgUpdate) => {

        const msg =
            msgUpdate.messages[0];

        if (!msg.message) return;

        const text =
            msg.message.conversation ||
            msg.message.extendedTextMessage?.text;

        const isReply =
            msg.message?.extendedTextMessage
                ?.contextInfo?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        const index =
            parseInt(text) - 1;

        if (
            isNaN(index) ||
            !seasons[index]
        ) {
            return conn.sendMessage(from, {
                text: '❌ Invalid Season'
            }, { quoted: msg });
        }

        conn.ev.off(
            'messages.upsert',
            listener
        );

        await conn.sendMessage(from, {
            react: {
                text: '📥',
                key: msg.key
            }
        });

        await showEpisodes(
            conn,
            msg,
            from,
            targetJid,
            isCustomTarget,
            seasons[index],
            tv.show_title,
            botname,
            botfooter
        );

    };

    conn.ev.on(
        'messages.upsert',
        listener
    );

    setTimeout(() => {
        conn.ev.off(
            'messages.upsert',
            listener
        );
    }, 60000);
}

async function showEpisodes(
    conn,
    quotedMsg,
    from,
    targetJid,
    isCustomTarget,
    season,
    seriesTitle,
    botname,
    botfooter
) {

    const episodes =
        season.episodes || [];

    const list =
        episodes
            .slice(0, 30)
            .map((x, i) =>
                `❰ ${i + 1} ❱ ${x.title}`
            )
            .join('\n');

    const sentMsg =
        await conn.sendMessage(
            from,
            {
                text: `╭────♡◉◉◉♡────⌬
📺 *${seriesTitle}*
╰────♡◉◉◉♡────⌬

🎬 ${season.title}

${list}

───────────────

Reply: 1 - ${episodes.length}

> AnImEs By || MiZtY AnImEs || mizty.site 🌌

${botfooter}`
            },
            { quoted: quotedMsg }
        );

    const listener =
        async (msgUpdate) => {

        const msg =
            msgUpdate.messages[0];

        if (!msg.message) return;

        const text =
            msg.message.conversation ||
            msg.message.extendedTextMessage?.text;

        const isReply =
            msg.message?.extendedTextMessage
                ?.contextInfo?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        const index =
            parseInt(text) - 1;

        if (
            isNaN(index) ||
            !episodes[index]
        ) {
            return conn.sendMessage(from, {
                text: '❌ Invalid Episode'
            }, { quoted: msg });
        }

        conn.ev.off(
            'messages.upsert',
            listener
        );

        await conn.sendMessage(from, {
            react: {
                text: '📥',
                key: msg.key
            }
        });

        await showEpisodeDownloads(
            conn,
            msg,
            from,
            targetJid,
            isCustomTarget,
            episodes[index].url,
            botname,
            botfooter
        );

    };

    conn.ev.on(
        'messages.upsert',
        listener
    );

    setTimeout(() => {
        conn.ev.off(
            'messages.upsert',
            listener
        );
    }, 60000);
}

async function showEpisodeDownloads(
    conn,
    quotedMsg,
    from,
    targetJid,
    isCustomTarget,
    episodeUrl,
    botname,
    botfooter
) {

    const { data } =
        await axios.get(
            `${EPISODE_API}?url=${encodeURIComponent(episodeUrl)}`
        );

    if (!data.success) {
        throw new Error(
            'Episode download links not found'
        );
    }

    const downloads =
        data.downloads || [];

    const list =
        downloads.map((x, i) =>
            `❰ ${i + 1} ❱ ${x.quality}`
        ).join('\n');

    const sentMsg =
        await conn.sendMessage(
            from,
            {
                text: `╭────♡◉◉◉♡────⌬
📥 *Episode Download*
╰────♡◉◉◉♡────⌬

🎬 ${data.title}

${list}

───────────────

Reply: 1 - ${downloads.length}

> AnImEs By || MiZtY AnImEs || mizty.site 🌌

${botfooter}`
            },
            { quoted: quotedMsg }
        );

    const listener =
        async (msgUpdate) => {

        const msg =
            msgUpdate.messages[0];

        if (!msg.message) return;

        const text =
            msg.message.conversation ||
            msg.message.extendedTextMessage?.text;

        const isReply =
            msg.message?.extendedTextMessage
                ?.contextInfo?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        const index =
            parseInt(text) - 1;

        if (
            isNaN(index) ||
            !downloads[index]
        ) {
            return conn.sendMessage(from, {
                text: '❌ Invalid Quality'
            }, { quoted: msg });
        }

        conn.ev.off(
            'messages.upsert',
            listener
        );

        const selected =
            downloads[index];

        await conn.sendMessage(from, {
            react: {
                text: '⬇️',
                key: msg.key
            }
        });

        const doneCaption = `
╭──〔 🌸 Anime Episode Delivery 🌸 〕──⬣

૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა Your anime is ready~ 💕

🎬 Title ➜ ${data.title}

━━━━━━━━━━━━━━━

🍿 Enjoy your watch time!

🌸 Thanks for using ${botname}

♡ Powered By 🌐 https://sulaofc.store

anime • movies • series • updates

━━━━━━━━━━━━━━━`;
        
        await conn.sendMessage(
    targetJid || from,
    {
        document: {
            url: selected.link
        },
        mimetype: 'video/mp4',
        fileName: data.title
            .replace(/[\\/:*?"<>|]/g, '')
            .trim() + '.mp4',
        caption: doneCaption
    },
    { quoted: msg }
);

        if (
            isCustomTarget &&
            targetJid
        ) {

            await conn.sendMessage(
                from,
                {
                    text: `✅ Successfully Sent

📤 To:
${targetJid}`
                },
                { quoted: msg }
            );

        }

        await conn.sendMessage(from, {
            react: {
                text: '✅',
                key: msg.key
            }
        });

    };

    conn.ev.on(
        'messages.upsert',
        listener
    );

    setTimeout(() => {
        conn.ev.off(
            'messages.upsert',
            listener
        );
    }, 60000);
}
