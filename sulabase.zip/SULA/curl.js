const axios = require('axios');

/**
 * Parses raw cURL command strings into Axios request configurations
 */
function parseCurl(curlString) {
    // Clean up line continuations (\) and extra whitespace
    const cleanCurl = curlString.replace(/\\\r?\n/g, ' ').replace(/\s+/g, ' ').trim();

    // Match arguments handling quoted strings
    const regex = /(?:[^\s"']+|"[^"]*"|'[^']*')+/g;
    const args = cleanCurl.match(regex) || [];

    let method = 'GET';
    let url = '';
    const headers = {};
    let data = null;

    for (let i = 0; i < args.length; i++) {
        let arg = args[i].replace(/^['"]|['"]$/g, ''); // strip outer quotes

        if (arg === 'curl' || arg === '-s' || arg === '--compressed' || arg === '-k') {
            continue;
        }

        if (arg === '-X' || arg === '--request') {
            method = args[++i].replace(/^['"]|['"]$/g, '').toUpperCase();
        } else if (arg === '-H' || arg === '--header') {
            const headerStr = args[++i].replace(/^['"]|['"]$/g, '');
            const colonIndex = headerStr.indexOf(':');
            if (colonIndex !== -1) {
                const key = headerStr.substring(0, colonIndex).trim();
                const value = headerStr.substring(colonIndex + 1).trim();
                headers[key] = value;
            }
        } else if (arg === '-d' || arg === '--data' || arg === '--data-raw' || arg === '--data-binary') {
            if (method === 'GET') method = 'POST';
            const rawData = args[++i].replace(/^['"]|['"]$/g, '');
            try {
                data = JSON.parse(rawData);
            } catch (e) {
                data = rawData;
            }
        } else if (arg.startsWith('http://') || arg.startsWith('https://')) {
            url = arg;
        }
    }

    if (!url) throw new Error("Could not extract a valid target URL from the provided cURL command.");

    return { method, url, headers, data };
}

module.exports = {
    name: 'curl',
    alias: ['bashcurl', 'execute', 'req'],
    category: 'tools',
    description: 'Executes raw multi-line cURL commands directly in WhatsApp',

    run: async ({ conn, mek, from, q }) => {
        const botfooter = '© SULA MD | Thenux Core Engine';

        if (!q) {
            return conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
🛠️ *RAW cURL RUNNER*
╰────♡◉◉◉♡────⌬

Paste your full multi-line cURL command directly after *.curl*

*Example:*
\`\`\`
.curl curl -s -X GET "https://api.example.com/data" \\
-H "Authorization: Bearer token"
\`\`\`

${botfooter}`
            }, { quoted: mek });
        }

        try {
            await conn.sendMessage(from, { react: { text: '⚡', key: mek.key } });

            // Parse raw cURL command into an Axios config
            const config = parseCurl(q);
            config.timeout = 30000; // 30-second safeguard timeout

            const startTime = Date.now();
            const response = await axios(config);
            const duration = Date.now() - startTime;

            let responseBody = typeof response.data === 'object' 
                ? JSON.stringify(response.data, null, 2) 
                : String(response.data);

            // Truncate response if it exceeds WhatsApp text limits
            if (responseBody.length > 3000) {
                responseBody = responseBody.substring(0, 3000) + '\n\n...[Output Truncated]';
            }

            const output = `╭────♡◉◉◉♡────⌬
📡 *cURL EXECUTION SUCCESSFUL*
╰────♡◉◉◉♡────⌬

🌐 *URL:* ${config.url}
⚡ *Status:* ${response.status} ${response.statusText} (${duration}ms)
🛠️ *Method:* ${config.method}

📋 *Response Payload:*
\`\`\`json
${responseBody}
\`\`\`

${botfooter}`;

            await conn.sendMessage(from, { text: output }, { quoted: mek });
            await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });

        } catch (err) {
            await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });

            let errDetail = err.message;
            if (err.response && err.response.data) {
                errDetail = typeof err.response.data === 'object'
                    ? JSON.stringify(err.response.data, null, 2)
                    : String(err.response.data);
            }

            return conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
❌ *cURL EXECUTION ERROR*
╰────♡◉◉◉♡────⌬

📌 *Details:*
\`\`\`
${errDetail}
\`\`\`

${botfooter}`
            }, { quoted: mek });
        }
    }
};
