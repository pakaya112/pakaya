const { downloadMediaMessage } = require('baileys');

module.exports = {
    name: 'setgpp',

    run: async ({
        conn,
        mek,
        from,
        isGroup,
        isAdmin,
        isBotAdmins
    }) => {

        try {

            if (!isGroup) {
                return conn.sendMessage(from, {
                    text: '❌ This command only works in groups!'
                }, { quoted: mek });
            }

            if (!isAdmin) {
                return conn.sendMessage(from, {
                    text: '❌ Only admins can use this command!'
                }, { quoted: mek });
            }

            if (!isBotAdmins) {
                return conn.sendMessage(from, {
                    text: '❌ Bot must be admin first!'
                }, { quoted: mek });
            }

            const quoted =
                mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;

            if (!quoted?.imageMessage) {

                return conn.sendMessage(from, {
                    text: '❌ Reply to an image!\n\nExample:\n.setgpp (reply image)'
                }, { quoted: mek });
            }

            const media = await downloadMediaMessage(
                {
                    key: mek.message.extendedTextMessage.contextInfo.stanzaId
                        ? {
                              remoteJid: from,
                              id: mek.message.extendedTextMessage.contextInfo.stanzaId,
                              participant: mek.message.extendedTextMessage.contextInfo.participant
                          }
                        : mek.key,
                    message: quoted
                },
                'buffer',
                {},
                {
                    logger: conn.logger,
                    reuploadRequest: conn.updateMediaMessage
                }
            );

            await conn.updateProfilePicture(from, media);

            await conn.sendMessage(from, {
                text: '✅ Group profile picture updated successfully!'
            }, { quoted: mek });

        } catch (err) {

            await conn.sendMessage(from, {
                text: `❌ Error:\n${err.message}`
            }, { quoted: mek });
        }
    }
};
