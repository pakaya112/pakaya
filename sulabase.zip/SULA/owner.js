module.exports = {
    name: 'owner',
    run: async ({ conn, mek, from }) => {

        const ownerNumber = '94703266859';
        const ownerName = '𝐒𝐔𝐋𝐀𝐊𝐒𝐇𝐀 𝐌𝐀𝐃𝐀𝐑𝐀';
        const organization = 'SULA-MD WHATSAPP BOT DEVELOPER 🍬';

        const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${ownerName}
ORG:${organization};
TEL;type=CELL;type=VOICE;waid=${ownerNumber}:${ownerNumber}
END:VCARD`;

        try {
        
            const sentMsg = await conn.sendMessage(from, {
                contacts: {
                    displayName: ownerName,
                    contacts: [{ vcard }]
                }
            }, { quoted: mek });

            const caption = `
╭────♡◉◉◉♡────⌬
👑 *OWNER DETAILS*
🌸 *Official Developer Information*
╰────♡◉◉◉♡────⌬

👤 *Name:*  
➤ Sulaksha Madara

📱 *WhatsApp:*  
➤ +94 70 326 6859

✉️ *Email:*  
➤ support@sulaofc.store

───────────────

🌐 *Facebook:*  
➤ https://www.facebook.com/profile.php?id=61580784301118

💬 *WhatsApp Group:*  
➤ https://chat.whatsapp.com/JoOoFt3SkhN80ITMDjKm80

💼 *LinkedIn:*  
➤ https://www.linkedin.com/in/sulaksha-madara

📢 *WhatsApp Channel:*  
➤ https://whatsapp.com/channel/0029Vb79RGG3WHTRUxAwqX2v

🌍 *Website:*  
➤ https://sulaofc.store

───────────────

💖 *Need Help?*

➤ Bot Support
➤ Business Inquiries
➤ Custom Bot Services

───────────────

🚀 *SULA-MD MINI BOT*
⚡ Fast • Stable • Powerful

> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃`;

            await conn.sendMessage(from, {
                text: caption,
                contextInfo: {
                    mentionedJid: [`${ownerNumber}@s.whatsapp.net`],
                    stanzaId: sentMsg.key.id
                }
            }, { quoted: mek });

        } catch (err) {
            console.error("Owner command error:", err);

            await conn.sendMessage(from, {
                text: "❌ Error sending owner info!"
            }, { quoted: mek });
        }
    }
};
