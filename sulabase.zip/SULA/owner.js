module.exports = {
    name: 'owner',
    alias: ['dev', 'developer'],

    run: async ({ conn, mek, from }) => {

        try {

            // 🔥 Baileys function inside command
            const {
                prepareWAMessageMedia
            } = await import('baileys');

            // 👑 Owner details
            const ownerNumber = '94703266859';
            const ownerName = '𝐒𝐔𝐋𝐀𝐊𝐒𝐇𝐀 𝐌𝐀𝐃𝐀𝐑𝐀';
            const organization = 'SULA-MD WHATSAPP BOT DEVELOPER 🍬';

            // 🖼️ Preview images
            const images = [
                'https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg',
                'https://raw.githubusercontent.com/sulamadara1147/data/main/file_00000000aebc81fabec39df618cbaaaa.png',
                'https://raw.githubusercontent.com/sulamadara1147/data/main/file_00000000a110820bbf9795a61a83a104.png',
                'https://raw.githubusercontent.com/sulamadara1147/data/main/file_00000000ebdc81fa86d8cfa0aff5620c.png',
                'https://raw.githubusercontent.com/sulamadara1147/data/main/file_00000000f09081fdb4a210e508f8179f.png'
            ];

            // 📇 vCard
            const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${ownerName}
ORG:${organization};
TEL;type=CELL;type=VOICE;waid=${ownerNumber}:${ownerNumber}
END:VCARD`;

            // 👤 Send contact
            const sentContact = await conn.sendMessage(
                from,
                {
                    contacts: {
                        displayName: ownerName,
                        contacts: [{ vcard }]
                    }
                },
                { quoted: mek }
            );

            // 📝 Owner caption
            const caption = `
╭────♡◉◉◉♡────⌬
👑 *OWNER DETAILS*
🌸 *Official Developer Information*
╰────♡◉◉◉♡────⌬

👤 *Name:*  
➤ Sulaksha Madara

📱 *WhatsApp:*  
➤ +94 70 326 6859

✉️ *Email:*  
➤ support@sulaofc.store

───────────────

🌐 *Facebook:*  
➤ https://www.facebook.com/profile.php?id=61580784301118

💬 *WhatsApp Group:*  
➤ https://chat.whatsapp.com/JoOoFt3SkhN80ITMDjKm80

💼 *LinkedIn:*  
➤ https://www.linkedin.com/in/sulaksha-madara

📢 *WhatsApp Channel:*  
➤ https://whatsapp.com/channel/0029Vb79RGG3WHTRUxAwqX2v

🌍 *Website:*  
➤ https://sulaofc.store

───────────────

💖 *Need Help?*

➤ Bot Support
➤ Business Inquiries
➤ Custom Bot Services

───────────────

🚀 *SULA-MD MINI BOT*
⚡ Fast • Stable • Powerful

> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃`;

            const link = 'https://sulaofc.store';

            // ⏳ Initial message
            const sent = await conn.sendMessage(
                from,
                {
                    text: `${caption}`
                },
                { quoted: mek }
            );

            // 🔄 Rotate preview in background
(async () => {

    for (const imageUrl of images) {

        try {

            const media = await prepareWAMessageMedia(
                {
                    image: {
                        url: imageUrl
                    }
                },
                {
                    upload: conn.waUploadToServer,
                    mediaTypeOverride: 'thumbnail-link'
                }
            );

            const imageMessage = media.imageMessage;

            await conn.sendMessage(
                from,
                {
                    edit: sent.key,
                    text: caption,
                    linkPreview: {
                        'matched-text': link,
                        title: 'SULA MD • Owner',
                        description: 'Official SULA-MD WhatsApp Bot Developer',
                        jpegThumbnail: imageMessage?.jpegThumbnail,
                        highQualityThumbnail: imageMessage
                    }
                }
            );

            await new Promise(resolve =>
                setTimeout(resolve, 10000)
            );

        } catch (e) {
            console.log(e);
        }

    }

})();

// 🔊 Voice (send immediately)
await conn.sendMessage(
    from,
    {
        audio: {
            url: 'https://raw.githubusercontent.com/sulamadara1147/data/main/sulavoice.opus'
        },
        mimetype: 'audio/ogg; codecs=opus',
        ptt: true
    },
    { quoted: mek }
);

        } catch (err) {

            console.error(
                'OWNER COMMAND ERROR:',
                err
            );

            await conn.sendMessage(
                from,
                {
                    text: `❌ *Owner command error!*\n\n${err.message}`
                },
                { quoted: mek }
            );
        }
    }
};
