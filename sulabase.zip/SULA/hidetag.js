module.exports = {
    name: "hidetag",
    description: "Tag all members without showing their names (Available for everyone).",
    category: "group",

    run: async ({ conn, mek, from, args, isGroup, participants }) => {
        try {
        
            if (!isGroup) return conn.sendMessage(from, { text: "❌ This command can only be used in groups!" }, { quoted: mek });

            let message = args.join(" ") || (mek.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation) || "Hi everyone! 👋";

            await conn.sendMessage(from, { 
                text: message, 
                mentions: participants.map(p => p.id) 
            });

        } catch (err) {
            //console.error("HIDETAG ERROR:", err);
            await conn.sendMessage(from, { text: "❌ Error occurred!" }, { quoted: mek });
        }
    }
};
