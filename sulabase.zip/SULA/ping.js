module.exports = {
    name: 'ping',

    run: async ({ conn, mek, from }) => {

        try {
            const chatFrom =
                from ||
                mek?.key?.remoteJid ||
                mek?.key?.participant;

            if (!chatFrom) return;

            const start = Date.now();

            // ⏱️ small delay for realistic ping
            await new Promise(r => setTimeout(r, 100));

            const ping = Date.now() - start;

            await conn.sendMessage(chatFrom, {
                text: `🚀 Speed : ${ping}ms`
            }, { quoted: mek });

        } catch (err) {
            console.log("PING ERROR:", err);

            const fallback =
                from ||
                mek?.key?.remoteJid;

            if (fallback) {
                await conn.sendMessage(fallback, {
                    text: '❌ Ping failed!'
                });
            }
        }
    }
};
