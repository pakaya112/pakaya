const fs = require("fs");
const { Sticker, StickerTypes } = require("wa-sticker-formatter");

module.exports = {
    name: "sticker",
    alias: ["s", "sti"],

    run: async ({ conn, mek, from, q }) => {


const {
    default: makeWASocket,
    useMultiFileAuthState,
    delay,
    makeCacheableSignalKeyStore,
    Browsers,
    downloadContentFromMessage,
    jidNormalizedUser,
    proto,
    prepareWAMessageMedia,
    downloadMediaMessage,
    generateForwardMessageContent,
    generateWAMessageFromContent
} = await import('baileys');

        try {

            // 📥 quoted detect
            const getQuoted = (msg, type) =>
                msg?.message?.extendedTextMessage?.contextInfo?.quotedMessage?.[type + "Message"] ||
                msg?.message?.extendedTextMessage?.contextInfo?.quotedMessage?.viewOnceMessage?.message?.[type + "Message"];

            const isQuotedImage = getQuoted(mek, "image");
            const isQuotedSticker = getQuoted(mek, "sticker");
            const isDirectImage = mek.message?.imageMessage || mek.message?.viewOnceMessage?.message?.imageMessage;

            const inputType =
                isQuotedImage ? "image" :
                isQuotedSticker ? "sticker" :
                isDirectImage ? "image" :
                null;

            if (!inputType) {
                return conn.sendMessage(from, {
                    text: "⚠️ Image එකකට reply කරලා .sticker දාන්න!"
                }, { quoted: mek });
            }

            const mediaMessage = isQuotedImage || isQuotedSticker || mek.message?.imageMessage;

            // 📥 download
            const stream = await downloadContentFromMessage(mediaMessage, inputType);
            let buffer = Buffer.from([]);

            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            // 📂 temp file
            const tempFile = `./temp_${Date.now()}.${inputType === "sticker" ? "webp" : "jpg"}`;
            await fs.promises.writeFile(tempFile, buffer);

            // 🎨 create sticker
            const sticker = new Sticker(tempFile, {
                pack: "© SULA MD",
                author: "SULA",
                type: q?.includes("-c") ? StickerTypes.CROPPED : StickerTypes.FULL,
                quality: 90
            });

            const stBuff = await sticker.toBuffer();

            // 📤 send
            await conn.sendMessage(from, {
                sticker: stBuff
            }, { quoted: mek });

            // 🧹 cleanup
            fs.unlinkSync(tempFile);

        } catch (err) {
            console.error(err);

            await conn.sendMessage(from, {
                text: `❌ Sticker error:\n${err.message}`
            }, { quoted: mek });
        }
    }
};
