module.exports = {
    name: "kick",
    description: "Groups වලින් සාමාජිකයින් ඉවත් කිරීම.",
    category: "group",

    run: async ({ conn, mek, from, args, isGroup, sender, isAdmin, isBotAdmins }) => {
        try {
            
            if (!isGroup) {
                return conn.sendMessage(from, { text: "❌ Group only command!" }, { quoted: mek });
            }

            if (!isBotAdmins) {
                return conn.sendMessage(from, { text: "❌ Bot must be admin!" }, { quoted: mek });
            }

            if (!isAdmin) {
                return conn.sendMessage(from, { text: "❌ You must be admin!" }, { quoted: mek });
            }

            let user = mek.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || 
                       mek.message?.extendedTextMessage?.contextInfo?.participant || 
                       (args[0] ? args[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : null);

            if (!user) {
                return conn.sendMessage(from, { text: "⚠️ Reply / Tag / Give number!\nExample: .kick @user" }, { quoted: mek });
            }

            if (user === conn.user.id.split(":")[0] + "@s.whatsapp.net") {
                return conn.sendMessage(from, { text: "❌ You can't kick yourself!" }, { quoted: mek });
            }

            await conn.groupParticipantsUpdate(from, [user], "remove");

            return conn.sendMessage(from, { 
                text: `👢 User removed successfully! @${user.split("@")[0]}`,
                mentions: [user] 
            }, { quoted: mek });

        } catch (err) {
            // console.error("KICK ERROR:", err);
            await conn.sendMessage(from, { text: "❌ Failed to remove user!" }, { quoted: mek });
        }
    }
};
