const { MongoClient } = require('mongodb');
const fs = require('fs');
const path = require('path');
const { ReadData } = require('../database');

const SETTINGS_MONGO_URL = "mongodb+srv://sulasetting:Sulast01@cluster0.ycxpa8f.mongodb.net/minisula";
const AUTH_MONGO_URL = "mongodb+srv://sulaofc-web:sulaofcweb0112@cluster0.zzx21xb.mongodb.net/minisula";

module.exports = {
    name: 'resetsetting',
    alias: ['delsetting', 'clearsetting', 'resetsettings', 'resetpassword', 'resetall'],
    description: 'Delete bot owner settings and password from MongoDB, resetting to default',

    run: async ({ conn, mek, from }) => {
        let settingsClient;
        let authClient;

        try {
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.

Want access to this feature?

Create your own bot:
🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, { react: { text: '⏳', key: mek.key } });

            const botOwnerNumber = conn.user.id.split(':')[0].replace(/\D/g, '').trim();
            const botfooter = await ReadData(botOwnerNumber, 'BOT_FOOTER');

            settingsClient = new MongoClient(SETTINGS_MONGO_URL, { maxPoolSize: 3 });
            authClient = new MongoClient(AUTH_MONGO_URL, { maxPoolSize: 3 });

            await Promise.all([settingsClient.connect(), authClient.connect()]);

            const authDb = authClient.db("minisula");
            const passCollection = authDb.collection("password");

            const userPassDoc = await passCollection.findOne({
                $or: [{ _id: botOwnerNumber }, { number: botOwnerNumber }]
            });

            let collectionName = "settings";

            if (process.env.APP_ID && String(process.env.APP_ID).trim() !== "") {
                collectionName = `SULAAPP${String(process.env.APP_ID).trim()}`;
            } else if (userPassDoc) {
                let appId = userPassDoc.appId !== undefined ? String(userPassDoc.appId).trim() : null;
                if (!appId && userPassDoc.password) {
                    const pass = String(userPassDoc.password).trim();
                    if (pass.startsWith("SULA") && pass.length > 6) {
                        appId = pass.substring(6);
                    } else {
                        appId = pass.replace(/^SULA/i, '').replace(/^\d{2}/, '');
                    }
                }
                if (appId) {
                    collectionName = `SULAAPP${appId}`;
                }
            }

            const settingsDb = settingsClient.db("minisula");
            const settingsCollection = settingsDb.collection(collectionName);

            const settingsDeleteResult = await settingsCollection.deleteOne({
                $or: [{ id: botOwnerNumber }, { id: Number(botOwnerNumber) }]
            });

            const passDeleteResult = await passCollection.deleteOne({
                $or: [{ _id: botOwnerNumber }, { number: botOwnerNumber }]
            });

            const filePath = path.join(process.cwd(), 'SETTINGS', `${botOwnerNumber}.json`);
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
            }

            const isSettingsDeleted = settingsDeleteResult.deletedCount > 0;
            const isPassDeleted = passDeleteResult.deletedCount > 0;

            if (isSettingsDeleted || isPassDeleted) {
                await conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬
🗑️ *RESET SUCCESSFUL*
╰────♡◉◉◉♡────⌬

👤 *Bot Number:* ${botOwnerNumber}

⚙️ *Settings Deleted:* ${isSettingsDeleted ? "✅ Yes" : "ℹ️ Already Default"}

🔐 *Password Reset:* ${isPassDeleted ? "✅ Deleted (New password will be generated on .setting)" : "ℹ️ No Saved Password"}
🔄 All configurations have been restored to defaults.

${botfooter}`
                }, { quoted: mek });
            } else {
                await conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬
ℹ️ *NO SAVED DATA FOUND*
╰────♡◉◉◉♡────⌬

👤 *Bot Number:* ${botOwnerNumber}

⚠️ No custom settings or saved password found. Default configurations are already active.

${botfooter}`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });

        } catch (err) {
            await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
            await conn.sendMessage(from, {
                text: `❌ *Error:* ${err.message}`
            }, { quoted: mek });
        } finally {
            if (settingsClient) await settingsClient.close();
            if (authClient) await authClient.close();
        }
    }
};
