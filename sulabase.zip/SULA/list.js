const fs = require('fs');
const path = require('path');
const { ReadData } = require('../database');

module.exports = {
    name: 'list',
    alias: ['allcmds', 'cmdlist', 'commands'],

    run: async ({ conn, mek, from }) => {
        try {
            const date = new Date().toLocaleDateString('en-GB', { timeZone: 'Asia/Colombo' });
            const time = new Date().toLocaleTimeString('en-GB', { 
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                timeZone: 'Asia/Colombo'
            });

            const number = conn.user.id.split(':')[0];

            const Images = await ReadData(number, "SULA_IMAGE_PATH");
            const botname = await ReadData(number, "BOT_NAME");
            const botfooter = await ReadData(number, "BOT_FOOTER");

            // Targets your SULA command folder configuration directly
            const commandsDir = path.join(__dirname, '../SULA'); 
            let totalCmds = 0;
            let commandListText = "";

            if (fs.existsSync(commandsDir)) {
                const files = fs.readdirSync(commandsDir).filter(file => file.endsWith('.js'));
                totalCmds = files.length;

                // Loop through every file to extract its command name property dynamically
                commandListText = files.map((file, index) => {
                    try {
                        const fileModule = require(path.join(commandsDir, file));
                        if (fileModule && fileModule.name) {
                            return `*${index + 1}.* .${fileModule.name}`;
                        }
                    } catch (e) {
                        return `*${index + 1}.* .${file.replace('.js', '')}`;
                    }
                    return null;
                }).filter(Boolean).join('\n');
            } else {
                commandListText = "⚠️ SULA directory module path not found.";
            }

            // ===== ALL COMMANDS LIST FORMAT =====
            const caption = `
╭─────♡◉◉◉♡─────⌬
💖 *Hello User...!* 🌸  
🌷 *Complete ${botname} Dynamic List* ✨  
╰─────♡◉◉◉♡─────⌬

┆ ➤ 🌸
┆   ➤ 💫
┆     ➤ 🌷

📅 *Date:* ${date} 📆  
⌚ *Time:* ${time} ⏳  
📊 *Total Modules:* ${totalCmds}

─────────────── 💗

📜 *LOADED BOT COMMANDS:*

${commandListText}

─────────────── 🌸

🌐 *SULA-MD Mini Bot Web* 💕  
> https://sulaofc.store

┆ ✦ 🌷
┆   ➤ 💖
┆     ➤ 🌸

${botfooter}
`;

            const qcontact = {
                key: {
                    participant: "0@s.whatsapp.net",
                    remoteJid: "status@broadcast"
                },
                message: {
                    contactMessage: {
                        displayName: "SULA-MD",
                        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:SULA-MD;;;;\nFN:SULA-MD\nTEL;type=CELL;type=VOICE;waid=94703266859:+94 70 326 6859\nEND:VCARD`,
                        jpegThumbnail: null,
                        sendEphemeral: true
                    }
                }
            };

            // Send the compiled dynamic list text matching your design setup
            await conn.sendMessage(from, {
                image: { url: Images },
                caption: caption
            }, { quoted: qcontact });

        } catch (err) {
            console.error(err);
        }
    }
};
