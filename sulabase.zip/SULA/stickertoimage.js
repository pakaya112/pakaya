//const { downloadContentFromMessage } = require("baileys");


module.exports = {
    name: "take",

    run: async ({ conn, mek, from }) => {
        try {

const {
    default: makeWASocket,
    useMultiFileAuthState,
    delay,
    makeCacheableSignalKeyStore,
    Browsers,
    downloadContentFromMessage,
    jidNormalizedUser,
    proto,
    prepareWAMessageMedia,
    downloadMediaMessage,
    generateForwardMessageContent,
    generateWAMessageFromContent
} = await import('baileys');

            const quoted =
                mek.message?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage ||
                mek.message?.extendedTextMessage?.contextInfo?.quotedMessage?.viewOnceMessage?.message?.stickerMessage;

            if (!quoted) {
                return conn.sendMessage(from, {
                    text: "⚠️ Sticker එකකට reply කරලා `.take` use කරන්න!"
                }, { quoted: mek });
            }

            const stream = await downloadContentFromMessage(quoted, "sticker");
            let buffer = Buffer.from([]);

            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            await conn.sendMessage(from, {
                image: buffer,
                caption: "🖼️ Sticker converted to image"
            }, { quoted: mek });

        } catch (err) {
            console.error("TAKE ERROR:", err);

            await conn.sendMessage(from, {
                text: "❌ Failed to convert sticker!"
            }, { quoted: mek });
        }
    }
};
