const axios = require('axios');
const { ReadData } = require('../database');

const SEARCH_API = 'https://anime.mizta.site/api/search2';
const INFO_API = 'https://anime.mizta.site/api/info2';
const EPISODES_API = 'https://anime.mizta.site/api/episodes2';
const FINAL_API = 'https://anime.mizta.site/api/final2';

const DEFAULT_IMAGE = 'https://raw.githubusercontent.com/sulamadara1147/data/main/file_00000000097071fabaedacd96b9efefc.png';

module.exports = {
    name: 'animeen',
    alias: ['anen', 'animehq'],

    run: async ({ conn, mek, from, q }) => {
        try {
            // Owner Permission Check
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.\n\nWant access to this feature?\n\nCreate your own bot:\n🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'SULA MD';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© SULA MD';

            if (!q) {
                return conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬\n🎌 *Anime EN Search*\n╰────♡◉◉◉♡────⌬\n\nExample:\n\n.animeen re zero\n\n.animeen 9476xxxxxxx@s.whatsapp.net re zero\n\n${botfooter}`
                }, { quoted: mek });
            }

            const args = q.trim().split(' ');
            let targetJid = null;
            let searchQuery = q;
            let isCustomTarget = false;

            // Custom JID Target Checking
            if (
                args[0]?.includes('@s.whatsapp.net') ||
                args[0]?.includes('@g.us') ||
                args[0]?.includes('@lid')
            ) {
                targetJid = args[0];
                searchQuery = args.slice(1).join(' ');
                isCustomTarget = true;
            }

            await conn.sendMessage(from, {
                react: { text: '⏳', key: mek.key }
            });

            // 1. Search Request
            const { data } = await axios.get(`${SEARCH_API}?q=${encodeURIComponent(searchQuery)}`);

            if (!data.success || !data.data?.length) {
                throw new Error('No English subbed/dubbed results found.');
            }

            const results = data.data.slice(0, 10);
            const list = results.map((x, i) => `❰ ${i + 1} ❱ *${x.title}*\n👀 Views: ${x.views || 'N/A'}`).join('\n\n');

            const sentMsg = await conn.sendMessage(from, {
                image: { url: results[0].image || DEFAULT_IMAGE },
                caption: `╭────♡◉◉◉♡────⌬\n🎌 *Anime EN Results*\n╰────♡◉◉◉♡────⌬\n\n${list}\n\n───────────────\n\nReply: 1 - ${results.length}\n\n> AnImEs By || MiZtY AnImEs || mizty.site 🌌\n\n${botfooter}`
            }, { quoted: mek });

            // Listener 1: Handle Anime Selection
            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];
                if (!msg.message) return;

                const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                if (!isReply) return;

                const index = parseInt(text) - 1;
                if (isNaN(index) || !results[index]) {
                    return conn.sendMessage(from, { text: '❌ Invalid Selection' }, { quoted: msg });
                }

                conn.ev.off('messages.upsert', listener);
                const selected = results[index];

                await conn.sendMessage(from, { react: { text: '📥', key: msg.key } });

                // Next Step: Get Info and watch_now_link
                return await fetchAnimeInfo(conn, msg, from, targetJid, isCustomTarget, selected.url, botname, botfooter);
            };

            conn.ev.on('messages.upsert', listener);
            setTimeout(() => { conn.ev.off('messages.upsert', listener); }, 60000);

        } catch (err) {
            return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: mek });
        }
    }
};

// 2. Fetch Anime Info & Go to Episode Fetcher
async function fetchAnimeInfo(conn, quotedMsg, from, targetJid, isCustomTarget, infoUrl, botname, botfooter) {
    try {
        const { data } = await axios.get(`${INFO_API}?url=${encodeURIComponent(infoUrl)}`);

        if (!data.success || !data.data) {
            throw new Error('Failed to retrieve anime details.');
        }

        const anime = data.data;
        const watchNowLink = anime.watch_now_link;

        if (!watchNowLink) {
            throw new Error('Streaming link not found for this anime.');
        }

        // 📝 Synopsis එක දිග වැඩි නම් කෙටි කිරීම
        const cleanSynopsis = anime.overview ? (anime.overview.length > 250 ? anime.overview.slice(0, 250) + '...' : anime.overview) : 'No description available.';

        // Next Step: 3. Fetch Episodes directly using the watchNowLink
        const epReq = await axios.get(`${EPISODES_API}?url=${encodeURIComponent(watchNowLink)}`);
        
        if (!epReq.data.success || !epReq.data.data?.length) {
            throw new Error('Episodes list could not be loaded.');
        }

        const episodes = epReq.data.data;
        
        // ලැයිස්තුව ලස්සනට පෙන්වන්න (පළමු එපිසෝඩ් 30 සීමාව)
        const epListText = episodes.slice(0, 30).map(x => `❰ ${x.number} ❱ ${x.title}`).join('\n');

        const sentMsg = await conn.sendMessage(from, {
            image: { url: anime.poster || DEFAULT_IMAGE },
            caption: `╭────♡◉◉◉♡────⌬\n🌸 *${anime.title}*\n╰────♡◉◉◉♡────⌬\n\n🎯 Type: ${anime.details?.type || 'TV'}\n📅 Year: ${anime.details?.released_year || 'N/A'}\n⭐ Score: ${anime.details?.score || 'N/A'}\n🎭 Genres: ${anime.details?.genres || 'N/A'}\n\n📝 *Synopsis:*\n${cleanSynopsis}\n\n*Episodes List (Total: ${epReq.data.total_episodes}):*\n${epListText}\n\n───────────────\n\nReply with Episode Number (e.g: 1)\n\n> AnImEs By || MiZtY AnImEs || mizty.site 🌌\n\n${botfooter}`
        }, { quoted: quotedMsg });

        // Listener 2: Handle Episode Selection
        const listener = async (msgUpdate) => {
            const msg = msgUpdate.messages[0];
            if (!msg.message) return;

            const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
            const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

            if (!isReply) return;

            // User ගහන number එක අනුව හරියටම මැච් වෙන Episode එක සෙවීම
            const selectedEp = episodes.find(x => x.number === text.trim());

            if (!selectedEp) {
                return conn.sendMessage(from, { text: '❌ Invalid Episode Number. Please reply with a valid number from the list.' }, { quoted: msg });
            }

            conn.ev.off('messages.upsert', listener);
            await conn.sendMessage(from, { react: { text: '⬇️', key: msg.key } });

            // Next Step: 4. Final Download Processing
            await fetchFinalDownload(conn, msg, from, targetJid, isCustomTarget, selectedEp.url, botname, botfooter);
        };

        conn.ev.on('messages.upsert', listener);
        setTimeout(() => { conn.ev.off('messages.upsert', listener); }, 90000); // 1.5 mins timeout for typing numbers

    } catch (err) {
        return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: quotedMsg });
    }
}

// 4. Fetch Download Links & Send File
async function fetchFinalDownload(conn, quotedMsg, from, targetJid, isCustomTarget, episodeUrl, botname, botfooter) {
    try {
        const { data } = await axios.get(`${FINAL_API}?url=${encodeURIComponent(episodeUrl)}`);

        if (!data.success || !data.data?.length) {
            throw new Error('Download links are currently unavailable for this episode.');
        }

        // පළවෙනි ලින්ක් එක (Pixeldrain/Direct Link) ලබා ගැනීම
        const dlOption = data.data[0];

        const doneCaption = `\n╭──〔 🌸 Anime EN Delivery 🌸 〕──⬣\n\nYour English anime episode is ready! 🎉\n\n🎬 *Provider:* ${dlOption.provider || 'Premium'}\n💎 *Quality:* ${dlOption.quality || 'HD'}\n\n━━━━━━━━━━━━━━━\n🍿 Enjoy your watch time!\n🌸 Thanks for using ${botname}\n🌐 Powered By https://sulaofc.store\n━━━━━━━━━━━━━━━`;

        // Safe File Name එකක් සකස් කිරීම
        const safeTitle = `Anime_Episode_${Date.now()}`;
        const fileName = `${safeTitle}.mp4`;

        // Document එකක් විදිහට Video එක යැවීම
        await conn.sendMessage(targetJid || from, {
            document: { url: dlOption.direct_link },
            mimetype: 'video/mp4',
            fileName,
            caption: doneCaption
        }, { quoted: quotedMsg });

        if (isCustomTarget && targetJid) {
            await conn.sendMessage(from, {
                text: `✅ Successfully Sent!\n\n📤 To: ${targetJid}`
            }, { quoted: quotedMsg });
        }

        await conn.sendMessage(from, { react: { text: '✅', key: quotedMsg.key } });

    } catch (err) {
        return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: quotedMsg });
    }
}
