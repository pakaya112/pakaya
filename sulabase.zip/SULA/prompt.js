const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'prompt',
    alias: ['promptgen', 'makeprompt', 'aiprompt'],
    run: async ({ conn, mek, from, q }) => {

        if (!q) {
            return conn.sendMessage(from, {
                text: `╭─❌ *MISSING TOPIC*
│
│ Example:
│ .prompt ecommerce website
│ .prompt anime downloader api
│ .prompt whatsapp bot
│ .prompt portfolio website
╰───────────────`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '🧠', key: mek.key }
        });

        try {
            const number = conn.user.id.split(':')[0];

            const botname =
                await ReadData(number, 'BOT_NAME') || 'THENUX BOT';

            const botfooter =
                await ReadData(number, 'BOT_FOOTER') || '© THENUX';

            const aiQuery = `
You are an expert AI prompt engineer.

Create a powerful, detailed, professional prompt for this topic:
"${q}"

The prompt should be useful for ChatGPT, Claude, Gemini, Cursor, Bolt, Lovable, Replit, or Windsurf.

Make it:
- clear
- advanced
- production-ready
- detailed
- well structured
- include features
- include UI/UX requirements if project related
- include backend/database/API requirements if needed
- include error handling
- include deployment instructions
- include final expected output format

Return only the final prompt. Do not explain.
`;

            const apiUrl =
                `https://api.bk9.dev/ai/llama?q=${encodeURIComponent(aiQuery)}`;

            const { data } = await axios.get(apiUrl, {
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0',
                    'Accept': 'application/json'
                }
            });

            if (!data?.status || !data?.BK9) {
                throw new Error('Prompt generation failed');
            }

            let prompt = String(data.BK9).trim();

            if (prompt.length > 3500) {
                prompt = prompt.slice(0, 3500) + '\n\n...';
            }

            const response = `
╭────♡◉◉◉♡────⌬
🧠 *AI PROMPT GENERATOR*
╰────♡◉◉◉♡────⌬

📌 *Topic:* ${q}
🤖 *Model:* BK9 Llama

───────────────

${prompt}

───────────────
${botfooter}
`;

            await conn.sendMessage(from, {
                text: response
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '✅', key: mek.key }
            });

        } catch (err) {
            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });

            await conn.sendMessage(from, {
                text: `╭─❌ *PROMPT ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
            }, { quoted: mek });
        }
    }
};
