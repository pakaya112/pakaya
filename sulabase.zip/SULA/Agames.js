const crypto = require('crypto');

module.exports = {
    name: 'arcade',
    alias: ['games', 'play', 'minigames', 'hub', 'gamehub'],
    category: 'games',
    description: 'All-in-One Neon Cyber Arcade Matrix featuring 9 playable mini-games with 3x3 Main Menu navigation.',

    run: async ({ conn, client, mek, from }) => {
        const botClient = conn || client;

        try {
            await botClient.sendMessage(from, { react: { text: '🕹️', key: mek.key } });

            const response_id = crypto.randomUUID();

            const htmlGamePayload = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>CYBER ARCADE MATRIX - 9 IN 1</title>
<style>
* { -webkit-tap-highlight-color: transparent; -webkit-user-select: none; user-select: none; -webkit-touch-callout: none; box-sizing: border-box; margin: 0; padding: 0; }
body { margin: 0; background: #05070d; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #f1f5f9; touch-action: none; overflow: hidden; }
.wrapper { width: 100%; max-width: 480px; margin: auto; padding: 12px 10px 10px; }

.card { 
  background: linear-gradient(180deg, #0b0f19, #05070d); 
  border: 2px solid #00f2fe; 
  border-radius: 20px; 
  overflow: visible; 
  box-shadow: 0 0 25px rgba(0, 242, 254, 0.25), 0 16px 40px rgba(0,0,0,0.9); 
  padding: 14px 10px 10px; 
  position: relative; 
}

.border-badge {
  position: absolute;
  top: -11px;
  left: 50%;
  transform: translateX(-50%);
  background: #05070d;
  border: 1.5px solid #00f2fe;
  border-radius: 20px;
  padding: 2px 14px;
  font-size: 9px;
  font-weight: 900;
  letter-spacing: 1.8px;
  color: #00f2fe;
  box-shadow: 0 0 14px rgba(0, 242, 254, 0.5);
  text-transform: uppercase;
  white-space: nowrap;
  z-index: 30;
}

.header { display: flex; justify-content: space-between; align-items: center; margin-top: 2px; margin-bottom: 6px; }
.title { font-size: 10px; letter-spacing: 1.5px; color: #00f2fe; font-weight: 800; text-transform: uppercase; }
.top-pill { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); border-radius: 20px; padding: 4px 10px; font-size: 10px; font-weight: 800; color: #ff007f; }

.viewport { position: relative; width: 100%; height: 330px; background: #020408; border: 1.5px solid #1e293b; border-radius: 14px; overflow: hidden; }
.view-screen { display: none; width: 100%; height: 100%; position: absolute; inset: 0; }
.view-screen.active { display: flex; flex-direction: column; align-items: center; justify-content: center; }

/* 3x3 Perfectly Fitted Menu Grid */
.menu-grid { 
  display: grid; 
  grid-template-columns: repeat(3, 1fr); 
  grid-template-rows: repeat(3, 1fr); 
  gap: 6px; 
  width: 100%; 
  height: 100%; 
  padding: 8px; 
}
.menu-card { 
  background: linear-gradient(135deg, rgba(255,255,255,0.04), rgba(255,255,255,0.01)); 
  border: 1.5px solid rgba(255,255,255,0.08); 
  border-radius: 12px; 
  padding: 4px 2px; 
  display: flex; 
  flex-direction: column; 
  align-items: center; 
  justify-content: center; 
  cursor: pointer; 
  transition: 0.15s; 
}
.menu-card:active { transform: scale(0.92); border-color: #00f2fe; box-shadow: 0 0 15px rgba(0, 242, 254, 0.4); }
.menu-icon { font-size: 22px; margin-bottom: 2px; }
.menu-name { font-size: 10px; font-weight: 900; color: #fff; text-align: center; }
.menu-tag { font-size: 7.5px; font-weight: 700; color: #94a3b8; text-transform: uppercase; margin-top: 1px; }

.game-toolbar { display: none; margin-top: 8px; gap: 8px; width: 100%; }
.back-btn { flex: 1; padding: 10px; background: rgba(255,255,255,0.06); border: 1.5px solid rgba(255,255,255,0.12); border-radius: 10px; color: #cbd5e1; font-weight: 800; font-size: 12px; cursor: pointer; text-align: center; }
.back-btn:active { background: #ef4444; color: #fff; border-color: #ef4444; }

/* Car Controls */
.car-ctrls { display: none; grid-template-columns: 1fr 1fr; gap: 8px; width: 100%; margin-top: 8px; }
.ctrl-btn { padding: 10px; font-size: 13px; font-weight: 800; border: none; border-radius: 10px; color: #fff; cursor: pointer; }
.ctrl-btn-l { background: #2563eb; }
.ctrl-btn-r { background: #db2777; }

/* Tic Tac Toe */
.ttt-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; width: 220px; height: 220px; }
.ttt-cell { background: #0f172a; border: 1.5px solid #334155; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 34px; font-weight: 900; cursor: pointer; }
.ttt-cell.x { color: #00f2fe; text-shadow: 0 0 10px rgba(0,242,254,0.6); }
.ttt-cell.o { color: #ff007f; text-shadow: 0 0 10px rgba(255,0,127,0.6); }

/* RPS */
.rps-options { display: flex; gap: 12px; margin-top: 14px; }
.rps-btn { width: 68px; height: 68px; border-radius: 16px; background: #0f172a; border: 2px solid #334155; font-size: 28px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
.rps-btn:active { transform: scale(0.92); border-color: #00f2fe; }

/* Reflex */
.reflex-box { width: 200px; height: 200px; border-radius: 20px; display: flex; flex-direction: column; align-items: center; justify-content: center; font-weight: 900; cursor: pointer; text-align: center; padding: 16px; }
.reflex-waiting { background: #dc2626; color: #fff; }
.reflex-ready { background: #16a34a; color: #fff; box-shadow: 0 0 25px rgba(22,163,74,0.7); }

/* Snake Controls */
.snake-ctrls { display: none; grid-template-columns: repeat(4, 1fr); gap: 6px; width: 100%; margin-top: 8px; }
.s-btn { padding: 9px; background: #1e293b; border: 1px solid #334155; border-radius: 8px; color: #fff; font-size: 13px; font-weight: 800; cursor: pointer; }

/* Slot Machine Styling */
.slot-container { width: 100%; height: 100%; display: flex; flex-direction: column; justify-content: space-around; padding: 10px 14px; }
.slot-window { background: rgba(0, 0, 0, 0.55); border: 1.5px solid rgba(255, 215, 0, 0.25); border-radius: 14px; padding: 8px; }
.reels { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
.reel { background: rgba(255, 255, 255, 0.04); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 10px; height: 88px; display: flex; align-items: center; justify-content: center; font-size: 42px; overflow: hidden; }
.reel.spinning { animation: blurAnim 0.12s infinite alternate; }
@keyframes blurAnim { from { filter: blur(2px); transform: translateY(-4px); } to { filter: blur(2px); transform: translateY(4px); } }
.slot-banner { text-align: center; font-size: 11px; font-weight: 700; color: #dfe6e9; min-height: 18px; }
.slot-banner.win { color: #55efc4; text-shadow: 0 0 10px rgba(85, 239, 196, 0.8); font-size: 12px; }
.slot-controls { display: flex; gap: 6px; }
.bet-btn { flex: 1; padding: 7px 2px; background: rgba(255, 255, 255, 0.06); border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 10px; color: #b2bec3; font-weight: 700; font-size: 10px; cursor: pointer; }
.bet-btn.active { background: rgba(255, 215, 0, 0.2); border-color: #ffd700; color: #ffd700; }
.spin-btn { width: 100%; padding: 10px; background: linear-gradient(135deg, #f39c12, #e74c3c); border: none; border-radius: 12px; color: #fff; font-weight: 900; font-size: 13px; letter-spacing: 1px; cursor: pointer; box-shadow: 0 6px 18px rgba(231, 76, 60, 0.4); }
.spin-btn:disabled { opacity: 0.5; cursor: not-allowed; box-shadow: none; }

/* Footer Branding */
.credit-bar { margin-top: 8px; text-align: center; font-size: 10px; font-weight: 800; letter-spacing: 1.5px; color: #64748b; text-transform: uppercase; border-top: 1px dashed rgba(255,255,255,0.08); padding-top: 6px; }
.credit-bar span { color: #00f2fe; text-shadow: 0 0 8px rgba(0,242,254,0.5); }
</style>
</head>
<body>
<div class="wrapper">
  <div class="card">
    <div class="border-badge">𝚂𝚄𝙻𝙰 𝙼𝙳 𝙶𝙰𝙼𝙴𝚂</div>

    <div class="header">
      <div>
        <div class="title">CYBER ARCADE</div>
        <h2 style="font-size: 15px; font-weight: 900; color: #fff;" id="hubTitle">Select Game 🕹️</h2>
      </div>
      <div class="top-pill" id="scoreBadge">ARCADE READY</div>
    </div>

    <div class="viewport">
      <!-- 3x3 Menu Screen -->
      <div class="view-screen active" id="view-menu">
        <div class="menu-grid">
          <div class="menu-card" data-launch="car" style="border-color: rgba(245, 158, 11, 0.4);">
            <div class="menu-icon">🏎️</div>
            <div class="menu-name">Highway</div>
            <div class="menu-tag">Racer 2D</div>
          </div>
          <div class="menu-card" data-launch="ttt" style="border-color: rgba(56, 189, 248, 0.4);">
            <div class="menu-icon">❌⭕</div>
            <div class="menu-name">Tic-Tac</div>
            <div class="menu-tag">Smart AI</div>
          </div>
          <div class="menu-card" data-launch="rps" style="border-color: rgba(236, 72, 153, 0.4);">
            <div class="menu-icon">✂️</div>
            <div class="menu-name">R.P.S</div>
            <div class="menu-tag">Streak AI</div>
          </div>
          <div class="menu-card" data-launch="reflex" style="border-color: rgba(34, 197, 94, 0.4);">
            <div class="menu-icon">⚡</div>
            <div class="menu-name">Reflex</div>
            <div class="menu-tag">Speed Tap</div>
          </div>
          <div class="menu-card" data-launch="snake" style="border-color: rgba(168, 85, 247, 0.4);">
            <div class="menu-icon">🐍</div>
            <div class="menu-name">Snake</div>
            <div class="menu-tag">Retro 2D</div>
          </div>
          <div class="menu-card" data-launch="pong" style="border-color: rgba(239, 68, 68, 0.4);">
            <div class="menu-icon">🏓</div>
            <div class="menu-name">PingPong</div>
            <div class="menu-tag">Vs Paddle</div>
          </div>
          <div class="menu-card" data-launch="dino" style="border-color: rgba(139, 92, 246, 0.4);">
            <div class="menu-icon">🦖</div>
            <div class="menu-name">Dino</div>
            <div class="menu-tag">Runner 2D</div>
          </div>
          <div class="menu-card" data-launch="slice" style="border-color: rgba(244, 63, 94, 0.4);">
            <div class="menu-icon">⚔️</div>
            <div class="menu-name">Blade</div>
            <div class="menu-tag">Cyber Slice</div>
          </div>
          <div class="menu-card" data-launch="slot" style="border-color: rgba(255, 215, 0, 0.4);">
            <div class="menu-icon">🎰</div>
            <div class="menu-name">Slots</div>
            <div class="menu-tag">Lucky Spin</div>
          </div>
        </div>
      </div>

      <!-- Games Viewports -->
      <div class="view-screen" id="view-car"><canvas id="cCar" width="320" height="330"></canvas></div>
      <div class="view-screen" id="view-ttt">
        <div style="font-size: 11px; font-weight: 800; color: #94a3b8; margin-bottom: 10px;" id="tttStatus">You (X) vs AI (O) • Your Turn</div>
        <div class="ttt-grid">
          <div class="ttt-cell" data-idx="0"></div><div class="ttt-cell" data-idx="1"></div><div class="ttt-cell" data-idx="2"></div>
          <div class="ttt-cell" data-idx="3"></div><div class="ttt-cell" data-idx="4"></div><div class="ttt-cell" data-idx="5"></div>
          <div class="ttt-cell" data-idx="6"></div><div class="ttt-cell" data-idx="7"></div><div class="ttt-cell" data-idx="8"></div>
        </div>
      </div>
      <div class="view-screen" id="view-rps">
        <div style="font-size: 13px; font-weight: 800; color: #94a3b8; margin-bottom: 6px;" id="rpsResult">Pick your weapon:</div>
        <div style="font-size: 34px; height: 50px; display: flex; align-items: center; gap: 14px;">
          <span id="rpsPlayer">❔</span> vs <span id="rpsBot">🤖</span>
        </div>
        <div class="rps-options">
          <div class="rps-btn" data-choice="rock">🪨</div>
          <div class="rps-btn" data-choice="paper">📄</div>
          <div class="rps-btn" data-choice="scissors">✂️</div>
        </div>
      </div>
      <div class="view-screen" id="view-reflex">
        <div class="reflex-box reflex-waiting" id="reflexBox">
          <div style="font-size: 18px;" id="reflexText">WAIT FOR GREEN...</div>
          <div style="font-size: 11px; margin-top: 6px; opacity: 0.8;" id="reflexSub">Do not tap yet!</div>
        </div>
      </div>
      <div class="view-screen" id="view-snake"><canvas id="cSnake" width="300" height="300"></canvas></div>
      <div class="view-screen" id="view-pong"><canvas id="cPong" width="300" height="300"></canvas></div>
      <div class="view-screen" id="view-dino"><canvas id="cDino" width="320" height="330"></canvas></div>
      <div class="view-screen" id="view-slice"><canvas id="cSlice" width="320" height="330"></canvas></div>

      <!-- Slot Machine Viewport -->
      <div class="view-screen" id="view-slot">
        <div class="slot-container">
          <div class="slot-window">
            <div class="reels">
              <div class="reel" id="r1">💎</div>
              <div class="reel" id="r2">7️⃣</div>
              <div class="reel" id="r3">🍒</div>
            </div>
          </div>
          <div class="slot-banner" id="slotBanner">Select Bet & Tap Spin!</div>
          <div class="slot-controls">
            <button class="bet-btn active" data-b="10">10 🪙</button>
            <button class="bet-btn" data-b="25">25 🪙</button>
            <button class="bet-btn" data-b="50">50 🪙</button>
            <button class="bet-btn" data-b="100">100 🪙</button>
          </div>
          <button class="spin-btn" id="slotSpinBtn">SPIN 🎲</button>
        </div>
      </div>
    </div>

    <!-- External Controls -->
    <div class="car-ctrls" id="carCtrls">
      <button class="ctrl-btn ctrl-btn-l" id="leftBtn">⬅️ LEFT</button>
      <button class="ctrl-btn ctrl-btn-r" id="rightBtn">RIGHT ➡️</button>
    </div>

    <div class="snake-ctrls" id="snakeCtrls">
      <button class="s-btn" data-dir="up">⬆️</button>
      <button class="s-btn" data-dir="left">⬅️</button>
      <button class="s-btn" data-dir="down">⬇️</button>
      <button class="s-btn" data-dir="right">➡️</button>
    </div>

    <div class="game-toolbar" id="gameToolbar">
      <button class="back-btn" id="mainMenuBtn">🏠 MAIN MENU</button>
    </div>

    <div class="credit-bar">Engineered by <span>THENUX & UDMODZ</span> ⚡</div>
  </div>
</div>

<script>
(function() {
  var activeView = 'menu';
  var hubTitle = document.getElementById('hubTitle');
  var scoreBadge = document.getElementById('scoreBadge');
  var gameToolbar = document.getElementById('gameToolbar');
  var carCtrls = document.getElementById('carCtrls');
  var snakeCtrls = document.getElementById('snakeCtrls');

  function openScreen(viewId) {
    activeView = viewId;
    document.querySelectorAll('.view-screen').forEach(function(s) { s.classList.remove('active'); });
    document.getElementById('view-' + viewId).classList.add('active');

    carCtrls.style.display = (viewId === 'car') ? 'grid' : 'none';
    snakeCtrls.style.display = (viewId === 'snake') ? 'grid' : 'none';
    gameToolbar.style.display = (viewId === 'menu') ? 'none' : 'flex';

    if (viewId === 'menu') {
      hubTitle.textContent = 'Select Game 🕹️';
      scoreBadge.textContent = 'ARCADE READY';
    } else if (viewId === 'car') {
      hubTitle.textContent = 'Highway Rush 🏎️';
      scoreBadge.textContent = 'SCORE: ' + carScore;
    } else if (viewId === 'ttt') {
      hubTitle.textContent = 'Tic-Tac-Toe AI ❌⭕';
      scoreBadge.textContent = 'WINS: ' + tttWins;
      resetTTT();
    } else if (viewId === 'rps') {
      hubTitle.textContent = 'Rock Paper Scissors ✂️';
      scoreBadge.textContent = 'STREAK: ' + rpsStreak;
    } else if (viewId === 'reflex') {
      hubTitle.textContent = 'Reflex Speed Tap ⚡';
      scoreBadge.textContent = 'BEST: ' + (bestReflex ? bestReflex + 'ms' : '--');
      startReflex();
    } else if (viewId === 'snake') {
      hubTitle.textContent = 'Cyber Snake 🐍';
      scoreBadge.textContent = 'SCORE: ' + snakeScore;
      resetSnake();
    } else if (viewId === 'pong') {
      hubTitle.textContent = 'Neon Ping Pong 🏓';
      scoreBadge.textContent = 'YOU: ' + pongPlayerScore + ' | AI: ' + pongAiScore;
      resetPong();
    } else if (viewId === 'dino') {
      hubTitle.textContent = 'Dino Runner 🦖';
      scoreBadge.textContent = 'SCORE: ' + Math.floor(dinoScore);
      resetDino();
    } else if (viewId === 'slice') {
      hubTitle.textContent = 'Cyber Blade ⚔️';
      scoreBadge.textContent = 'SCORE: ' + sliceScore;
      resetSlice();
    } else if (viewId === 'slot') {
      hubTitle.textContent = 'Neon Slots 🎰';
      scoreBadge.textContent = 'COINS: ' + slotBalance;
    }
  }

  document.querySelectorAll('.menu-card').forEach(function(card) {
    card.addEventListener('pointerdown', function(e) {
      e.preventDefault();
      openScreen(card.dataset.launch);
    });
  });

  document.getElementById('mainMenuBtn').addEventListener('pointerdown', function(e) {
    e.preventDefault();
    openScreen('menu');
  });

  /* 1. HIGHWAY RUSH */
  var cvsCar = document.getElementById('cCar'), ctxCar = cvsCar.getContext('2d');
  var carW = 320, carH = 330, lanes = [55, 125, 195, 265];
  var currentLane = 1, playerX = lanes[currentLane], targetX = lanes[currentLane], playerY = carH - 60;
  var speed = 4.5, roadOffset = 0, carScore = 0, carGameOver = false, traffic = [];

  function spawnTraffic() {
    var l = Math.floor(Math.random() * lanes.length);
    var colors = ['#ef4444', '#3b82f6', '#10b981', '#8b5cf6', '#ec4899'];
    traffic.push({ x: lanes[l], y: -50, w: 24, h: 42, color: colors[Math.floor(Math.random() * colors.length)], speed: 1.5 + Math.random() * 1.5 });
  }

  function drawCar(x, y, w, h, col, isP) {
    ctxCar.save();
    ctxCar.fillStyle = '#0b0f19';
    ctxCar.fillRect(x - w/2 - 2, y - h/2 + 5, 4, 8);
    ctxCar.fillRect(x + w/2 - 2, y - h/2 + 5, 4, 8);
    ctxCar.fillRect(x - w/2 - 2, y + h/2 - 13, 4, 8);
    ctxCar.fillRect(x + w/2 - 2, y + h/2 - 13, 4, 8);
    ctxCar.fillStyle = col;
    ctxCar.fillRect(x - w/2, y - h/2, w, h);
    ctxCar.fillStyle = '#0f172a';
    ctxCar.fillRect(x - w/2 + 3, y - h/2 + (isP ? 8 : 12), w - 6, 12);
    ctxCar.fillStyle = '#93c5fd';
    ctxCar.fillRect(x - w/2 + 4, y - h/2 + (isP ? 10 : 14), w - 8, 8);
    ctxCar.restore();
  }

  var spawnT = 0;
  function updateCar() {
    if (activeView === 'car') {
      ctxCar.clearRect(0, 0, carW, carH);
      ctxCar.fillStyle = '#064e3b';
      ctxCar.fillRect(0, 0, 20, carH); ctxCar.fillRect(carW - 20, 0, 20, carH);
      ctxCar.fillStyle = '#1e293b';
      ctxCar.fillRect(20, 0, carW - 40, carH);
      ctxCar.fillStyle = '#fde68a';
      ctxCar.fillRect(20, 0, 3, carH); ctxCar.fillRect(carW - 23, 0, 3, carH);

      if (!carGameOver) roadOffset = (roadOffset + speed) % 36;
      ctxCar.fillStyle = '#f8fafc';
      for (var l = 1; l < lanes.length; l++) {
        var lx = (lanes[l - 1] + lanes[l]) / 2;
        for (var y = -36 + roadOffset; y < carH; y += 36) ctxCar.fillRect(lx - 1.5, y, 3, 18);
      }

      if (!carGameOver) {
        carScore++;
        scoreBadge.textContent = 'SCORE: ' + carScore;
        playerX += (targetX - playerX) * 0.25;
        spawnT++;
        if (spawnT > 45) { spawnTraffic(); spawnT = 0; }
      }

      for (var i = traffic.length - 1; i >= 0; i--) {
        var t = traffic[i];
        if (!carGameOver) t.y += (speed - t.speed);
        drawCar(t.x, t.y, t.w, t.h, t.color, false);
        if (Math.abs(playerX - t.x) < 20 && Math.abs(playerY - t.y) < 36 && !carGameOver) carGameOver = true;
        if (t.y > carH + 60) traffic.splice(i, 1);
      }

      if (!carGameOver) drawCar(playerX, playerY, 24, 42, '#f59e0b', true);

      if (carGameOver) {
        ctxCar.fillStyle = 'rgba(15,23,42,0.85)';
        ctxCar.fillRect(0, 0, carW, carH);
        ctxCar.textAlign = 'center';
        ctxCar.fillStyle = '#ef4444';
        ctxCar.font = '900 22px sans-serif';
        ctxCar.fillText('CRASHED! 💥', carW/2, carH/2 - 10);
        ctxCar.fillStyle = '#fbbf24';
        ctxCar.font = '700 12px sans-serif';
        ctxCar.fillText('TAP TO RESTART', carW/2, carH/2 + 25);
      }
    }
    requestAnimationFrame(updateCar);
  }

  function moveCarLeft() { if (!carGameOver && currentLane > 0) { currentLane--; targetX = lanes[currentLane]; } }
  function moveCarRight() { if (!carGameOver && currentLane < lanes.length - 1) { currentLane++; targetX = lanes[currentLane]; } }
  document.getElementById('leftBtn').addEventListener('pointerdown', function(e) { e.preventDefault(); moveCarLeft(); });
  document.getElementById('rightBtn').addEventListener('pointerdown', function(e) { e.preventDefault(); moveCarRight(); });
  cvsCar.addEventListener('pointerdown', function(e) {
    e.preventDefault();
    if (carGameOver) { carScore = 0; traffic = []; currentLane = 1; targetX = lanes[currentLane]; playerX = lanes[currentLane]; carGameOver = false; return; }
    var rect = cvsCar.getBoundingClientRect();
    var x = (e.clientX - rect.left) * (carW / rect.width);
    if (x < carW / 2) moveCarLeft(); else moveCarRight();
  });
  updateCar();

  /* 2. TIC TAC TOE */
  var tttBoard = Array(9).fill(''), tttTurn = 'X', tttGameOver = false, tttWins = 0;
  var tttStatus = document.getElementById('tttStatus'), tttCells = document.querySelectorAll('.ttt-cell');

  function checkTTTWinner(b) {
    var wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    for (var i = 0; i < wins.length; i++) {
      var w = wins[i];
      if (b[w[0]] && b[w[0]] === b[w[1]] && b[w[0]] === b[w[2]]) return b[w[0]];
    }
    if (b.every(function(cell) { return cell !== ''; })) return 'tie';
    return null;
  }

  function botMove() {
    var empty = [];
    tttBoard.forEach(function(v, i) { if (v === '') empty.push(i); });
    if (empty.length === 0 || tttGameOver) return;
    var move = empty[Math.floor(Math.random() * empty.length)];
    tttBoard[move] = 'O';
    renderTTT();
    var res = checkTTTWinner(tttBoard);
    if (res) finishTTT(res);
    else { tttTurn = 'X'; tttStatus.textContent = 'Your Turn (X)'; }
  }

  function renderTTT() {
    tttCells.forEach(function(c, i) {
      c.textContent = tttBoard[i];
      c.className = 'ttt-cell ' + (tttBoard[i] === 'X' ? 'x' : tttBoard[i] === 'O' ? 'o' : '');
    });
  }

  function finishTTT(res) {
    tttGameOver = true;
    if (res === 'X') { tttWins++; tttStatus.textContent = '🎉 You Won! Tap to replay'; scoreBadge.textContent = 'WINS: ' + tttWins; }
    else if (res === 'O') tttStatus.textContent = '💀 AI Won! Tap to replay';
    else tttStatus.textContent = '🤝 Game Tie! Tap to replay';
  }

  function resetTTT() {
    tttBoard = Array(9).fill('');
    tttTurn = 'X';
    tttGameOver = false;
    tttStatus.textContent = 'You (X) vs AI (O) • Your Turn';
    renderTTT();
  }

  tttCells.forEach(function(cell) {
    cell.addEventListener('pointerdown', function(e) {
      e.preventDefault();
      if (tttGameOver) { resetTTT(); return; }
      var idx = parseInt(cell.dataset.idx, 10);
      if (tttBoard[idx] !== '' || tttTurn !== 'X') return;
      tttBoard[idx] = 'X';
      renderTTT();
      var res = checkTTTWinner(tttBoard);
      if (res) finishTTT(res);
      else {
        tttTurn = 'O';
        tttStatus.textContent = 'AI Thinking...';
        setTimeout(botMove, 400);
      }
    });
  });

  /* 3. ROCK PAPER SCISSORS */
  var rpsStreak = 0;
  var rpsPlayer = document.getElementById('rpsPlayer'), rpsBot = document.getElementById('rpsBot'), rpsResult = document.getElementById('rpsResult');
  var emojis = { rock: '🪨', paper: '📄', scissors: '✂️' };

  document.querySelectorAll('.rps-btn').forEach(function(btn) {
    btn.addEventListener('pointerdown', function(e) {
      e.preventDefault();
      var pChoice = btn.dataset.choice;
      var choices = ['rock', 'paper', 'scissors'];
      var bChoice = choices[Math.floor(Math.random() * choices.length)];

      rpsPlayer.textContent = emojis[pChoice];
      rpsBot.textContent = emojis[bChoice];

      if (pChoice === bChoice) {
        rpsResult.textContent = '🤝 It is a Tie!';
      } else if (
        (pChoice === 'rock' && bChoice === 'scissors') ||
        (pChoice === 'paper' && bChoice === 'rock') ||
        (pChoice === 'scissors' && bChoice === 'paper')
      ) {
        rpsStreak++;
        rpsResult.textContent = '🎉 You Win!';
        scoreBadge.textContent = 'STREAK: ' + rpsStreak;
      } else {
        rpsStreak = 0;
        rpsResult.textContent = '💀 Bot Wins!';
        scoreBadge.textContent = 'STREAK: 0';
      }
    });
  });

  /* 4. REFLEX TAP */
  var reflexBox = document.getElementById('reflexBox'), reflexText = document.getElementById('reflexText'), reflexSub = document.getElementById('reflexSub');
  var reflexState = 'waiting', reflexStart = 0, reflexTimer = null, bestReflex = 0;

  function startReflex() {
    clearTimeout(reflexTimer);
    reflexState = 'waiting';
    reflexBox.className = 'reflex-box reflex-waiting';
    reflexText.textContent = 'WAIT FOR GREEN...';
    reflexSub.textContent = 'Do not tap yet!';

    var delay = 1500 + Math.random() * 2500;
    reflexTimer = setTimeout(function() {
      reflexState = 'ready';
      reflexStart = Date.now();
      reflexBox.className = 'reflex-box reflex-ready';
      reflexText.textContent = 'TAP NOW! ⚡';
      reflexSub.textContent = 'Tap as fast as you can!';
    }, delay);
  }

  reflexBox.addEventListener('pointerdown', function(e) {
    e.preventDefault();
    if (reflexState === 'waiting') {
      clearTimeout(reflexTimer);
      reflexText.textContent = 'TOO EARLY! ⚠️';
      reflexSub.textContent = 'Tap to try again';
      reflexState = 'done';
    } else if (reflexState === 'ready') {
      var ms = Date.now() - reflexStart;
      reflexText.textContent = ms + ' ms!';
      reflexSub.textContent = 'Tap to try again';
      reflexState = 'done';
      if (!bestReflex || ms < bestReflex) {
        bestReflex = ms;
        scoreBadge.textContent = 'BEST: ' + bestReflex + 'ms';
      }
    } else if (reflexState === 'done') {
      startReflex();
    }
  });

  /* 5. CYBER SNAKE */
  var cvsSnake = document.getElementById('cSnake'), ctxSnake = cvsSnake.getContext('2d');
  var gridSize = 15, snakeGridCount = 20;
  var snake = [{x: 10, y: 10}], snakeDir = {x: 0, y: -1}, nextDir = {x: 0, y: -1}, snakeFood = {x: 5, y: 5};
  var snakeScore = 0, snakeGameOver = false, snakeInterval = null;

  function spawnSnakeFood() {
    snakeFood = {
      x: Math.floor(Math.random() * snakeGridCount),
      y: Math.floor(Math.random() * snakeGridCount)
    };
  }

  function resetSnake() {
    snake = [{x: 10, y: 10}];
    snakeDir = {x: 0, y: -1};
    nextDir = {x: 0, y: -1};
    snakeScore = 0;
    snakeGameOver = false;
    spawnSnakeFood();
    clearInterval(snakeInterval);
    snakeInterval = setInterval(updateSnake, 110);
  }

  function updateSnake() {
    if (activeView !== 'snake' || snakeGameOver) return;
    snakeDir = nextDir;
    var head = {x: snake[0].x + snakeDir.x, y: snake[0].y + snakeDir.y};

    if (head.x < 0 || head.x >= snakeGridCount || head.y < 0 || head.y >= snakeGridCount) {
      snakeGameOver = true;
      return;
    }

    for (var i = 0; i < snake.length; i++) {
      if (snake[i].x === head.x && snake[i].y === head.y) {
        snakeGameOver = true;
        return;
      }
    }

    snake.unshift(head);
    if (head.x === snakeFood.x && head.y === snakeFood.y) {
      snakeScore += 10;
      scoreBadge.textContent = 'SCORE: ' + snakeScore;
      spawnSnakeFood();
    } else {
      snake.pop();
    }

    ctxSnake.clearRect(0, 0, 300, 300);
    ctxSnake.fillStyle = '#0f172a';
    ctxSnake.fillRect(0, 0, 300, 300);

    ctxSnake.fillStyle = '#ff007f';
    ctxSnake.fillRect(snakeFood.x * gridSize + 1, snakeFood.y * gridSize + 1, gridSize - 2, gridSize - 2);

    snake.forEach(function(part, idx) {
      ctxSnake.fillStyle = (idx === 0) ? '#00f2fe' : '#38bdf8';
      ctxSnake.fillRect(part.x * gridSize + 1, part.y * gridSize + 1, gridSize - 2, gridSize - 2);
    });

    if (snakeGameOver) {
      ctxSnake.fillStyle = 'rgba(15,23,42,0.85)';
      ctxSnake.fillRect(0, 0, 300, 300);
      ctxSnake.textAlign = 'center';
      ctxSnake.fillStyle = '#ef4444';
      ctxSnake.font = '900 20px sans-serif';
      ctxSnake.fillText('GAME OVER 💥', 150, 140);
      ctxSnake.fillStyle = '#fbbf24';
      ctxSnake.font = '700 12px sans-serif';
      ctxSnake.fillText('Tap screen to restart', 150, 165);
    }
  }

  document.querySelectorAll('.s-btn').forEach(function(btn) {
    btn.addEventListener('pointerdown', function(e) {
      e.preventDefault();
      var d = btn.dataset.dir;
      if (d === 'up' && snakeDir.y === 0) nextDir = {x: 0, y: -1};
      if (d === 'down' && snakeDir.y === 0) nextDir = {x: 0, y: 1};
      if (d === 'left' && snakeDir.x === 0) nextDir = {x: -1, y: 0};
      if (d === 'right' && snakeDir.x === 0) nextDir = {x: 1, y: 0};
    });
  });

  cvsSnake.addEventListener('pointerdown', function(e) {
    e.preventDefault();
    if (snakeGameOver) resetSnake();
  });

  /* 6. NEON PING PONG */
  var cvsPong = document.getElementById('cPong'), ctxPong = cvsPong.getContext('2d');
  var pongW = 300, pongH = 300, paddleW = 60, paddleH = 8;
  var playerPaddleX = (pongW - paddleW) / 2, aiPaddleX = (pongW - paddleW) / 2;
  var ballX = pongW / 2, ballY = pongH / 2, ballVx = 3, ballVy = -3;
  var pongPlayerScore = 0, pongAiScore = 0;

  function resetPongBall() {
    ballX = pongW / 2;
    ballY = pongH / 2;
    ballVx = (Math.random() < 0.5 ? -1 : 1) * (2.5 + Math.random() * 1.5);
    ballVy = 3.5;
  }

  function resetPong() {
    pongPlayerScore = 0;
    pongAiScore = 0;
    resetPongBall();
  }

  function updatePong() {
    if (activeView === 'pong') {
      ctxPong.clearRect(0, 0, pongW, pongH);
      ctxPong.fillStyle = '#0f172a';
      ctxPong.fillRect(0, 0, pongW, pongH);

      ctxPong.strokeStyle = 'rgba(255,255,255,0.1)';
      ctxPong.setLineDash([6, 6]);
      ctxPong.beginPath();
      ctxPong.moveTo(0, pongH / 2);
      ctxPong.lineTo(pongW, pongH / 2);
      ctxPong.stroke();
      ctxPong.setLineDash([]);

      var aiCenter = aiPaddleX + paddleW / 2;
      if (aiCenter < ballX - 6) aiPaddleX += 3.2;
      else if (aiCenter > ballX + 6) aiPaddleX -= 3.2;
      aiPaddleX = Math.max(0, Math.min(pongW - paddleW, aiPaddleX));

      ballX += ballVx;
      ballY += ballVy;

      if (ballX <= 4 || ballX >= pongW - 4) ballVx *= -1;

      if (ballY <= 14 + paddleH && ballX >= aiPaddleX && ballX <= aiPaddleX + paddleW) {
        ballVy = Math.abs(ballVy);
      }
      if (ballY >= pongH - 14 - paddleH && ballX >= playerPaddleX && ballX <= playerPaddleX + paddleW) {
        ballVy = -Math.abs(ballVy);
      }

      if (ballY < 0) {
        pongPlayerScore++;
        scoreBadge.textContent = 'YOU: ' + pongPlayerScore + ' | AI: ' + pongAiScore;
        resetPongBall();
      } else if (ballY > pongH) {
        pongAiScore++;
        scoreBadge.textContent = 'YOU: ' + pongPlayerScore + ' | AI: ' + pongAiScore;
        resetPongBall();
      }

      ctxPong.fillStyle = '#ff007f';
      ctxPong.fillRect(aiPaddleX, 10, paddleW, paddleH);
      ctxPong.fillStyle = '#00f2fe';
      ctxPong.fillRect(playerPaddleX, pongH - 10 - paddleH, paddleW, paddleH);

      ctxPong.fillStyle = '#fbbf24';
      ctxPong.beginPath();
      ctxPong.arc(ballX, ballY, 5, 0, Math.PI * 2);
      ctxPong.fill();
    }
    requestAnimationFrame(updatePong);
  }

  cvsPong.addEventListener('pointermove', function(e) {
    var rect = cvsPong.getBoundingClientRect();
    var x = (e.clientX - rect.left) * (pongW / rect.width);
    playerPaddleX = Math.max(0, Math.min(pongW - paddleW, x - paddleW / 2));
  });
  updatePong();

  /* 7. DINO RUNNER */
  var cvsDino = document.getElementById('cDino'), ctxDino = cvsDino.getContext('2d');
  var dinoW = 320, dinoH = 330, dinoGY = 260;
  var dino, dinoObstacles, dinoScore = 0, dinoSpeed = 5, dinoGameOver = false, dinoRunT = 0, dinoSpawnTimer = 70;

  function resetDino() {
    dino = { x: 35, y: dinoGY - 30, w: 26, h: 30, vy: 0, jumping: false };
    dinoObstacles = [];
    dinoScore = 0;
    dinoSpeed = 5;
    dinoGameOver = false;
    dinoRunT = 0;
    dinoSpawnTimer = 60 + Math.random() * 30;
    scoreBadge.textContent = 'SCORE: 0';
  }

  function jumpDino() {
    if (dinoGameOver) { resetDino(); return; }
    if (!dino.jumping) {
      dino.jumping = true;
      dino.vy = -12.5;
    }
  }

  function updateDino() {
    if (activeView === 'dino') {
      ctxDino.clearRect(0, 0, dinoW, dinoH);
      ctxDino.fillStyle = '#090d16';
      ctxDino.fillRect(0, 0, dinoW, dinoH);

      ctxDino.strokeStyle = '#334155';
      ctxDino.lineWidth = 2;
      ctxDino.beginPath();
      ctxDino.moveTo(0, dinoGY);
      ctxDino.lineTo(dinoW, dinoGY);
      ctxDino.stroke();

      if (!dinoGameOver) {
        dinoRunT += 1;
        dinoScore += 0.15;
        scoreBadge.textContent = 'SCORE: ' + Math.floor(dinoScore);
        dinoSpeed = Math.min(10, dinoSpeed + 0.001);

        dino.y += dino.vy;
        dino.vy += 0.7;
        if (dino.y >= dinoGY - 30) {
          dino.y = dinoGY - 30;
          dino.vy = 0;
          dino.jumping = false;
        }

        dinoSpawnTimer--;
        if (dinoSpawnTimer <= 0) {
          var h = 20 + Math.random() * 20;
          dinoObstacles.push({ x: dinoW + 10, y: dinoGY - h, w: 14 + Math.random() * 6, h: h });
          dinoSpawnTimer = Math.max(35, 65 - dinoSpeed * 2) + Math.random() * 25;
        }
      }

      ctxDino.fillStyle = '#00f2fe';
      ctxDino.fillRect(dino.x, dino.y, dino.w, dino.h);
      ctxDino.fillStyle = '#fff';
      ctxDino.fillRect(dino.x + 18, dino.y + 4, 4, 4);

      var legOff = dino.jumping ? 0 : Math.sin(dinoRunT * 0.4) * 4;
      ctxDino.fillStyle = '#00f2fe';
      ctxDino.fillRect(dino.x + 4, dino.y + 30, 5, 6 + legOff);
      ctxDino.fillRect(dino.x + 16, dino.y + 30, 5, 6 - legOff);

      for (var i = dinoObstacles.length - 1; i >= 0; i--) {
        var o = dinoObstacles[i];
        if (!dinoGameOver) o.x -= dinoSpeed;
        ctxDino.fillStyle = '#ef4444';
        ctxDino.fillRect(o.x, o.y, o.w, o.h);

        if (dino.x + 4 < o.x + o.w && dino.x + dino.w - 4 > o.x && dino.y + 4 < o.y + o.h && dino.y + dino.h > o.y) {
          dinoGameOver = true;
        }
        if (o.x < -30) dinoObstacles.splice(i, 1);
      }

      if (dinoGameOver) {
        ctxDino.fillStyle = 'rgba(15,23,42,0.85)';
        ctxDino.fillRect(0, 0, dinoW, dinoH);
        ctxDino.textAlign = 'center';
        ctxDino.fillStyle = '#ef4444';
        ctxDino.font = '900 22px sans-serif';
        ctxDino.fillText('GAME OVER 💥', dinoW / 2, dinoH / 2 - 10);
        ctxDino.fillStyle = '#fbbf24';
        ctxDino.font = '700 12px sans-serif';
        ctxDino.fillText('TAP TO JUMP & RETRY', dinoW / 2, dinoH / 2 + 25);
      }
    }
    requestAnimationFrame(updateDino);
  }
  cvsDino.addEventListener('pointerdown', function(e) { e.preventDefault(); jumpDino(); });
  updateDino();

  /* 8. CYBER BLADE SLICE */
  var cvsSlice = document.getElementById('cSlice'), ctxSlice = cvsSlice.getContext('2d');
  var sliceW = 320, sliceH = 330;
  var sliceScore = 0, sliceOrbs = [], sliceParticles = [], sliceTrail = [], sliceGameOver = false, sliceIsSwiping = false, sliceTimer = 0;
  var SLICE_COLORS = ['#ff007f', '#00f2fe', '#ffe600', '#00ff66', '#a29bfe'];

  function resetSlice() {
    sliceScore = 0;
    sliceOrbs = [];
    sliceParticles = [];
    sliceTrail = [];
    sliceGameOver = false;
    sliceTimer = 0;
    scoreBadge.textContent = 'SCORE: 0';
  }

  function spawnSliceOrb() {
    var isBomb = Math.random() < 0.18;
    var r = isBomb ? 16 : 20;
    var x = 30 + Math.random() * (sliceW - 60);
    sliceOrbs.push({
      x: x, y: sliceH + r,
      vx: (Math.random() - 0.5) * 3,
      vy: -(9.5 + Math.random() * 3),
      r: r,
      color: isBomb ? '#ff2a2a' : SLICE_COLORS[Math.floor(Math.random() * SLICE_COLORS.length)],
      isBomb: isBomb,
      sliced: false
    });
  }

  function sliceBurst(x, y, color, cnt) {
    for (var i = 0; i < cnt; i++) {
      var angle = Math.random() * Math.PI * 2, spd = 2 + Math.random() * 4;
      sliceParticles.push({
        x: x, y: y,
        vx: Math.cos(angle) * spd, vy: Math.sin(angle) * spd,
        color: color, life: 1, size: 2 + Math.random() * 2
      });
    }
  }

  function checkOrbSlice(x, y) {
    if (sliceGameOver) return;
    for (var i = 0; i < sliceOrbs.length; i++) {
      var o = sliceOrbs[i];
      if (!o.sliced) {
        var dx = x - o.x, dy = y - o.y;
        if (Math.sqrt(dx * dx + dy * dy) < o.r + 14) {
          o.sliced = true;
          sliceBurst(o.x, o.y, o.color, o.isBomb ? 25 : 14);
          if (o.isBomb) {
            sliceGameOver = true;
          } else {
            sliceScore += 10;
            scoreBadge.textContent = 'SCORE: ' + sliceScore;
          }
        }
      }
    }
  }

  function updateSlice() {
    if (activeView === 'slice') {
      ctxSlice.clearRect(0, 0, sliceW, sliceH);
      ctxSlice.fillStyle = '#06040d';
      ctxSlice.fillRect(0, 0, sliceW, sliceH);

      if (!sliceGameOver) {
        sliceTimer++;
        if (sliceTimer > 40) {
          spawnSliceOrb();
          if (Math.random() < 0.3) spawnSliceOrb();
          sliceTimer = 0;
        }
      }

      for (var i = sliceOrbs.length - 1; i >= 0; i--) {
        var o = sliceOrbs[i];
        o.x += o.vx;
        o.y += o.vy;
        o.vy += 0.22;

        if (!o.sliced) {
          ctxSlice.fillStyle = o.color;
          ctxSlice.beginPath();
          ctxSlice.arc(o.x, o.y, o.r, 0, Math.PI * 2);
          ctxSlice.fill();
        }
        if (o.y > sliceH + 40 || o.sliced) sliceOrbs.splice(i, 1);
      }

      for (var p = sliceParticles.length - 1; p >= 0; p--) {
        var pt = sliceParticles[p];
        pt.x += pt.vx; pt.y += pt.vy; pt.life -= 0.04;
        if (pt.life <= 0) sliceParticles.splice(p, 1);
        else {
          ctxSlice.fillStyle = pt.color;
          ctxSlice.beginPath();
          ctxSlice.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
          ctxSlice.fill();
        }
      }

      if (sliceTrail.length > 1) {
        ctxSlice.strokeStyle = '#00f2fe';
        ctxSlice.lineWidth = 4;
        ctxSlice.lineCap = 'round';
        ctxSlice.beginPath();
        ctxSlice.moveTo(sliceTrail[0].x, sliceTrail[0].y);
        for (var t = 1; t < sliceTrail.length; t++) ctxSlice.lineTo(sliceTrail[t].x, sliceTrail[t].y);
        ctxSlice.stroke();
      }

      for (var tr = sliceTrail.length - 1; tr >= 0; tr--) {
        sliceTrail[tr].age = (sliceTrail[tr].age || 0) + 1;
        if (sliceTrail[tr].age > 5) sliceTrail.splice(tr, 1);
      }

      if (sliceGameOver) {
        ctxSlice.fillStyle = 'rgba(8, 4, 18, 0.85)';
        ctxSlice.fillRect(0, 0, sliceW, sliceH);
        ctxSlice.textAlign = 'center';
        ctxSlice.fillStyle = '#ff2a2a';
        ctxSlice.font = '900 22px sans-serif';
        ctxSlice.fillText('BOMB DETONATED! 💥', sliceW / 2, sliceH / 2 - 10);
        ctxSlice.fillStyle = '#fff';
        ctxSlice.font = '700 12px sans-serif';
        ctxSlice.fillText('Tap to Restart', sliceW / 2, sliceH / 2 + 25);
      }
    }
    requestAnimationFrame(updateSlice);
  }

  function getSlicePos(e) {
    var rect = cvsSlice.getBoundingClientRect();
    var cx = (e.touches && e.touches.length > 0) ? e.touches[0].clientX : e.clientX;
    var cy = (e.touches && e.touches.length > 0) ? e.touches[0].clientY : e.clientY;
    return { x: (cx - rect.left) * (sliceW / rect.width), y: (cy - rect.top) * (sliceH / rect.height) };
  }

  cvsSlice.addEventListener('pointerdown', function(e) {
    e.preventDefault();
    if (sliceGameOver) { resetSlice(); return; }
    sliceIsSwiping = true;
    var pos = getSlicePos(e);
    sliceTrail.push({ x: pos.x, y: pos.y, age: 0 });
    checkOrbSlice(pos.x, pos.y);
  });
  cvsSlice.addEventListener('pointermove', function(e) {
    e.preventDefault();
    if (!sliceIsSwiping && !e.buttons) return;
    var pos = getSlicePos(e);
    sliceTrail.push({ x: pos.x, y: pos.y, age: 0 });
    checkOrbSlice(pos.x, pos.y);
  });
  window.addEventListener('pointerup', function() { sliceIsSwiping = false; sliceTrail = []; });
  updateSlice();

  /* 9. NEON SLOTS (SLOT MACHINE) */
  var SLOT_ICONS = ['🍒', '🍋', '🍇', '🔔', '💎', '7️⃣'];
  var SLOT_MULTIPLIERS = { '7️⃣': 50, '💎': 25, '🔔': 15, '🍇': 10, '🍋': 8, '🍒': 5 };
  var slotBalance = parseInt(localStorage.getItem('slot_bal') || '500', 10);
  if (isNaN(slotBalance) || slotBalance < 10) slotBalance = 500;
  var slotCurrentBet = 10;
  var slotSpinning = false;

  var slotBannerEl = document.getElementById('slotBanner');
  var slotSpinBtn = document.getElementById('slotSpinBtn');
  var r1 = document.getElementById('r1');
  var r2 = document.getElementById('r2');
  var r3 = document.getElementById('r3');
  var betBtns = document.querySelectorAll('.bet-btn');

  function updateSlotBalance(val) {
    slotBalance = Math.max(0, val);
    if (activeView === 'slot') scoreBadge.textContent = 'COINS: ' + slotBalance;
    try { localStorage.setItem('slot_bal', String(slotBalance)); } catch(e){}
  }

  betBtns.forEach(function(btn) {
    btn.addEventListener('pointerdown', function(e) {
      e.preventDefault();
      if (slotSpinning) return;
      betBtns.forEach(function(b) { b.classList.remove('active'); });
      btn.classList.add('active');
      slotCurrentBet = parseInt(btn.dataset.b, 10);
    });
  });

  function getRandomSlotIcon() {
    return SLOT_ICONS[Math.floor(Math.random() * SLOT_ICONS.length)];
  }

  function runSlotSpin() {
    if (slotSpinning) return;
    if (slotBalance < slotCurrentBet) {
      slotBannerEl.className = 'slot-banner';
      slotBannerEl.textContent = '⚠️ Low coins! Resetting +250 🪙';
      updateSlotBalance(250);
      return;
    }

    slotSpinning = true;
    slotSpinBtn.disabled = true;
    updateSlotBalance(slotBalance - slotCurrentBet);

    slotBannerEl.className = 'slot-banner';
    slotBannerEl.textContent = 'Rolling the reels...';

    r1.classList.add('spinning');
    r2.classList.add('spinning');
    r3.classList.add('spinning');

    var res1 = getRandomSlotIcon();
    var res2 = getRandomSlotIcon();
    var res3 = getRandomSlotIcon();

    var t1 = setInterval(function() { r1.textContent = getRandomSlotIcon(); }, 70);
    var t2 = setInterval(function() { r2.textContent = getRandomSlotIcon(); }, 70);
    var t3 = setInterval(function() { r3.textContent = getRandomSlotIcon(); }, 70);

    setTimeout(function() {
      clearInterval(t1);
      r1.classList.remove('spinning');
      r1.textContent = res1;
    }, 900);

    setTimeout(function() {
      clearInterval(t2);
      r2.classList.remove('spinning');
      r2.textContent = res2;
    }, 1400);

    setTimeout(function() {
      clearInterval(t3);
      r3.classList.remove('spinning');
      r3.textContent = res3;
      evalSlotOutcome(res1, res2, res3);
    }, 1900);
  }

  function evalSlotOutcome(a, b, c) {
    slotSpinning = false;
    slotSpinBtn.disabled = false;

    if (a === b && b === c) {
      var multi = SLOT_MULTIPLIERS[a] || 5;
      var won = slotCurrentBet * multi;
      updateSlotBalance(slotBalance + won);
      slotBannerEl.className = 'slot-banner win';
      slotBannerEl.textContent = '🎉 JACKPOT! Won +' + won + ' 🪙 (' + multi + 'x)';
      return;
    }

    if (a === b || b === c || a === c) {
      var match = (a === b || a === c) ? a : b;
      var wonPair = Math.floor(slotCurrentBet * 1.5);
      updateSlotBalance(slotBalance + wonPair);
      slotBannerEl.className = 'slot-banner win';
      slotBannerEl.textContent = '✨ Pair Match (' + match + ')! Won +' + wonPair + ' 🪙';
      return;
    }

    slotBannerEl.className = 'slot-banner';
    slotBannerEl.textContent = 'No luck! Spin again 🎲';
  }

  slotSpinBtn.addEventListener('pointerdown', function(e) {
    e.preventDefault();
    runSlotSpin();
  });

})();
</script>
</body>
</html>`;

            if (typeof botClient.sendHTML === 'function') {
                await botClient.sendHTML(from, htmlGamePayload, {
                    title: 'THENUX & UDMODZ Cyber Arcade Matrix 🕹️',
                    trustedSources: ['thenuxofc.store', 'nixel.dev']
                });
            } else {
                const messageEnvelope = {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2,
                        botMetadata: {
                            messageDisclaimerText: "",
                            botResponseId: crypto.randomUUID(),
                            verificationMetadata: {
                                proofs: [
                                    {
                                        version: 1,
                                        useCase: 1,
                                        signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                        certificateChain: [
                                            "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                            "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                        ]
                                    }
                                ]
                            }
                        }
                    },
                    botForwardedMessage: {
                        message: {
                            richResponseMessage: {
                                messageType: 1,
                                submessages: [{ messageType: 2, messageText: "THENUX & UDMODZ Cyber Arcade Matrix 🕹️" }],
                                unifiedResponse: {
                                    data: Buffer.from(JSON.stringify({
                                        response_id,
                                        sections: [
                                            {
                                                view_model: {
                                                    primitive: {
                                                        __typename: "GenAIaeacdsnwHtmlPrimitive",
                                                        payload: htmlGamePayload,
                                                        trusted_sources: ["thenuxofc.store", "nixel.dev"]
                                                    },
                                                    __typename: "GenAISingleLayoutViewModel"
                                                }
                                            }
                                        ]
                                    })).toString('base64')
                                },
                                contextInfo: {
                                    forwardingScore: 1,
                                    isForwarded: true,
                                    forwardedAiBotMessageInfo: { botJid: "867051314767696@bot" },
                                    forwardOrigin: 4
                                }
                            }
                        }
                    }
                };
                await botClient.relayMessage(from, messageEnvelope, {});
            }

            await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });

        } catch (err) {
            console.error('❌ [Arcade Relay Error]:', err.message);
            await botClient.sendMessage(from, { react: { text: '❌', key: mek.key } });
            return botClient.sendMessage(from, {
                text: `❌ *Arcade Relay Failed*\n\nReason: ${err.message}`
            }, { quoted: mek });
        }
    }
};
