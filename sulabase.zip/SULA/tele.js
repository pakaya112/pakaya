const axios = require('axios');
const { ReadData } = require('../database');

const TELEDL_API = 'https://sula-teledl-api.udmodz-2ab.workers.dev';

// ─── API fetch (metadata only, fast) ─────────────────────────────────────────

async function teledlFetch(telegramUrl) {
    const res = await axios.get(
        `${TELEDL_API}/?url=${encodeURIComponent(telegramUrl)}`,
        {
            timeout: 30000,
            headers: { 'User-Agent': 'Mozilla/5.0' },
            validateStatus: () => true
        }
    );
    const data = res.data;
    if (data && data.error) throw new Error(data.error);
    if (res.status >= 400)  throw new Error(`API error ${res.status}`);
    return data;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatBytes(bytes) {
    if (!bytes || bytes === 0) return null;
    if (bytes < 1024 * 1024)         return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 * 1024 * 1024)  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
    return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

const MIME_MAP = {
    mp4: 'video/mp4',  mkv: 'video/x-matroska', mov: 'video/quicktime',
    avi: 'video/x-msvideo', webm: 'video/webm', ts: 'video/MP2T',
    mp3: 'audio/mpeg', ogg: 'audio/ogg',  opus: 'audio/ogg',
    m4a: 'audio/mp4',  flac: 'audio/flac', wav: 'audio/wav', aac: 'audio/aac',
    pdf: 'application/pdf',
    apk: 'application/vnd.android.package-archive',
    zip: 'application/zip',
    rar: 'application/x-rar-compressed',
    '7z': 'application/x-7z-compressed',
    tar: 'application/x-tar',
    gz:  'application/gzip',
    exe: 'application/x-msdownload',
    iso: 'application/x-iso9660-image',
    jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png',
    gif: 'image/gif',  webp: 'image/webp', heic: 'image/heic',
    txt: 'text/plain', csv: 'text/csv',
    doc: 'application/msword',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xls: 'application/vnd.ms-excel',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ppt: 'application/vnd.ms-powerpoint',
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
};

// ─── Plugin ───────────────────────────────────────────────────────────────────

module.exports = {
    name: 'telegram',
    alias: ['tg', 'tgdl', 'tdl'],

    run: async ({ conn, mek, from, q }) => {

        if (!q || !/t\.me\/[A-Za-z0-9_]+\/\d+/i.test(q)) {
            return conn.sendMessage(from, {
                text:
`╭────♡◉◉◉♡────⌬
📨 *TELEGRAM DOWNLOADER*
🌸 *Public Post Downloader*
╰────♡◉◉◉♡────⌬

📌 *Example:*
➤ .tg https://t.me/channel/123

⚠️ Only public channels work

> © SULA MD`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '⏳', key: mek.key }
        });

        try {
            const number    = conn.user.id.split(':')[0];
            const botname   = await ReadData(number, 'BOT_NAME')   || 'SULA MD';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© SULA MD';

            // 1. Fetch metadata + direct CDN URL from worker
            const result = await teledlFetch(q);

            const fileName    = result.videoname || 'telegram_file';
            const downloadUrl = Object.values(result.links || {})[0];
            if (!downloadUrl) throw new Error('No download link returned from API');

            const ext      = (fileName.split('.').pop() || '').toLowerCase();
            const mimetype = MIME_MAP[ext] || 'application/octet-stream';
            const expiry   = result.expiry ? new Date(result.expiry).toUTCString() : '48 hours';

            // 2. HEAD request: get file size without downloading
            let fileSize = null;
            try {
                const head = await axios.head(downloadUrl, {
                    timeout: 8000,
                    headers: { 'User-Agent': 'Mozilla/5.0' },
                    maxRedirects: 10,
                    validateStatus: () => true
                });
                const cl = parseInt(head.headers['content-length'] || '0');
                if (cl > 0) fileSize = formatBytes(cl);
            } catch {}

            // 3. Notify user — show file info before starting upload
            await conn.sendMessage(from, {
                text:
`╭────♡◉◉◉♡────⌬
⬇️ *DOWNLOADING...*
╰────♡◉◉◉♡────⌬

📂 *File:* ${fileName}
🗂️ *Type:* ${ext.toUpperCase() || 'FILE'}${fileSize ? `\n📦 *Size:* ${fileSize}` : ''}

🔗 Streaming directly to WhatsApp...`
            }, { quoted: mek });

            // 4. Open CDN stream — no temp file, no full buffer
            //    Streams directly: Telegram CDN → Node → Baileys → WhatsApp
            //    Supports up to 2GB (limited only by WhatsApp's own document limit)
            const streamRes = await axios({
                method: 'GET',
                url: downloadUrl,
                responseType: 'stream',
                timeout: 0,                 // no timeout — let it stream as long as needed
                maxContentLength: Infinity,
                maxBodyLength: Infinity,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                }
            });

            if (streamRes.status >= 400) {
                throw new Error(`CDN returned status ${streamRes.status}`);
            }

            const caption =
`╭────♡◉◉◉♡────⌬
📨 *TELEGRAM FILE*
✨ *${botname} Successfully Sent*
╰────♡◉◉◉♡────⌬

📂 ${fileName}${fileSize ? `\n📦 *Size:* ${fileSize}` : ''}
⏰ *Expires:* ${expiry}

${botfooter}`;

            // 5. Pass the live Readable stream to Baileys
            //    Baileys pipes it directly to WhatsApp Media Upload
            await conn.sendMessage(from, {
                document: { stream: streamRes.data },
                mimetype,
                fileName,
                caption
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '✅', key: mek.key }
            });

        } catch (err) {

            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });

            return conn.sendMessage(from, {
                text:
`╭────♡◉◉◉♡────⌬
❌ *TELEGRAM DOWNLOAD FAILED*
╰────♡◉◉◉♡────⌬

📌 *Reason:*
➤ ${err.message}

> © SULA MD`
            }, { quoted: mek });
        }
    }
};
