const axios = require('axios');
const crypto = require('crypto');
const { ReadData, WriteData } = require('../database');

module.exports = {
    name: 'thenuxai',
    alias: ['thenux', 'ai', 'video'],
    category: 'ai',
    description: 'Thenux AI Engine with direct Video & Image generation, code, and chat.',

    run: async ({ conn, client, mek, from, q }) => {
        const botClient = conn || client;
        const API_ENDPOINT = 'https://thenux-kyrex-ai.scieovlogs12345.workers.dev';
        const INTERNAL_KEY = 'tnx_live_ca62b9c3ca9ff6ea38f3da199e83bcb0468d24ea86b65208';
        const botfooter = '> Thenux • www.thenuxofc.store';

        try {
            const sender = mek.key.participant || mek.key.remoteJid;
            const number = botClient.user.id.split(':')[0];

            let apiKey = INTERNAL_KEY;
            let customKeyFound = false;

            try {
                const storedKey = await ReadData(number, 'THENUX_API_KEY');
                if (storedKey && storedKey.trim() !== '' && storedKey.trim() !== 'guest') {
                    apiKey = storedKey.trim();
                    customKeyFound = true;
                }
            } catch (e) {
                apiKey = INTERNAL_KEY;
            }

            let userPrompt = q ? q.trim() : '';

            // ============================================================
            // OWNER ONLY: SET CUSTOM API KEY
            // ============================================================
            if (userPrompt.toLowerCase().startsWith('setkey ')) {
                const isOwner = mek.key.fromMe || sender.includes(number);
                if (!isOwner) {
                    return botClient.sendMessage(from, {
                        text: `🚫 *Access Denied*\n\nOnly the Bot Owner can configure the Thenux API Key!\n\n${botfooter}`
                    }, { quoted: mek });
                }

                const newKey = userPrompt.split(/\s+/)[1]?.trim();
                if (!newKey || !newKey.startsWith('tnx_')) {
                    return botClient.sendMessage(from, {
                        text: `❌ *Invalid Key Format*\n\nPlease provide a valid key starting with \`tnx_\`.\n\n*Usage:* \`.thenuxai setkey tnx_live_xxxx\`\n\n${botfooter}`
                    }, { quoted: mek });
                }

                if (typeof WriteData === 'function') {
                    await WriteData(number, 'THENUX_API_KEY', newKey);
                }

                return botClient.sendMessage(from, {
                    text: `🔑 *API Key Saved*\n\nActive Key: \`${newKey.substring(0, 12)}...\`\n\n${botfooter}`
                }, { quoted: mek });
            }

            // ============================================================
            // RESET CONVERSATION MEMORY THREAD
            // ============================================================
            if (userPrompt.toLowerCase() === 'reset') {
                if (typeof WriteData === 'function') {
                    await WriteData(number, 'THENUX_CHAT_ID', '');
                }
                return botClient.sendMessage(from, {
                    text: `🔄 *Thread Reset*\n\nConversation memory thread cleared successfully.\n\n${botfooter}`
                }, { quoted: mek });
            }

            // ============================================================
            // HELP MENU
            // ============================================================
            if (!userPrompt) {
                const menuText = `🎬 *Thenux AI Studio*\n
• *AI Video:* \`.ai video <prompt>\`
• *AI Image:* \`.ai draw <prompt>\`
• *Chat & Code:* \`.ai <prompt>\`

🌐 *Developer Portal:*
https://www.thenuxofc.store\n
${botfooter}`;

                return botClient.sendMessage(from, { text: menuText }, { quoted: mek });
            }

            let lowerPrompt = userPrompt.toLowerCase();

            // ============================================================
            // FEATURE 1: DIRECT AI VIDEO GENERATION
            // ============================================================
            const isVideoTrigger = /^(?:\.video|\.ai\s+\.video|video|generate\s+video|create\s+video|make\s+a\s+video|animate)/i.test(userPrompt) 
                || lowerPrompt.includes('create video') 
                || lowerPrompt.includes('video of');

            if (isVideoTrigger) {
                await botClient.sendMessage(from, { react: { text: '🎬', key: mek.key } });

                const cleanVidPrompt = userPrompt
                    .replace(/^(\.ai|\.video|\.thenuxai|\.vidgen)\s*/gi, '')
                    .replace(/^(\.video|video|generate\s+video(\s+of)?|create\s+video(\s+of)?|make\s+a\s+video(\s+of)?|animate)\s*:?/gi, '')
                    .replace(/^video\s*:?/gi, '')
                    .trim();

                if (!cleanVidPrompt) {
                    return botClient.sendMessage(from, {
                        text: `❌ *Missing Prompt*\n\nPlease describe what video you want to create.\n\n*Example:* \`.ai .video a cat walking on the moon, cinematic\`\n\n${botfooter}`
                    }, { quoted: mek });
                }

                const waitNotice = `🎬 *Video Generator*\n\n📌 *Prompt:* _${cleanVidPrompt}_\n⏳ *Status:* Rendering video... Please wait.\n\n${botfooter}`;
                await botClient.sendMessage(from, { text: waitNotice }, { quoted: mek });

                try {
                    const apiUrl = `https://apis.davidcyriltech.my.id/ai/txt2vid?prompt=${encodeURIComponent(cleanVidPrompt)}&aspect_ratio=auto&ai_sound=true`;
                    const res = await axios.get(apiUrl, { timeout: 120000 });

                    const resData = res.data;
                    const videoUrl = resData?.result?.url || resData?.url || resData?.data?.url;

                    if (videoUrl && /^https?:\/\//i.test(videoUrl)) {
                        await botClient.sendMessage(from, {
                            video: { url: videoUrl },
                            mimetype: 'video/mp4',
                            caption: `🎬 *Video Generated*\n\n📌 *Prompt:* _${cleanVidPrompt}_`
                        }, { quoted: mek });

                        return await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });
                    } else {
                        throw new Error('Video service did not return a valid MP4 URL.');
                    }
                } catch (vidErr) {
                    console.error("Video Generation Error:", vidErr.message);
                    await botClient.sendMessage(from, { react: { text: '❌', key: mek.key } });
                    return botClient.sendMessage(from, {
                        text: `❌ *Generation Failed*\n\n${vidErr.message}\n\n${botfooter}`
                    }, { quoted: mek });
                }
            }

            // ============================================================
            // FEATURE 2: REAL-TIME WEB SEARCH
            // ============================================================
            if (lowerPrompt.startsWith('search ') || lowerPrompt.startsWith('find ')) {
                await botClient.sendMessage(from, { react: { text: '🔍', key: mek.key } });
                const searchQuery = userPrompt.replace(/^(search|find)\s+/i, '');

                try {
                    const searchRes = await axios.post(`${API_ENDPOINT}/api/proxy/search`, { q: searchQuery }, { timeout: 30000 });
                    if (searchRes.data?.results?.length > 0) {
                        let searchContext = `[Real-Time Web Search Context for "${searchQuery}"]:\n`;
                        searchRes.data.results.slice(0, 4).forEach((r, idx) => {
                            searchContext += `\n[${idx + 1}] ${r.title}\n${r.snippet}\nSource: ${r.url}\n`;
                        });
                        userPrompt = `${searchContext}\n\nUser Question: ${searchQuery}\nProvide a clean and direct answer using the search context above.`;
                    }
                } catch (sErr) {
                    console.warn('Web search proxy skipped:', sErr.message);
                }
            }

            // ============================================================
            // FEATURE 3: AI IMAGE GENERATION
            // ============================================================
            const artKeywords = ["draw", "gen image", "img ", "create a pic", "generate image", "photo of", "make logo", "create logo"];
            const isImageReq = artKeywords.some(kw => lowerPrompt.includes(kw)) && userPrompt.length < 500;

            if (isImageReq) {
                await botClient.sendMessage(from, { react: { text: '🎨', key: mek.key } });
                const imgRes = await axios.post(`${API_ENDPOINT}/api/image`, {
                    prompt: userPrompt,
                    mode: "thenux",
                    model: "t-nex-studio",
                    apiKey: customKeyFound ? apiKey : INTERNAL_KEY
                }, {
                    headers: {
                        'Content-Type': 'application/json',
                        'x-internal-api-key': INTERNAL_KEY
                    },
                    timeout: 120000
                });

                if (imgRes.data?.success && imgRes.data?.image) {
                    const base64Raw = imgRes.data.image.includes(',') ? imgRes.data.image.split(',')[1] : imgRes.data.image;
                    const imageBuffer = Buffer.from(base64Raw, 'base64');

                    await botClient.sendMessage(from, {
                        image: imageBuffer,
                        caption: `🎨 *Image Generated*\n\n📌 *Prompt:* _${imgRes.data.prompt || userPrompt}_`
                    }, { quoted: mek });

                    return await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });
                }
            }

            // ============================================================
            // FEATURE 4: CHAT & CODING ENGINE
            // ============================================================
            let chosenModel = "t-nex-1.0";
            let chosenMode = "thenux";

            const codeKeywords = ["code", "bug", "fix", "function", "javascript", "html", "css", "react", "api", "json", "build website"];
            const bizKeywords = ["store", "shop", "marketing", "product description", "ecommerce", "business", "crm", "sales"];

            if (codeKeywords.some(kw => lowerPrompt.includes(kw))) {
                chosenModel = "t-nex-ultra";
            } else if (bizKeywords.some(kw => lowerPrompt.includes(kw))) {
                chosenModel = "t-nex-business";
                chosenMode = "nexora";
            }

            await botClient.sendMessage(from, { react: { text: '⏳', key: mek.key } });

            let quotedMessage = mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            let imageBase64Data = null;

            if (quotedMessage) {
                const imgNode = quotedMessage.imageMessage || quotedMessage.viewOnceMessage?.message?.imageMessage;
                if (imgNode && botClient.downloadMediaMessage) {
                    try {
                        const buffer = await botClient.downloadMediaMessage(mek);
                        if (buffer) {
                            imageBase64Data = `data:image/jpeg;base64,${buffer.toString('base64')}`;
                        }
                    } catch (e) {}
                }
            }

            let chatId = null;
            try { chatId = await ReadData(number, 'THENUX_CHAT_ID'); } catch (e) { chatId = null; }

            const payload = {
                message: userPrompt,
                prompt: userPrompt,
                chatId: chatId || undefined,
                userId: number,
                mode: chosenMode,
                model: chosenModel,
                plan: "Elite",
                apiKey: customKeyFound ? apiKey : INTERNAL_KEY,
                internal_api_key: INTERNAL_KEY
            };

            if (imageBase64Data) {
                payload.image = imageBase64Data;
                payload.image_url = imageBase64Data;
            }

            const response = await axios.post(`${API_ENDPOINT}/api/chat`, payload, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${customKeyFound ? apiKey : INTERNAL_KEY}`,
                    'X-API-Key': customKeyFound ? apiKey : INTERNAL_KEY,
                    'x-internal-api-key': INTERNAL_KEY
                },
                timeout: 180000
            });

            if (!response.data || (!response.data.success && !response.data.response && !response.data.text)) {
                throw new Error(response.data?.error || 'Worker execution returned no usable response.');
            }

            let rawAiText = response.data.response || response.data.text || response.data.result || '';
            let choiceButtonsText = "";

            if (rawAiText.includes(':::choice')) {
                try {
                    const parts = rawAiText.split(':::choice');
                    rawAiText = parts[0].trim();
                    const parsedChoices = JSON.parse(parts[1].trim());
                    if (Array.isArray(parsedChoices)) {
                        choiceButtonsText = `\n\n💡 *Suggestions:*\n`;
                        parsedChoices.forEach(btn => {
                            choiceButtonsText += `• ${btn.text}\n`;
                        });
                    }
                } catch (e) {}
            }

            if (rawAiText.includes('```workspace')) {
                try {
                    const jsonMatch = rawAiText.match(/```workspace\s*([\s\S]*?)\s*```/);
                    if (jsonMatch) {
                        const workspace = JSON.parse(jsonMatch[1]);
                        let formattedWorkspace = `\n\n📁 *Workspace: ${workspace.title || 'Code Suite'}*\n`;
                        if (workspace.files) {
                            Object.keys(workspace.files).forEach(fileName => {
                                formattedWorkspace += `\n📄 *File:* \`${fileName}\`\n\`\`\`\n${workspace.files[fileName]}\n\`\`\`\n`;
                            });
                        }
                        rawAiText = rawAiText.replace(jsonMatch[0], formattedWorkspace);
                    }
                } catch (e) {}
            }

            const outputCaption = `${rawAiText}${choiceButtonsText}`;

            await botClient.sendMessage(from, { text: outputCaption }, { quoted: mek });
            await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });

        } catch (err) {
            console.error("Thenux AI Execution Error:", err);
            await botClient.sendMessage(from, { react: { text: '❌', key: mek.key } });

            let errMsg = err.message;
            if (err.response?.data?.error) errMsg = err.response.data.error;

            return botClient.sendMessage(from, {
                text: `❌ *Error Occurred*\n\n${errMsg}`
            }, { quoted: mek });
        }
    }
};