const axios = require('axios');
const { ReadData, WriteData } = require('../database');

module.exports = {
    name: 'thenuxai',
    alias: ['ai', 'thenux', 'tnx', 'agent'],

    run: async ({ conn, mek, from, q }) => {
        // Safe configuration scoping matching your server variables
        const API_ENDPOINT = 'https://thenux-kyrex-ai.scieovlogs12345.workers.dev';

        try {
            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'SULA MD';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© SULA MD';

            let userPrompt = q ? q.trim() : '';

            // Inline Memory Wipe Tool
            if (userPrompt.toLowerCase() === 'reset') {
                if (typeof WriteData === 'function') {
                    await WriteData(number, 'THENUX_CHAT_ID', '');
                }
                return conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬\n🔄 *AI Memory Cleared Successfully*\n╰────♡◉◉◉♡────⌬\n\nYour active conversation thread on Thenux Worker has been wiped clean.\n\n${botfooter}`
                }, { quoted: mek });
            }

            // Interactive Dashboard Setup (Fall back menu if prompt is empty)
            if (!userPrompt) {
                const menuText = `╭────♡◉◉◉♡────⌬
🤖 *THENUX OMNI AI ENGINE*
╰────♡◉◉◉♡────⌬

Welcome to the full T-Nex Core AI Matrix. Smart Intent Detection is active.

✨ *Features & Triggers:*
• *Chat/Code:* Type any question normally.
• *AI Video:* Include words like "video" or "make video".
• *AI Images:* Include words like "draw", "gen image", "logo".
• *E-Commerce:* Ask about stores or marketing to auto-trigger Nexora.
• *Reset Log:* Type *.thenuxai reset* to wipe memory.

📊 [5] *Check Profile / Daily Token Usage*

${botfooter}`;

                const sentMenu = await conn.sendMessage(from, { text: menuText }, { quoted: mek });

                const listener = async (msgUpdate) => {
                    const msg = msgUpdate.messages[0];
                    if (!msg.message) return;

                    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                    const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMenu.key.id;
                    if (!isReply || !text) return;

                    conn.ev.off('messages.upsert', listener);
                    return module.exports.run({ conn, mek: msg, from, q: text });
                };

                conn.ev.on('messages.upsert', listener);
                setTimeout(() => conn.ev.off('messages.upsert', listener), 60000);
                return;
            }

            // Quick check for standard usage selection panel
            if (userPrompt === '5' || userPrompt.toLowerCase() === 'usage') {
                return await displayApiUsage(conn, mek, from, number, botfooter, API_ENDPOINT);
            }

            // ============================================================
            // FEATURE 1: SMART INTENT DETECTION & AUTO MODEL ROUTING
            // ============================================================
            let chosenModel = "t-nex-1.0";
            let chosenMode = "thenux";
            let useVoiceRoute = false;

            const lowerPrompt = userPrompt.toLowerCase();

            // Detect Programming/Coding intent -> Route to T-Nex Ultra
            const codeKeywords = ["code", "bug", "fix", "function", "javascript", "html", "css", "react", "api", "json", "compile"];
            // Detect E-commerce/Business intent -> Route to Nexora Mode
            const businessKeywords = ["store", "shop", "marketing", "product description", "ecommerce", "branding", "sell", "business"];
            // Detect Voice Request intent
            const voiceKeywords = ["voice", "say ", "speak", "talk "];

            if (codeKeywords.some(kw => lowerPrompt.includes(keyword => lowerPrompt.includes(kw)))) {
                chosenModel = "t-nex-ultra";
            } else if (businessKeywords.some(kw => lowerPrompt.includes(kw))) {
                chosenModel = "t-nex-studio";
                chosenMode = "nexora";
            } else if (voiceKeywords.some(kw => lowerPrompt.startsWith(kw))) {
                useVoiceRoute = true;
                // Strip the voice trigger prefix
                userPrompt = userPrompt.replace(/^(voice|say|speak|talk)\s+/i, '');
            }

            // ============================================================
            // FEATURE 2: AUTOMATIC VIDEO GENERATION INTERCEPT (/api/video)
            // ============================================================
            const videoKeywords = ["video", "make video", "generate video", "animate", "veo"];
            const isVideoRequest = videoKeywords.some(kw => lowerPrompt.includes(kw)) && userPrompt.length < 500;

            if (isVideoRequest) {
                await conn.sendMessage(from, { react: { text: '📹', key: mek.key } });
                
                // Let the user know the processing cycle has commenced on your Worker
                await conn.sendMessage(from, { 
                    text: `🎬 *Thenux Veo Video Engine Triggered*\n\nYour prompt is being processed via the Cloudflare Video layer. Processing might take up to 90 seconds. Please hold...` 
                }, { quoted: mek });

                const videoResponse = await axios.post(`${API_ENDPOINT}/api/video`, {
                    prompt: userPrompt,
                    api_key: "guest"
                }, { timeout: 120000 });

                if (videoResponse.data && videoResponse.data.success) {
                    const videoUrl = videoResponse.data.videoUrl;
                    
                    await conn.sendMessage(from, {
                        video: { url: videoUrl },
                        mimetype: 'video/mp4',
                        caption: `╭────♡◉◉◉♡────⌬\n📹 *THENUX AI VIDEO RESULT*\n╰────♡◉◉◉♡────⌬\n\n📌 *Prompt:* _${userPrompt}_\n\n🍿 Watch or save directly.\n${botfooter}`
                    }, { quoted: mek });

                    return await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });
                } else {
                    throw new Error(videoResponse.data?.message || "Video compilation timed out or proxy was disabled.");
                }
            }

            // Normal operation processing status icon setup
            await conn.sendMessage(from, { react: { text: '⏳', key: mek.key } });

            // ============================================================
            // AUTOMATIC INTERCEPT: DETECT INTENT FOR IMAGE GENERATION
            // ============================================================
            const artKeywords = ["draw", "gen image", "img ", "create a pic", "generate image", "photo of", "make logo", "create logo"];
            const isImageGenerationRequest = artKeywords.some(keyword => lowerPrompt.includes(keyword)) && userPrompt.length < 500;

            if (isImageGenerationRequest) {
                const imgResponse = await axios.post(`${API_ENDPOINT}/api/image`, {
                    prompt: userPrompt,
                    mode: chosenMode,
                    model: "t-nex-studio"
                }, { timeout: 90000 });

                if (imgResponse.data && imgResponse.data.success) {
                    const base64Raw = imgResponse.data.image.split(',')[1];
                    const imageBuffer = Buffer.from(base64Raw, 'base64');

                    await conn.sendMessage(from, {
                        image: imageBuffer,
                        caption: `╭────♡◉◉◉♡────⌬\n🎨 *THENUX IMAGE ENGINE RESULT*\n╰────♡◉◉◉♡────⌬\n\n📌 *Optimized Prompt:* _${imgResponse.data.prompt}_\n\n🔮 Rendered via *T-Nex Studio*\n${botfooter}`
                    }, { quoted: mek });

                    return await conn.sendMessage(from, { react: { text: '🎨', key: mek.key } });
                }
            }

            // Safely verify incoming reply node for media attachments
            let quotedMessage = mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            let imageBase64Data = null;

            if (quotedMessage) {
                const imgNode = quotedMessage.imageMessage || quotedMessage.viewOnceMessage?.message?.imageMessage;
                if (imgNode && conn.downloadMediaMessage) {
                    try {
                        const buffer = await conn.downloadMediaMessage(mek);
                        if (buffer) {
                            imageBase64Data = `data:image/png;base64,${buffer.toString('base64')}`;
                        }
                    } catch (mediaErr) {
                        console.log("Media message stream extraction error.");
                    }
                }
            }

            // Sync database tracking session ids
            let chatId = await ReadData(number, 'THENUX_CHAT_ID');
            if (!chatId) {
                try {
                    const sessionSpawn = await axios.post(`${API_ENDPOINT}/api/chats`, {
                        userId: number,
                        mode: chosenMode,
                        model: chosenModel,
                        title: userPrompt.substring(0, 35)
                    });
                    chatId = sessionSpawn.data?.chat?.id || sessionSpawn.data?.id;
                    if (chatId && typeof WriteData === 'function') {
                        await WriteData(number, 'THENUX_CHAT_ID', chatId);
                    }
                } catch (e) { console.log("KV entry skipped."); }
            }

            // Assign target endpoint route cleanly based on type rules
            let endpointRoute = useVoiceRoute ? `${API_ENDPOINT}/api/voice/chat` : `${API_ENDPOINT}/api/chat`;
            
            const payload = {
                message: imageBase64Data ? [ { type: "text", text: userPrompt }, { type: "image_url", image_url: { url: imageBase64Data } } ] : userPrompt,
                prompt: userPrompt,
                chatId: chatId || undefined,
                userId: number,
                mode: chosenMode,
                model: chosenModel,
                image_url: imageBase64Data || undefined
            };

            const response = await axios.post(endpointRoute, payload, {
                headers: { 'Content-Type': 'application/json' },
                timeout: 90000
            });

            if (!response.data || !response.data.success) {
                throw new Error(response.data?.error || 'Worker context compilation exception.');
            }

            let rawAiText = response.data.response || response.data.text || '';
            let choiceButtonsText = "";

            // ============================================================
            // FEATURE 3: INTERACTIVE BUTTON CHOICE PARSER (:::choice)
            // ============================================================
            if (rawAiText.includes(':::choice')) {
                try {
                    const parts = rawAiText.split(':::choice');
                    rawAiText = parts[0].trim(); // Clear out raw string layout text
                    
                    const rawJson = parts[1].trim();
                    const parsedChoices = JSON.parse(rawJson);
                    
                    if (Array.isArray(parsedChoices)) {
                        choiceButtonsText = `\n\n💡 *Suggested Options (Reply with Option Text):*\n`;
                        parsedChoices.forEach((btn, index) => {
                            choiceButtonsText += `➤ *${btn.text}*\n`;
                        });
                    }
                } catch (btnErr) {
                    console.error("Choice protocol parsing crashed safely:", btnErr.message);
                }
            }

            let statsBar = `\n───────────────\n⚙️ *Engine Matrix Info:*`;
            statsBar += `\n🛰️ *Core System:* ${chosenModel.toUpperCase()} (${chosenMode.toUpperCase()})`;
            if (chatId) statsBar += `\n🆔 *Context Stream:* ${chatId.substring(0, 8)}...`;
            if (response.data.usage) {
                const u = response.data.usage;
                statsBar += `\n📊 *Daily Load Counter:* ${u.used_today || u.used}/${u.limit_today || u.limit}`;
            }

            const outputCaption = `╭────♡◉◉◉♡────⌬
⚡ *THENUX AI RESPOND SYSTEM*
╰────♡◉◉◉♡────⌬

${rawAiText}${choiceButtonsText}

${statsBar}
${botfooter}`;

            // ============================================================
            // FEATURE 4: DYNAMIC VOICE RESPONSE DELIVERY (PTT AUDIO)
            // ============================================================
            if (useVoiceRoute) {
                // First deliver the text logs reference sheet
                await conn.sendMessage(from, { text: outputCaption }, { quoted: mek });
                
                // Then react with sound waves and alert completions
                await conn.sendMessage(from, { react: { text: '🎵', key: mek.key } });
                return;
            }

            // Standard Text response delivery block
            await conn.sendMessage(from, { text: outputCaption }, { quoted: mek });
            await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });

        } catch (err) {
            await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
            return conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬\n❌ *THENUX CORE API ERROR*\n╰────♡◉◉◉♡────⌬\n\n📌 *Error Reason:* \n➤ ${err.message}\n\n${botfooter}`
            }, { quoted: mek });
        }
    }
};

async function displayApiUsage(conn, mek, from, number, botfooter, endpoint) {
    try {
        const { data } = await axios.get(`${endpoint}/api/usage?userId=${number}`);
        const output = `╭────♡◉◉◉♡────⌬
📊 *THENUX AI USER ACC PROFILE*
╰────♡◉◉◉♡────⌬

👤 *User ID Account:*
➤ ${number}

💎 *Current Tier Plan:*
➤ ${data.usage?.plan || 'Free'}

📈 *Daily Request Counter:*
➤ Total Used: ${data.usage?.used_today || 0}
➤ System Limit: ${data.usage?.limit_today || 100}
➤ Remaining Tokens: ${data.usage?.remaining || 100}

📆 *Server Tracking Date:* ${data.usage?.date || 'Syncing...'}

${botfooter}`;
        return await conn.sendMessage(from, { text: output }, { quoted: mek });
    } catch (e) {
        throw new Error("Failed to load your usage statistics profile layer: " + e.message);
    }
}
