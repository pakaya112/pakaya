const { ReadData } = require('../database');
const axios = require("axios");
const fs = require("fs");
const path = require("path");

module.exports = {
    name: 'menu',

    run: async ({ conn, mek, from }) => {

        try {

            const date = new Date().toLocaleDateString('en-GB', { timeZone: 'Asia/Colombo' });
            const time = new Date().toLocaleTimeString('en-GB', { 
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                timeZone: 'Asia/Colombo'
            });

            const number = conn.user.id.split(':')[0];

            const Images = await ReadData(number, "SULA_IMAGE_PATH");
            const botname = await ReadData(number, "BOT_NAME");
            const botfooter = await ReadData(number, "BOT_FOOTER");

            // ===== MAIN MENU =====
            const caption = `
╭─────♡◉◉◉♡─────⌬
💖 *Hello User...!* 🌸  
🌷 *Welcome to ${botname} Menu* ✨  
╰─────♡◉◉◉♡─────⌬

┆ ➤ 🌸
┆   ➤ 💫
┆     ➤ 🌷

📅 *Date:* ${date} 📆  
⌚ *Time:* ${time} ⏳  

─────────────── 💗

✨ *Select a category:* ✨  

❶ 🛠️ System  
❷ 👥 Group  
❸ 🖼️ Media  
❹ 📥 Download  
❺ 🫧 Anime  
❻ 🌐 Info  
❼ 🎯 Fun  
❽ 🔞 NSFW 
❾ 🎥 Movie

─────────────── 🌸

🌐 *SULA-MD Mini Bot Web* 💕  
> https://sulaofc.store

┆ ✦ 🌷
┆   ➤ 💖
┆     ➤ 🌸

${botfooter}
`;


            const qcontact = {
    key: {
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast"
    },
    message: {
        contactMessage: {
            displayName: "SULA-MD",
            vcard: `BEGIN:VCARD
VERSION:3.0
N:SULA-MD;;;;
FN:SULA-MD
TEL;type=CELL;type=VOICE;waid=94703266859:+94 70 326 6859
END:VCARD`,
            jpegThumbnail: null,
            sendEphemeral: true
        }
    }
};
            

            // 🖼️ IMAGE
            const sentMsg = await conn.sendMessage(from, {
                image: { url: Images },
                caption
            }, { quoted: qcontact });

            // 🎙️ VOICE
            await conn.sendMessage(from, {
    audio: {
        url: 'https://raw.githubusercontent.com/sulamadara1147/data/main/sulavoice.opus'
    },
    mimetype: 'audio/ogg; codecs=opus',
    ptt: true
}, { quoted: qcontact });

            // ===== LISTENER =====
            const listener = async (update) => {
                const m = update.messages[0];
                if (!m?.message) return;

                const text =
                    m.message.conversation ||
                    m.message.extendedTextMessage?.text;

                const isReply =
                    m.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id &&
                    m.key.remoteJid === from;

                if (!isReply) return;

                let replyText = "";

                switch(text) {

case "1":
replyText =
"╭───❀ 𝓢𝓨𝓢𝓣𝓔𝓜 ❀───╮\n\n" +
"❶ 💖 *.alive*\n" +
"❷ ⚡ *.ping*\n" +
"❸ ⚙️ *.setting*\n" +
"❹ 👑 *.owner*\n" +
"❺ 🔗 *.pair*\n" +
"❻ 🤝 *.helpcenter*\n" +
"❼ 🆔 *.jid*\n\n" +
"─────────────── 🌸";
break;

case "2":
replyText =
"╭───❀ 𝓖𝓡𝓞𝓤𝓟 ❀───╮\n\n" +
"❶ ➕ *.add*\n" +
"❷ ❌ *.kick*\n" +
"❸ ⬆️ *.promote*\n" +
"❹ ⬇️ *.demote*\n" +
"❺ 🔓 *.group open*\n" +
"❻ 🔒 *.group close*\n" +
"❼ 📄 *.groupinfo*\n" +
"❽ 📢 *.tagall*\n" +
"❾ 👻 *.hidetag*\n" +
"❿ 📋 *.grouplist*\n" +
"⓫ ⚙️ *.groupsetting*\n" +
"⓬ 🖼️ *.setgpp*\n" +
"⓭ 📝 *.setgdesc*\n" +
"⓮ ✏️ *.setgname*\n" +
"⓯ 🚪 *.leave*\n\n" +
"─────────────── 🌸";
break;

case "3":
replyText =
"╭───❀ 𝓜𝓔𝓓𝓘𝓐 ❀───╮\n\n" +
"❶ 🎭 *.sticker*\n" +
"❷ 💾 *.save*\n" +
"❸ 🔗 *.tourl*\n" +
"❹ 🖼️ *.getpp*\n" +
"❺ 📱 *.winfo*\n" +
"❻ 🌐 *.ssweb*\n" +
"❼ 🎨 *.imaggen*\n" +
"❽ ☢️ *.bomb*\n"+
"❾ 🪧 *.take*\n"+
"❿ 🖲️ *.ffstalk*\n"+
"⓫ 🔁 *.rmbg*\n\n"+
"─────────────── 🌸";
break;

case "4":
replyText =
"╭───❀ 𝓓𝓞𝓦𝓝𝓛𝓞𝓐𝓓 ❀───╮\n\n" +
"❶ 📘 *.facebook*\n" +
"❷ 🎵 *.tiktok*\n" +
"❸ 📸 *.instagram*\n" +
"❹ 🎧 *.song*\n" +
"❺ 🎬 *.video*\n" +
"❻ 🔗 *.csend*\n" +
"❼ 📦 *.apk*\n" +
"❽ 📎 *.comicdl*\n" +
"❾ 🏷️ *.mangadl*\n\n" +
"─────────────── 🌸";
break;

case "5":
replyText =
"╭───❀ 𝓐𝓝𝓘𝓜𝓔 ❀───╮\n\n" +
"❶ 🐱 *.animeimg neko*\n" +
"❷ 💕 *.animeimg waifu*\n" +
"❸ 🦊 *.animeimg fox_girl*\n" +
"❹ 🤗 *.animeimg hug*\n" +
"❺ 💋 *.animeimg kiss*\n" +
"❻ 🫳 *.animeimg pat*\n" +
"❼ 🎮 *.bluearchive*\n\n" +
"─────────────── 🌸";
break;

case "6":
replyText =
"╭───❀ 𝓘𝓝𝓕𝓞 ❀───╮\n\n" +
"❶ 🚀 *.nasa*\n" +
"❷ 🎶 *.lyrics*\n" +
"❸ 📚 *.pastpaper*\n" +
"❹ 📄 *.cinfo*\n" +
"❺ 📦 *.npm*\n" +
"❻ 🏷️ *.googlesearch*\n" +
"❼ 🖲️ *.aidetect*\n" +
"❽ 🪧 *.github*\n" +
"❾ ➕ *.gdrive*\n" +
"❿ ➕ *.mediafire*\n" +
"⓫ ✅ *.aividgen*\n\n"+
"─────────────── 🌸";
break;

case "7":
replyText =
"╭───❀ 𝓕𝓤𝓝 ❀───╮\n\n" +
"❶ 🤖 *.ai*\n" +
"❷ 🌍 *.tr*\n" +
"❸ 👁️ *.vv*\n" +
"❹ 👀 *.vv2*\n" +
"❺ ➕ *.short*\n" +
"❻ 🏷️ *.logo*\n" +
"❼ 🧬 *.prompt*\n" +
"❽ 🪧 *.nasaimg*\n" +
"❾ 🩷 *.thenuxai*\n" +
"❿ 📖 *.walkatha*\n" +
"⓫ 🔌 *.srename*\n" +
"⓬ 🔗 *.tovoice*\n\n"+
"─────────────── 🌸";
break;

case "8":
replyText =
"╭───❀ 𝓝𝓢𝓕𝓦 ❀───╮\n\n" +
"❶ 🔞 *.henati*\n" +
"❷ 🤤 *.xnxx*\n\n"+
"─────────────── 🌸";
break;

case "9":
replyText =
"╭───❀ 𝓜𝓞𝓥𝓘𝓔 ❀───╮\n\n" +
"❶ 🎥 *.cinesubz*\n" +
"❷ 📹 *.sinhalasub*\n"+
"❸ 🤗 *.anime*\n" +
"❹ 🏷️ *.animeen*\n" +
"❺ 🤤 *.hanime*\n" +
"❻ 🧬 *.animost*\n" +
"❼ ➕ *.subcat*\n\n" +
"─────────────── 🌸";
break;

                }

                await conn.sendMessage(from, {
                    text: replyText + "\n\n" + botfooter
                }, { quoted: m });

                conn.ev.off("messages.upsert", listener);
            };

            conn.ev.on("messages.upsert", listener);

        } catch (err) {}
    }
};
