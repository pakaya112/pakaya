//const { downloadContentFromMessage } = require('baileys');

module.exports = {
    name: 'vv',
    run: async ({ conn, mek, from }) => {

const {
    default: makeWASocket,
    useMultiFileAuthState,
    delay,
    makeCacheableSignalKeyStore,
    Browsers,
    downloadContentFromMessage,
    jidNormalizedUser,
    proto,
    prepareWAMessageMedia,
    downloadMediaMessage,
    generateForwardMessageContent,
    generateWAMessageFromContent
} = await import('baileys');


        try {
            const quoted = mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;

            if (!quoted) {
                return conn.sendMessage(from, {
                    text: '❌ Please reply to a ViewOnce message!'
                }, { quoted: mek });
            }

            const mtype = Object.keys(quoted)[0];

            const isViewOnce =
                (mtype === 'imageMessage' && quoted.imageMessage?.viewOnce) ||
                (mtype === 'videoMessage' && quoted.videoMessage?.viewOnce) ||
                (mtype === 'audioMessage' && quoted.audioMessage?.viewOnce);

            if (!isViewOnce) {
                return conn.sendMessage(from, {
                    text: '❌ This is not a ViewOnce message!'
                }, { quoted: mek });
            }

            
            const stream = await downloadContentFromMessage(
                quoted[mtype],
                mtype.replace('Message', '')
            );

            const chunks = [];
            for await (const chunk of stream) {
                chunks.push(chunk);
            }

            const buffer = Buffer.concat(chunks);

            let media = {};
            let caption = '';

            const baseCaption = `
╭━━❀ 𝓥𝓘𝓔𝓦 𝓞𝓝𝓒𝓔 ❀━━╮
👁️ *VIEW ONCE UNLOCKED* 👁️
╰━━━━━━━━━━━━━╯`;

            if (mtype === 'imageMessage') {
                caption = quoted.imageMessage?.caption || baseCaption;

                media = {
                    image: buffer,
                    caption
                };
            }

            if (mtype === 'videoMessage') {
                caption = quoted.videoMessage?.caption || baseCaption;

                media = {
                    video: buffer,
                    caption
                };
            }

            if (mtype === 'audioMessage') {
                media = {
                    audio: buffer,
                    mimetype: 'audio/mpeg',
                    ptt: quoted.audioMessage?.ptt || false
                };
            }

      
            await conn.sendMessage(from, media, { quoted: mek });


            await conn.sendMessage(from, {
                react: { text: '👁️', key: mek.key }
            });

        } catch (err) {
            console.error("VV error:", err);

            await conn.sendMessage(from, {
                text: `❌ Error decrypting ViewOnce!\n${err.message}`
            }, { quoted: mek });
        }
    }
};
