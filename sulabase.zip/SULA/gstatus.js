const { generateWAMessageContent, generateMessageID } = require('baileys');
const { ReadData } = require('../database');

async function sendGroupStatus(socket, groupJid, content, options = {}) {
    try {
        let waMsgContent;
        if ('message' in content && content.message) {
            waMsgContent = content;
        } else {
            waMsgContent = await generateWAMessageContent(content, {
                upload: socket.waUploadToServer
            });
        }
        const msg = {
            message: {
                groupStatusMessageV2: {
                    message: waMsgContent.message || waMsgContent
                }
            }
        };
        const messageId = options.messageId || generateMessageID();
        return await socket.relayMessage(groupJid, msg.message, {
            messageId,
            ...options
        });
    } catch (err) {
        console.error("Group Status Send Error:", err);
        throw err;
    }
}

module.exports = {
    name: 'gstatus',
    alias: ['groupstatus', 'gst'],
    description: 'Send a text status update to the current group',

    run: async ({ conn, mek, from, q, isGroup }) => {
        try {
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.

Want access to this feature?

Create your own bot:
🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            if (!isGroup) {
                return await conn.sendMessage(from, {
                    text: `❌ *This command can only be used in groups!*`
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃';

            const statusText = q ? q.trim() : '';

            if (!statusText) {
                return await conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬
❌ *PLEASE PROVIDE STATUS TEXT!*
╰────♡◉◉◉♡────⌬

📌 *Usage:*
➤ Text Status: *.gstatus your text*

*Example:*
➤ *.gstatus Good Morning All!*

${botfooter}`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, { react: { text: '⏳', key: mek.key } });

            await sendGroupStatus(conn, from, {
                text: statusText
            });

            await conn.sendMessage(from, { react: { text: '✅', key: mek.key } });

        } catch (err) {
            await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
            await conn.sendMessage(from, {
                text: `❌ *Error:* ${err.message}`
            }, { quoted: mek });
        }
    }
};
