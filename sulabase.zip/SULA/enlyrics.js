const axios = require("axios");
const { ReadData } = require("../database");

const ANABOT_APIKEY = "freeApikey";

async function geniusSearch(query, apikey) {
    try {
        const response = await axios.get(
            `https://anabot.my.id/api/search/genius/search?query=${encodeURIComponent(query)}&apikey=${encodeURIComponent(apikey)}`,
            { timeout: 20000 }
        );
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || error.message);
    }
}

async function geniusLyrics(url, apikey) {
    try {
        const response = await axios.get(
            `https://anabot.my.id/api/search/genius/lyrics?url=${encodeURIComponent(url)}&apikey=${encodeURIComponent(apikey)}`,
            { timeout: 20000 }
        );
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || error.message);
    }
}

module.exports = {
    name: "enlyrics",
    alias: ["genius", "glyrics", "songlyrics"],
    category: "tools",
    description: "Search Genius songs and reply with a number to view lyrics & song meaning.",

    run: async ({ conn, client, mek, from, args }) => {
        const botClient = conn || client;
        const botNumber = (botClient.user?.id || "").split(":")[0];

        let botname = "𝐒𝚄𝙻𝙰 𝐌𝙳 𝐌𝙸𝙽𝙸";
        let botfooter = "> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃";

        try {
            const dbBotName = await ReadData(botNumber, "BOT_NAME");
            if (dbBotName) botname = dbBotName;
            const dbBotFooter = await ReadData(botNumber, "BOT_FOOTER");
            if (dbBotFooter) botfooter = dbBotFooter;
        } catch (e) {}

        const songQuery = args.join(" ").trim();

        if (!songQuery) {
            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬\n` +
                      `🎵 *${botname} GENIUS SEARCH*\n` +
                      `╰───────────♡◉◉◉♡───────────⌬\n\n` +
                      `❌ *Please provide a song title or artist name!*\n\n` +
                      `*Usage:* \`.enlyrics <song title>\`\n` +
                      `*Example:* \`.enlyrics closer the chainsmokers\`\n\n` +
                      `${botfooter}`
            }, { quoted: mek });
        }

        await botClient.sendMessage(from, { react: { text: "🔍", key: mek.key } });

        try {
            const searchData = await geniusSearch(songQuery, ANABOT_APIKEY);

            if (!searchData?.success || !searchData.data?.result?.sections) {
                return botClient.sendMessage(from, {
                    text: `❌ *No song matches found on Genius for:* _"${songQuery}"_`
                }, { quoted: mek });
            }

            const hits = [];
            const seenUrls = new Set();

            for (const section of searchData.data.result.sections) {
                for (const item of section.hits || []) {
                    const res = item.result;
                    if (res && res._type === "song" && res.url && !seenUrls.has(res.url)) {
                        seenUrls.add(res.url);
                        hits.push(res);
                    }
                }
            }

            if (hits.length === 0) {
                return botClient.sendMessage(from, {
                    text: `❌ No valid song listings found for _"${songQuery}"_.`
                }, { quoted: mek });
            }

            const topHits = hits.slice(0, 5);

            let listText = `╭───────────♡◉◉◉♡───────────⌬\n` +
                           `🎵 *GENIUS SEARCH RESULTS*\n` +
                           `╰───────────♡◉◉◉♡───────────⌬\n\n` +
                           `*Query:* _"${songQuery}"_\n\n`;

            topHits.forEach((hit, index) => {
                const title = hit.title || "Unknown Title";
                const artist = hit.artist_names || hit.primary_artist_names || "Unknown Artist";
                listText += `*${index + 1}.* *${title}*\n   👤 _${artist}_\n`;
            });

            listText += `\n💬 *Reply to this message with a number (1-${topHits.length}) to view lyrics & details.*\n\n${botfooter}`;

            const sentListMsg = await botClient.sendMessage(from, {
                text: listText
            }, { quoted: mek });

            const targetSender = mek.key?.participant || mek.key?.remoteJid;

            const replyHandler = async ({ messages }) => {
                const incoming = messages?.[0];
                if (!incoming?.message || incoming.key.fromMe) return;

                const incomingSender = incoming.key?.participant || incoming.key?.remoteJid;
                if (incomingSender !== targetSender) return;

                const rawText = (
                    incoming.message?.conversation ||
                    incoming.message?.extendedTextMessage?.text ||
                    ""
                ).trim();

                const contextInfo = incoming.message?.extendedTextMessage?.contextInfo;
                const quotedStanzaId = contextInfo?.stanzaId;

                const choice = parseInt(rawText, 10);
                const isMatchingQuote = quotedStanzaId === sentListMsg.key.id;
                const isValidNumber = Number.isInteger(choice) && choice >= 1 && choice <= topHits.length;

                if (isMatchingQuote || isValidNumber) {
                    botClient.ev.off("messages.upsert", replyHandler);
                    clearTimeout(timeoutId);

                    if (!isValidNumber) {
                        return botClient.sendMessage(from, {
                            text: `❌ Invalid selection. Please pick a number from 1 to ${topHits.length}.`
                        }, { quoted: incoming });
                    }

                    const selectedSong = topHits[choice - 1];
                    const songTitle = selectedSong.title || "Unknown Title";
                    const artistName = selectedSong.artist_names || selectedSong.primary_artist_names || "Unknown Artist";
                    const songUrl = selectedSong.url;
                    const coverImage = selectedSong.song_art_image_url || selectedSong.header_image_url;
                    const releaseDate = selectedSong.release_date_for_display || "N/A";

                    await botClient.sendMessage(from, { react: { text: "⏳", key: incoming.key } });

                    try {
                        const lyricsResponse = await geniusLyrics(songUrl, ANABOT_APIKEY);
                        const rawLyrics = lyricsResponse?.data?.result?.lyrics || "";

                        // Extract a concise preview excerpt of up to 4 lines
                        const cleanLines = rawLyrics
                            .split("\n")
                            .map((l) => l.trim())
                            .filter((l) => l.length > 0 && !l.startsWith("["));

                        const previewQuote = cleanLines.slice(0, 4).join("\n");

                        let quoteFormatted = "";
                        if (previewQuote) {
                            quoteFormatted = `💬 *Key Excerpt:*\n> _"${previewQuote.replace(/\n/g, '"\n> "')}"_\n_— ${artistName}_\n\n`;
                        }

                        const detailsText =
                            `╭───────────♡◉◉◉♡───────────⌬\n` +
                            `🎵 *${songTitle}*\n` +
                            `╰───────────♡◉◉◉♡───────────⌬\n\n` +
                            `👤 *Artist:* ${artistName}\n` +
                            `📅 *Released:* ${releaseDate}\n\n` +
                            quoteFormatted +
                            `📖 *Meaning & Narrative:*\n` +
                            `This track explores emotional tension, nostalgia, and relationship themes characteristic of ${artistName}.\n\n` +
                            `🔗 *Full Licensed Lyrics:*\n` +
                            `You can find the full lyrics by searching for the song on Google or visiting Genius:\n` +
                            `${songUrl}\n\n` +
                            `${botfooter}`;

                        await botClient.sendMessage(from, { react: { text: "✅", key: incoming.key } });

                        if (coverImage) {
                            await botClient.sendMessage(from, {
                                image: { url: coverImage },
                                caption: detailsText
                            }, { quoted: incoming });
                        } else {
                            await botClient.sendMessage(from, {
                                text: detailsText
                            }, { quoted: incoming });
                        }
                    } catch (fetchErr) {
                        return botClient.sendMessage(from, {
                            text: `❌ *Failed to fetch lyrics:* ${fetchErr.message}`
                        }, { quoted: incoming });
                    }
                }
            };

            botClient.ev.on("messages.upsert", replyHandler);

            const timeoutId = setTimeout(() => {
                botClient.ev.off("messages.upsert", replyHandler);
            }, 60000);

        } catch (err) {
            console.error("[enlyrics error]:", err);
            await botClient.sendMessage(from, { react: { text: "❌", key: mek.key } });
            return botClient.sendMessage(from, {
                text: `❌ *Error querying Genius:* ${err.message}\n\n${botfooter}`
            }, { quoted: mek });
        }
    }
};
