const axios = require('axios');
const { ReadData } = require('../database');

// --- API Endpoints ---
const SEARCH_API = 'https://api.chamindu.site/api/v1/movies/baiscopes/search';
const MOVIE_INFO_API = 'https://api.chamindu.site/api/v1/movies/baiscopes/infodl';

const API_KEY = 'chama_api_c4352392c75ea7c9ef640b0c79d1d174';
const DEFAULT_IMAGE = 'https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg';

module.exports = {
    name: 'baiscope',
    alias: ['baiscopes', 'bs', 'bscope'],

    run: async ({ conn, mek, from, q }) => {
        try {
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.\n\nWant access to this feature?\n\nCreate your own bot:\n🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'SULA MD';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© SULA MD';

            // Query එකක් දී නැතිනම් උදාහරණයක් පෙන්වීම
            if (!q) {
                return await conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬\n🎬 *Baiscopes Movie Search*\n╰────♡◉◉◉♡────⌬\n\n📌 *Example:* \n.baiscope avatar\n.baiscope 9476xxxxxxx@s.whatsapp.net avatar\n\n${botfooter}`
                }, { quoted: mek });
            }

            // Target JID logic (e.g. .baiscope 9476xxxxxxx@s.whatsapp.net avatar)
            const args = q.trim().split(' ');
            let targetJid = null;
            let searchQuery = q;
            let isCustomTarget = false;

            if (args[0]?.includes('@s.whatsapp.net') || args[0]?.includes('@g.us') || args[0]?.includes('@lid')) {
                targetJid = args[0];
                searchQuery = args.slice(1).join(' ').trim();
                isCustomTarget = true;
            }

            await conn.sendMessage(from, { react: { text: '⏳', key: mek.key } });

            // Search API Call
            const { data } = await axios.get(`${SEARCH_API}?q=${encodeURIComponent(searchQuery)}&api_key=${API_KEY}`);
            
            if (!data.status || !data.data?.length) {
                throw new Error(`No movies found for "${searchQuery}" on Baiscopes.`);
            }

            // TV shows ෆිල්ටර් කර movies පමණක් තෝරා ගැනීම
            const results = data.data
                .filter(x => x.type !== 'tvshows' && !x.link?.includes('/tvshows/'))
                .slice(0, 10);

            if (!results.length) {
                throw new Error(`No movie results found for "${searchQuery}". (TV shows are excluded)`);
            }

            const list = results.map((x, i) =>
                `❰ ${i + 1} ❱ *${x.title}*\n⭐ Rating: ${x.rating || 'N/A'}`
            ).join('\n\n');

            const caption = `╭────♡◉◉◉♡────⌬\n🎬 *Baiscopes Movie Results*\n✨ *${botname} Ready*\n╰────♡◉◉◉♡────⌬\n\n🔍 *Query:* ${searchQuery}\n\n${list}\n\n───────────────\n\nReply with a number: 1 - ${results.length}\n\n${botfooter}`;

            const sentMsg = await conn.sendMessage(from, {
                image: { url: results[0].image || DEFAULT_IMAGE },
                caption
            }, { quoted: mek });

            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];
                if (!msg.message) return;

                const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                if (!isReply) return;

                const index = parseInt(text) - 1;
                if (isNaN(index) || !results[index]) {
                    conn.ev.off('messages.upsert', listener);
                    return conn.sendMessage(from, { text: '❌ Invalid Selection. Please run the command again.' }, { quoted: msg });
                }

                conn.ev.off('messages.upsert', listener);
                await conn.sendMessage(from, { react: { text: '📥', key: msg.key } });

                const selected = results[index];
                return await showMovieInfo(conn, msg, from, targetJid, isCustomTarget, selected.link, selected.title, botname, botfooter);
            };

            conn.ev.on('messages.upsert', listener);
            setTimeout(() => { conn.ev.off('messages.upsert', listener); }, 60000);

        } catch (err) {
            return conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬\n❌ *Baiscopes Error*\n╰────♡◉◉◉♡────⌬\n\n⚠️ ${err.message}`
            }, { quoted: mek });
        }
    }
};

// ==========================================
// 🎬 MOVIE INFO & DOWNLOAD FLOW
// ==========================================
async function showMovieInfo(conn, quotedMsg, from, targetJid, isCustomTarget, movieLink, backupTitle, botname, botfooter) {
    try {
        const { data } = await axios.get(`${MOVIE_INFO_API}?q=${encodeURIComponent(movieLink)}&api_key=${API_KEY}`);
        if (!data.status || !data.data) {
            throw new Error('Movie details not found.');
        }

        const movie = data.data;
        const downloads = movie.downloads || [];

        if (!downloads.length) {
            throw new Error('No download links found for this movie.');
        }

        const realTitle = movie.title || backupTitle || 'Movie';
        const cleanStory = movie.story ? (movie.story.length > 250 ? movie.story.slice(0, 250) + '...' : movie.story) : 'No description available.';

        const list = downloads.map((x, i) =>
            `❰ ${i + 1} ❱ *${x.quality || 'HD'}* - (${x.size || 'N/A'})`
        ).join('\n');

        const caption = `╭────♡◉◉◉♡────⌬\n🎥 *${realTitle}*\n╰────♡◉◉◉♡────⌬\n\n⭐ IMDb: ${movie.imdb || 'N/A'}\n🎭 Genres: ${movie.genres?.join(', ') || 'N/A'}\n🎬 Director: ${movie.director || 'N/A'}\n\n📖 *Story:*\n${cleanStory}\n\n*Available Download Qualities:*\n${list}\n\n───────────────\n\nReply with Quality Number (e.g: 1)\n\n${botfooter}`;

        const sentMsg = await conn.sendMessage(from, {
            image: { url: movie.image?.trim() || DEFAULT_IMAGE },
            caption
        }, { quoted: quotedMsg });

        const listener = async (msgUpdate) => {
            const msg = msgUpdate.messages[0];
            if (!msg.message) return;

            const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
            const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

            if (!isReply) return;

            const index = parseInt(text) - 1;
            if (isNaN(index) || !downloads[index]) {
                conn.ev.off('messages.upsert', listener);
                return conn.sendMessage(from, { text: '❌ Invalid Quality Selection.' }, { quoted: msg });
            }

            conn.ev.off('messages.upsert', listener);
            await conn.sendMessage(from, { react: { text: '⬇️', key: msg.key } });

            await showMovieDownloadMenu(conn, msg, from, targetJid, isCustomTarget, {
                title: realTitle,
                image: movie.image?.trim() || DEFAULT_IMAGE,
                quality: downloads[index].quality || 'HD',
                size: downloads[index].size || 'N/A',
                link: downloads[index].link,
                botname,
                botfooter
            });
        };

        conn.ev.on('messages.upsert', listener);
        setTimeout(() => { conn.ev.off('messages.upsert', listener); }, 60000);

    } catch (err) {
        return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: quotedMsg });
    }
}

async function showMovieDownloadMenu(conn, quotedMsg, from, targetJid, isCustomTarget, info) {
    const caption = `╭────♡◉◉◉♡────⌬\n📥 *Download Options*\n✨ *${info.botname}*\n╰────♡◉◉◉♡────⌬\n\n🎬 *Title:* ${info.title}\n💎 *Quality:* ${info.quality}\n📦 *Size:* ${info.size}\n\n───────────────\n\n📁 ❶ Send Movie as File\n🔗 ❷ Direct Download Link\n\n───────────────\n\nReply: 1 / 2\n\n${info.botfooter}`;

    const sentMsg = await conn.sendMessage(from, {
        image: { url: info.image },
        caption
    }, { quoted: quotedMsg });

    const listener = async (msgUpdate) => {
        const msg = msgUpdate.messages[0];
        if (!msg.message) return;

        const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
        const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        conn.ev.off('messages.upsert', listener);

        if (!['1', '2'].includes(text)) {
            return conn.sendMessage(from, { text: '❌ Invalid Option. Please choose 1 or 2.' }, { quoted: msg });
        }

        // --- 🛡️ 2GB FILE SIZE BLOCKER LOGIC ---
        const rawSize = String(info.size).toUpperCase();
        const sizeNum = parseFloat(rawSize);
        if (rawSize.includes('GB') && sizeNum >= 2.0 && text === '1') {
            await conn.sendMessage(from, { react: { text: '⚠️', key: msg.key } });
            return await conn.sendMessage(from, {
                text: `⚠️ *File Size Limit Exceeded! (2GB+)*\n\nThe file size is *${info.size}*. Due to WhatsApp file size limitations, files over 2GB cannot be sent directly as documents.\n\n🔗 *Direct Download Link:*\n${info.link}\n\n${info.botfooter}`
            }, { quoted: msg });
        }

        const cleanTitle = (info.title || 'Movie').replace(/[\\/:*?"<>|]/g, '').trim();
        const doneCaption = `\n╭──〔 🎬 Baiscopes Delivery 〕──⬣\n\nHere is your requested movie! 🍿🎉\n\n🎞️ *Title:* ${cleanTitle}\n💎 *Quality:* ${info.quality}\n📦 *Size:* ${info.size}\n\n━━━━━━━━━━━━━━━\n🍿 Enjoy your movie!\n🌸 Thanks for using ${info.botname}\n━━━━━━━━━━━━━━━`;

        if (text === '1') {
            await conn.sendMessage(targetJid || from, {
                document: { url: info.link },
                mimetype: 'video/mp4',
                fileName: `${cleanTitle}.mp4`,
                caption: doneCaption
            }, { quoted: msg });

            if (isCustomTarget && targetJid) {
                await conn.sendMessage(from, {
                    text: `✅ Movie Successfully Delivered!\n\n📤 To: ${targetJid}`
                }, { quoted: msg });
            }
        } else {
            await conn.sendMessage(from, {
                text: `${doneCaption}\n\n🔗 *Direct Download Link:*\n${info.link}`
            }, { quoted: msg });
        }

        await conn.sendMessage(from, { react: { text: '✅', key: msg.key } });
    };

    conn.ev.on('messages.upsert', listener);
    setTimeout(() => { conn.ev.off('messages.upsert', listener); }, 60000);
}
