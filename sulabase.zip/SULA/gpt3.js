const axios = require('axios');

module.exports = {
    name: 'gpt3',
    alias: ['ai3', 'chatgpt3'],

    run: async ({ conn, mek, from, q }) => {

        if (!q) {
            return conn.sendMessage(from, {
                text: 'Please ask something.'
            }, { quoted: mek });
        }

        try {
            const apiUrl = `https://thenuxai-gpt.vercel.app/api/gpt?q=${encodeURIComponent(q)}&model=gpt3`;

            const { data } = await axios.get(apiUrl);

            if (!data?.response) {
                throw new Error('No response from API');
            }

            await conn.sendMessage(from, {
                text: data.response
            }, { quoted: mek });

        } catch (err) {
            await conn.sendMessage(from, {
                text: 'Error: ' + err.message
            }, { quoted: mek });
        }
    }
};
