const axios = require("axios");

module.exports = {
    name: "bluearchive",

    run: async ({ conn, mek, from }) => {

        try {

            await conn.sendMessage(from, {
                react: { text: "🎮", key: mek.key }
            });

            const res = await axios.get(
                "https://www.movanest.xyz/v2/bluearchive",
                { responseType: "arraybuffer" }
            );

            const buffer = Buffer.from(res.data);

            await conn.sendMessage(from, {
                image: buffer,
                caption: `
✨ Random Anime Character

💖 Enjoy your image!
`
            }, { quoted: mek });

        } catch (err) {
           // console.log("BA ERROR:", err);

            await conn.sendMessage(from, {
                text: "❌ Failed to get image!"
            }, { quoted: mek });
        }
    }
};
