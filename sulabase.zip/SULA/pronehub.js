const axios = require("axios");
const { ReadData } = require('../database');

module.exports = {
    name: "ph",
    alias: ["pornhub", "phub"],
    category: "nsfw",
    description: "Search and download Pornhub videos.",
    run: async ({ conn, mek, from, q, number }) => {
        try {
            // 📊 LOAD DATABASE DATA
            const Images = await ReadData(number, "SULA_IMAGE_PATH");
            const botname = await ReadData(number, "BOT_NAME") || "SULA-MD";
            const botfooter = await ReadData(number, "BOT_FOOTER") || "Powered by Sula";

            if (!q.trim()) {
                return conn.sendMessage(from, {
                    text: `🩷 *Hey baby~*\n\n✨ Send *title* or *keyword* 💕\n\n${botfooter}`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, { react: { text: "🔍", key: mek.key } });

            const searchUrl = `https://ph-dnuz.vercel.app/search?q=${encodeURIComponent(q)}`;
            const searchRes = await axios.get(searchUrl);

            if (!searchRes.data.success || !searchRes.data.results.length) {
                return conn.sendMessage(from, { text: `🥺 *No results found baby* 💔` }, { quoted: mek });
            }

            const videos = searchRes.data.results.slice(0, 5);

            let listText = `🩷✨ *${botname} PORNHUB SEARCH* ✨🩷\n\n`;
            listText += `╭─❀ *Choose Your Video* ❀─╮\n`;
            listText += `│ 💌 Reply with number (1-5)\n`;
            listText += `╰───────────────❀\n\n`;

            videos.forEach((v, i) => {
                listText += `│ ${i + 1} 🎀 _${v.title}_\n│ ⏱️ (${v.duration})\n│\n`;
            });

            listText += `╰───────────────❀\n\n💞 *Pick one baby...*\n\n${botfooter}`;

            // 🖼️ IMAGE LOGIC: PH Thumbnail -> Database Image -> Text Only
            let menuImage = null;
            const phThumb = videos[0].thumbnail;

            try {
                // PH Thumbnail එක වැඩ කරනවාදැයි පරීක්ෂා කරයි
                await axios.head(phThumb, { timeout: 3000 });
                menuImage = phThumb;
            } catch {
                // එය අසාර්ථක නම් ඩේටාබේස් image එක බලයි
                if (Images) menuImage = Images;
            }

            let sentMsg;
            if (menuImage) {
                try {
                    sentMsg = await conn.sendMessage(from, { image: { url: menuImage }, caption: listText }, { quoted: mek });
                } catch {
                    sentMsg = await conn.sendMessage(from, { text: listText }, { quoted: mek });
                }
            } else {
                sentMsg = await conn.sendMessage(from, { text: listText }, { quoted: mek });
            }

            const messageID = sentMsg.key.id;

            // 🎯 HANDLE REPLY
            const handler = async ({ messages }) => {
                const rmek = messages[0];
                if (!rmek?.message) return;

                const text = rmek.message.conversation || rmek.message.extendedTextMessage?.text;
                const contextInfo = rmek.message?.extendedTextMessage?.contextInfo;

                if (contextInfo?.stanzaId !== messageID) return;

                const choice = parseInt(text?.trim());
                if (isNaN(choice) || choice < 1 || choice > videos.length) return;

                const selectedVideo = videos[choice - 1];
                await conn.sendMessage(from, { react: { text: "📥", key: rmek.key } });

                try {
                    const dlRes = await axios.get(`https://ph-dnuz.vercel.app/download/?url=${encodeURIComponent(selectedVideo.link)}`);
                    if (!dlRes.data.success) throw new Error();

                    const videoData = dlRes.data.data;
                    const stream = videoData.videos.find(v => v.quality === '720p') || videoData.videos[0];

                    let caption = `🩷🎬 *${botname} DOWNLOAD* 🎬🩷\n\n🎀 *Title:* _${videoData.title}_\n⏱️ *Duration:* _${videoData.duration}_\n\n💞 *Enjoy baby...* ✨\n\n${botfooter}`;

                    await conn.sendMessage(from, {
                        video: { url: stream.url },
                        mimetype: 'video/mp4',
                        caption: caption
                    }, { quoted: rmek });

                    await conn.sendMessage(from, { react: { text: "✨", key: rmek.key } });
                    conn.ev.off('messages.upsert', handler);

                } catch (err) {
                    conn.sendMessage(from, { text: `❌ *Download failed baby*` }, { quoted: rmek });
                    conn.ev.off('messages.upsert', handler);
                }
            };

            conn.ev.on('messages.upsert', handler);
            setTimeout(() => conn.ev.off('messages.upsert', handler), 120000);

        } catch (e) {
            console.log("PH ERROR:", e.message);
        }
    }
};

