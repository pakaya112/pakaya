module.exports = {
    name: "promote",
    description: "Promote a member to admin.",
    category: "group",

    run: async ({ conn, mek, from, args, isGroup, isAdmin, isBotAdmins }) => {
        try {
            if (!isGroup) return conn.sendMessage(from, { text: "❌ This command can only be used in groups!" }, { quoted: mek });
            if (!isBotAdmins) return conn.sendMessage(from, { text: "❌ I need Admin privileges to promote users!" }, { quoted: mek });
            if (!isAdmin) return conn.sendMessage(from, { text: "❌ Only group admins can use this command!" }, { quoted: mek });

            let user = mek.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || 
                       mek.message?.extendedTextMessage?.contextInfo?.participant || 
                       (args[0] ? args[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net" : null);

            if (!user) return conn.sendMessage(from, { text: "⚠️ Please tag or reply to the user you want to promote!" }, { quoted: mek });

            await conn.groupParticipantsUpdate(from, [user], "promote");

            return conn.sendMessage(from, { 
                text: `✅ Successfully promoted @${user.split("@")[0]} to Admin!`,
                mentions: [user] 
            }, { quoted: mek });

        } catch (err) {
           // console.error("PROMOTE ERROR:", err);
            await conn.sendMessage(from, { text: "❌ Error occurred while promoting user." }, { quoted: mek });
        }
    }
};
