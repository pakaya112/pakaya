const axios = require('axios');
const { ReadData } = require('../database');

const NASA_API = 'https://thenux-nasa.netlify.app/api/landsat';

module.exports = {
    name: 'nasaimg',
    alias: ['nasalandsat', 'nasaname', 'landsat'],

    run: async ({ conn, mek, from, q }) => {
        try {
            const number = conn.user.id.split(':')[0];

            const botname =
                await ReadData(number, 'BOT_NAME') || 'SULA MD';

            const botfooter =
                await ReadData(number, 'BOT_FOOTER') || '© SULA MD';

            if (!q) {
                return conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬
🚀 *NASA Landsat Name Generator*
╰────♡◉◉◉♡────⌬

Spell your name using real satellite imagery from NASA!

📌 *Example:*
➤ .nasaimg Sula

${botfooter}`
                }, { quoted: mek });
            }

            const args = q.trim().split(' ');
            let targetJid = null;
            let nameQuery = q;
            let isCustomTarget = false;

            if (
                args[0]?.includes('@s.whatsapp.net') ||
                args[0]?.includes('@g.us') ||
                args[0]?.includes('@lid')
            ) {
                targetJid = args[0];
                nameQuery = args.slice(1).join(' ');
                isCustomTarget = true;
            }

            nameQuery = nameQuery.replace(/\s+/g, '');

            if (nameQuery.length > 15) {
                throw new Error('Please provide a name shorter than 15 characters.');
            }

            await conn.sendMessage(from, {
                react: {
                    text: '⏳',
                    key: mek.key
                }
            });

            const { data } = await axios.get(
                `${NASA_API}?name=${encodeURIComponent(nameQuery)}`
            );

            if (!data.success || !data.letters || data.letters.length === 0) {
                throw new Error('Failed to fetch Landsat images for this name.');
            }

            // Map all the working satellite letter URLs from the API response
            const mediaCards = data.letters.map((item, index) => ({
                image: { url: item.imageUrl },
                caption: `🔠 *Letter:* ${item.letter.toUpperCase()} (${index + 1}/${data.letters.length})`
            }));

            // Main introductory header block
            const introductionText = `╭────♡◉◉◉♡────⌬
🚀 *NASA LANDSAT ALBUM GENERATED*
╰────♡◉◉◉♡────⌬

🗺️ *Text:* ${data.cleanName.toUpperCase()}
🛰️ *Source:* NASA Landsat Database

Swipe through the images below to see your name spelled in satellite photography! 🌌

${botfooter}`;

            const activeTarget = targetJid || from;

            // Step 1: Send the main text banner
            await conn.sendMessage(activeTarget, { text: introductionText }, { quoted: mek });

            // Step 2: Stream all the cards sequentially into a clean chat album block
            for (const card of mediaCards) {
                await conn.sendMessage(activeTarget, card);
            }

            if (isCustomTarget && targetJid) {
                await conn.sendMessage(from, {
                    text: `✅ Successfully delivered NASA Landsat album to thread: ${targetJid}`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, {
                react: {
                    text: '✅',
                    key: mek.key
                }
            });

        } catch (err) {
            await conn.sendMessage(from, {
                react: {
                    text: '❌',
                    key: mek.key
                }
            });

            return conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
❌ *NASA API GENERATOR ERROR*
╰────♡◉◉◉♡────⌬

📌 *Reason:*
➤ ${err.message}

${botfooter}`
            }, { quoted: mek });
        }
    }
};
