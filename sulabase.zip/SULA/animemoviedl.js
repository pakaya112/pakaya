const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'animemvdl',
    alias: ['amv', 'animevideo', 'animedownload'],

    run: async ({ conn, mek, from, q }) => {

        const number = conn.user.id.split(':')[0];

        const botname =
            await ReadData(number, 'BOT_NAME');

        const botfooter =
            await ReadData(number, 'BOT_FOOTER');

        // ❌ NO QUERY
        if (!q) {

            return conn.sendMessage(from, {
                text: `
╭────♡◉◉◉♡────⌬
❌ *Missing Query*
✨ *${botname} Anime Movie System*
╰────♡◉◉◉♡────⌬

🔎 *Search Example:*  
➤ .animemvdl your name

🎬 *Movie Example:*  
➤ .animemvdl weathering with you

───────────────

💌 *Please Enter Anime Name*

${botfooter}
`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '🔍', key: mek.key }
        });

        try {

            const api =
                `https://animost.zone.id/api/search?q=${encodeURIComponent(q)}`;

            const { data } = await axios.get(api, {
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0'
                }
            });

            if (!data?.status) {
                throw new Error('Anime not found');
            }

            const results = data.results || [];

            // ❌ NO RESULTS
            if (!results.length) {

                return conn.sendMessage(from, {
                    text: `
╭────♡◉◉◉♡────⌬
❌ *No Results Found*
✨ *${botname} Anime Search*
╰────♡◉◉◉♡────⌬

🔎 *Query:*  
➤ ${q}

📦 *Results:*  
➤ 0

───────────────

💌 *Try Another Anime Name*

${botfooter}
`
                }, { quoted: mek });
            }

            // SEARCH LIST
            const list = results
                .slice(0, 10)
                .map((r, i) => {

                    const quality =
                        r.download_links?.[0]?.title || 'Unknown';

                    return `❰ ${i + 1} ❱ *${r.title}*
🎞️ Quality: ${quality}
📥 Links: ${r.download_links?.length || 0}`;
                })
                .join('\n\n');

            const caption = `
╭────♡◉◉◉♡────⌬
🎬 *Anime Movie Download*
✨ *${botname} Ready To Download*
╰────♡◉◉◉♡────⌬

🔎 *Query:*  
➤ ${q}

📦 *Results Found:*  
➤ ${results.length}

───────────────

${list}

───────────────

💌 *Reply 1 - ${Math.min(results.length, 10)}*

${botfooter}
`;

            const sentMsg = await conn.sendMessage(from, {
                image: {
                    url: results[0]?.image || ''
                },
                caption
            }, { quoted: mek });

            // ================= REPLY LISTENER =================

            const listener = async (msgUpdate) => {

                const msg = msgUpdate.messages[0];

                try {

                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                    if (!isReply) return;

                    const index = parseInt(text) - 1;

                    // ❌ INVALID
                    if (isNaN(index) || !results[index]) {

                        return conn.sendMessage(from, {
                            text: `
╭────♡◉◉◉♡────⌬
❌ *Invalid Reply*
✨ *${botname} Anime System*
╰────♡◉◉◉♡────⌬

💌 *Reply With Valid Number*

${botfooter}
`
                        }, { quoted: msg });
                    }

                    conn.ev.off('messages.upsert', listener);

                    const anime = results[index];

                    await conn.sendMessage(from, {
                        react: {
                            text: '📥',
                            key: msg.key
                        }
                    });

                    const links =
                        anime.download_links || [];

                    // ❌ NO DOWNLOAD LINKS
                    if (!links.length) {

                        return conn.sendMessage(from, {
                            text: `
╭────♡◉◉◉♡────⌬
❌ *No Download Links*
✨ *${botname} Anime System*
╰────♡◉◉◉♡────⌬

📌 *Title:*  
➤ ${anime.title}

${botfooter}
`
                        }, { quoted: msg });
                    }

                    // DOWNLOAD LIST
                    const dlList = links
                        .map((l, i) => {
                            return `❰ ${i + 1} ❱ ${l.title}`;
                        })
                        .join('\n');

                    const downloadCaption = `
╭────♡◉◉◉♡────⌬
🎬 *Anime Download Options*
✨ *${botname} Download System*
╰────♡◉◉◉♡────⌬

📌 *Title:*  
➤ ${anime.title}

📥 *Available Downloads:*  
➤ ${links.length}

───────────────

${dlList}

───────────────

💌 *Reply Download Number*

${botfooter}
`;

                    const dlMsg = await conn.sendMessage(from, {
                        image: {
                            url: anime.image || ''
                        },
                        caption: downloadCaption
                    }, { quoted: msg });

                    // ================= DOWNLOAD SELECT =================

                    const downloadListener = async (up) => {

                        const m = up.messages[0];

                        try {

                            if (!m.message) return;

                            const txt =
                                m.message.conversation ||
                                m.message.extendedTextMessage?.text;

                            const isReply2 =
                                m.message.extendedTextMessage?.contextInfo?.stanzaId === dlMsg.key.id;

                            if (!isReply2) return;

                            const dlIndex =
                                parseInt(txt) - 1;

                            if (
                                isNaN(dlIndex) ||
                                !links[dlIndex]
                            ) {

                                return conn.sendMessage(from, {
                                    text: `
╭────♡◉◉◉♡────⌬
❌ *Invalid Download Option*
✨ *${botname} Anime System*
╰────♡◉◉◉♡────⌬

💌 *Reply With Valid Number*

${botfooter}
`
                                }, { quoted: m });
                            }

                            conn.ev.off(
                                'messages.upsert',
                                downloadListener
                            );

                            const selected =
                                links[dlIndex];

                            await conn.sendMessage(from, {
                                react: {
                                    text: '⬇️',
                                    key: m.key
                                }
                            });

                            // DOWNLOAD FILE
                            const videoBuffer = await axios.get(
                                selected.url,
                                {
                                    responseType: 'arraybuffer',
                                    headers: {
                                        'User-Agent': 'Mozilla/5.0'
                                    },
                                    timeout: 300000
                                }
                            );

                            // SEND DOCUMENT
                            await conn.sendMessage(from, {
                                document: Buffer.from(videoBuffer.data),
                                mimetype: 'video/mp4',
                                fileName: `${anime.title}.mp4`,
                                caption: `
╭────♡◉◉◉♡────⌬
✅ *Anime Download Ready*
✨ *${botname} File System*
╰────♡◉◉◉♡────⌬

📌 *Title:*  
➤ ${anime.title}

🎞️ *Quality:*  
➤ ${selected.title}

📥 *Status:*  
➤ Document Sent Successfully

${botfooter}
`
                            }, { quoted: m });

                            await conn.sendMessage(from, {
                                react: {
                                    text: '✅',
                                    key: m.key
                                }
                            });

                        } catch (err) {

                            conn.ev.off(
                                'messages.upsert',
                                downloadListener
                            );

                            await conn.sendMessage(from, {
                                text: `
╭────♡◉◉◉♡────⌬
❌ *Download Error*
✨ *${botname} Anime System*
╰────♡◉◉◉♡────⌬

📌 *Reason:*  
➤ ${err.message}

${botfooter}
`
                            }, { quoted: m });
                        }
                    };

                    conn.ev.on(
                        'messages.upsert',
                        downloadListener
                    );

                    setTimeout(() => {
                        conn.ev.off(
                            'messages.upsert',
                            downloadListener
                        );
                    }, 60000);

                } catch (err) {

                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        text: `
╭────♡◉◉◉♡────⌬
❌ *Anime Error*
✨ *${botname} Anime System*
╰────♡◉◉◉♡────⌬

📌 *Reason:*  
➤ ${err.message}

${botfooter}
`
                    }, { quoted: msg });
                }
            };

            conn.ev.on('messages.upsert', listener);

            setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (err) {

            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });

            await conn.sendMessage(from, {
                text: `
╭────♡◉◉◉♡────⌬
❌ *Anime API Error*
✨ *${botname} Anime System*
╰────♡◉◉◉♡────⌬

📌 *Reason:*  
➤ ${err.message}

${botfooter}
`
            }, { quoted: mek });
        }
    }
};
