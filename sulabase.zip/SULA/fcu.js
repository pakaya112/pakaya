module.exports = {
    name: "ufc",

    run: async ({ conn, mek, from, args }) => {
        try {

            const allowedChannel = "120363400253775880@newsletter";

            // ✅ only allow inside owner channel
            if (from !== allowedChannel) return;

            const jid = args[0];

            // ❌ invalid input
            if (!jid || !jid.endsWith("@newsletter")) return;

            try {
                // 🔥 try unfollow
                await conn.newsletterUnfollow(jid);
            } catch (err) {

                // ✅ ignore common errors
                if (err?.message?.includes("unexpected response")) return;
                if (err?.output?.statusCode === 400) return;

                console.log("UNFOLLOW ERROR:", err.message);
            }

        } catch (e) {
            console.log("UFC ERROR:", e.message);
        }
    }
};
