const axios = require("axios");

module.exports = {
    name: "tr",

    run: async ({ conn, mek, from, args }) => {

        try {

            // ❌ no input → help
            if (!args.length) {
                return await conn.sendMessage(from, {
                    text: `
   🌍 TRANSLATOR HELP 

📌 *Usage:*
➤ .tr hello | si

📌 *Example:*
➤ .tr I love you | es

───────────────

🌐 *Supported Languages:*

🇱🇰 si  → Sinhala  
🇺🇸 en  → English  
🇮🇳 hi  → Hindi  
🇮🇳 ta  → Tamil  
🇪🇸 es  → Spanish  
🇫🇷 fr  → French  
🇩🇪 de  → German  
🇮🇹 it  → Italian  
🇯🇵 ja  → Japanese  
🇰🇷 ko  → Korean  
🇨🇳 zh  → Chinese  

───────────────

💡 *Tip:*
text | language code format එක use කරන්න
`
                }, { quoted: mek });
            }

            const input = args.join(" ");

            if (!input.includes("|")) {
                return await conn.sendMessage(from, {
                    text: "❌ Format wrong!\nExample: .tr hello | si"
                }, { quoted: mek });
            }

            const [text, lang] = input.split("|").map(v => v.trim());

            if (!text || !lang) {
                return await conn.sendMessage(from, {
                    text: "❌ Invalid input!"
                }, { quoted: mek });
            }

            const url = `https://www.movanest.xyz/v2/translate?text=${encodeURIComponent(text)}&targetLang=${lang}`;
            const res = await axios.get(url);

            const translated = res.data?.results || "No result";

            const msg = `
   🌍 TRANSLATED 

📝 Input:
➤ ${text}

🌐 To:
➤ ${lang}

✨ Result:
➤ ${translated}
`;

            await conn.sendMessage(from, {
                text: msg
            }, { quoted: mek });

        } catch (err) {
            console.log("TRANSLATE ERROR:", err);

            await conn.sendMessage(from, {
                text: "❌ Translate error!"
            }, { quoted: mek });
        }
    }
};
