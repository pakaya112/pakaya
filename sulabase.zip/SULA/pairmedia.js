module.exports = {
    name: 'pairmedia',
    alias: ['pmedia', 'bot'],

    run: async ({ conn, mek, from }) => {
        try {

            const {
                prepareWAMessageMedia,
                generateWAMessageFromContent
            } = await import('baileys');

            // 🖼️ SULA IMAGE
            const image = await prepareWAMessageMedia(
                {
                    image: {
                        url: 'https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg'
                    }
                },
                {
                    upload: conn.waUploadToServer
                }
            );

            // 🎥 SULA VIDEO
            const video = await prepareWAMessageMedia(
                {
                    video: {
                        url: 'https://github.com/sulamadara1147/data/raw/refs/heads/main/VID-20250415-WA0268.mp4'
                    }
                },
                {
                    upload: conn.waUploadToServer
                }
            );

            // 🖼️ Create image message
            const msg = generateWAMessageFromContent(
                from,
                {
                    imageMessage: {
                        ...image.imageMessage,

                        contextInfo: {
                            pairedMediaType: 5,
                            statusSourceType: 0
                        }
                    }
                },
                {}
            );

            // 📤 Send image
            await conn.relayMessage(
                from,
                msg.message,
                {
                    messageId: msg.key.id
                }
            );

            // 🎥 Send paired video
            await conn.relayMessage(
                from,
                {
                    videoMessage: {
                        ...video.videoMessage,

                        contextInfo: {
                            pairedMediaType: 6,
                            statusSourceType: 0
                        }
                    },

                    messageContextInfo: {
                        messageAssociation: {
                            associationType: 12,
                            parentMessageKey: msg.key
                        }
                    }
                },
                {}
            );

            console.log('✅ SULA paired media sent successfully');

        } catch (err) {

            console.error('PAIRMEDIA ERROR:', err);

            await conn.sendMessage(
                from,
                {
                    text: `❌ Paired media error!\n\n${err.message}`
                },
                { quoted: mek }
            );
        }
    }
};
