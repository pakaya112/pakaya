const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'aidetect',
    alias: ['aidetec', 'aicheck', 'gptdetect', 'txtdetect'],

    run: async ({ conn, mek, from, q }) => {

        if (!q) {
            return await conn.sendMessage(
                from,
                {
                    text: `❌ *Please provide text to analyze!*

📌 Example:
*.aidetect This text may have been written by AI*`
                },
                { quoted: mek }
            );
        }

        try {

            await conn.sendMessage(from, {
                react: {
                    text: '🧠',
                    key: mek.key
                }
            });

            const number = conn.user.id.split(':')[0];

            const botname =
                await ReadData(number, 'BOT_NAME') ||
                'SULA MD';

            const botfooter =
                await ReadData(number, 'BOT_FOOTER') ||
                '© SULA MD';

            const Images =
                await ReadData(number, 'SULA_IMAGE_PATH') ||
                'https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg';

            const apiUrl =
                `https://api.bk9.dev/tools/txtdetect?q=${encodeURIComponent(q)}`;

            const { data } = await axios.get(apiUrl, {
                timeout: 60000,
                headers: {
                    'User-Agent': 'Mozilla/5.0',
                    Accept: 'application/json'
                }
            });

            if (!data?.status || !data?.BK9?.success) {
                throw new Error(
                    data?.BK9?.message || 'AI Detection Failed'
                );
            }

            const result = data.BK9.data || {};

            const human =
                parseFloat(result.isHuman) || 0;

            const fake =
                parseFloat(result.fakePercentage) || 0;

            const ai =
                Math.max(0, 100 - human);

            let verdict = 'Unknown';
            let emoji = '❔';

            if (human >= 70) {
                verdict = 'Most Likely Human Written';
                emoji = '🧑';
            } else if (human >= 40) {
                verdict = 'Mixed / Unclear';
                emoji = '⚠️';
            } else {
                verdict = 'Most Likely AI Generated';
                emoji = '🤖';
            }

            const inputPreview =
                (result.input_text || q).slice(0, 500);

            const specialSentences =
                Array.isArray(result.specialSentences)
                    ? result.specialSentences.slice(0, 5)
                    : [];

            const flaggedText =
                specialSentences.length
                    ? specialSentences
                          .map(
                              (sentence, index) =>
                                  `❰ ${index + 1} ❱ ${sentence}`
                          )
                          .join('\n')
                    : 'No suspicious sentences detected';

            const caption = `
╭━━━〔 🧠 AI TEXT DETECTOR 〕━━━⬣

${emoji} *Verdict:* ${verdict}

📊 *Human Score:* ${human.toFixed(1)}%
🤖 *AI Score:* ${ai.toFixed(1)}%
⚠️ *Fake Percentage:* ${fake.toFixed(1)}%

🌐 *Detected Language:* ${result.detected_language || 'Unknown'}

━━━━━━━━━━━━━━━━━━

💬 *Feedback:*
${result.feedback || 'No feedback available'}

📝 *Additional Notes:*
${result.additional_feedback || 'No additional feedback'}

━━━━━━━━━━━━━━━━━━

📌 *Text Preview:*

${inputPreview}${
                (result.input_text || q).length > 500
                    ? '...'
                    : ''
            }

━━━━━━━━━━━━━━━━━━

🔎 *Flagged Sentences:*

${flaggedText}

━━━━━━━━━━━━━━━━━━

🤖 *Bot:* ${botname}

${botfooter}
`;

            await conn.sendMessage(
                from,
                {
                    image: {
                        url: Images
                    },
                    caption: caption
                },
                { quoted: mek }
            );

            await conn.sendMessage(from, {
                react: {
                    text: '✅',
                    key: mek.key
                }
            });

        } catch (err) {

            console.error('AI Detect Error:', err);

            await conn.sendMessage(from, {
                react: {
                    text: '❌',
                    key: mek.key
                }
            });

            await conn.sendMessage(
                from,
                {
                    text: `❌ *AI DETECT ERROR*

📛 *Reason:*
${err.message}`
                },
                { quoted: mek }
            );
        }
    }
};
