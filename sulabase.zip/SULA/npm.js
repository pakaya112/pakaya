const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: "npm",
    alias: ["npms", "package"],
    category: "tools",
    description: "Search npm package details.",

    run: async ({ conn, mek, from, q }) => {

        try {

            const number = conn.user.id.split(':')[0];

            const botname = await ReadData(number, "BOT_NAME");
            const botfooter = await ReadData(number, "BOT_FOOTER");

            if (!q) {

                return await conn.sendMessage(from, {
                    text: `
╭────♡◉◉◉♡────⌬
📦 *NPM PACKAGE SEARCH*  
🌸 *${botname} Developer Tools* ✨  
╰────♡◉◉◉♡────⌬

❌ *Please provide package name*

📌 *Example:*  
➤ .npm express

💖 Search package details instantly from npmjs.

${botfooter}
`
                }, { quoted: mek });

            }

            await conn.sendMessage(from, {
                react: { text: '🔎', key: mek.key }
            });

            const apiUrl = `https://registry.npmjs.org/${encodeURIComponent(q)}`;

            const { data, status } = await axios.get(apiUrl);

            if (status !== 200) {

                return await conn.sendMessage(from, {
                    text: `❌ Package not found!\n\n${botfooter}`
                }, { quoted: mek });

            }

            const latestVersion = data["dist-tags"]?.latest || 'N/A';

            const description =
                data.description || 'No description available.';

            const license =
                data.license || 'Unknown';

            const npmUrl =
                `https://www.npmjs.com/package/${q}`;

            const repository = data.repository
                ? data.repository.url
                    .replace('git+', '')
                    .replace('.git', '')
                : 'Not available';

            const homepage =
                data.homepage || 'Not available';

            const keywords =
                data.keywords?.join(', ') || 'None';

            const caption = `
╭────♡◉◉◉♡────⌬
📦 *NPM PACKAGE RESULT*  
🌸 *${botname} found your package ✨*  
╰────♡◉◉◉♡────⌬

📌 *PACKAGE NAME*  
➤ ${q}

📝 *DESCRIPTION*  
➤ ${description}

⚡ *LATEST VERSION*  
➤ ${latestVersion}

🪪 *LICENSE*  
➤ ${license}

🌐 *REPOSITORY*  
➤ ${repository}

🔗 *NPM URL*  
➤ ${npmUrl}

🏠 *HOMEPAGE*  
➤ ${homepage}

🏷️ *KEYWORDS*  
➤ ${keywords}

───────────────

💖 *Developer tools made easier with ${botname}* ✨

${botfooter}
`;

            await conn.sendMessage(from, {
                text: caption
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '✅', key: mek.key }
            });

        } catch (err) {

           // console.log("NPM ERROR:", err);

            await conn.sendMessage(from, {
                text: `
❌ *NPM Search Failed*

📌 Reason: ${err.message}

${botfooter || ""}
`
            }, { quoted: mek });

        }
    }
};