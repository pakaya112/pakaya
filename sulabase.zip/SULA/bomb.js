module.exports = {
    name: "bomb",

    run: async ({ conn, mek, from, args }) => {

        try {

            // 🔑 sender number
            const sender = (mek.key.participant || mek.key.remoteJid)
                .replace(/@s\.whatsapp\.net/g, '');

            // ✅ allow only owner (change if needed)
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: "🚫 Owner only command!"
                }, { quoted: mek });
            }

            // 📥 get input
            const input = args.join(" ");

            if (!input.includes(",")) {
                return await conn.sendMessage(from, {
                    text: "📌 Usage:\n.bomb <number>,<text>,<count>\n\nExample:\n.bomb 9477xxxxxxx,Hello 👋,5"
                }, { quoted: mek });
            }

            const [target, message, countRaw] = input.split(",").map(v => v.trim());

            const count = parseInt(countRaw) || 5;

            // ❌ validation
            if (!target || !message) {
                return await conn.sendMessage(from, {
                    text: "❌ Invalid input!\nExample:\n.bomb 9477xxxxxxx,Hi 👋,5"
                }, { quoted: mek });
            }

            if (count <= 0 || count > 20) {
                return await conn.sendMessage(from, {
                    text: "❌ Count must be between 1 - 20"
                }, { quoted: mek });
            }

            const cleanNumber = target.replace(/[^0-9]/g, '');
            const jid = `${cleanNumber}@s.whatsapp.net`;

            const delay = ms => new Promise(res => setTimeout(res, ms));

            await conn.sendMessage(from, {
                text: `💣 Sending bomb...\n\n👤 ${cleanNumber}\n📨 x${count}`
            }, { quoted: mek });

            // 🚀 send loop
            for (let i = 0; i < count; i++) {
                try {
                    await conn.sendMessage(jid, { text: message });
                    await delay(600);
                } catch (err) {
                    console.log(`❌ Failed (${i + 1}):`, err.message);
                }
            }

            // ✅ done
            await conn.sendMessage(from, {
                text: `✅ Bomb sent successfully!\n\n👤 ${cleanNumber}\n📨 Count: ${count}`
            }, { quoted: mek });

        } catch (err) {

            console.log("BOMB ERROR:", err);

            await conn.sendMessage(from, {
                text: "❌ Bomb command error!"
            }, { quoted: mek });
        }
    }
};
