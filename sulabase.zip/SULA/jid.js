module.exports = {
    name: 'jid',
    run: async ({ conn, mek, from, q }) => {

        try {
            let chatJid = from;
            let jidType = 'User';
            let gggg = mek.key.remoteJidAlt || '';

        
            const quoted = mek.message?.extendedTextMessage?.contextInfo?.participant;

            if (quoted) {
                chatJid = quoted;

            } else if (q) {
                const input = q.replace(/[^0-9@.]/g, '');

              
                if (/^[0-9]{9,15}$/.test(input)) {
                    chatJid = `${input}@s.whatsapp.net`;

        
                } else if (input.endsWith('@g.us')) {
                    chatJid = input;
                    jidType = 'Group';

            
                } else if (input.endsWith('@newsletter')) {
                    chatJid = input;
                    jidType = 'Newsletter';

                } else {
                    return conn.sendMessage(from, {
                        text: '❌ Invalid input!\n\nSend:\n• Phone number\n• Group JID\n• Or reply a message'
                    }, { quoted: mek });
                }

            } else {
                if (from.endsWith('@g.us')) jidType = 'Group';
                if (from.endsWith('@newsletter')) jidType = 'Newsletter';
            }

            const caption = `
*🆔 𝐂hat 𝐉ID:*   ${gggg}
*🏷️ 𝐂hat 𝐋ID:*   ${chatJid} 
*📞 𝐂hat 𝐓YPE:*  ${jidType}`;

            await conn.sendMessage(from, {
                text: caption
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '✅', key: mek.key }
            });

        } catch (err) {
            console.error(err);

            await conn.sendMessage(from, {
                text: '❌ Error retrieving JID!'
            }, { quoted: mek });
        }
    }
};
