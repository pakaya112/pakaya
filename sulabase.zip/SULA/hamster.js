const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'hamster',
    alias: ['hamsterdl', 'xhamster'],
    run: async ({ conn, mek, from, q }) => {

        if (!q || !q.startsWith('http')) {
            return conn.sendMessage(from, {
                text: `╭─❌ *INVALID URL*
│ Example:
│ .hamster https://xhamster.com/videos/xxxx
╰───────────────`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, { react: { text: '⏳', key: mek.key } });

        try {
            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'THENUX BOT';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© THENUX';

            const fixedUrl = q
                .replace('https://hamster.com/', 'https://xhamster.com/')
                .replace('http://hamster.com/', 'https://xhamster.com/');

            const apiUrl = `https://thenux-hamsterdl.netlify.app/api/savethevideo?url=${encodeURIComponent(fixedUrl)}`;

            let data;
            let lastError = '';

            for (let i = 1; i <= 3; i++) {
                const res = await axios.get(apiUrl, {
                    timeout: 180000,
                    validateStatus: () => true,
                    headers: {
                        'User-Agent': 'Mozilla/5.0',
                        'Accept': 'application/json'
                    }
                });

                data = res.data;

                if (res.status === 200 && data?.success) break;

                lastError = data?.error || data?.message || `API status ${res.status}`;
                await new Promise(r => setTimeout(r, 5000));
            }

            if (!data?.success) {
                throw new Error(lastError || 'API failed');
            }

            const meta = data.metadata || {};
            const video = data.downloads?.find(v => v.format === 'mp4') || data.downloads?.[0];

            if (!video?.direct_download) {
                throw new Error('Video download link not found');
            }

            const caption = `
╭────♡◉◉◉♡────⌬
🔥 *HAMSTER VIDEO READY*
╰────♡◉◉◉♡────⌬

🎬 *Title:*
${meta.title || 'No Title'}

📺 *Quality:* ${video.quality || 'Auto'}
🎞️ *Format:* ${video.format || 'mp4'}

───────────────
❶ 📽️ Video
❷ 📁 Document

💌 *Reply:* 1 / 2

${botfooter}
`;

            const sentMsg = await conn.sendMessage(from, {
                image: { url: meta.thumbnail || '' },
                caption
            }, { quoted: mek });

            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];

                try {
                    if (!msg.message) return;

                    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                    const isReply = msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                    if (!isReply) return;

                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        react: { text: '⬇️', key: msg.key }
                    });

                    const fileName = `${(meta.title || 'hamster_video')
                        .replace(/[\\/:*?"<>|]/g, '')
                        .slice(0, 50)}.mp4`;

                    if (text === '1') {
                        await conn.sendMessage(from, {
                            video: { url: video.direct_download },
                            mimetype: 'video/mp4',
                            fileName,
                            caption: `✅ *Downloaded Successfully*\n\n${botname}`
                        }, { quoted: msg });

                    } else if (text === '2') {
                        await conn.sendMessage(from, {
                            document: { url: video.direct_download },
                            mimetype: 'video/mp4',
                            fileName
                        }, { quoted: msg });

                    } else {
                        return conn.sendMessage(from, {
                            text: '❌ Reply only with 1 or 2'
                        }, { quoted: msg });
                    }

                    await conn.sendMessage(from, {
                        react: { text: '✅', key: msg.key }
                    });

                } catch (err) {
                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        text: `╭─❌ *DOWNLOAD ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
                    }, { quoted: msg });
                }
            };

            conn.ev.on('messages.upsert', listener);

            setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (err) {
            await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });

            await conn.sendMessage(from, {
                text: `╭─❌ *HAMSTER API ERROR*
│
│ *Reason:* ${err.message}
│
│ Try xhamster.com link instead of hamster.com.
╰───────────────`
            }, { quoted: mek });
        }
    }
};
