const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'fetch',
    alias: ['get', 'api', 'json', 'curl'],
    run: async ({ conn, mek, from, q }) => {

        if (!q || !q.startsWith('http')) {
            return conn.sendMessage(from, {
                text: `╭─❌ *INVALID URL*
│
│ Use:
│ .fetch https://api.example.com/data
│
│ Also works:
│ .api https://example.com
╰───────────────`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '⏳', key: mek.key }
        });

        try {
            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'THENUX BOT';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© THENUX';

            const start = Date.now();

            const res = await axios.get(q, {
                timeout: 30000,
                maxRedirects: 5,
                validateStatus: () => true,
                headers: {
                    'User-Agent': 'Mozilla/5.0',
                    'Accept': '*/*'
                }
            });

            const ms = Date.now() - start;
            const contentType = res.headers['content-type'] || 'unknown';

            let output;
            let mode = 'TEXT';

            if (typeof res.data === 'object') {
                mode = 'JSON';
                output = JSON.stringify(res.data, null, 2);
            } else {
                output = String(res.data);
                if (output.trim().startsWith('{') || output.trim().startsWith('[')) {
                    try {
                        output = JSON.stringify(JSON.parse(output), null, 2);
                        mode = 'JSON';
                    } catch {}
                } else if (output.includes('<html') || output.includes('<!DOCTYPE')) {
                    mode = 'HTML';
                }
            }

            if (output.length > 3500) {
                output = output.slice(0, 3500) + '\n\n...TRUNCATED';
            }

            await conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
🌐 *FETCH RESULT*
╰────♡◉◉◉♡────⌬

🔗 *URL:*
${q}

📡 *Status:* ${res.status}
⚡ *Time:* ${ms}ms
📦 *Type:* ${contentType}
🧾 *Mode:* ${mode}

───────────────

\`\`\`${output}\`\`\`

${botfooter}`
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '✅', key: mek.key }
            });

        } catch (err) {
            await conn.sendMessage(from, {
                text: `╭─❌ *FETCH ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });
        }
    }
};
