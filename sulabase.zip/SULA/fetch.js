const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'fetch',
    alias: ['udpony', 'thenuxkriya', 'sulabdu', 'udhikaputha'],
    run: async ({ conn, mek, from, q }) => {
        if (!q) {
            return conn.sendMessage(from, {
                text: `╭─❌ *INVALID URL*
│
│ *Basic Usage:*
│ .fetch <URL>
│ .fetch <targetJID> <URL>
│
│ *Advanced Usage:*
│ .fetch URL | METHOD | BODY | HEADERS
│
│ *Examples:*
│ 1. Standard GET Request:
│ .fetch https://example.com
│
│ 2. Direct File Download (Targeted):
│ .fetch 947046785766@s.whatsapp.net https://example.com/file.mp4
│
│ 3. POST Request with JSON Body:
│ .fetch https://api.ex.com/users | POST | {"name":"Bot"}
│
│ 4. Passing Custom Headers:
│ .fetch https://api.ex.com/data | GET | null | {"Authorization":"Bearer 123"}
╰───────────────`
            }, { quoted: mek });
        }

        const rawInput = q.trim();
        let targetJid = from;
        let urlInput = rawInput;

        // Parse target JID if present (e.g. .fetch 947046785766@s.whatsapp.net url)
        const args = rawInput.split(/\s+/);
        if (args.length > 1) {
            let potentialJid = args[0];
            if (/^\d+$/.test(potentialJid)) {
                potentialJid = `${potentialJid}@s.whatsapp.net`;
            }
            if (potentialJid.includes('@s.whatsapp.net') || potentialJid.includes('@g.us') || potentialJid.includes('@lid')) {
                targetJid = potentialJid;
                urlInput = args.slice(1).join(' ');
            }
        }

        // Parse custom methods/body/headers
        const parts = urlInput.split('|').map(p => p.trim());
        const urlStr = parts[0];
        const method = (parts[1] || 'GET').toUpperCase();
        const bodyStr = parts[2] || null;
        const headersStr = parts[3] || null;

        if (!urlStr || !urlStr.startsWith('http')) {
            return conn.sendMessage(from, {
                text: `╭─❌ *INVALID URL*
│
│ Please provide a valid HTTP/HTTPS link.
│ Example: .fetch https://example.com
╰───────────────`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '⏳', key: mek.key }
        });

        try {
            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'THENUX BOT';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© THENUX';

            let requestBody = undefined;
            if (bodyStr && bodyStr !== 'null') {
                try {
                    requestBody = JSON.parse(bodyStr);
                } catch {
                    requestBody = bodyStr;
                }
            }

            let customHeaders = {};
            if (headersStr && headersStr !== 'null') {
                try {
                    customHeaders = JSON.parse(headersStr);
                } catch {}
            }

            const start = Date.now();

            // Perform stream request to inspect content-type before reading the whole body into RAM
            const res = await axios({
                method: method,
                url: urlStr,
                data: requestBody,
                headers: Object.assign({
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': '*/*'
                }, customHeaders),
                timeout: 60000,
                maxRedirects: 5,
                validateStatus: () => true,
                responseType: 'stream'
            });

            const ms = Date.now() - start;
            const contentTypeHeader = res.headers['content-type'] || 'application/octet-stream';
            const contentType = contentTypeHeader.split(';')[0].trim().toLowerCase();

            const isText = 
                contentType.includes('json') ||
                contentType.includes('text') ||
                contentType.includes('javascript') ||
                contentType.includes('xml') ||
                contentType.includes('html');

            if (!isText) {
                // Destroy stream immediately to consume 0 RAM and avoid downloading the file locally
                res.data.destroy();

                let fileName = 'file';
                const contentDisposition = res.headers['content-disposition'];
                if (contentDisposition) {
                    const match = contentDisposition.match(/filename=["']?([^"';]+)["']?/i);
                    if (match && match[1]) {
                        fileName = match[1];
                    }
                } else {
                    try {
                        const parsedUrl = new URL(urlStr);
                        const pathname = parsedUrl.pathname;
                        const lastPart = pathname.substring(pathname.lastIndexOf('/') + 1);
                        if (lastPart && lastPart.includes('.')) {
                            fileName = decodeURIComponent(lastPart);
                        }
                    } catch {}
                }

                if (!fileName.includes('.')) {
                    const extMap = {
                        'video/mp4': 'mp4',
                        'video/3gpp': '3gp',
                        'video/quicktime': 'mov',
                        'video/x-msvideo': 'avi',
                        'audio/mpeg': 'mp3',
                        'audio/ogg': 'ogg',
                        'audio/wav': 'wav',
                        'audio/webm': 'webm',
                        'image/jpeg': 'jpg',
                        'image/png': 'png',
                        'image/gif': 'gif',
                        'application/pdf': 'pdf',
                        'application/zip': 'zip',
                        'application/x-zip-compressed': 'zip',
                        'application/vnd.android.package-archive': 'apk'
                    };
                    const ext = extMap[contentType] || 'bin';
                    fileName = `${fileName}.${ext}`;
                }

                const caption = `╭────♡◉◉◉♡────⌬
📦 *FETCH FILE DOWNLOAD*
╰────♡◉◉◉♡────⌬

🔗 *Source URL:*
${urlStr}

📁 *File Name:* ${fileName}
📦 *MIME Type:* ${contentType}
📡 *Status:* ${res.status}
⚡ *Resolved In:* ${ms}ms

${botfooter}`;

                // Send directly using URL stream in Baileys (0 local storage, 0 ram buffer)
                await conn.sendMessage(targetJid, {
                    document: { url: urlStr },
                    mimetype: contentType,
                    fileName: fileName,
                    caption: caption
                }, { quoted: mek });

                if (targetJid !== from) {
                    await conn.sendMessage(from, {
                        text: `✅ File successfully dispatched to target JID: ${targetJid}`
                    }, { quoted: mek });
                }

                await conn.sendMessage(from, {
                    react: { text: '✅', key: mek.key }
                });

                return;
            }

            // Read text output with limits to prevent buffer overflow/RAM spikes
            let output = '';
            await new Promise((resolve, reject) => {
                res.data.on('data', chunk => {
                    output += chunk.toString();
                    if (output.length > 50000) {
                        res.data.destroy();
                        resolve();
                    }
                });
                res.data.on('end', resolve);
                res.data.on('error', reject);
            });

            let mode = 'TEXT';
            if (contentType.includes('json')) {
                mode = 'JSON';
                try {
                    output = JSON.stringify(JSON.parse(output), null, 2);
                } catch {}
            } else if (contentType.includes('html')) {
                mode = 'HTML';
            }

            if (output.length > 3500) {
                output = output.slice(0, 3500) + '\n\n...TRUNCATED';
            }

            const responseText = `╭────♡◉◉◉♡────⌬
🌐 *FETCH RESULT*
╰────♡◉◉◉♡────⌬

🔗 *URL:*
${urlStr}

📡 *Status:* ${res.status}
⚡ *Time:* ${ms}ms
📦 *Type:* ${contentTypeHeader}
🧾 *Mode:* ${mode}

───────────────

\`\`\`${output}\`\`\`

${botfooter}`;

            await conn.sendMessage(targetJid, {
                text: responseText
            }, { quoted: mek });

            if (targetJid !== from) {
                await conn.sendMessage(from, {
                    text: `✅ Fetch results successfully dispatched to target JID: ${targetJid}`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, {
                react: { text: '✅', key: mek.key }
            });

        } catch (err) {
            await conn.sendMessage(from, {
                text: `╭─❌ *FETCH ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });
        }
    }
};
