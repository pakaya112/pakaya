const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'ttsearch',
    alias: ['tiktoksearch', 'tsearch'],

    run: async ({ conn, mek, from, q }) => {

        try {

            const number = conn.user.id.split(':')[0];

            const botname =
                await ReadData(number, 'BOT_NAME');

            const botfooter =
                await ReadData(number, 'BOT_FOOTER');

            if (!q) {

                return await conn.sendMessage(from, {
                    text:
`╭────♡◉◉◉♡────⌬
🔍 *TIKTOK SEARCH PANEL*
🌸 *${botname} TikTok Search*
╰────♡◉◉◉♡────⌬

❌ *Please enter a search query*

📌 *Example:*
➤ .ttsearch sula

${botfooter}`
                }, { quoted: mek });

            }

            await conn.sendMessage(from, {
                react: {
                    text: '🔎',
                    key: mek.key
                }
            });

            const api =
`https://apis-starlights-team.koyeb.app/starlight/tiktoksearch?text=${encodeURIComponent(q)}`;

            const { data } = await axios.get(api);

            if (!data?.data?.length) {

                return await conn.sendMessage(from, {
                    text:
`╭────♡◉◉◉♡────⌬
❌ *NO RESULTS FOUND*
╰────♡◉◉◉♡────⌬

🔎 Query:
➤ ${q}

${botfooter}`
                }, { quoted: mek });

            }

            const results = data.data.slice(0, 10);

            let caption =
`╭────♡◉◉◉♡────⌬
🎵 *TIKTOK SEARCH RESULTS*
✨ *${botname} TikTok Engine*
╰────♡◉◉◉♡────⌬

🔎 *Search:* ${q}

📥 *Reply Number To Download*

────────────────\n`;

            results.forEach((item, index) => {

                caption +=
`*${index + 1} • ${item.author}*

🎬 ${item.title || 'No Title'}

❤️ ${item.likes.toLocaleString()}
👀 ${item.views.toLocaleString()}

────────────────\n`;

            });

            caption += `\n${botfooter}`;

            const sentMsg = await conn.sendMessage(from, {
                image: { url: results[0].cover },
                caption
            }, { quoted: mek });

            const listener = async (msgUpdate) => {

                try {

                    const msg = msgUpdate.messages[0];
                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message?.extendedTextMessage?.contextInfo?.stanzaId ===
                        sentMsg.key.id;

                    if (!isReply) return;

                    const index = parseInt(text);

                    if (
                        isNaN(index) ||
                        index < 1 ||
                        index > results.length
                    ) {

                        return await conn.sendMessage(from, {
                            text:
`╭────♡◉◉◉♡────⌬
❌ *INVALID NUMBER*
╰────♡◉◉◉♡────⌬

📌 Reply with numbers
➤ 1 - ${results.length}

${botfooter}`
                        }, { quoted: msg });

                    }

                    clearTimeout(timeout);
                    conn.ev.off('messages.upsert', listener);

                    const selected =
                        results[index - 1];

                    await conn.sendMessage(from, {
                        react: {
                            text: '⬇️',
                            key: msg.key
                        }
                    });

                    const videoCaption =
`╭────♡◉◉◉♡────⌬
🎬 *TIKTOK VIDEO READY*
✨ *Downloaded Successfully*
╰────♡◉◉◉♡────⌬

👤 *Author:*
➤ ${selected.author}

📝 *Title:*
➤ ${selected.title || 'No Title'}

❤️ *Likes:* ${selected.likes.toLocaleString()}
👀 *Views:* ${selected.views.toLocaleString()}

${botfooter}`;

                    await conn.sendMessage(from, {

                        video: {
                            url: selected.nowm
                        },

                        caption: videoCaption

                    }, { quoted: msg });

                    await conn.sendMessage(from, {
                        react: {
                            text: '✅',
                            key: msg.key
                        }
                    });

                } catch (err) {

                    clearTimeout(timeout);
                    conn.ev.off('messages.upsert', listener);

                    console.log(err);

                    await conn.sendMessage(from, {
                        text:
`╭────♡◉◉◉♡────⌬
❌ *DOWNLOAD FAILED*
╰────♡◉◉◉♡────⌬

📌 Reason:
➤ ${err.message}

${botfooter}`
                    }, { quoted: mek });

                }

            };

            const timeout = setTimeout(() => {

                conn.ev.off('messages.upsert', listener);

            }, 60000);

            conn.ev.on('messages.upsert', listener);

        } catch (err) {

            console.log(err);

            await conn.sendMessage(from, {
                text:
`╭────♡◉◉◉♡────⌬
❌ *TIKTOK SEARCH FAILED*
╰────♡◉◉◉♡────⌬

📌 Reason:
➤ ${err.message}

${botfooter}`
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: {
                    text: '❌',
                    key: mek.key
                }
            });

        }

    }
};
