module.exports = {
    name: "chnrl",

    run: async ({ conn, mek, from, args }) => {
        try {

            const allowedChannel = "120363405459268369@newsletter";

            if (from !== allowedChannel) return;

            const body =
                mek.message?.conversation ||
                mek.message?.extendedTextMessage?.text || "";

            const raw = body.replace(/^[.\/!]chnrl\s*/i, '').trim();

            const parts = raw.split(',').map(x => x.trim());

            const link = parts[0];
            const emojiList = parts.slice(1);

            if (!emojiList.length) return;

            const linkParts = link.split('/');
            const channelId = linkParts[4];
            const messageId = linkParts[5];

            if (!channelId || !messageId) return;

            const res = await conn.newsletterMetadata("invite", channelId);

            const randomEmoji = emojiList[
                Math.floor(Math.random() * emojiList.length)
            ];

            await conn.newsletterReactMessage(
                res.id,
                messageId,
                randomEmoji
            );

        } catch (err) {
            console.log("CHNRL ERROR:", err.message);
        }
    }
};
