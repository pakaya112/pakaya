const axios = require("axios");

module.exports = {
    name: "ssweb",
    alias: ["ss"],

    run: async ({ conn, mek, from, q }) => {
        try {
            if (!q) {
                return conn.sendMessage(from, {
                    text: "❌ Give URL!\n\nExample:\n.ssweb google.com"
                }, { quoted: mek });
            }

            let url = q.trim();

            url = url.replace(/\s+/g, "");

  
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "https://" + url;
            }

            if (!url.includes(".")) {
                return conn.sendMessage(from, {
                    text: "❌ Invalid URL!"
                }, { quoted: mek });
            }

            const api = `https://www.movanest.xyz/v2/ssweb?url=${encodeURIComponent(url)}&width=1280&height=720&full_page=true`;

            await conn.sendMessage(from, {
                text: "⏳ Capturing screenshot..."
            }, { quoted: mek });

            const res = await axios.get(api, {
                responseType: "arraybuffer",
                timeout: 30000
            });

            await conn.sendMessage(from, {
                image: Buffer.from(res.data),
                caption: `🌐 *Website Screenshot*\n\n🔗 ${url}`
            }, { quoted: mek });

        } catch (err) {
            console.log("SSWEB ERROR:", err.message);

            await conn.sendMessage(from, {
                text: "❌ Failed to capture screenshot!"
            }, { quoted: mek });
        }
    }
};
