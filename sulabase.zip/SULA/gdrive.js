const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'gdrive',
    alias: ['gd', 'drive'],

    run: async ({ conn, mek, from, q }) => {

        if (!q) {
            return conn.sendMessage(from, {
                text: `╭─❌ *MISSING GOOGLE DRIVE URL*
│
│ Example:
│ .gdrive https://drive.google.com/drive/folders/xxxx
╰───────────────`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '⏳', key: mek.key }
        });

        try {
            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'THENUX BOT';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© THENUX';

            const api =
                `https://thenuxgdrive.netlify.app/api/gdrive?url=${encodeURIComponent(q)}`;

            const { data } = await axios.get(api, {
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0',
                    'Accept': 'application/json'
                }
            });

            if (!data?.success || !data?.files?.length) {
                throw new Error(data?.error || 'No files found');
            }

            const file = data.files[0];

            if (!file.download_url) {
                throw new Error('Download URL not found');
            }

            const caption = `╭────♡◉◉◉♡────⌬
📁 *GOOGLE DRIVE DOWNLOAD*
╰────♡◉◉◉♡────⌬

📌 *File:* ${file.name}
📦 *Size:* ${file.size_formatted || 'Unknown'}
🧾 *Type:* ${file.mimeType || 'Unknown'}

🤖 *Bot:* ${botname}

${botfooter}`;

            await conn.sendMessage(from, {
                document: { url: file.download_url },
                mimetype: file.mimeType || 'application/octet-stream',
                fileName: file.name || 'google-drive-file',
                caption
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '✅', key: mek.key }
            });

        } catch (err) {
            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });

            await conn.sendMessage(from, {
                text: `╭─❌ *GDRIVE ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
            }, { quoted: mek });
        }
    }
};
