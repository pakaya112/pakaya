const axios = require('axios');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { ReadData } = require('../database');

// --- Temp Folder Configuration ---
const TEMP_DIR = path.join(__dirname, 'temp_series');
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}
process.env.TMPDIR = TEMP_DIR;
os.tmpdir = () => TEMP_DIR;

// --- API Endpoints ---
const SEARCH_API = 'https://seriezloaded-vortex.vercel.app/search?search=';
const SCRAPE_API = 'https://seriezloaded-vortex.vercel.app/scrape?url=';
const DEFAULT_IMAGE = 'https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg';

// Helper: Convert KB/Bytes to Clean Formatted MB/GB
function formatFileSize(sizeStr) {
    if (!sizeStr || sizeStr === 'N/A') return 'N/A';
    const str = String(sizeStr).trim();
    if (/kb$/i.test(str)) {
        const kb = parseFloat(str.replace(/kb/i, '').trim());
        if (isNaN(kb)) return sizeStr;
        const mb = kb / 1024;
        return mb >= 1024 ? `${(mb / 1024).toFixed(2)} GB` : `${mb.toFixed(2)} MB`;
    }
    if (/^\d+$/.test(str)) {
        const bytes = parseInt(str);
        const mb = bytes / (1024 * 1024);
        return mb >= 1024 ? `${(mb / 1024).toFixed(2)} GB` : `${mb.toFixed(2)} MB`;
    }
    return sizeStr;
}

// 1. API Call Function (With Retries)
async function apiCallWithRetry(url, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await axios.get(url, { timeout: 25000 });
            if (!response.data) throw new Error('API returned empty response');
            return response.data;
        } catch (error) {
            if (i === retries - 1) throw error;
            await new Promise(res => setTimeout(res, 2000));
        }
    }
}

// 2. Stream File Download Function (RAM Overflow Prevention)
async function downloadWithRetry(url, destPath, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            const { data } = await axios({
                url: url,
                method: 'GET',
                responseType: 'stream',
                timeout: 300000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
                }
            });

            const writer = fs.createWriteStream(destPath);
            data.pipe(writer);

            await new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', (err) => {
                    writer.close();
                    reject(err);
                });
                data.on('error', (err) => {
                    writer.close();
                    reject(err);
                });
            });

            return true;
        } catch (error) {
            if (fs.existsSync(destPath)) {
                try { fs.unlinkSync(destPath); } catch (e) {}
            }
            if (i === retries - 1) throw error;
            await new Promise(res => setTimeout(res, 2000));
        }
    }
}

module.exports = {
    name: 'seriez',
    alias: ['sz', 'sload'],
    category: 'download',
    description: 'Search and Download Series from SeriezLoaded',

    run: async ({ conn, mek, from, q }) => {
        try {
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.\n\nWant access to this feature?\n\nCreate your own bot:\n🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'SULA MD';

            if (!q) {
                return await conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬\n🎬 *SeriezLoaded Downloader*\n╰────♡◉◉◉♡────⌬\n\n📌 *Examples:* \n.series Breaking Bad\n.series 9476xxxxxxx@s.whatsapp.net Game of Thrones`
                }, { quoted: mek });
            }

            const args = q.trim().split(' ');
            let targetJid = null;
            let searchQuery = q.trim();
            let isCustomTarget = false;

            if (args[0]?.includes('@s.whatsapp.net') || args[0]?.includes('@g.us') || args[0]?.includes('@lid')) {
                targetJid = args[0];
                searchQuery = args.slice(1).join(' ').trim();
                isCustomTarget = true;
            }

            await conn.sendMessage(from, { react: { text: '🔍', key: mek.key } });

            let searchData;
            try {
                searchData = await apiCallWithRetry(`${SEARCH_API}${encodeURIComponent(searchQuery)}`, 3);
            } catch (e) {
                return await conn.sendMessage(from, { text: `❌ *Search failed:* ${e.message}` }, { quoted: mek });
            }

            if (!searchData.success || !searchData.results?.length) {
                return await conn.sendMessage(from, { text: `❌ *No results found for:* ${searchQuery}` }, { quoted: mek });
            }

            const results = searchData.results.slice(0, 10);
            const list = results.map((r, i) =>
                `❰ ${i + 1} ❱ *${r.title.replace(/&#8211;/g, '–').replace(/&#\d+;/g, '').trim()}*`
            ).join('\n\n');

            const caption = `╭────♡◉◉◉♡────⌬\n🎬 *SeriezLoaded Results*\n✨ *${botname} Ready*\n╰────♡◉◉◉♡────⌬\n\n🔍 *Query:* ${searchQuery}\n\n${list}\n\n───────────────\n\nReply with a number: 1 - ${results.length}`;

            const sentMsg = await conn.sendMessage(from, {
                image: { url: results[0]?.image || DEFAULT_IMAGE },
                caption
            }, { quoted: mek });

            const timeoutTimer = setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];
                if (!msg.message) return;

                const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                if (!isReply) return;

                const index = parseInt(text?.trim()) - 1;
                if (isNaN(index) || !results[index]) {
                    clearTimeout(timeoutTimer);
                    conn.ev.off('messages.upsert', listener);
                    return conn.sendMessage(from, { text: '❌ Invalid Selection. Please run the command again.' }, { quoted: msg });
                }

                clearTimeout(timeoutTimer);
                conn.ev.off('messages.upsert', listener);
                await conn.sendMessage(from, { react: { text: '⏳', key: msg.key } });

                const selected = results[index];

                let scrapeData;
                try {
                    scrapeData = await apiCallWithRetry(`${SCRAPE_API}${encodeURIComponent(selected.link)}`, 3);
                } catch (e) {
                    return await conn.sendMessage(from, { text: `❌ *Failed to load episodes:* ${e.message}` }, { quoted: msg });
                }

                if (!scrapeData.success || !scrapeData.episodes?.length) {
                    return await conn.sendMessage(from, { text: '❌ No episodes found for this series.' }, { quoted: msg });
                }

                const episodes = scrapeData.episodes;
                const displayLimit = Math.min(episodes.length, 30);
                const epList = episodes.slice(0, displayLimit).map((e, i) =>
                    `❰ ${i + 1} ❱ *${e.episode}*`
                ).join('\n');

                const cleanTitle = scrapeData.title.replace(/&#8211;/g, '–').replace(/&#\d+;/g, '').trim();

                const epCaption = `╭────♡◉◉◉♡────⌬\n📺 *${cleanTitle}*\n╰────♡◉◉◉♡────⌬\n\n🎞️ *Total Episodes:* ${scrapeData.total_episodes || episodes.length}\n\n${epList}\n\n───────────────\n\nReply with Episode Number (1 - ${displayLimit})`;

                const epMsg = await conn.sendMessage(from, {
                    image: { url: scrapeData.image || selected.image || DEFAULT_IMAGE },
                    caption: epCaption
                }, { quoted: msg });

                const epTimeoutTimer = setTimeout(() => {
                    conn.ev.off('messages.upsert', epListener);
                }, 60000);

                const epListener = async (epUpdate) => {
                    const epReply = epUpdate.messages[0];
                    if (!epReply?.message) return;

                    const epText = epReply.message.conversation || epReply.message.extendedTextMessage?.text;
                    const isIt = epReply.message?.extendedTextMessage?.contextInfo?.stanzaId === epMsg.key.id;

                    if (!isIt) return;

                    const epNum = parseInt(epText?.trim()) - 1;
                    if (isNaN(epNum) || !episodes[epNum]) {
                        clearTimeout(epTimeoutTimer);
                        conn.ev.off('messages.upsert', epListener);
                        return conn.sendMessage(from, { text: '❌ Invalid Episode Choice.' }, { quoted: epReply });
                    }

                    clearTimeout(epTimeoutTimer);
                    conn.ev.off('messages.upsert', epListener);
                    const selectedEp = episodes[epNum];

                    await showDownloadMenu(conn, epReply, from, targetJid, isCustomTarget, {
                        seriesTitle: cleanTitle,
                        epTitle: selectedEp.episode,
                        directLink: selectedEp.direct_link,
                        image: scrapeData.image || selected.image || DEFAULT_IMAGE,
                        botname
                    });
                };

                conn.ev.on('messages.upsert', epListener);
            };

            conn.ev.on('messages.upsert', listener);

        } catch (err) {
            console.error('Series plugin error:', err);
            await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
            await conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬\n❌ *Series Error*\n╰────♡◉◉◉♡────⌬\n\n⚠️ ${err.message}`
            }, { quoted: mek });
        }
    }
};

// ==========================================
// 🚀 DOWNLOAD & FILE SEND DISPATCHER
// ==========================================
async function showDownloadMenu(conn, quotedMsg, from, targetJid, isCustomTarget, info) {
    const isZip = info.directLink.includes('send.now') || info.directLink.includes('.zip');

    if (isZip) {
        return await conn.sendMessage(from, {
            text: `📦 *ZIP File Download Link:*\n\n🎬 *Series:* ${info.seriesTitle}\n🎞️ *Episode:* ${info.epTitle}\n\n🔗 ${info.directLink}`
        }, { quoted: quotedMsg });
    }

    const caption = `╭────♡◉◉◉♡────⌬\n📥 *Download Options*\n✨ *${info.botname}*\n╰────♡◉◉◉♡────⌬\n\n🎬 *Series:* ${info.seriesTitle}\n🎞️ *Episode:* ${info.epTitle}\n\n───────────────\n\n📁 ❶ Send as File\n🔗 ❷ Direct Download Link\n\n───────────────\n\nReply: 1 / 2`;

    const sentMsg = await conn.sendMessage(from, {
        image: { url: info.image || DEFAULT_IMAGE },
        caption
    }, { quoted: quotedMsg });

    const timeoutTimer = setTimeout(() => {
        conn.ev.off('messages.upsert', listener);
    }, 60000);

    const listener = async (msgUpdate) => {
        const msg = msgUpdate.messages[0];
        if (!msg.message) return;

        const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
        const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        clearTimeout(timeoutTimer);
        conn.ev.off('messages.upsert', listener);

        const chosenOption = text?.trim();

        if (!['1', '2'].includes(chosenOption)) {
            return conn.sendMessage(from, { text: '❌ Invalid Option. Please choose 1 or 2.' }, { quoted: msg });
        }

        await conn.sendMessage(from, { react: { text: '⏳', key: msg.key } });

        let tempFilePath = null;

        try {
            const ext = info.directLink.includes('.mkv') ? 'mkv' : 'mp4';
            const fileName = `${info.seriesTitle.replace(/[^a-zA-Z0-9]/g, '_')}_${info.epTitle.replace(/[^a-zA-Z0-9]/g, '_')}.${ext}`;

            // Clean Delivery Caption Style
            const doneCaption = `╭──〔 🎬 SeriezLoaded Delivery 🎬 〕──⬣\n\n` +
                                `૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა Your series episode is ready~ 💕\n\n` +
                                `🎬 Series ➜ ${info.seriesTitle}\n` +
                                `🎞️ Episode ➜ ${info.epTitle}\n\n` +
                                `━━━━━━━━━━━━━━━\n\n` +
                                `🍿 Enjoy your watch time!\n\n` +
                                `🌸 Thanks for using ${info.botname}\n\n` +
                                `♡ Powered By 🌐 https://sulaofc.store\n\n` +
                                `movies • series • updates\n\n` +
                                `━━━━━━━━━━━━━━━`;

            if (chosenOption === '1') {
                tempFilePath = path.join(TEMP_DIR, `${Date.now()}_${fileName}`);

                await conn.sendMessage(from, {
                    text: `⏳ *Downloading file to server...*\n\n📄 *File:* ${fileName}\n\n*(Please wait, sending file shortly...)*`
                }, { quoted: msg });

                await downloadWithRetry(info.directLink, tempFilePath, 3);

                // File Size Check on downloaded file
                const stats = fs.statSync(tempFilePath);
                const fileSizeInBytes = stats.size;
                const isOver2GB = fileSizeInBytes >= 2147483648; // 2GB

                if (isOver2GB) {
                    await conn.sendMessage(from, { react: { text: '⚠️', key: msg.key } });
                    return await conn.sendMessage(from, {
                        text: `⚠️ *File Size Limit Exceeded! (2GB+)*\n\nThe file is larger than 2GB. Due to WhatsApp file size limitations, files over 2GB cannot be sent directly as documents.\n\n🔗 *Direct Download Link:*\n${info.directLink}`
                    }, { quoted: msg });
                }

                await conn.sendMessage(from, { react: { text: '📤', key: msg.key } });

                const mimetype = ext === 'mkv' ? 'video/x-matroska' : 'video/mp4';

                await conn.sendMessage(targetJid || from, {
                    document: { stream: fs.createReadStream(tempFilePath) },
                    mimetype: mimetype,
                    fileName: fileName,
                    caption: doneCaption
                }, { quoted: msg });

                if (isCustomTarget && targetJid) {
                    await conn.sendMessage(from, {
                        text: `✅ Successfully Delivered!\n\n📤 To: ${targetJid}`
                    }, { quoted: msg });
                }

                await conn.sendMessage(from, { react: { text: '✅', key: msg.key } });

            } else {
                await conn.sendMessage(from, {
                    text: `${doneCaption}\n\n🔗 *Direct Download Link:*\n${info.directLink}`
                }, { quoted: msg });
                await conn.sendMessage(from, { react: { text: '✅', key: msg.key } });
            }

        } catch (err) {
            console.error('Download/Send Error:', err);
            await conn.sendMessage(from, { react: { text: '❌', key: msg.key } });
            await conn.sendMessage(from, {
                text: `❌ *Download Failed:*\n${err.message}\n\n🔗 *Direct Link:*\n${info.directLink}`
            }, { quoted: msg });
        } finally {
            try {
                if (tempFilePath && fs.existsSync(tempFilePath)) {
                    fs.unlinkSync(tempFilePath);
                }
            } catch (cleanupErr) {
                console.error('Temp cleanup error:', cleanupErr);
            }
        }
    };

    conn.ev.on('messages.upsert', listener);
}
