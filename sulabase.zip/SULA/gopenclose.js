module.exports = {
    name: "group",
    description: "Open or Close the group chat.",
    category: "group",

    run: async ({ conn, mek, from, args, isGroup, isAdmin, isBotAdmins }) => {
        try {
            if (!isGroup) return conn.sendMessage(from, { text: "❌ Group only!" }, { quoted: mek });
            if (!isAdmin) return conn.sendMessage(from, { text: "❌ You must be an Admin!" }, { quoted: mek });
            if (!isBotAdmins) return conn.sendMessage(from, { text: "❌ Bot must be an Admin!" }, { quoted: mek });

            const action = args[0];

            if (action === 'open' || action === 'unmute') {
                await conn.groupSettingUpdate(from, 'not_announcement');
                return conn.sendMessage(from, { text: "✅ Group opened! Everyone can send messages now." }, { quoted: mek });
            } 
            
            else if (action === 'close' || action === 'mute') {
                await conn.groupSettingUpdate(from, 'announcement');
                return conn.sendMessage(from, { text: "🔒 Group closed! Only admins can send messages." }, { quoted: mek });
            } 
            
            else {
                return conn.sendMessage(from, { text: "⚠️ Use: .group open OR .group close" }, { quoted: mek });
            }

        } catch (err) {
            // console.error(err);
        }
    }
};
