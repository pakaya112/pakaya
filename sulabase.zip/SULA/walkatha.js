const axios = require('axios');

module.exports = {
    name: 'walkatha',
    run: async ({ conn, mek, from, q }) => {

        if (!q) {
            return conn.sendMessage(from, {
                text: '❌ Story name / keyword එකක් දෙන්න!\n\nExample: .walkatha love'
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            text: '🔎 Searching stories...'
        }, { quoted: mek });

        try {
            const { data } = await axios.get(
                `https://thenux-walkatha-api.vercel.app/api/search?q=${encodeURIComponent(q)}`
            );

            if (!data?.results?.length) {
                return conn.sendMessage(from, {
                    text: '❌ No stories found!'
                }, { quoted: mek });
            }

            const results = data.results.slice(0, 15);

            let caption = `
╭━━❀ 𝓚𝓐𝓣𝓗𝓐 𝓟𝓐𝓝𝓔𝓛 ❀━━╮
   🎀📚 STORY SEARCH 📚🎀
╰━━━━━━━━━━━━━━━╯

┊ ✧ 🌸 ✧ 🌼 ✧ ✨ ✧ 🌷

🔍 *Search:* ${q}

🌸✨ *Available Stories* ✨🌸

╭───────────────❀\n`;

            results.forEach((s, i) => {
                caption += `📖 *${i + 1}.* ${s.title}\n`;
                caption += `   👤 ${s.author || "Unknown"} | 📅 ${s.date || "N/A"}\n\n`;
            });

            caption += `╰───────────────❀

💖✨ *Select your story* ✨💖

🔢 Reply with number (1 - ${results.length})

─────────────── 🌸

🌷 Enjoy reading 💞
╰━━━❀━━━━━━━❀━━━╯`;

            const sentMsg = await conn.sendMessage(from, {
                text: caption
            }, { quoted: mek });

            // ⏱️ timeout
            const timeout = setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 120000);

            const listener = async (msgUpdate) => {
                try {
                    const msg = msgUpdate.messages[0];
                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                    if (!isReply) return;

                    const num = parseInt(text);
                    if (isNaN(num) || num < 1 || num > results.length) {
                        return conn.sendMessage(from, {
                            text: `❌ Invalid number! Choose 1 - ${results.length}`
                        }, { quoted: msg });
                    }

                    const story = results[num - 1];

                    await conn.sendMessage(from, {
                        react: { text: '⏬', key: msg.key }
                    });

                    const detailRes = await axios.get(
                        `https://thenux-walkatha-api.vercel.app/api/download?url=${encodeURIComponent(story.link)}`
                    );

                    const d = detailRes.data;

                    let storyText = `
╭━━━❀ 𝓢𝓣𝓞𝓡𝓨 ❀━━━╮
📖 *${d.title || story.title}*
╰━━━━━━━━━━━━━╯

${d.category ? `🏷️ Category: ${d.category}` : ''}

━━━━━━━━━━━━━━

`;

                    if (Array.isArray(d.paragraphs)) {
                        storyText += d.paragraphs.join("\n\n");
                    }

                    await conn.sendMessage(from, {
                        text: storyText
                    }, { quoted: msg });

                    await conn.sendMessage(from, {
                        react: { text: '✅', key: msg.key }
                    });

                    clearTimeout(timeout);
                    conn.ev.off('messages.upsert', listener);

                } catch (err) {
                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        text: '❌ Story load කරන්න බැරි වුණා!'
                    }, { quoted: mek });
                }
            };

            conn.ev.on('messages.upsert', listener);

        } catch (err) {
            await conn.sendMessage(from, {
                text: `❌ Error: ${err.message}`
            }, { quoted: mek });
        }
    }
};
