const fs = require("fs");
const { Sticker } = require("wa-sticker-formatter");

module.exports = {
    name: "srename",
    alias: ["stickerrename"],

    run: async ({ conn, mek, from, q }) => {

        const {
            downloadContentFromMessage
        } = await import("baileys");

        try {

            if (!q) {
                return conn.sendMessage(from, {
                    text:
`╭───❍
│ 🏷️ *Sticker Rename*
╰───────────

Reply to a sticker and use:

.srename Pack Name

or

.srename Pack Name|Author Name`
                }, { quoted: mek });
            }

            const quoted =
                mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;

            if (!quoted?.stickerMessage) {
                return conn.sendMessage(from, {
                    text: "❌ Please reply to a sticker!"
                }, { quoted: mek });
            }

            const parts = q.split("|");

            const pack =
                parts[0]?.trim() ||
                "ₛᵤₗₐ ₛₜᵢCₖₑᵣ 🩷👻";

            const author =
                parts[1]?.trim() ||
                "© 𝚂𝚄𝙻𝙰 𝙼𝙳";

            await conn.sendMessage(from, {
                react: {
                    text: "⏳",
                    key: mek.key
                }
            });

            const stream = await downloadContentFromMessage(
                quoted.stickerMessage,
                "sticker"
            );

            let buffer = Buffer.from([]);

            for await (const chunk of stream) {
                buffer = Buffer.concat([
                    buffer,
                    chunk
                ]);
            }

            const tempFile =
                `./sticker_${Date.now()}.webp`;

            fs.writeFileSync(
                tempFile,
                buffer
            );

            const sticker = new Sticker(
                tempFile,
                {
                    pack,
                    author,
                    quality: 100
                }
            );

            const stickerBuffer =
                await sticker.toBuffer();

            await conn.sendMessage(
                from,
                {
                    sticker: stickerBuffer
                },
                {
                    quoted: mek
                }
            );

            if (
                fs.existsSync(tempFile)
            ) {
                fs.unlinkSync(tempFile);
            }

            await conn.sendMessage(from, {
                react: {
                    text: "✅",
                    key: mek.key
                }
            });

        } catch (err) {

            console.error(
                "Sticker Rename Error:",
                err
            );

            await conn.sendMessage(from, {
                react: {
                    text: "❌",
                    key: mek.key
                }
            });

            await conn.sendMessage(
                from,
                {
                    text:
`╭───❍
│ ❌ *Rename Failed*
╰───────────

${err.message}`
                },
                {
                    quoted: mek
                }
            );
        }
    }
};
