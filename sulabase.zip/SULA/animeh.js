const axios = require('axios');
const { ReadData } = require('../database');

const SEARCH_API = 'https://hanime.travillhub.com/api/h2';
const INFO_API = 'https://hanime.travillhub.com/api/h2';
const DL_API = 'https://hanime.travillhub.com/api/dl';

const DEFAULT_IMAGE = 'https://raw.githubusercontent.com/sulamadara1147/data/main/file_00000000097071fabaedacd96b9efefc.png';

module.exports = {
    name: 'hanime',
    alias: ['hanimeclub', 'hclub'],

    run: async ({ conn, mek, from, q }) => {
        try {
            // Owner Permission Check
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.\n\nWant access to this feature?\n\nCreate your own bot:\n🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'SULA MD';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© SULA MD';

            if (!q) {
                return conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬\n🎌 *H-Anime Search*\n╰────♡◉◉◉♡────⌬\n\nExample:\n\n.hanime boku\n\n.hanime 9476xxxxxxx@s.whatsapp.net boku\n\n${botfooter}`
                }, { quoted: mek });
            }

            const args = q.trim().split(' ');
            let targetJid = null;
            let searchQuery = q;
            let isCustomTarget = false;

            // Custom JID Target Checking
            if (
                args[0]?.includes('@s.whatsapp.net') ||
                args[0]?.includes('@g.us') ||
                args[0]?.includes('@lid')
            ) {
                targetJid = args[0];
                searchQuery = args.slice(1).join(' ');
                isCustomTarget = true;
            }

            await conn.sendMessage(from, {
                react: { text: '⏳', key: mek.key }
            });

            // 1. Search Request
            const { data } = await axios.get(`${SEARCH_API}?q=${encodeURIComponent(searchQuery)}`);

            if (!data.success || !data.results?.length) {
                throw new Error('No results found for your query.');
            }

            // Results 10කට සීමා කිරීම
            const results = data.results.slice(0, 10);
            const list = results.map((x, i) => `❰ ${i + 1} ❱ *${x.title}*\n📅 Year: ${x.year || 'N/A'}`).join('\n\n');

            const sentMsg = await conn.sendMessage(from, {
                image: { url: results[0].image || DEFAULT_IMAGE },
                caption: `╭────♡◉◉◉♡────⌬\n🎌 *H-Anime Search Results*\n╰────♡◉◉◉♡────⌬\n\n${list}\n\n───────────────\n\nReply: 1 - ${results.length}\n\n> AnImEs By || MiZtY AnImEs || mizty.site 🌌\n\n${botfooter}`
            }, { quoted: mek });

            // Listener for Selection
            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];
                if (!msg.message) return;

                const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                if (!isReply) return;

                const index = parseInt(text) - 1;
                if (isNaN(index) || !results[index]) {
                    return conn.sendMessage(from, { text: '❌ Invalid Selection' }, { quoted: msg });
                }

                conn.ev.off('messages.upsert', listener);
                const selected = results[index];

                await conn.sendMessage(from, {
                    react: { text: '📥', key: msg.key }
                });

                // Next Step: Show Anime Details & Episodes
                return await showAnimeInfo(conn, msg, from, targetJid, isCustomTarget, selected.url, botname, botfooter);
            };

            conn.ev.on('messages.upsert', listener);
            setTimeout(() => { conn.ev.off('messages.upsert', listener); }, 60000);

        } catch (err) {
            return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: mek });
        }
    }
};

// 2. Show Anime Info & Episode List
async function showAnimeInfo(conn, quotedMsg, from, targetJid, isCustomTarget, infoUrl, botname, botfooter) {
    try {
        const { data } = await axios.get(`${INFO_API}?info=${encodeURIComponent(infoUrl)}`);

        if (!data.success) {
            throw new Error('Anime details could not be fetched.');
        }

        const episodes = data.episodes || [];
        if (!episodes.length) {
            throw new Error('No episodes found for this anime.');
        }

        const list = episodes.map((x, i) => `❰ ${i + 1} ❱ ${x.title}`).join('\n');
        const genres = data.genres ? data.genres.join(', ') : 'N/A';

        const sentMsg = await conn.sendMessage(from, {
            image: { url: data.poster || DEFAULT_IMAGE },
            caption: `╭────♡◉◉◉♡────⌬\n🌸 *${data.title}*\n╰────♡◉◉◉♡────⌬\n\n⭐ Rating: ${data.rating || 'N/A'}\n🎭 Genres: ${genres}\n📝 Synopsis: ${data.synopsis ? data.synopsis.slice(0, 150) + '...' : 'No Description'}\n\n*Episodes List:*\n${list}\n\n───────────────\n\nReply: 1 - ${episodes.length}\n\n> AnImEs By || MiZtY AnImEs || mizty.site 🌌\n\n${botfooter}`
        }, { quoted: quotedMsg });

        const listener = async (msgUpdate) => {
            const msg = msgUpdate.messages[0];
            if (!msg.message) return;

            const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
            const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

            if (!isReply) return;

            const index = parseInt(text) - 1;
            if (isNaN(index) || !episodes[index]) {
                return conn.sendMessage(from, { text: '❌ Invalid Episode Selection' }, { quoted: msg });
            }

            conn.ev.off('messages.upsert', listener);
            await conn.sendMessage(from, { react: { text: '⬇️', key: msg.key } });

            // Next Step: Fetch Download Links
            await downloadAndSendAnime(conn, msg, from, targetJid, isCustomTarget, episodes[index].url, botname, botfooter);
        };

        conn.ev.on('messages.upsert', listener);
        setTimeout(() => { conn.ev.off('messages.upsert', listener); }, 60000);

    } catch (err) {
        return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: quotedMsg });
    }
}

// 3. Fetch Links and Send Document
async function downloadAndSendAnime(conn, quotedMsg, from, targetJid, isCustomTarget, episodeUrl, botname, botfooter) {
    try {
        const { data } = await axios.get(`${DL_API}?url=${encodeURIComponent(episodeUrl)}`);

        if (!data.success || !data.downloads?.length) {
            throw new Error('Download links not found for this episode.');
        }

        // සාමාන්‍යයෙන් මේ API එකේ එක ඩවුන්ලෝඩ් ලින්ක් එකයි එන්නේ (e.g., quality: "DOWNLOAD")
        const downloadOption = data.downloads[0]; 

        const doneCaption = `\n╭──〔 🌸 H-Anime Delivery 🌸 〕──⬣\n\nYour requested anime is ready! 💕\n\n🎬 *Title:* ${data.title}\n🍿 *Duration:* ${data.duration || 'N/A'}\n\n━━━━━━━━━━━━━━━\n🌸 Thanks for using ${botname}\n🌐 Powered By https://sulaofc.store\n━━━━━━━━━━━━━━━`;

        const fileName = data.title.replace(/[\\/:*?"<>|]/g, '').trim() + '.mp4';

        // Document එකක් විදිහට Video එක යැවීම
        await conn.sendMessage(targetJid || from, {
            document: { url: downloadOption.link },
            mimetype: 'video/mp4',
            fileName,
            caption: doneCaption
        }, { quoted: quotedMsg });

        // Custom JID එකක් දුන්නා නම්, සාර්ථකයි කියලා original chat එකට මැසේජ් එකක් දානවා
        if (isCustomTarget && targetJid) {
            await conn.sendMessage(from, {
                text: `✅ Successfully Sent to Target!\n\n📤 To: ${targetJid}`
            }, { quoted: quotedMsg });
        }

        await conn.sendMessage(from, { react: { text: '✅', key: quotedMsg.key } });

    } catch (err) {
        return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: quotedMsg });
    }
}
