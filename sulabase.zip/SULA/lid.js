module.exports = {
    name: 'jid',
    alias: ["id"],
    run: async ({ conn, mek, from, q }) => {

        try {
            let targetLid = '';
            let targetJid = '';
            let chatType = 'User';

            // Quoted message
            const quotedLid = mek.message?.extendedTextMessage?.contextInfo?.participant;
            const quotedJid = mek.message?.extendedTextMessage?.contextInfo?.participantAlt;

            if (quotedLid) {
                targetLid = quotedLid;
                targetJid = quotedJid || '';
                if (targetLid.endsWith('@g.us')) chatType = 'Group';
                else if (targetLid.endsWith('@newsletter')) chatType = 'Newsletter';
            } else if (q) {
                const input = q.replace(/[^0-9@.]/g, '');

                if (/^[0-9]{9,15}$/.test(input)) {
                    targetJid = `${input}@s.whatsapp.net`;
                    try {
                        const mapping = await conn.signalRepository?.lidMapping?.getLid({ jid: targetJid });
                        if (mapping) targetLid = mapping;
                    } catch (e) {}
                } else if (input.endsWith('@lid')) {
                    targetLid = input;
                    try {
                        const mapping = await conn.signalRepository?.lidMapping?.getJid({ lid: targetLid });
                        if (mapping) targetJid = mapping;
                    } catch (e) {}
                } else if (input.endsWith('@g.us')) {
                    targetLid = input;
                    targetJid = input;
                    chatType = 'Group';
                } else if (input.endsWith('@newsletter')) {
                    targetLid = input;
                    targetJid = input;
                    chatType = 'Newsletter';
                } else {
                    return conn.sendMessage(from, {
                        text: '❌ Invalid input!\n\nSend:\n• Phone number\n• Group JID/LID\n• Or reply to a message'
                    }, { quoted: mek });
                }

            } else {
                if (from.endsWith('@g.us')) {
                    targetLid = from;
                    targetJid = from;
                    chatType = 'Group';
                } else if (from.endsWith('@newsletter')) {
                    targetLid = from;
                    targetJid = from;
                    chatType = 'Newsletter';
                } else {
                    targetLid = from;
                    targetJid = mek.key.remoteJidAlt || '';
                }
            }

            const caption = `
*🆔 𝐂hat 𝐉ID:*   ${targetJid || 'Not Available'}
*🏷️ 𝐂hat 𝐋ID:*   ${targetLid || 'Not Available'} 
*📞 𝐂hat 𝐓YPE:*  ${chatType}`;

            await conn.sendMessage(from, {
                text: caption
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '✅', key: mek.key }
            });

        } catch (err) {
            console.error(err);

            await conn.sendMessage(from, {
                text: '❌ Error retrieving LID!'
            }, { quoted: mek });
        }
    }
};
