const axios = require('axios');
const cheerio = require('cheerio');

async function mediafireDl(url) {
    const res = await axios.get(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0'
        }
    });

    const $ = cheerio.load(res.data);

    const link = $('a#downloadButton').attr('href');

    if (!link) throw new Error('Download link not found');

    const size = $('a#downloadButton')
        .text()
        .replace('Download', '')
        .replace('(', '')
        .replace(')', '')
        .trim();

    const fileName = decodeURIComponent(
        link.split('/').pop().split('?')[0]
    );

    const ext = fileName.split('.').pop();

    return {
        fileName,
        ext,
        size,
        link
    };
}

module.exports = {
    name: 'mediafire',

    run: async ({ conn, mek, from, q }) => {

        if (!q) {
            return conn.sendMessage(from, {
                text:
`╭─❌ *MEDIAFIRE DOWNLOADER*
│
│ Example:
│ .mediafire https://www.mediafire.com/file/xxxxx/file
╰───────────────`
            }, { quoted: mek });
        }

        try {

            await conn.sendMessage(from, {
                react: {
                    text: '⏳',
                    key: mek.key
                }
            });

            const data = await mediafireDl(q);

            const caption =
`╭────♡◉◉◉♡────⌬
📦 *MEDIAFIRE DOWNLOAD*
╰────♡◉◉◉♡────⌬

📄 Name:
${data.fileName}

📦 Size:
${data.size}

🧩 Type:
${data.ext.toUpperCase()}

⬇️ Sending file...
`;

            await conn.sendMessage(from, {
                text: caption
            }, { quoted: mek });

            await conn.sendMessage(from, {
                document: {
                    url: data.link
                },
                mimetype: 'application/octet-stream',
                fileName: data.fileName
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: {
                    text: '✅',
                    key: mek.key
                }
            });

        } catch (e) {

            await conn.sendMessage(from, {
                react: {
                    text: '❌',
                    key: mek.key
                }
            });

            await conn.sendMessage(from, {
                text:
`╭─❌ *MEDIAFIRE ERROR*
│
│ *Reason:* ${e.message}
╰───────────────`
            }, { quoted: mek });
        }
    }
};
