const axios = require("axios");
const { ReadData } = require("../database");

module.exports = {
    name: "apk",
    alias: ["app", "aptoide"],
    category: "download",
    description: "Search and download APK files.",

    run: async ({ conn, mek, from, q }) => {

        try {

            const number = conn.user.id.split(':')[0];

            const botname = await ReadData(number, "BOT_NAME");
            const botfooter = await ReadData(number, "BOT_FOOTER");

            if (!q) {

                return await conn.sendMessage(from, {
                    text: `
╭────♡◉◉◉♡────⌬
📦 *APK SEARCH PANEL*  
🌸 *${botname} APK Downloader* ✨  
╰────♡◉◉◉♡────⌬

❌ *Please provide app name*

📌 *Example:*  
➤ .apk whatsapp

💖 Search and download APK files easily.

${botfooter}
`
                }, { quoted: mek });

            }

            await conn.sendMessage(from, {
                react: { text: "🔎", key: mek.key }
            });

            const apiUrl = `https://ws75.aptoide.com/api/7/apps/search/query=${encodeURIComponent(q)}`;

            const { data } = await axios.get(apiUrl);

            if (!data?.datalist?.list || data.datalist.list.length === 0) {

                return await conn.sendMessage(from, {
                    text: `❌ No apps found!\n\n${botfooter}`
                }, { quoted: mek });

            }

            const app = data.datalist.list[0];

            const appName = app.name || "Unknown";
            const packageName = app.package || "Unknown";
            const version = app.file?.vername || "Unknown";
            const size = (app.size / 1024 / 1024).toFixed(2) + " MB";
            const developer = app.developer?.name || "Unknown";
            const downloads = app.stats?.downloads || "0";
            const rating = app.stats?.rating?.avg || "0";
            const icon = app.icon;
            const apkUrl = app.file?.path;

            const caption = `
╭────♡◉◉◉♡────⌬
📦 *APK SEARCH RESULT*  
🌸 *${botname} found your app ✨*  
╰────♡◉◉◉♡────⌬

📌 *APP NAME*  
➤ ${appName}

📦 *PACKAGE*  
➤ ${packageName}

⚡ *VERSION*  
➤ ${version}

🧑‍💻 *DEVELOPER*  
➤ ${developer}

⭐ *RATING*  
➤ ${rating}

📥 *DOWNLOADS*  
➤ ${downloads}

💾 *SIZE*  
➤ ${size}

───────────────

❶ 📦 DOWNLOAD APK

───────────────

💌 *Reply:* 1

💖 *Ready to download your APK file*

${botfooter}
`;

            const sentMessage = await conn.sendMessage(from, {
                image: { url: icon },
                caption
            }, { quoted: mek });

            const messageID = sentMessage.key.id;

            const timeout = setTimeout(() => {
                conn.ev.off("messages.upsert", handler);
            }, 60000);
            
            const handler = async (msgUpdate) => {

                try {

                    const msg = msgUpdate.messages[0];

                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message?.extendedTextMessage?.contextInfo?.stanzaId === messageID;

                    if (!isReply) return;

                    if (text.trim() !== "1") {

                        return await conn.sendMessage(from, {
                            text: "❌ Reply only with 1"
                        }, { quoted: msg });

                    }

                    await conn.sendMessage(from, {
                        react: { text: "⬇️", key: msg.key }
                    });

                    clearTimeout(timeout);

                    await conn.sendMessage(from, {
                        document: { url: apkUrl },
                        mimetype: "application/vnd.android.package-archive",
                        fileName: `${appName}.apk`,
                        caption: `
╭────♡◉◉◉♡────⌬
📦 *APK DOWNLOADED*  
✨ *${botname} delivered your app*  
╰────♡◉◉◉♡────⌬

📌 ${appName}
⚡ Version: ${version}

💖 Enjoy your application ✨

${botfooter}
`
                    }, { quoted: msg });
                    
                    await conn.sendMessage(from, {
                        react: { text: "✅", key: msg.key }
                    });

                    conn.ev.off("messages.upsert", handler);

                } catch (err) {

                    conn.ev.off("messages.upsert", handler);

                    await conn.sendMessage(from, {
                        text: `❌ Error: ${err.message}`
                    }, { quoted: mek });

                }
            };

            conn.ev.on("messages.upsert", handler);

        } catch (err) {

            await conn.sendMessage(from, {
                text: `
❌ *APK Search Failed*

📌 Reason: ${err.message}

${botfooter || ""}
`
            }, { quoted: mek });

        }
    }
};
