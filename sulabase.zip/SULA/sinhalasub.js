const axios = require('axios');
const { ReadData } = require('../database');

const SEARCH_API = 'https://apis.sadas.dev/api/v1/movie/sinhalasub/search';
const INFO_API = 'https://apis.sadas.dev/api/v1/movie/sinhalasub/infodl';
const TV_INFO_API = 'https://apis.sadas.dev/api/v1/movie/sinhalasub/tv/info';
const TV_DL_API = 'https://apis.sadas.dev/api/v1/movie/sinhalasub/tv/dl';

const API_KEY = 'SULA0310';

module.exports = {
    name: 'sinhalasub',
    alias: ['ssub', 'sinmovie'],

    run: async ({ conn, mek, from, q }) => {

        if (!mek.key.fromMe) {
            return await conn.sendMessage(from, {
                text: `❌ You are not allowed to use this command.

Want access to this feature?

Create your own bot:
🌐 https://sulaofc.store/bots`
            }, { quoted: mek });
        }

        const number = conn.user.id.split(':')[0];

        const botname =
            await ReadData(number, 'BOT_NAME') ||
            'SULA MD';

        const botfooter =
            await ReadData(number, 'BOT_FOOTER') ||
            '© SULA MD';

        if (!q) {
            return conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
⚠️ *Missing Query*
✨ *SinhalaSub Search*
╰────♡◉◉◉♡────⌬

🔎 Example:

.sinhalasub venom

───────────────

💌 Enter Movie Or TV Series Name

${botfooter}`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: {
                text: '⏳',
                key: mek.key
            }
        });

        try {

            const { data } = await axios.get(
                `${SEARCH_API}?q=${encodeURIComponent(q)}&apiKey=${API_KEY}`
            );

            if (!data.status || !data.data?.length) {
                throw new Error('No results found');
            }

            const results = data.data.slice(0, 10);

            const list = results.map((x, i) =>
                `❰ ${i + 1} ❱ *${x.Title}*`
            ).join('\n\n');

            const caption = `╭────♡◉◉◉♡────⌬
🎬 *SinhalaSub Results*
✨ *${botname} Ready*
╰────♡◉◉◉♡────⌬

🔍 *Query:*
➤ ${q}

📦 *Results:*
➤ ${results.length}

───────────────

${list}

───────────────

💌 *Reply:* 1 - ${results.length}

${botfooter}`;

            const sentMsg = await conn.sendMessage(
                from,
                {
                    image: { url: results[0].Img },
                    caption
                },
                { quoted: mek }
            );

            const listener = async (msgUpdate) => {

                const msg = msgUpdate.messages[0];

                if (!msg.message) return;

                const text =
                    msg.message.conversation ||
                    msg.message.extendedTextMessage?.text;

                const isReply =
                    msg.message?.extendedTextMessage
                        ?.contextInfo?.stanzaId === sentMsg.key.id;

                if (!isReply) return;

                const index = parseInt(text) - 1;

                if (isNaN(index) || !results[index]) {
                    return conn.sendMessage(from, {
                        text: `❌ Invalid Selection`
                    }, { quoted: msg });
                }

                conn.ev.off('messages.upsert', listener);

                await conn.sendMessage(from, {
                    react: {
                        text: '📥',
                        key: msg.key
                    }
                });

                const selected = results[index];

                if (selected.Link.includes('/tvshows/')) {
                    return await showTVInfo(
                        conn,
                        msg,
                        from,
                        selected.Link,
                        botname,
                        botfooter
                    );
                }

                return await showMovieInfo(
                    conn,
                    msg,
                    from,
                    selected.Link,
                    botname,
                    botfooter
                );
            };

            conn.ev.on('messages.upsert', listener);

            setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (err) {

            return conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
❌ *Search Failed*
╰────♡◉◉◉♡────⌬

⚠️ ${err.message}

${botfooter}`
            }, { quoted: mek });

        }
    }
};

async function showMovieInfo(
    conn,
    quotedMsg,
    from,
    movieLink,
    botname,
    botfooter
) {

    const { data } = await axios.get(
        `${INFO_API}?q=${encodeURIComponent(movieLink)}&apiKey=${API_KEY}`
    );

    if (!data.status || !data.data) {
        throw new Error('Movie details not found');
    }

    const movie = data.data;

    let downloads = (movie.downloadLinks || [])
        .filter(x =>
            x.server.includes('DLServer')
        )
        .filter(x =>
            x.quality.includes('480') ||
            x.quality.includes('720')
        );

    if (!downloads.length) {
        throw new Error('No supported quality found');
    }

    const list = downloads.map((x, i) =>
        `❰ ${i + 1} ❱ *${x.quality}*\n📦 ${x.size}`
    ).join('\n\n');

    const caption = `╭────♡◉◉◉♡────⌬
🎥 *Movie Download Panel*
✨ *${botname} Ready*
╰────♡◉◉◉♡────⌬

📌 *Title:*
➤ ${movie.title}

⭐ *Rating:*
➤ ${movie.rating || 'N/A'}

🌍 *Country:*
➤ ${movie.country || 'Unknown'}

───────────────

📥 *Choose Quality*

${list}

───────────────

💌 *Reply:* 1 - ${downloads.length}

${botfooter}`;

    const sentMsg = await conn.sendMessage(
        from,
        {
            image: {
                url: movie.images?.[0]
            },
            caption
        },
        { quoted: quotedMsg }
    );

    const listener = async (msgUpdate) => {

        const msg = msgUpdate.messages[0];
        if (!msg.message) return;

        const text =
            msg.message.conversation ||
            msg.message.extendedTextMessage?.text;

        const isReply =
            msg.message?.extendedTextMessage
                ?.contextInfo?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        const index = parseInt(text) - 1;

        if (isNaN(index) || !downloads[index]) {
            return conn.sendMessage(from, {
                text: '❌ Invalid Quality Selection'
            }, { quoted: msg });
        }

        conn.ev.off('messages.upsert', listener);

        await conn.sendMessage(from, {
            react: {
                text: '⬇️',
                key: msg.key
            }
        });

        await showMovieDownloadMenu(
            conn,
            msg,
            from,
            {
                title: movie.title,
                image: movie.images?.[0],
                quality: downloads[index].quality,
                size: downloads[index].size,
                link: downloads[index].link,
                botname,
                botfooter
            }
        );
    };

    conn.ev.on('messages.upsert', listener);

    setTimeout(() => {
        conn.ev.off('messages.upsert', listener);
    }, 60000);
}

async function showMovieDownloadMenu(
    conn,
    quotedMsg,
    from,
    info
) {

    const caption = `╭────♡◉◉◉♡────⌬
📥 *Download Options*
✨ *${info.botname}*
╰────♡◉◉◉♡────⌬

🎬 *Title:*
➤ ${info.title}

💎 *Quality:*
➤ ${info.quality}

📦 *Size:*
➤ ${info.size}

───────────────

📁 ❶ Send Movie

🔗 ❷ Direct Link

───────────────

💌 *Reply:* 1 / 2

${info.botfooter}`;

    const sentMsg = await conn.sendMessage(
        from,
        {
            image: {
                url: info.image
            },
            caption
        },
        { quoted: quotedMsg }
    );

    const listener = async (msgUpdate) => {

        const msg = msgUpdate.messages[0];
        if (!msg.message) return;

        const text =
            msg.message.conversation ||
            msg.message.extendedTextMessage?.text;

        const isReply =
            msg.message?.extendedTextMessage
                ?.contextInfo?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        conn.ev.off('messages.upsert', listener);

        if (!['1', '2'].includes(text)) {
            return conn.sendMessage(from, {
                text: '❌ Invalid Option'
            }, { quoted: msg });
        }

        const sizeMatch = parseFloat(
            String(info.size)
        );

        if (
            text === '1' &&
            String(info.size)
                .toUpperCase()
                .includes('GB') &&
            sizeMatch >= 2
        ) {
            return conn.sendMessage(from, {
                text: `⚠️ File Too Large

📦 ${info.size}

Use Direct Link Option`
            }, { quoted: msg });
        }

        const doneCaption = `╭────♡◉◉◉♡────⌬
✅ *Movie Ready*
✨ *${info.botname}*
╰────♡◉◉◉♡────⌬

🎬 *Title:*
➤ ${info.title}

💎 *Quality:*
➤ ${info.quality}

📦 *Size:*
➤ ${info.size}

───────────────

🍿 Enjoy Your Movie

${info.botfooter}`;

        const fileName =
            (info.title || 'Movie')
                .replace(/[\\/:*?"<>|]/g, '')
                .trim() + '.mp4';

        if (text === '1') {

            await conn.sendMessage(from, {
                document: {
                    url: info.link
                },
                mimetype: 'video/mp4',
                fileName,
                caption: doneCaption
            }, { quoted: msg });

        } else {

            await conn.sendMessage(from, {
                text: `${doneCaption}

🔗 *Direct Download Link*

${info.link}`
            }, { quoted: msg });

        }

        await conn.sendMessage(from, {
            react: {
                text: '✅',
                key: msg.key
            }
        });
    };

    conn.ev.on('messages.upsert', listener);

    setTimeout(() => {
        conn.ev.off('messages.upsert', listener);
    }, 60000);
}

async function showTVInfo(
    conn,
    quotedMsg,
    from,
    tvLink,
    botname,
    botfooter
) {

    const { data } = await axios.get(
        `${TV_INFO_API}?q=${encodeURIComponent(tvLink)}&apiKey=${API_KEY}`
    );

    if (!data.status || !data.data) {
        throw new Error('TV Series details not found');
    }

    const tv = data.data;

    const episodes =
        tv.episodes_data?.episodes_list || [];

    if (!episodes.length) {
        throw new Error('No episodes found');
    }

    const list = episodes
        .slice(0, 20)
        .map((x, i) =>
            `❰ ${i + 1} ❱ *${x.title}*`
        )
        .join('\n');

    const caption = `╭────♡◉◉◉♡────⌬
📺 *TV Series Panel*
✨ *${botname} Ready*
╰────♡◉◉◉♡────⌬

🎬 *Title:*
➤ ${tv.title}

⭐ *Rating:*
➤ ${tv.rating || 'N/A'}

📦 *Episodes:*
➤ ${tv.episodes_count}

───────────────

${list}

───────────────

💌 *Reply:* 1 - ${episodes.length}

${botfooter}`;

    const sentMsg = await conn.sendMessage(
        from,
        { text: caption },
        { quoted: quotedMsg }
    );

    const listener = async (msgUpdate) => {

        const msg = msgUpdate.messages[0];
        if (!msg.message) return;

        const text =
            msg.message.conversation ||
            msg.message.extendedTextMessage?.text;

        const isReply =
            msg.message?.extendedTextMessage
                ?.contextInfo?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        const index = parseInt(text) - 1;

        if (isNaN(index) || !episodes[index]) {
            return conn.sendMessage(from, {
                text: '❌ Invalid Episode'
            }, { quoted: msg });
        }

        conn.ev.off('messages.upsert', listener);

        await conn.sendMessage(from, {
            react: {
                text: '📥',
                key: msg.key
            }
        });

        await showEpisodeQualities(
            conn,
            msg,
            from,
            episodes[index].link,
            tv.title,
            botname,
            botfooter
        );
    };

    conn.ev.on('messages.upsert', listener);

    setTimeout(() => {
        conn.ev.off('messages.upsert', listener);
    }, 60000);
}

async function showEpisodeQualities(
    conn,
    quotedMsg,
    from,
    episodeLink,
    seriesTitle,
    botname,
    botfooter
) {

    const { data } = await axios.get(
        `${TV_DL_API}?q=${encodeURIComponent(episodeLink)}&apiKey=${API_KEY}`
    );

    if (!data.status || !data.data?.length) {
        throw new Error('Episode links not found');
    }

    let qualities = data.data
        .filter(x =>
            x.host.includes('DLServer')
        )
        .filter(x =>
            x.quality.includes('480') ||
            x.quality.includes('720')
        );

    if (!qualities.length) {
        throw new Error('No supported quality found');
    }

    const list = qualities.map((x, i) =>
        `❰ ${i + 1} ❱ *${x.quality}*`
    ).join('\n');

    const caption = `╭────♡◉◉◉♡────⌬
📥 *Episode Download*
✨ *${botname} Ready*
╰────♡◉◉◉♡────⌬

🎬 *Series:*
➤ ${seriesTitle}

───────────────

${list}

───────────────

💌 *Reply:* 1 - ${qualities.length}

${botfooter}`;

    const sentMsg = await conn.sendMessage(
        from,
        { text: caption },
        { quoted: quotedMsg }
    );

    const listener = async (msgUpdate) => {

        const msg = msgUpdate.messages[0];
        if (!msg.message) return;

        const text =
            msg.message.conversation ||
            msg.message.extendedTextMessage?.text;

        const isReply =
            msg.message?.extendedTextMessage
                ?.contextInfo?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        const index = parseInt(text) - 1;

        if (isNaN(index) || !qualities[index]) {
            return conn.sendMessage(from, {
                text: '❌ Invalid Quality'
            }, { quoted: msg });
        }

        conn.ev.off('messages.upsert', listener);

        await conn.sendMessage(from, {
            react: {
                text: '⬇️',
                key: msg.key
            }
        });

        await showTVDownloadMenu(
            conn,
            msg,
            from,
            {
                title: seriesTitle,
                quality: qualities[index].quality,
                link: qualities[index].finalDownloadUrl,
                botname,
                botfooter
            }
        );
    };

    conn.ev.on('messages.upsert', listener);

    setTimeout(() => {
        conn.ev.off('messages.upsert', listener);
    }, 60000);
}

async function showTVDownloadMenu(
    conn,
    quotedMsg,
    from,
    info
) {

    const caption = `╭────♡◉◉◉♡────⌬
📥 *Episode Options*
✨ *${info.botname}*
╰────♡◉◉◉♡────⌬

🎬 *Series:*
➤ ${info.title}

💎 *Quality:*
➤ ${info.quality}

───────────────

📁 ❶ Send Episode

🔗 ❷ Direct Link

───────────────

💌 *Reply:* 1 / 2

${info.botfooter}`;

    const sentMsg = await conn.sendMessage(
        from,
        { text: caption },
        { quoted: quotedMsg }
    );

    const listener = async (msgUpdate) => {

        const msg = msgUpdate.messages[0];
        if (!msg.message) return;

        const text =
            msg.message.conversation ||
            msg.message.extendedTextMessage?.text;

        const isReply =
            msg.message?.extendedTextMessage
                ?.contextInfo?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        conn.ev.off('messages.upsert', listener);

        if (!['1', '2'].includes(text)) {
            return conn.sendMessage(from, {
                text: '❌ Invalid Option'
            }, { quoted: msg });
        }

        const doneCaption = `╭────♡◉◉◉♡────⌬
✅ *Episode Ready*
✨ *${info.botname}*
╰────♡◉◉◉♡────⌬

🎬 *Series:*
➤ ${info.title}

💎 *Quality:*
➤ ${info.quality}

───────────────

🍿 Enjoy Your Episode

${info.botfooter}`;

        if (text === '1') {

            await conn.sendMessage(from, {
                document: {
                    url: info.link
                },
                mimetype: 'video/mp4',
                fileName: `${info.title}.mp4`,
                caption: doneCaption
            }, { quoted: msg });

        } else {

            await conn.sendMessage(from, {
                text: `${doneCaption}

🔗 *Direct Download Link*

${info.link}`
            }, { quoted: msg });

        }

        await conn.sendMessage(from, {
            react: {
                text: '✅',
                key: msg.key
            }
        });
    };

    conn.ev.on('messages.upsert', listener);

    setTimeout(() => {
        conn.ev.off('messages.upsert', listener);
    }, 60000);
}