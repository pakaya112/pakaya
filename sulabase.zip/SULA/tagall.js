module.exports = {
    name: "tagall",
    description: "Mention all members in the group (Public).",
    category: "group",

    run: async ({ conn, mek, from, args, isGroup, groupMetadata }) => {
        try {
        
            if (!isGroup) return conn.sendMessage(from, { text: "❌ This command can only be used in groups!" }, { quoted: mek });

            const participants = groupMetadata.participants;

            let message = args.join(" ") || "Hey everyone! 👋";

            let teks = `📢 *TAG ALL MEMBERS*\n\n` +
                       `📝 *Message:* ${message}\n\n` +
                       `✨ *Group Members:*\n`;

            for (let mem of participants) {
                teks += `🔹 @${mem.id.split("@")[0]}\n`;
            }

            teks += `\n*Total:* ${participants.length}\n\n` +
                    `🚀 *Powered by SULA MD*`;

            await conn.sendMessage(from, { 
                text: teks, 
                mentions: participants.map(p => p.id) 
            }, { quoted: mek });

        } catch (err) {
            console.error("TAGALL ERROR:", err);
            await conn.sendMessage(from, { text: "❌ Failed to tag members. Make sure I am in a group!" }, { quoted: mek });
        }
    }
};
