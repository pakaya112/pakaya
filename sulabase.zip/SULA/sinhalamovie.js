const axios = require('axios');
const { ReadData } = require('../database');

const API_BASE_URL = 'https://vortexsinhaladl.vercel.app/api';

module.exports = {
    name: 'sdub',
    alias: [],
    description: 'Search and Download Sinhala Dubbed Movies using API',

    run: async ({ conn, mek, from, q, prefix }) => {
        try {
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.

Want access to this feature?

Create your own bot:
🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME');
            const botfooter = await ReadData(number, 'BOT_FOOTER');

            if (!q) {
                return await conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬
🎬 *SINHALA MOVIE SEARCH*
╰────♡◉◉◉♡────⌬

*Usage:*
➤ ${prefix || '.'}sdub <movie name>

*Examples:*
➤ ${prefix || '.'}sdub minions
➤ ${prefix || '.'}sdub harry potter
➤ ${prefix || '.'}sdub avengers

${botfooter}`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, { react: { text: '🔍', key: mek.key } });

            const searchRes = await axios.get(`${API_BASE_URL}/search?q=${encodeURIComponent(q.trim())}`, { timeout: 20000 });
            const searchData = searchRes.data;

            if (!searchData.success || !searchData.results || searchData.results.length === 0) {
                return await conn.sendMessage(from, {
                    text: `❌ *No results found for:* ${q}`
                }, { quoted: mek });
            }

            const top = searchData.results.slice(0, 10);
            const resultText = top.map((r, i) => `❰ ${i + 1} ❱ *${r.name}*`).join('\n\n');

            const caption = `╭────♡◉◉◉♡────⌬
🎬 *${botname} | SINHALA MOVIES*
╰────♡◉◉◉♡────⌬

🔍 *Results for:* ${q}

${resultText}

───────────────

Reply: 1 - ${top.length}

${botfooter}`;

            let sentMsg;
            if (top[0]?.icon) {
                sentMsg = await conn.sendMessage(from, {
                    image: { url: top[0].icon },
                    caption: caption
                }, { quoted: mek });
            } else {
                sentMsg = await conn.sendMessage(from, { text: caption }, { quoted: mek });
            }

            const searchMsgId = sentMsg.key.id;

            const searchHandler = async (msgUpdate) => {
                const reply = msgUpdate.messages[0];
                if (!reply?.message) return;

                const isReply = reply.message?.extendedTextMessage?.contextInfo?.stanzaId === searchMsgId;
                if (!isReply) return;

                const replyText = (reply.message.conversation || reply.message.extendedTextMessage?.text || '').trim();
                const selNum = parseInt(replyText);

                if (isNaN(selNum) || selNum < 1 || selNum > top.length) {
                    return await conn.sendMessage(from, {
                        text: `❌ *Invalid number!* Enter 1 to ${top.length}`
                    }, { quoted: reply });
                }

                conn.ev.off('messages.upsert', searchHandler);
                const selected = top[selNum - 1];

                await conn.sendMessage(from, { react: { text: '⏳', key: reply.key } });

                let detail;
                try {
                    const movieRes = await axios.get(`${API_BASE_URL}/movie?url=${encodeURIComponent(selected.link)}`, { timeout: 30000 });
                    detail = movieRes.data;
                } catch (e) {
                    return await conn.sendMessage(from, {
                        text: `❌ *Failed to connect API:* ${e.message}`
                    }, { quoted: reply });
                }

                if (!detail.success || !detail.finalLink) {
                    return await conn.sendMessage(from, {
                        text: `❌ *Download link not found for this movie!*`
                    }, { quoted: reply });
                }

                const infoCaption = `╭────♡◉◉◉♡────⌬
🎬 *${botname} | MOVIE DETAILS*
╰────♡◉◉◉♡────⌬

📽️ *Title:* ${detail.name}

───────────────

📥 *Reply:* \`1\` to download movie

${botfooter}`;

                let infoMsg;
                if (detail.icon) {
                    infoMsg = await conn.sendMessage(from, {
                        image: { url: detail.icon },
                        caption: infoCaption
                    }, { quoted: reply });
                } else {
                    infoMsg = await conn.sendMessage(from, { text: infoCaption }, { quoted: reply });
                }

                const infoMsgId = infoMsg.key.id;

                const dlHandler = async (dlUpdate) => {
                    const dlReply = dlUpdate.messages[0];
                    if (!dlReply?.message) return;

                    const isIt = dlReply.message?.extendedTextMessage?.contextInfo?.stanzaId === infoMsgId;
                    if (!isIt) return;

                    const dlText = (dlReply.message.conversation || dlReply.message.extendedTextMessage?.text || '').trim();
                    if (dlText !== '1') {
                        return await conn.sendMessage(from, {
                            text: `❌ *Reply* \`1\` *to download*`
                        }, { quoted: dlReply });
                    }

                    conn.ev.off('messages.upsert', dlHandler);

                    await conn.sendMessage(from, { react: { text: '⬇️', key: dlReply.key } });

                    try {
                        const fileName = `${detail.name.replace(/[^a-zA-Z0-9\s]/g, '').trim()}.mp4`;
                        
                        // Cloudflare URL Clean-up: decode කර නැවත encode කිරීමේදී single quote සහ colon ගැටලු විසඳීම
                        let rawUrl = detail.finalLink.trim();
                        let cleanUrl;
                        try {
                            cleanUrl = encodeURI(decodeURI(rawUrl)).replace(/'/g, '%27');
                        } catch {
                            cleanUrl = rawUrl;
                        }

                        // File size validation (2GB Limit check)
                        const head = await axios.head(cleanUrl, { timeout: 15000 }).catch(() => null);
                        const contentLength = head?.headers?.['content-length'];
                        
                        if (contentLength && parseInt(contentLength) >= 2048 * 1024 * 1024) {
                            const sizeGB = (parseInt(contentLength) / (1024 * 1024 * 1024)).toFixed(2);
                            return await conn.sendMessage(from, {
                                text: `⚠️ *File Size Exceeded! (${sizeGB} GB)*\n\nමෙම චිත්‍රපටයේ ප්‍රමාණය 2GB ට වඩා වැඩි බැවින් WhatsApp සීමාවන් නිසා සෘජුව යැවීමට නොහැක.\n\n🔗 *Direct Download Link:*\n${cleanUrl}`
                            }, { quoted: dlReply });
                        }

                        const doneCaption = `
╭──〔 🌸 Movie Delivery 🌸 〕──⬣

૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა Your movie is ready~ 💕

🎬 Title ➜ ${detail.name}

━━━━━━━━━━━━━━━

🍿 Enjoy your watch time!

🌸 Thanks for using ${botname}

♡ Powered By 🌐 https://sulaofc.store

━━━━━━━━━━━━━━━`;

                        await conn.sendMessage(from, {
                            document: { url: cleanUrl },
                            fileName: fileName,
                            mimetype: 'video/mp4',
                            caption: doneCaption
                        }, { quoted: dlReply });

                        await conn.sendMessage(from, { react: { text: '✅', key: dlReply.key } });

                    } catch (e) {
                        await conn.sendMessage(from, {
                            text: `❌ *Send failed:* ${e.message}\n\n📥 *Direct Link:*\n${detail.finalLink}`
                        }, { quoted: dlReply });
                        await conn.sendMessage(from, { react: { text: '❌', key: dlReply.key } });
                    }
                };

                conn.ev.on('messages.upsert', dlHandler);
                setTimeout(() => conn.ev.off('messages.upsert', dlHandler), 10 * 60 * 1000);
            };

            conn.ev.on('messages.upsert', searchHandler);
            setTimeout(() => conn.ev.off('messages.upsert', searchHandler), 5 * 60 * 1000);

        } catch (err) {
            await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
            await conn.sendMessage(from, { text: `❌ *Error:* ${err.message}` }, { quoted: mek });
        }
    }
};
