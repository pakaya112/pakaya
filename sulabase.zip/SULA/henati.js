const axios = require("axios");
const { ReadData } = require('../database');

module.exports = {
    name: "henati",
    alias: ["heni"],
    category: "nsfw",
    description: "Search and download hentai videos.",
    run: async ({ conn, mek, from, q }) => {
        try {
            // 🧠 QUERY 
            const query = q.trim() || "random";
            const API_URL = `https://www.movanest.xyz/v2/hentai?query=${encodeURIComponent(query)}`;

            // ⏳ REACT
            await conn.sendMessage(from, {
                react: { text: "🍓", key: mek.key }
            });

            // 🎯 FETCH DATA
            const res = await axios.get(API_URL);

             const number = conn.user.id.split(':')[0];
            const Images = await ReadData(number, "SULA_IMAGE_PATH");
            const botname = await ReadData(number, "BOT_NAME");
            const botfooter = await ReadData(number, "BOT_FOOTER");
            
            if (!res.data.status || !res.data.result || res.data.result.length === 0) {
                return conn.sendMessage(from, { text: "❌ No results found!" }, { quoted: mek });
            }

            // වීඩියෝ 5ක් පමණක් තෝරා ගැනීම
            const videos = res.data.result.slice(0, 5);

            // 💖 MENU CAPTION (TIKTOK STYLE UI)
            let listText = `╭━━❀ 𝓗𝓔𝓝𝓣𝓐𝓘 𝓟𝓐𝓝𝓔𝓛 ❀━━╮\n`;
            listText += `🎀🩷  ${botname} H-SEARCH  🩷🎀\n`;
            listText += `╰━━━━━━━━━━━━━━━╯\n\n`;
            listText += `🌸✨ *SEARCH RESULTS FOR:* _${query}_ ✨🌸\n\n`;

            videos.forEach((v, i) => {
                listText += `╭───────────────❀\n`;
                listText += `│ ${i + 1} ║❯❯ 🎬 *${v.title.substring(0, 30)}...*\n`;
                listText += `│    ║ 👁️ _${v.views_count} views_\n`;
                listText += `╰───────────────❀\n`;
            });

            listText += `\n💖✨ *Select your video* ✨💖\n\n`;
            listText += `💌 *Reply with 1 - ${videos.length}*\n`;
            listText += `🌷 𝑬𝒏𝒋𝒐𝒚 𝒚𝒐𝒖𝒓 𝒕𝒊𝒎𝒆 💞\n\n${botfooter}\n\n`;
            listText += `╰━━━━━━━━━━━━╯`;

            // 📩 SEND MENU
            const sent = await conn.sendMessage(from, {
                image: { url: 'https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg' }, 
                caption: listText
            }, { quoted: mek });

            const messageID = sent.key.id;
            const sender = mek.key.participant || mek.key.remoteJid;

            // 🎯 HANDLE REPLY
            const handler = async (msgUpdate) => {
                const rmek = msgUpdate.messages[0];
                if (!rmek?.message || rmek.key.remoteJid !== from) return;

                const text = rmek.message.conversation || rmek.message.extendedTextMessage?.text;
                const isReply = rmek.message?.extendedTextMessage?.contextInfo?.stanzaId === messageID;
                const isSender = (rmek.key.participant || rmek.key.remoteJid) === sender;

                if (!isReply || !isSender) return;

                const choice = parseInt(text);
                if (isNaN(choice) || choice < 1 || choice > videos.length) {
                    return; 
                }

                try {
                    const selected = videos[choice - 1];
                    const videoUrl = selected.video_1 || selected.video_2;

                    await conn.sendMessage(from, { react: { text: "⬇️", key: rmek.key } });

                    // 💖 FINAL CAPTION (TIKTOK STYLE)
                    let caption = `╭━━❀ 𝓓𝓞𝓦𝓝𝓛𝓞𝓐𝓓𝓘𝓝𝓖 ❀━━╮\n\n`;
                    caption += `📌 *Title:* _${selected.title}_\n`;
                    caption += `🍓 *Category:* _${selected.category}_\n`;
                    caption += `👀 *Views:* _${selected.views_count}_\n\n`;
                    caption += `─────────────── 🌸\n`;
                    caption += `💞 *Enjoy babe...* ✨\n\n${botfooter}\n\n`;
                    caption += `╰━━━━━━━━━━━━╯`;

                    // ⬇️ SEND VIDEO
                    await conn.sendMessage(from, {
                        video: { url: videoUrl },
                        mimetype: 'video/mp4',
                        caption: caption
                    }, { quoted: rmek });

                    await conn.sendMessage(from, { react: { text: "✅", key: rmek.key } });

                    clearTimeout(timeout);
                    conn.ev.off('messages.upsert', handler);

                } catch (e) {
                    conn.ev.off('messages.upsert', handler);
                }
            };

            conn.ev.on('messages.upsert', handler);

            const timeout = setTimeout(() => {
                conn.ev.off('messages.upsert', handler);
            }, 60000);

        } catch (err) {
            await conn.sendMessage(from, { text: "❌ API Error or Timeout!" }, { quoted: mek });
        }
    }
};
