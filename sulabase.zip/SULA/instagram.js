const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'instagram',
    alias: ['ig', 'insta', 'instadl'],

    run: async ({ conn, mek, from, q }) => {

        try {

            if (!q || !q.startsWith('http')) {

                return conn.sendMessage(from, {
                    text:
`╭────♡◉◉◉♡────⌬
❌ *INVALID INSTAGRAM URL*
🌸 *Instagram Downloader*
╰────♡◉◉◉♡────⌬

🔗 Please provide a valid Instagram URL

📌 *Example:*
➤ .instagram https://instagram.com/reel/xxxx

> © SULA MD`
                }, { quoted: mek });

            }

            await conn.sendMessage(from, {
                react: {
                    text: '⏳',
                    key: mek.key
                }
            });

            const number =
                conn.user.id.split(':')[0];

            const BOT_NAME =
                await ReadData(number, 'BOT_NAME');

            const BOT_FOOTER =
                await ReadData(number, 'BOT_FOOTER');

            const Images =
                await ReadData(number, 'SULA_IMAGE_PATH') ||
                'https://files.catbox.moe/4r6ynf.jpg';

            const api =
`https://instaapi-thenux.netlify.app/.netlify/functions/insta?url=${encodeURIComponent(q)}`;

            const { data } = await axios.get(api, {
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0'
                }
            });

            if (!data?.success) {

                throw new Error(
                    data?.error ||
                    'Failed to fetch Instagram media'
                );

            }

            const title =
                data.title || 'Instagram Reel';

            const username =
                data.username || 'unknown';

            const thumbnail =
                data.thumbnail || Images;

            const video =
                data.best ||
                data.downloads?.find(v => v.type === 'mp4')?.url;

            const audio =
                data.downloads?.find(v => v.type === 'mp3')?.url;

            const caption =
`╭────♡◉◉◉♡────⌬
📥 *INSTAGRAM DOWNLOADER*
✨ *${BOT_NAME} Media System*
╰────♡◉◉◉♡────⌬

👤 *Username*
➤ @${username}

📝 *Caption*
➤ ${title.length > 200
? title.slice(0, 200) + '...'
: title}

───────────────

📥 *Reply Number*

❶ 🎬 Download Video
❷ 🎵 Download Audio

───────────────

💌 *Reply:* 1 / 2

${BOT_FOOTER}
`;

            const sent =
                await conn.sendMessage(from, {

                    image: {
                        url: thumbnail
                    },

                    caption

                }, { quoted: mek });

            const listener =
                async (msgUpdate) => {

                const msg =
                    msgUpdate.messages[0];

                try {

                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const replied =
                        msg.message?.extendedTextMessage
                        ?.contextInfo?.stanzaId ===
                        sent.key.id;

                    if (!replied) return;

                    if (!['1', '2'].includes(text))
                        return;

                    conn.ev.off(
                        'messages.upsert',
                        listener
                    );

                    // VIDEO
                    if (text === '1') {

                        await conn.sendMessage(from, {
                            react: {
                                text: '⬇️',
                                key: msg.key
                            }
                        });

                        await conn.sendMessage(from, {

                            video: {
                                url: video
                            },

                            mimetype: 'video/mp4',

                            caption:
`╭────♡◉◉◉♡────⌬
🎬 *INSTAGRAM VIDEO*
✨ *Downloaded Successfully*
╰────♡◉◉◉♡────⌬

👤 *Username*
➤ @${username}

📝 *Caption*
➤ ${title.length > 100
? title.slice(0, 100) + '...'
: title}

${BOT_FOOTER}`

                        }, { quoted: msg });

                    }

                    // AUDIO
                    else if (text === '2') {

                        if (!audio) {

                            return conn.sendMessage(from, {
                                text:
`╭────♡◉◉◉♡────⌬
❌ *AUDIO NOT AVAILABLE*
╰────♡◉◉◉♡────⌬

${BOT_FOOTER}`
                            }, { quoted: msg });

                        }

                        await conn.sendMessage(from, {
                            react: {
                                text: '🎵',
                                key: msg.key
                            }
                        });

                        await conn.sendMessage(from, {

                            audio: {
                                url: audio
                            },

                            mimetype: 'audio/mp4',
                            ptt: false

                        }, { quoted: msg });

                    }

                    await conn.sendMessage(from, {
                        react: {
                            text: '✅',
                            key: msg.key
                        }
                    });

                } catch (err) {

                    conn.ev.off(
                        'messages.upsert',
                        listener
                    );

                    await conn.sendMessage(from, {
                        text:
`╭────♡◉◉◉♡────⌬
❌ *INSTAGRAM DOWNLOAD ERROR*
╰────♡◉◉◉♡────⌬

📌 *Reason:*
➤ ${err.message}

${BOT_FOOTER}`
                    }, { quoted: msg });

                }

            };

            conn.ev.on(
                'messages.upsert',
                listener
            );

            setTimeout(() => {

                conn.ev.off(
                    'messages.upsert',
                    listener
                );

            }, 60000);

        } catch (err) {

            await conn.sendMessage(from, {
                react: {
                    text: '❌',
                    key: mek.key
                }
            });

            return conn.sendMessage(from, {
                text:
`╭────♡◉◉◉♡────⌬
❌ *INSTAGRAM API ERROR*
╰────♡◉◉◉♡────⌬

📌 *Reason:*
➤ ${err.message}

${BOT_FOOTER}`
            }, { quoted: mek });

        }

    }
};
