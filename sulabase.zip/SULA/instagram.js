const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'instagram',
    alias: ['ig', 'insta', 'instadl'],

    run: async ({ conn, mek, from, q }) => {
        try {
            if (!q || !q.startsWith('http') || !q.includes('instagram.com')) {
                return conn.sendMessage(from, {
                    text:
`╭────♡◉◉◉♡────⌬
❌ *INVALID INSTAGRAM URL*
🌸 *Instagram Downloader*
╰────♡◉◉◉♡────⌬

🔗 Please provide a valid Instagram URL

📌 *Example:*
➤ .instagram https://www.instagram.com/reel/xxxx

> © SULA MD`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, {
                react: {
                    text: '⏳',
                    key: mek.key
                }
            });

            const number = conn.user.id.split(':')[0];
            const BOT_NAME = await ReadData(number, 'BOT_NAME');
            const BOT_FOOTER = await ReadData(number, 'BOT_FOOTER');
            const defaultImage = await ReadData(number, 'SULA_IMAGE_PATH');

            const api = `https://apis.davidcyriltech.my.id/instagram?url=${encodeURIComponent(q)}`;
            const { data } = await axios.get(api, {
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0'
                }
            });

            if (!data?.success || !data?.result) {
                throw new Error('Failed to fetch Instagram media');
            }

            const result = data.result;
            const video = result.video;
            const audio = result.audio || null;
            const thumbnail = result.thumbnail || defaultImage;
            const title = result.title || 'Instagram Video';
            const likes = result.likeCount ? `❤️ ${result.likeCount.toLocaleString()}` : '';
            const comments = result.commentCount ? `💬 ${result.commentCount.toLocaleString()}` : '';
            const quality = result.quality ? `📺 Quality: ${result.quality}` : '';

            if (!video) {
                throw new Error('No video found for this URL');
            }

            const caption =
`╭────♡◉◉◉♡────⌬
📥 *INSTAGRAM DOWNLOADER*
✨ *${BOT_NAME} Media System*
╰────♡◉◉◉♡────⌬

📝 *Caption*
➤ ${title.length > 200 ? title.slice(0, 200) + '...' : title}

${likes} ${comments}
${quality}

───────────────

📥 *Reply Number*

❶ 🎬 Download Video
❷ 🎵 Download Audio

───────────────

💌 *Reply:* 1 / 2

${BOT_FOOTER}
`;

            const sent = await conn.sendMessage(from, {
                image: {
                    url: thumbnail
                },
                caption
            }, { quoted: mek });

            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];

                try {
                    if (!msg.message) return;

                    const text = (msg.message.conversation || msg.message.extendedTextMessage?.text || '').trim();
                    const replied = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sent.key.id;

                    if (!replied) return;

                    if (!['1', '2'].includes(text)) return;

                    conn.ev.off('messages.upsert', listener);

                    if (text === '1') {
                        await conn.sendMessage(from, {
                            react: {
                                text: '⬇️',
                                key: msg.key
                            }
                        });

                        await conn.sendMessage(from, {
                            video: {
                                url: video
                            },
                            mimetype: 'video/mp4',
                            caption:
`╭────♡◉◉◉♡────⌬
🎬 *INSTAGRAM VIDEO*
✨ *Downloaded Successfully*
╰────♡◉◉◉♡────⌬

📝 *Caption*
➤ ${title.length > 100 ? title.slice(0, 100) + '...' : title}

${BOT_FOOTER}`
                        }, { quoted: msg });
                    } else if (text === '2') {
                        await conn.sendMessage(from, {
                            react: {
                                text: '🎵',
                                key: msg.key
                            }
                        });

                        await conn.sendMessage(from, {
                            audio: {
                                url: audio || video
                            },
                            mimetype: 'audio/mp4',
                            ptt: false
                        }, { quoted: msg });
                    }

                    await conn.sendMessage(from, {
                        react: {
                            text: '✅',
                            key: msg.key
                        }
                    });

                } catch (err) {
                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        text:
`╭────♡◉◉◉♡────⌬
❌ *INSTAGRAM DOWNLOAD ERROR*
╰────♡◉◉◉♡────⌬

📌 *Reason:*
➤ ${err.message}

${BOT_FOOTER}`
                    }, { quoted: msg });
                }
            };

            conn.ev.on('messages.upsert', listener);
            setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (err) {
            await conn.sendMessage(from, {
                react: {
                    text: '❌',
                    key: mek.key
                }
            });

            return conn.sendMessage(from, {
                text:
`╭────♡◉◉◉♡────⌬
❌ *INSTAGRAM API ERROR*
╰────♡◉◉◉♡────⌬

📌 *Reason:*
➤ ${err.message}

${BOT_FOOTER}`
            }, { quoted: mek });
        }
    }
};
