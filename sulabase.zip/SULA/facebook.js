const axios = require('axios');
const { ReadData } = require('../database');

async function fetchMeta(url) {

    try {

        const res = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0'
            },
            timeout: 30000
        });

        const html = res.data;

        const titleMatch = html.match(
            /<meta property="og:title" content="(.*?)"/
        );

        const imageMatch = html.match(
            /<meta property="og:image" content="(.*?)"/
        );

        return {
            title:
                titleMatch?.[1]
                    ?.replace(/&amp;/g, '&')
                    ?.replace(/&#039;/g, "'")
                    ?.replace(/&quot;/g, '"')
                || 'Facebook Video',

            thumbnail:
                imageMatch?.[1]
                    ?.replace(/&amp;/g, '&')
                || 'https://upload.wikimedia.org/wikipedia/commons/c/cd/Facebook_logo_%28square%29.png'
        };

    } catch {

        return {
            title: 'Facebook Video',
            thumbnail:
'https://upload.wikimedia.org/wikipedia/commons/c/cd/Facebook_logo_%28square%29.png'
        };
    }
}

async function fbScrape(url) {

    const backends = [
        'https://backend1.tioo.eu.org',
        'https://backend2.tioo.eu.org',
        'https://backend3.tioo.eu.org',
        'https://backend4.tioo.eu.org'
    ];

    const meta = await fetchMeta(url);

    for (const api of backends) {

        try {

            const res = await axios.get(
                `${api}/fbdown?url=${encodeURIComponent(url)}`,
                {
                    headers: {
                        'User-Agent': 'Mozilla/5.0'
                    },
                    timeout: 30000
                }
            );

            const json = res.data;

            if (
                json &&
                !json.error &&
                (
                    json.Normal_video ||
                    json.HD
                )
            ) {

                return {
                    title: meta.title,
                    thumbnail: meta.thumbnail,
                    video: json.HD || json.Normal_video
                };
            }

        } catch (e) {

            console.log(
                'FB Backend Failed:',
                api
            );
        }
    }

    return null;
}

module.exports = {

    name: 'facebook',
    alias: ['fb'],

    run: async ({ conn, mek, from, q }) => {

        if (!q || !q.startsWith('http')) {

            return conn.sendMessage(from, {
                text:
`❌ Please provide a valid Facebook URL!

Example:
.facebook https://facebook.com/...`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: {
                text: '⏳',
                key: mek.key
            }
        });

        try {

            // 🌸 SCRAPE FACEBOOK
            const fb = await fbScrape(q);

            if (!fb) {
                throw new Error(
                    'Facebook video not found!'
                );
            }

            const number =
                conn.user.id.split(':')[0];

            const botname =
                await ReadData(
                    number,
                    'BOT_NAME'
                );

            const botfooter =
                await ReadData(
                    number,
                    'BOT_FOOTER'
                );

            const caption = `
╭────♡◉◉◉♡────⌬
📘 *Facebook Download Panel*
✨ *${botname} Ready To Download*
╰────♡◉◉◉♡────⌬

🎬 *Title:*  
➤ ${fb.title}

───────────────

📥 *Choose Download Type*

❶ 🎬 Video
❷ 📁 Document

───────────────

💌 *Reply 1 - 2*

${botfooter}
`;

            const sentMsg =
                await conn.sendMessage(
                    from,
                    {
                        image: {
                            url: fb.thumbnail
                        },
                        caption
                    },
                    { quoted: mek }
                );

            const timeout = setTimeout(() => {

                conn.ev.off(
                    'messages.upsert',
                    listener
                );

            }, 30000);

            const listener =
                async (msgUpdate) => {

                try {

                    const msg =
                        msgUpdate.messages[0];

                    if (!msg.message)
                        return;

                    const text =
                        msg.message.conversation ||
                        msg.message
                        .extendedTextMessage?.text;

                    const isReply =
                        msg.message
                        .extendedTextMessage
                        ?.contextInfo?.stanzaId ===
                        sentMsg.key.id;

                    if (!isReply)
                        return;

                    if (
                        !['1', '2']
                        .includes(text)
                    ) {

                        return conn.sendMessage(
                            from,
                            {
                                text:
'❌ Please reply only with numbers 1 - 2'
                            },
                            { quoted: msg }
                        );
                    }

                    clearTimeout(timeout);

                    await conn.sendMessage(
                        from,
                        {
                            react: {
                                text: '⬇️',
                                key: msg.key
                            }
                        }
                    );

                    const videoCaption = `
╭────♡◉◉◉♡────⌬
📘 *Facebook Video Downloaded*
✨ *${botname} Successfully Sent*
╰────♡◉◉◉♡────⌬

🎬 ${fb.title}

${botfooter}
`;

                    let media;

                    if (text === '1') {

                        media = {
                            video: {
                                url: fb.video
                            },
                            caption:
                                videoCaption
                        };
                    }

                    else if (text === '2') {

                        media = {
                            document: {
                                url: fb.video
                            },
                            mimetype:
                                'video/mp4',
                            fileName:
                                'facebook-video.mp4',
                            caption:
                                videoCaption
                        };
                    }

                    await conn.sendMessage(
                        from,
                        media,
                        { quoted: msg }
                    );

                    await conn.sendMessage(
                        from,
                        {
                            react: {
                                text: '✅',
                                key: msg.key
                            }
                        }
                    );

                    conn.ev.off(
                        'messages.upsert',
                        listener
                    );

                } catch (err) {

                    console.log(err);

                    clearTimeout(timeout);

                    conn.ev.off(
                        'messages.upsert',
                        listener
                    );

                    await conn.sendMessage(from, {
                        react: {
                            text: '❌',
                            key: mek.key
                        }
                    });

                    return conn.sendMessage(
                        from,
                        {
                            text:
`❌ Failed To Download Facebook Video

Reason: ${err.message}`
                        },
                        { quoted: mek }
                    );
                }
            };

            conn.ev.on(
                'messages.upsert',
                listener
            );

        } catch (err) {

            console.log(err);

            await conn.sendMessage(from, {
                react: {
                    text: '❌',
                    key: mek.key
                }
            });

            return conn.sendMessage(from, {
                text:
`❌ Failed To Download Facebook Video

Reason: ${err.message}`
            }, { quoted: mek });
        }
    }
};
