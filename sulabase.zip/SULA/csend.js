const { ReadData } = require('../database');
const yts = require('yt-search');
const axios = require('axios');

let API_BASE = "";

async function loadApiBase() {
    try {
        const { data } = await axios.get(
            "https://raw.githubusercontent.com/sulamd48/database/main/clin.json"
        );

        API_BASE = data.api;
    } catch (err) {
        console.error("Failed to load API:", err.message);
    }
}

loadApiBase();

async function sendNewsletterMedia(sock, jid, media, type, caption = '', options = {}) {
    const { 
        generateWAMessage, 
        encodeNewsletterMessage, 
        unixTimestampSeconds,
        generateMessageID,
        getContentType
    } = await import('baileys');

    try {
        const mediaSource = (typeof media === 'string' && (media.startsWith('http') || media.startsWith('./'))) 
            ? { url: media } 
            : media;

        let content = {};

        if (type === 'image') {
            content = { image: mediaSource, caption: caption };
        } else if (type === 'video') {
            content = { video: mediaSource, caption: caption };
        } else if (type === 'audio') {
            content = { 
                audio: mediaSource, 
                ptt: options.ptt || false,
                mimetype: 'audio/ogg; codecs=opus'
            };

            if (options.ptt) {
                content.waveform = new Uint8Array([0, 0, 50, 100, 150, 200, 150, 100, 50, 0, 120, 180, 250, 180, 120, 0]);
            }
        } else {
            content = { document: mediaSource, caption: caption, mimetype: options.mimetype || 'application/pdf' };
        }

        const fullMsg = await generateWAMessage(jid, content, {
            logger: sock.logger,
            userJid: sock.user.id,
            upload: async (readStream, opts) => {
                return sock.waUploadToServer(readStream, {
                    ...opts,
                    newsletter: true 
                });
            }
        });

        const msgId = generateMessageID();
        const messageProto = fullMsg.message;
        const encodedBytes = encodeNewsletterMessage(messageProto);

        const stanza = {
            tag: 'message',
            attrs: {
         to: jid,
                id: msgId,// එපා වෙලා තියෙන්නෙ
                    type: 'media' 
            },
            content: [
                {
                    tag: 'plaintext',
                    attrs: {
                        mediatype: type === 'audio' ? 'audio' : type
                    },
                    content: encodedBytes
                }
     ]
        };

  await sock.sendNode(stanza);

        return {
            key: { remoteJid: jid, fromMe: true, id: msgId },
            message: messageProto,
            messageTimestamp: unixTimestampSeconds()
        };

    } catch (error) {
        return null;
    }
}



const sendMessageChannel1 = async (sock, jid, content, options = {}) => {

const { 
        generateWAMessage, 
        encodeNewsletterMessage, 
        unixTimestampSeconds,
        generateMessageID,
        getContentType
    } = await import('baileys');


    const isNewsletter = jid.includes('@newsletter');

    if (!isNewsletter) {

        return sock.sendMessage(jid, content, options);
    }


    const fullMsg = await generateWAMessage(jid, content, {
        logger: sock.logger,
        userJid: sock.user.id,
        upload: async (readStream, opts) => {
            return await sock.waUploadToServer(readStream, { ...opts, newsletter: true });
        },
        ...options
    });

    const messageObj = fullMsg.message;
    const contentType = getContentType(messageObj);


    let mediaType = '';
    if (contentType === 'imageMessage') mediaType = 'image';
    else if (contentType === 'videoMessage') {
        mediaType = messageObj.videoMessage?.gifPlayback ? 'gif' : 'video';
    }
    else if (contentType === 'audioMessage') {

        mediaType = messageObj.audioMessage?.ptt ? 'ptt' : 'audio'; 
    }
    else if (contentType === 'documentMessage') mediaType = 'document';

    const bytes = encodeNewsletterMessage(messageObj);

    const stanza = {
        tag: 'message',
        attrs: {
            to: jid,
            id: fullMsg.key.id,
            type: mediaType ? 'media' : 'text',
        },
        content: [
            {
                tag: 'plaintext',
                attrs: mediaType ? { mediatype: mediaType } : {},
                content: bytes
            }
        ]
    };

    await sock.sendNode(stanza);

    return fullMsg;
};


module.exports = {
    name: 'csend',
    alias: ['channelsend', 'csong'],
    run: async ({ conn, mek, from, q }) => {
        const { generateWAMessage, getContentType } = await import('baileys');
        try {
            const number = conn.user.id.split(':')[0];
            const botfooter = await ReadData(number, 'BOT_FOOTER');
            const customCaption = await ReadData(number, 'CUSTOM_CAPTION');

            if (!q) {
                return await conn.sendMessage(from, { text: '❌ *Command format:*\n.csend <channel-jid>, <song>' }, { quoted: mek });
            }

            let targetJid, query;
            if (q.includes(',')) {
                const parts = q.split(',').map(p => p.trim());
                targetJid = parts[0];
                query = parts.slice(1).join(' ');
            } else {
                const args = q.split(' ');
                targetJid = args[0];
                query = args.slice(1).join(' ');
            }

            if (!targetJid || !query) {
                return await conn.sendMessage(from, { text: '❌ *Invalid format! Use:*\n.csend <channel-jid>, <song>' }, { quoted: mek });
            }

            await conn.sendMessage(from, { react: { text: "🔍", key: mek.key } });

            const search = await yts(query);
            if (!search.videos.length) {
                return await conn.sendMessage(from, { text: '❌ *Song not found! Please try a different search term.*' }, { quoted: mek });
            }

            const data = search.videos[0];

            if (data.seconds > 5400) {
                return await conn.sendMessage(from,
                    { text: `❌ *Song too long!*\n*Limit:* 1.5 hours` },
                    { quoted: mek }
                );
            } 

            let channelname = targetJid;

try {
    if (targetJid.includes('whatsapp.com/channel/')) {

        const cleanLink = targetJid.split('?')[0].replace(/\/+$/, '');
        const linkParts = cleanLink.split('/');

        let inviteCode =
            linkParts[linkParts.indexOf('channel') + 1] ||
            linkParts.pop();

        const metadata = await conn.newsletterMetadata(
            'invite',
            inviteCode
        );

        targetJid = metadata?.id || targetJid;

        const data =
            metadata?.thread_metadata || metadata;

        channelname =
            data?.name?.text ||
            data?.name ||
            "Unknown Channel";

    } else if (targetJid.includes('@newsletter')) {

        const metadata = await conn.newsletterMetadata(
            'jid',
            targetJid
        );

        const data =
            metadata?.thread_metadata || metadata;

        channelname =
            data?.name?.text ||
            data?.name ||
            "Unknown Channel";
    }

} catch (e) {
    console.log(
        "Channel info fetch error:",
        e.message
    );
}

            const menuMsg = await conn.sendMessage(
                from,
                {
                    image: { url: data.thumbnail },
                    caption: `
╭────♡◉◉◉♡────⌬
🎵 *CHANNEL SONG SEND PANEL*
🌸 *Choose Caption Mode ✨*
╰────♡◉◉◉♡────⌬

🎶 *Title:*  
➤ ${data.title}

⏱️ *Duration:*  
➤ ${data.timestamp}

📺 *Channel:*  
➤ ${channelname}

───────────────

💌 *Reply With Number*

❶ 🎀 With Caption  
❷ 🪄 No Caption  

───────────────

🎧 *SULA-MD Music System*

${botfooter}
`
                },
                { quoted: mek }
            );

            // Listener function
            const rplListener = async (update) => {
                try {
                    const m = update.messages[0];
                    if (!m?.message || m.key.remoteJid !== from) return;

                    const text = m.message.conversation || m.message?.extendedTextMessage?.text;
                    if (!['1', '2'].includes(text)) return;

                    conn.ev.off('messages.upsert', rplListener);

                    const waitMsg = await conn.sendMessage(from, { text: "⏳ *Processing your request. Please wait...*" }, { quoted: m });


// 🎧 NEW MP3 API
const api =
`https://ytdl.udmodzz.workers.dev/?url=${encodeURIComponent(data.url)}&type=aud`;

const { data: apiRes } = await axios.get(api, {
    headers: {
        'User-Agent': 'Mozilla/5.0'
    }
});

// ❌ API ERROR
if (!apiRes || !apiRes.links) {
    return await conn.sendMessage(from, {
        text: '❌ *Failed to fetch MP3!*'
    }, { quoted: m });
}

// ✅ DOWNLOAD URL
const downloadUrl =
    apiRes.links?.["128kbps"] ||
    apiRes.links?.["320kbps"] ||
    Object.values(apiRes.links || {})[0];

if (!downloadUrl) {
    return await conn.sendMessage(from, {
        text: '❌ *Download URL not found!*'
    }, { quoted: m });
}

                   if (!API_BASE) {
    return await conn.sendMessage(from, {
        text: "❌ API configuration not loaded. Please try again in a few seconds."
    }, { quoted: m });
}

                    const taskID = `song_${Date.now()}`;
                    const convertUrl = `${API_BASE}/convert?type=normal&id=${taskID}&url=${encodeURIComponent(downloadUrl)}`;

                    await fetch(convertUrl);

                    let isDone = false;
                    let finalAudioUrl = "";
                    let audioDuration = 0;
                    let audioWaveform = [];
                    let retryCount = 0;
                    const maxRetries = 60;

                    while (!isDone && retryCount < maxRetries) {
                        await new Promise(r => setTimeout(r, 5000));
                        try {
                            const checkResp = await fetch(`${API_BASE}/check?id=${taskID}`);
                            const statusData = await checkResp.json();

                            if (statusData.status === "done") {
                                isDone = true;
                                finalAudioUrl = statusData.direct_download_link;
                                audioDuration = statusData.duration;
                                audioWaveform = statusData.waveform;
                            } else if (statusData.status === "error") {
                                throw new Error(`API Error: ${statusData.reason}`);
                            }
                        } catch (e) {
                            console.log(`Polling check failed (retry ${retryCount}):`, e.message); 
                        }
                        retryCount++;
                    }

                    if (!finalAudioUrl) {
                        throw new Error("Conversion timed out or failed.");
                    }

                    if (text === '1') {
                        const captionText = customCaption
                            .replace(/{title}/g, data.title)
                            .replace(/{time}/g, data.timestamp)
                            .replace(/{views}/g, data.views?.toLocaleString() || '0')
                            .replace(/{channel}/g, channelname)
                            .replace(/{footer}/g, botfooter);

                                            
                    await sendNewsletterMedia(
    conn, 
    targetJid, 
    { url: data.thumbnail },
    "image", 
    captionText
);
                    }
                    


                    await new Promise(r => setTimeout(r, 2000));
                    
                    
                    await sendMessageChannel1(conn, targetJid, { 
                        audio: { url: finalAudioUrl }, 
                        mimetype: "audio/ogg; codecs=opus", 
                        ptt: true,
                        seconds: audioDuration || data.seconds,
                        waveform: new Uint8Array(audioWaveform)
                    });
                    

                    
                    await conn.sendMessage(from, { text: `✅ *Sent Successfully to ${channelname}!*\n\n🎧 ${data.title}\n\n${botfooter}`, edit: waitMsg.key });

                } catch (err) {
                    console.error(err);
                    await conn.sendMessage(from, { text: `❌ *Error processing:* ${err.message} ` });
                }
            };

            conn.ev.on('messages.upsert', rplListener);

            setTimeout(() => {
                conn.ev.off('messages.upsert', rplListener);
            }, 60000);

        } catch (err) {
            console.error(err);
            await conn.sendMessage(from, { text: `❌ *System Error:* ${err.message}` }, { quoted: mek });
        }
    }
};
