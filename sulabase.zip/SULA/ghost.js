const fs = require('fs');
const path = require('path');
const { ReadData } = require('../database');

// Active sessions for action confirmations (tag/kick)
const ghostSessions = new Map();

module.exports = {
    name: 'ghosts',
    alias: ['ghost', 'inactives', 'scanghosts', 'inactivemembers'],
    category: 'group',
    description: 'Scans real group chat message cache to identify truly inactive members.',

    run: async ({ conn, client, mek, from, q, isGroup }) => {
        const botClient = conn || client;
        const sender = mek.key.participant || mek.key.remoteJid;
        const botNumber = (botClient.user?.id || '').split(':')[0];

        // 1. Must be a group
        if (!from.endsWith('@g.us')) {
            return botClient.sendMessage(from, { text: '❌ This command can only be used in group chats!' }, { quoted: mek });
        }

        // 2. Fetch Dynamic Branding
        let botname = '𝐒𝚄𝙻𝙰 𝐌𝙳 𝐌𝙸𝙽𝙸';
        let botfooter = '> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃';
        try {
            const dbName = await ReadData(botNumber, 'BOT_NAME');
            if (dbName) botname = dbName;
            const dbFooter = await ReadData(botNumber, 'BOT_FOOTER');
            if (dbFooter) botfooter = dbFooter;
        } catch (e) {}

        // Fetch Group Metadata
        let groupMeta;
        try {
            groupMeta = await botClient.groupMetadata(from);
        } catch (err) {
            return botClient.sendMessage(from, { text: '❌ Failed to fetch group metadata. Ensure the bot is in this group.' }, { quoted: mek });
        }

        const participants = groupMeta.participants || [];
        const botJid = `${botNumber}@s.whatsapp.net`;
        const botMember = participants.find(p => p.id.split(':')[0] === botNumber || p.id === botJid);
        const isBotAdmin = botMember ? (botMember.admin === 'admin' || botMember.admin === 'superadmin') : false;

        const senderMember = participants.find(p => p.id === sender);
        const isSenderAdmin = senderMember ? (senderMember.admin === 'admin' || senderMember.admin === 'superadmin') : false;

        // ============================================================
        // STEP 2: HANDLE CONFIRMATION ACTIONS (TAG / KICK)
        // ============================================================
        const quotedId = mek.message?.extendedTextMessage?.contextInfo?.stanzaId;
        const replyChoice = (q || '').trim();

        if (quotedId && ghostSessions.has(quotedId)) {
            const session = ghostSessions.get(quotedId);

            if (session.sender !== sender) {
                return botClient.sendMessage(from, { text: '❌ Only the admin who ran the scan can trigger actions.' }, { quoted: mek });
            }

            if (!isSenderAdmin) {
                return botClient.sendMessage(from, { text: '❌ You must be an admin to execute ghost actions.' }, { quoted: mek });
            }

            // OPTION 1: TAG ALL GHOSTS
            if (replyChoice === '1') {
                await botClient.sendMessage(from, { react: { text: '📢', key: mek.key } });

                let tagMessage = `╭───────────♡◉◉◉♡───────────⌬\n`;
                tagMessage += `👻 *INACTIVE MEMBER ALERT*\n`;
                tagMessage += `╰───────────♡◉◉◉♡───────────⌬\n\n`;
                tagMessage += `⚠️ The following *${session.ghosts.length}* members have *0 messages* recorded in the recent history:\n\n`;

                session.ghosts.forEach((jid, index) => {
                    tagMessage += `${index + 1}. @${jid.split('@')[0]}\n`;
                });

                tagMessage += `\n💬 *Please send a message to confirm your activity or face removal.*\n\n${botfooter}`;

                ghostSessions.delete(quotedId);
                return await botClient.sendMessage(from, {
                    text: tagMessage,
                    mentions: session.ghosts
                }, { quoted: mek });
            }

            // OPTION 2: KICK ALL GHOSTS
            if (replyChoice === '2') {
                if (!isBotAdmin) {
                    return botClient.sendMessage(from, { text: '❌ I need to be a group *Admin* to kick inactive members.' }, { quoted: mek });
                }

                await botClient.sendMessage(from, { react: { text: '⚠️', key: mek.key } });

                const startKickNotice = `╭───────────♡◉◉◉♡───────────⌬\n⚡ *PURGING REAL GHOSTS*\n╰───────────♡◉◉◉♡───────────⌬\n\nRemoving *${session.ghosts.length}* inactive members... Please wait.`;
                await botClient.sendMessage(from, { text: startKickNotice }, { quoted: mek });

                let removedCount = 0;
                for (const ghostJid of session.ghosts) {
                    try {
                        await botClient.groupParticipantsUpdate(from, [ghostJid], 'remove');
                        removedCount++;
                        await new Promise(r => setTimeout(r, 1500)); // Prevent WhatsApp spam lock
                    } catch (e) {
                        console.warn(`[GHOSTS] Failed to remove ${ghostJid}:`, e.message);
                    }
                }

                ghostSessions.delete(quotedId);
                return await botClient.sendMessage(from, {
                    text: `✅ *Purge Complete!*\nSuccessfully removed *${removedCount}/${session.ghosts.length}* verified ghosts.\n\n${botfooter}`
                }, { quoted: mek });
            }

            // OPTION 3: CANCEL
            if (replyChoice === '3') {
                ghostSessions.delete(quotedId);
                return botClient.sendMessage(from, { text: '❌ Ghost purge cancelled.' }, { quoted: mek });
            }

            return botClient.sendMessage(from, { text: '❌ Invalid choice. Reply with *1* (Tag), *2* (Kick), or *3* (Cancel).' }, { quoted: mek });
        }

        // ============================================================
        // STEP 1: SCAN ACTUAL MESSAGES FROM REAL BAILEYS STORE & LOGS
        // ============================================================
        if (!isSenderAdmin) {
            return botClient.sendMessage(from, { text: '❌ Only group admins can run the ghost scanner.' }, { quoted: mek });
        }

        await botClient.sendMessage(from, { react: { text: '🔍', key: mek.key } });

        // Days threshold
        let days = parseInt((q || '').trim(), 10);
        if (isNaN(days) || days <= 0) days = 7;
        const nowSec = Math.floor(Date.now() / 1000);
        const cutoffSec = nowSec - (days * 86400);

        // Map to store latest active timestamps per user
        const activeUsersMap = new Map();

        // 1. Extract messages from Baileys in-memory store (conn.store / global.store)
        const store = botClient.store || global.store;
        let totalScannedMsgs = 0;

        if (store && store.messages && store.messages[from]) {
            const chatMessages = store.messages[from].array || store.messages[from];
            if (Array.isArray(chatMessages)) {
                totalScannedMsgs += chatMessages.length;
                for (const m of chatMessages) {
                    const author = m.key?.participant || m.participant || (m.key?.fromMe ? botJid : null);
                    const ts = typeof m.messageTimestamp === 'number' 
                        ? m.messageTimestamp 
                        : (m.messageTimestamp?.low || 0);

                    if (author && ts) {
                        const cleanAuthor = author.split(':')[0] + '@s.whatsapp.net';
                        const existing = activeUsersMap.get(cleanAuthor) || 0;
                        if (ts > existing) activeUsersMap.set(cleanAuthor, ts);
                    }
                }
            }
        }

        // 2. Also check file activity registry if it exists
        const logFile = path.join(process.cwd(), 'SETTINGS', 'group_activity.json');
        if (fs.existsSync(logFile)) {
            try {
                const logs = JSON.parse(fs.readFileSync(logFile, 'utf-8'));
                if (logs[from]) {
                    Object.entries(logs[from]).forEach(([uJid, ts]) => {
                        const clean = uJid.split(':')[0] + '@s.whatsapp.net';
                        const existing = activeUsersMap.get(clean) || 0;
                        if (ts > existing) activeUsersMap.set(clean, ts);
                    });
                }
            } catch (e) {}
        }

        // Add the current sender as active right now
        activeUsersMap.set(sender.split(':')[0] + '@s.whatsapp.net', nowSec);

        // Filter Ghost Members
        const ghostList = [];
        let activeCount = 0;

        for (const p of participants) {
            const cleanJid = p.id.split(':')[0] + '@s.whatsapp.net';
            const isAdm = p.admin === 'admin' || p.admin === 'superadmin';
            const isBot = cleanJid.includes(botNumber);

            // Never count Admins or the Bot as ghosts
            if (isAdm || isBot) {
                continue;
            }

            const lastSeen = activeUsersMap.get(cleanJid);

            // User is a ghost if:
            // 1. They have NO recorded messages in the store/logs at all
            // 2. Their last recorded message is older than cutoffSec
            if (!lastSeen || lastSeen < cutoffSec) {
                ghostList.push(cleanJid);
            } else {
                activeCount++;
            }
        }

        // Safeguard: If the bot has no stored messages for this chat yet
        if (totalScannedMsgs < 10 && activeUsersMap.size <= 2) {
            await botClient.sendMessage(from, { react: { text: '⚠️', key: mek.key } });
            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
⚠️ *INSUFFICIENT MESSAGE CACHE*
╰───────────♡◉◉◉♡───────────⌬

The bot was recently restarted or has only cached *${totalScannedMsgs} messages* in this group. 

Running a ghost scan now would falsely flag active members! 

💡 *Fix:* Let the bot stay in the group for a bit so it can log real chat activity, or make sure your \`store.bind(conn.ev)\` is enabled in your main bot entry file.

${botfooter}`
            }, { quoted: mek });
        }

        if (ghostList.length === 0) {
            await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });
            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
🎉 *NO GHOSTS FOUND*
╰───────────♡◉◉◉♡───────────⌬

All non-admin members have recorded activity within the last *${days} days*!

📊 *Total Members:* ${participants.length}
💬 *Active Tracked:* ${activeCount}

${botfooter}`
            }, { quoted: mek });
        }

        let summary = `╭───────────♡◉◉◉♡───────────⌬\n`;
        summary += `👻 *${botname} REAL GHOST SCANNER*\n`;
        summary += `╰───────────♡◉◉◉♡───────────⌬\n\n`;
        summary += `📊 *Total Group Members:* ${participants.length}\n`;
        summary += `💬 *Active Members Found:* ${activeCount}\n`;
        summary += `🕒 *Filter Window:* ${days} Days\n`;
        summary += `💀 *Verified Inactive Ghosts:* ${ghostList.length}\n\n`;

        summary += `*Ghost Members Preview:*\n`;
        ghostList.slice(0, 15).forEach((jid, i) => {
            const lastTs = activeUsersMap.get(jid);
            const statusStr = lastTs 
                ? `${Math.floor((nowSec - lastTs) / 86400)}d ago` 
                : 'Never spoken';
            summary += `${i + 1}. @${jid.split('@')[0]} ➔ _(${statusStr})_\n`;
        });

        if (ghostList.length > 15) {
            summary += `_...and ${ghostList.length - 15} more members._\n`;
        }

        summary += `\n──────────────────────\n`;
        summary += `⚡ *Choose an Action (Reply to this message):*\n`;
        summary += `*1* ➔ 📢 Tag All Inactive Members\n`;
        summary += `*2* ➔ 🚪 Kick All Inactive Members ${!isBotAdmin ? '_(Bot needs Admin)_' : ''}\n`;
        summary += `*3* ➔ ❌ Cancel Action\n\n`;
        summary += `${botfooter}`;

        const scanMsg = await botClient.sendMessage(from, {
            text: summary,
            mentions: ghostList.slice(0, 15)
        }, { quoted: mek });

        // Save session for confirmation reply
        ghostSessions.set(scanMsg.key.id, {
            sender: sender,
            days: days,
            ghosts: ghostList
        });

        // 5-minute timeout
        setTimeout(() => {
            if (ghostSessions.has(scanMsg.key.id)) ghostSessions.delete(scanMsg.key.id);
        }, 300000);

        await botClient.sendMessage(from, { react: { text: '👻', key: scanMsg.key } });
    }
};
