const axios = require('axios');
const { ReadData } = require('../database');

const VEO_AJAX_URL = 'https://veoaifree.com/wp-admin/admin-ajax.php';
const VEO_PAGE_URL = 'https://veoaifree.com/veo-video-generator/';
const VEO_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

function veoUrlEncode(obj) {
    return Object.entries(obj)
        .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`)
        .join('&');
}

function veoBaseHeaders(cookies = '') {
    return {
        'User-Agent': VEO_UA,
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Origin': 'https://veoaifree.com',
        'Referer': VEO_PAGE_URL,
        'X-Requested-With': 'XMLHttpRequest',
        'Cookie': cookies
    };
}

async function veoFetchNonce() {
    const res = await axios.get(VEO_PAGE_URL, {
        timeout: 120000,
        headers: {
            'User-Agent': VEO_UA,
            Accept: 'text/html'
        }
    });

    const html = res.data;
    const match = html.match(/"nonce"\s*:\s*"([a-f0-9]+)"/);

    if (!match) throw new Error('Veo nonce not found');

    const nonce = match[1];

    const setCookie = res.headers['set-cookie'] || [];
    const cookies = Array.isArray(setCookie)
        ? setCookie.map(c => c.split(';')[0]).join('; ')
        : '';

    return { nonce, cookies };
}

async function veoAjaxPost(params, cookies = '') {
    const res = await axios.post(VEO_AJAX_URL, veoUrlEncode(params), {
        timeout: 300000,
        headers: {
            ...veoBaseHeaders(cookies),
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        }
    });

    return String(res.data).trim();
}

const veoSleep = (ms) => new Promise(r => setTimeout(r, ms));

function buildLongPrompt(prompt) {
    return `
${prompt}

Create a longer cinematic AI video with smooth continuous motion, strong scene continuity, detailed camera movement, cinematic pacing, realistic transitions, stable subject consistency, high quality lighting, realistic physics, dynamic environment, dramatic atmosphere, and movie trailer style.

Video style:
- long duration feeling
- cinematic storytelling
- slow camera movement
- detailed action progression
- smooth transitions
- realistic movement
- high detail
- 4K cinematic quality
- no glitches
- no broken faces
- no distorted objects
`.trim();
}

async function generateVeoVideo(prompt) {
    const { nonce, cookies } = await veoFetchNonce();

    const finalPrompt = buildLongPrompt(prompt);

    const sceneData = await veoAjaxPost({
        action: 'veo_video_generator',
        nonce,
        prompt: finalPrompt,
        totalVariations: '1',
        aspectRatio: 'VIDEO_ASPECT_RATIO_LANDSCAPE',
        actionType: 'full-video-generate'
    }, cookies);

    if (!sceneData || sceneData.includes('Error') || sceneData.includes('failed')) {
        throw new Error(`Veo generation start failed: ${sceneData}`);
    }

    // Long initial wait
    await veoSleep(180000); // 3 minutes

    // Long retry system
    const MAX_RETRIES = 60; // up to 30 minutes polling
    const POLL_DELAY = 30000; // 30 seconds

    for (let i = 0; i < MAX_RETRIES; i++) {
        const raw = await veoAjaxPost({
            action: 'veo_video_generator',
            nonce,
            sceneData,
            actionType: 'final-video-results'
        }, cookies);

        if (
            raw &&
            !raw.includes('Rate Limit') &&
            !raw.includes('Error') &&
            !raw.includes('retry') &&
            !raw.includes('processing')
        ) {
            try {
                const data = JSON.parse(raw);

                if (data.videoUrl) return data.videoUrl.replace('videos/', 'video/');
                if (data.url) return data.url.replace('videos/', 'video/');
            } catch {}

            return raw.replace('videos/', 'video/');
        }

        await veoSleep(POLL_DELAY);
    }

    throw new Error('Video generation timed out after long wait');
}

module.exports = {
    name: 'aividgen',
    alias: ['veo', 'aivideo', 'text2video'],

    run: async ({ conn, mek, from, q }) => {
        if (!q) {
            return conn.sendMessage(from, {
                text: `╭─❌ *MISSING PROMPT*
│
│ Example:
│ .aividgen a cyberpunk city at night, cinematic, 4k
╰───────────────`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '🎬', key: mek.key }
        });

        try {
            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'THENUX BOT';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© THENUX';

            await conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
🎬 *AI VIDEO GENERATION STARTED*
╰────♡◉◉◉♡────⌬

📝 *Prompt:*
${q}

⏳ *Long mode enabled*
🕒 This can take 5 - 30 minutes depending on server load.

${botfooter}`
            }, { quoted: mek });

            const videoUrl = await generateVeoVideo(q);

            if (!videoUrl || !videoUrl.startsWith('http')) {
                throw new Error('Invalid video URL received');
            }

            const caption = `╭────♡◉◉◉♡────⌬
✅ *AI VIDEO GENERATED*
🎬 *${botname}*
╰────♡◉◉◉♡────⌬

📝 *Prompt:*
${q}

🔗 *Video URL:*
${videoUrl}

${botfooter}`;

            await conn.sendMessage(from, {
                video: { url: videoUrl },
                mimetype: 'video/mp4',
                fileName: 'ai-video.mp4',
                caption
            }, { quoted: mek }).catch(async () => {
                await conn.sendMessage(from, {
                    document: { url: videoUrl },
                    mimetype: 'video/mp4',
                    fileName: 'ai-video.mp4',
                    caption
                }, { quoted: mek });
            });

            await conn.sendMessage(from, {
                react: { text: '✅', key: mek.key }
            });

        } catch (err) {
            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });

            await conn.sendMessage(from, {
                text: `╭─❌ *AI VIDEO ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
            }, { quoted: mek });
        }
    }
};
