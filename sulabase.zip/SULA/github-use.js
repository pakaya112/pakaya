const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'github',
    alias: ['git', 'gh'],
    run: async ({ conn, mek, from, q }) => {

        if (!q) {
            return conn.sendMessage(from, {
                text: `❌ Enter GitHub username!\n\nExample: .github thenuxofc`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '⏳', key: mek.key }
        });

        try {
            const username = q.replace('@', '').trim();

            const { data } = await axios.get(
                `https://api.github.com/users/${encodeURIComponent(username)}`,
                {
                    timeout: 30000,
                    headers: {
                        'User-Agent': 'THENUX-BOT',
                        'Accept': 'application/vnd.github+json'
                    }
                }
            );

            const number = conn.user.id.split(':')[0];
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© THENUX';

            const caption = `
╭────♡◉◉◉♡────⌬
🐙 *GITHUB PROFILE*
╰────♡◉◉◉♡────⌬

👤 *Name:* ${data.name || 'N/A'}
🔖 *Username:* ${data.login}
📝 *Bio:* ${data.bio || 'N/A'}

📦 *Repos:* ${data.public_repos}
👥 *Followers:* ${data.followers}
➡️ *Following:* ${data.following}

📍 *Location:* ${data.location || 'N/A'}
🏢 *Company:* ${data.company || 'N/A'}
🌐 *Blog:* ${data.blog || 'N/A'}

🔗 *Profile:*
${data.html_url}

${botfooter}
`;

            await conn.sendMessage(from, {
                image: { url: data.avatar_url },
                caption
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '✅', key: mek.key }
            });

        } catch (err) {
            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });

            await conn.sendMessage(from, {
                text: `❌ GitHub user not found or API error!\n\nReason: ${err.message}`
            }, { quoted: mek });
        }
    }
};
