const { ReadData } = require('../database');

// 🔐 Password Generator
function generatePassword(numberStr) {

    const map = {
        '0':'G',
        '1':'K',
        '2':'S',
        '3':'V',
        '4':'C',
        '5':'X',
        '6':'A',
        '7':'Z',
        '8':'H',
        '9':'R'
    };

    let reversed = numberStr.split('').reverse().join('');
    let password = '';

    for (let char of reversed) {
        password += map[char] || char;
    }

    return password;
}

// ✅ STATUS FORMAT
function formatStatus(v) {
    return v === "on" ? "✅ ON" : "❌ OFF";
}

module.exports = {
    name: "setting",

    run: async ({ conn, mek, from }) => {

        try {

            // 🔒 OWNER ONLY
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: "❌ Owner only command!"
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];

            // 🔐 PASSWORD
            const password = generatePassword(number);

            // 📥 LOAD DATA
            const botname = await ReadData(number, "BOT_NAME");
            const botfooter = await ReadData(number, "BOT_FOOTER");
            const image = await ReadData(number, "SULA_IMAGE_PATH");

            const autoReply = await ReadData(number, "AUTO_REPLY");
            const autoVoice = await ReadData(number, "AUTO_VOICE");
            const autoTyping = await ReadData(number, "AUTO_TYPING");
            const autoRecording = await ReadData(number, "AUTO_RECORDING");

            const antiCall = await ReadData(number, "ANTI_CALL");
            const antiDelete = await ReadData(number, "ANTI_DELETE");
            const antiLink = await ReadData(number, "ANTI_LINK");
            const antiTag = await ReadData(number, "ANTI_TAG");
            const antiCommand = await ReadData(number, "ANTI_COMMAND");

            const statusSeen = await ReadData(number, "AUTO_STATUS_SEEN");
            const statusReact = await ReadData(number, "AUTO_STATUS_REACT");

            const reactEmoji = await ReadData(number, "AUTO_REACT_EMOJI");
            const statusEmoji = await ReadData(number, "STATUS_REACT_EMOJI");

            const mode = await ReadData(number, "MODE");
            const offline = await ReadData(number, "ALLWAYS_OFFLINE");

            // 💎 BEAUTIFUL PANEL
            const msg = `
╭────♡◉◉◉♡────⌬
⚙️ *SETTINGS PANEL*  
🌸 *${botname} Control Center*  
╰────♡◉◉◉♡────⌬

👤 *BOT NUMBER*  
➤ ${number}

🔐 *PASSWORD*  
➤ ${password}

🌐 *MODE*  
➤ ${mode || "PUBLIC"}

📴 *ALWAYS OFFLINE*  
➤ ${formatStatus(offline)}

───────────────

🤖 *BOT INFORMATION*

💖 *BOT NAME*  
➤ ${botname}

📝 *BOT FOOTER*  
➤ ${botfooter}

🖼️ *IMAGE URL*  
➤ ${image}

───────────────

⚡ *AUTO FEATURES*

💬 AUTO REPLY  
➤ ${formatStatus(autoReply)}

🎙️ AUTO VOICE  
➤ ${formatStatus(autoVoice)}

⌨️ AUTO TYPING  
➤ ${formatStatus(autoTyping)}

🎧 AUTO RECORDING  
➤ ${formatStatus(autoRecording)}

───────────────

📲 *STATUS SETTINGS*

👁️ STATUS SEEN  
➤ ${formatStatus(statusSeen)}

😍 STATUS REACT  
➤ ${formatStatus(statusReact)}

🎭 *STATUS EMOJIS*  
➤ ${statusEmoji}

───────────────

🛡️ *SECURITY SETTINGS*

📵 ANTI CALL  
➤ ${formatStatus(antiCall)}

🗑️ ANTI DELETE  
➤ ${formatStatus(antiDelete)}

🔗 ANTI LINK  
➤ ${formatStatus(antiLink)}

🪧 ANTI TAG  
➤ ${formatStatus(antiTag)}

☢️ ANTI COMMAND  
➤ ${formatStatus(antiCommand)}

───────────────

🌐 *LOGIN PANEL*  
➤ https://sulaofc.store/bot-settings

${botfooter}
`;

            // 📤 SEND
            await conn.sendMessage(from, {
                image: { url: image || 'https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg' },
                caption: msg
            }, { quoted: mek });

        } catch (err) {

            console.log("SETTING ERROR:", err);

            await conn.sendMessage(from, {
                text: `❌ Setting command error!\n\n${err.message}`
            }, { quoted: mek });

        }
    }
};
