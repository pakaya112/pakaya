const { MongoClient } = require('mongodb');
const { ReadData } = require('../database');

const uri = 'mongodb+srv://sulaofc-web:sulaofcweb0112@cluster0.zzx21xb.mongodb.net/minisula';
const client = new MongoClient(uri, { maxPoolSize: 3 });

function formatStatus(v) {
    return v === "on" ? "✅ ON" : "❌ OFF";
}

module.exports = {
    name: "setting",
    alias: ['password'],

    run: async ({ conn, mek, from }) => {
        try {
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: "❌ Owner only command!"
                }, { quoted: mek });
            }

            const appId = process.env.APP_ID;
            if (!appId) {
                return await conn.sendMessage(from, {
                    text: "❌ Error: `APP_ID` environment variable is not defined!"
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];

            await client.connect();
            const db = client.db('minisula');
            const collection = db.collection('password');

            const existingDoc = await collection.findOne({ _id: number });

            let finalPassword;
            if (existingDoc && existingDoc.password) {
                finalPassword = existingDoc.password;
            } else {
                const prefix = "SULA";
                const randomTwoDigits = Math.floor(Math.random() * 100).toString().padStart(2, '0');
                finalPassword = `${prefix}${randomTwoDigits}${appId}`;

                await collection.updateOne(
                    { _id: number },
                    {
                        $set: {
                            number: number,
                            password: finalPassword,
                            appId: appId,
                            createdAt: new Date()
                        }
                    },
                    { upsert: true }
                );
            }

            const botname = await ReadData(number, "BOT_NAME");
            const botfooter = await ReadData(number, "BOT_FOOTER");
            const image = await ReadData(number, "SULA_IMAGE_PATH");

            const autoReply = await ReadData(number, "AUTO_REPLY");
            const autoVoice = await ReadData(number, "AUTO_VOICE");

            const antiCall = await ReadData(number, "ANTI_CALL");
            const antiDelete = await ReadData(number, "ANTI_DELETE");
            const antiDeleteTarget = await ReadData(number, "ANTI_DELETE_TARGET");
            const antiLink = await ReadData(number, "ANTI_LINK");
            const antiTag = await ReadData(number, "ANTI_TAG");
            const antiCommand = await ReadData(number, "ANTI_COMMAND");

            const statusSeen = await ReadData(number, "AUTO_STATUS_SEEN");
            const statusReact = await ReadData(number, "AUTO_STATUS_REACT");

            const statusEmoji = await ReadData(number, "STATUS_REACT_EMOJI");

            const mode = await ReadData(number, "MODE");
            const offline = await ReadData(number, "ALLWAYS_OFFLINE");

            const viewOnce = await ReadData(number, "VIEW_ONCE");
            const viewOnceEmoji = await ReadData(number, "VIEW_ONCE_EMOJI");

            const msg = `
╭────♡◉◉◉♡────⌬
⚙️ *SETTINGS PANEL*  
🌸 *${botname} Control Center*  
╰────♡◉◉◉♡────⌬

👤 *BOT NUMBER*  
➤ ${number}

🔐 *PASSWORD*  
➤ ${finalPassword}

🌐 *MODE*  
➤ ${mode}

📴 *ALWAYS OFFLINE*  
➤ ${formatStatus(offline)}

───────────────

🤖 *BOT INFORMATION*

💖 *BOT NAME*  
➤ ${botname}

📝 *BOT FOOTER*  
➤ ${botfooter}

🖼️ *IMAGE URL*  
➤ ${image}

───────────────

⚡ *AUTO FEATURES*

💬 AUTO REPLY  
➤ ${formatStatus(autoReply)}

🎙️ AUTO VOICE  
➤ ${formatStatus(autoVoice)}

───────────────

📲 *STATUS SETTINGS*

👁️ STATUS SEEN  
➤ ${formatStatus(statusSeen)}

😍 STATUS REACT  
➤ ${formatStatus(statusReact)}

🎭 *STATUS EMOJIS*  
➤ ${statusEmoji}

───────────────

🛡️ *SECURITY SETTINGS*

📵 ANTI CALL  
➤ ${formatStatus(antiCall)}

🗑️ ANTI DELETE  
➤ ${formatStatus(antiDelete)} (Target: ${antiDeleteTarget})

🔗 ANTI LINK  
➤ ${formatStatus(antiLink)}

🪧 ANTI TAG  
➤ ${formatStatus(antiTag)}

☢️ ANTI COMMAND  
➤ ${formatStatus(antiCommand)}

───────────────

👁️‍🗨️ *VIEW ONCE SETTINGS*

🔓 AUTO READ/FORWARD  
➤ ${formatStatus(viewOnce)}

✨ VIEW ONCE EMOJIS  
➤ ${viewOnceEmoji}

───────────────

🌐 *LOGIN PANEL*  
➤ https://sulaofc.store/bot-settings

${botfooter || "> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃"}
`;

            await conn.sendMessage(from, {
                image: { url: image || 'https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg' },
                caption: msg
            }, { quoted: mek });

        } catch (err) {
            console.error("SETTING ERROR:", err);
            await conn.sendMessage(from, {
                text: `❌ Setting command error!\n\n${err.message}`
            }, { quoted: mek });
        }
    }
};
