const { ReadData } = require('../database');

module.exports = {
    name: 'groupsetting',
    alias: ['gcsettings', 'gsettings'],

    run: async ({
        conn,
        mek,
        from,
        isGroup,
        isAdmin,
        isBotAdmins
    }) => {

        try {

            if (!isGroup) {
                return conn.sendMessage(from, {
                    text: '❌ This command only works in groups!'
                }, { quoted: mek });
            }

            if (!isAdmin) {
                return conn.sendMessage(from, {
                    text: '❌ Only group admins can use this command!'
                }, { quoted: mek });
            }

            if (!isBotAdmins) {
                return conn.sendMessage(from, {
                    text: '❌ Bot must be admin first!'
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];

            const BOT_NAME =
                await ReadData(number, 'BOT_NAME') || 'SULA MD';

            const BOT_FOOTER =
                await ReadData(number, 'BOT_FOOTER') || '> SULA MD';

            const caption = `
╭────♡◉◉◉♡────⌬
⚙️ *GROUP SETTINGS PANEL*
🌸 *${BOT_NAME} Group Control*
╰────♡◉◉◉♡────⌬

1️⃣ Open Group

2️⃣ Close Group

3️⃣ Lock Group Info

4️⃣ Unlock Group Info

5️⃣ Enable Disappearing Messages

6️⃣ Disable Disappearing Messages

7️⃣ Get Group Link

8️⃣ Reset Group Link

9️⃣ Tag All Admins

🔟 Group Stats

───────────────

💌 *Reply With Number*

${BOT_FOOTER}
`;

            const sent = await conn.sendMessage(from, {
                text: caption
            }, { quoted: mek });

            const listener = async (msgUpdate) => {

                try {

                    const msg = msgUpdate.messages[0];

                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message.extendedTextMessage?.contextInfo?.stanzaId === sent.key.id;

                    if (!isReply) return;

                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        react: { text: '⚙️', key: msg.key }
                    });

                    if (text === '1') {

                        await conn.groupSettingUpdate(
                            from,
                            'not_announcement'
                        );

                        return conn.sendMessage(from, {
                            text: '✅ Group Opened Successfully!'
                        }, { quoted: msg });
                    }

                    if (text === '2') {

                        await conn.groupSettingUpdate(
                            from,
                            'announcement'
                        );

                        return conn.sendMessage(from, {
                            text: '✅ Group Closed Successfully!'
                        }, { quoted: msg });
                    }

                    if (text === '3') {

                        await conn.groupSettingUpdate(
                            from,
                            'locked'
                        );

                        return conn.sendMessage(from, {
                            text: '✅ Group Info Locked!'
                        }, { quoted: msg });
                    }

                    if (text === '4') {

                        await conn.groupSettingUpdate(
                            from,
                            'unlocked'
                        );

                        return conn.sendMessage(from, {
                            text: '✅ Group Info Unlocked!'
                        }, { quoted: msg });
                    }

                    if (text === '5') {

                        await conn.groupToggleEphemeral(
                            from,
                            86400
                        );

                        return conn.sendMessage(from, {
                            text: '✅ Disappearing Messages Enabled! (24 Hours)'
                        }, { quoted: msg });
                    }

                    if (text === '6') {

                        await conn.groupToggleEphemeral(
                            from,
                            0
                        );

                        return conn.sendMessage(from, {
                            text: '✅ Disappearing Messages Disabled!'
                        }, { quoted: msg });
                    }

                    if (text === '7') {

                        const code =
                            await conn.groupInviteCode(from);

                        return conn.sendMessage(from, {
                            text:
`╭────♡◉◉◉♡────⌬
🔗 *GROUP INVITE LINK*
╰────♡◉◉◉♡────⌬

https://chat.whatsapp.com/${code}

${BOT_FOOTER}`
                        }, { quoted: msg });
                    }

                    if (text === '8') {

                        const newCode =
                            await conn.groupRevokeInvite(from);

                        return conn.sendMessage(from, {
                            text:
`╭────♡◉◉◉♡────⌬
♻️ *GROUP LINK RESET*
╰────♡◉◉◉♡────⌬

🔗 New Link:

https://chat.whatsapp.com/${newCode}

${BOT_FOOTER}`
                        }, { quoted: msg });
                    }

                    if (text === '9') {

                        const metadata =
                            await conn.groupMetadata(from);

                        const admins =
                            metadata.participants
                                .filter(v => v.admin !== null)
                                .map(v => v.id);

                        let adminText =
`╭────♡◉◉◉♡────⌬
👑 *GROUP ADMINS*
╰────♡◉◉◉♡────⌬

`;

                        admins.forEach((a, i) => {
                            adminText += `${i + 1}. @${a.split('@')[0]}\n`;
                        });

                        adminText += `\n${BOT_FOOTER}`;

                        return conn.sendMessage(from, {
                            text: adminText,
                            mentions: admins
                        }, { quoted: msg });
                    }

                    if (text === '10') {

                        const metadata =
                            await conn.groupMetadata(from);

                        const admins =
                            metadata.participants.filter(v => v.admin !== null).length;

                        const created =
                            metadata.creation
                                ? new Date(metadata.creation * 1000).toLocaleString()
                                : 'Unknown';

                        return conn.sendMessage(from, {
                            text:
`╭────♡◉◉◉♡────⌬
📊 *GROUP STATS*
╰────♡◉◉◉♡────⌬

📛 *Name:* ${metadata.subject}

👥 *Members:* ${metadata.participants.length}

👑 *Admins:* ${admins}

📅 *Created:* ${created}

🆔 *Group ID:* 
${metadata.id}

📝 *Description:* 
${metadata.desc || 'No Description'}

${BOT_FOOTER}`
                        }, { quoted: msg });
                    }

                    await conn.sendMessage(from, {
                        text: '❌ Invalid Reply Number!'
                    }, { quoted: msg });

                } catch (err) {

                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        text: `❌ Error:\n${err.message}`
                    }, { quoted: mek });
                }
            };

            conn.ev.on('messages.upsert', listener);

            setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (err) {

            await conn.sendMessage(from, {
                text: `❌ Error:\n${err.message}`
            }, { quoted: mek });
        }
    }
};
