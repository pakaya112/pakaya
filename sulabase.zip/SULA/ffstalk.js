const axios = require("axios");

module.exports = {
    name: "ffstalk",
    alias: ["ffinfo", "freefire"],

    run: async ({ conn, mek, from, q }) => {
        try {
            if (!q) {
                return await conn.sendMessage(
                    from,
                    {
                        text: "❌ *Please provide a Free Fire UID!*\n\nExample:\n.ffstalk 87980657"
                    },
                    { quoted: mek }
                );
            }

            await conn.sendMessage(from, {
                react: { text: "⏳", key: mek.key }
            });

            const { data } = await axios.get(
                `https://www.00cc.eu.cc/freefire-stalk?uid=${encodeURIComponent(q)}`,
                {
                    headers: {
                        "User-Agent": "Mozilla/5.0",
                        Accept: "application/json"
                    }
                }
            );

            if (!data.success) {
                return await conn.sendMessage(
                    from,
                    {
                        text: "❌ *UID not found!*"
                    },
                    { quoted: mek }
                );
            }

            const r = data.result;

            const text = `
╭──〔 🎮 FREE FIRE STALK 〕──⬣

👤 *Name:* ${r.account_basic_info.name}
🆔 *UID:* ${r.account_basic_info.uid}
🌍 *Region:* ${r.account_basic_info.region}
⭐ *Level:* ${r.account_basic_info.level}
❤️ *Likes:* ${r.account_basic_info.likes}
🏅 *Honor:* ${r.account_basic_info.honor_score}

📅 *Created:* ${r.account_activity.created_at}
🟢 *Last Login:* ${r.account_activity.last_login}

🔥 *BR Rank:* ${r.account_activity.br_rank}
⚔️ *CS Rank:* ${r.account_activity.cs_rank}

👥 *Guild:* ${r.guild_info.guild_name || "None"}
👑 *Leader:* ${r.guild_info.leader?.leader_name || "-"}

🐶 *Pet:* ${r.pet_details.pet_name || "None"}
🎯 *Pet Level:* ${r.pet_details.pet_level || "-"}

💬 *Bio:*
${r.account_basic_info.bio || "No Bio"}

╰──────────────⬣
`;

            await conn.sendMessage(
                from,
                {
                    image: {
                        url: r.profile_image
                    },
                    caption: text
                },
                { quoted: mek }
            );

            await conn.sendMessage(from, {
                react: { text: "✅", key: mek.key }
            });

        } catch (err) {
            console.error(err);

            await conn.sendMessage(
                from,
                {
                    text: `❌ *Error:*\n${err.message}`
                },
                { quoted: mek }
            );
        }
    }
};
