const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'tiktok',
    alias: ['tt', 'tik'],
    
    run: async ({ conn, mek, from, q }) => {

        if (!q || !q.startsWith('http')) {
            return conn.sendMessage(from, {
                text: '❌ Please provide a valid TikTok URL!\n\nExample: .tiktok https://vm.tiktok.com/xxxx'
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '⏳', key: mek.key }
        });

        try {

            const apiUrl = `https://podda-api.zone.id/tiktok?url=${encodeURIComponent(q)}`;

            const { data } = await axios.get(apiUrl);

            if (!data || !data.status) {
                throw new Error('TikTok video not found!');
            }

            const tt = data;

            const number = conn.user.id.split(':')[0];

            const botname = await ReadData(number, 'BOT_NAME');
            const botfooter = await ReadData(number, 'BOT_FOOTER');

            const caption = `
╭────♡◉◉◉♡────⌬
🎬 *TikTok Download Panel*
✨ *${botname} Ready To Download*
╰────♡◉◉◉♡────⌬

📌 *Title:*  
➤ ${tt.title || 'TikTok Video'}

👤 *Author:*  
➤ ${tt.author || 'Unknown'}

❤️ *Likes:* ${tt.likes || 0}
👁️ *Views:* ${tt.views || 0}
💬 *Comments:* ${tt.comments || 0}

───────────────

📥 *Choose Download Type*

❶ 📽️ No Watermark
❷ 🎞️ HD Quality
❸ 📹 Watermark
❹ 🎵 Audio
❺ 📁 No Watermark Document
❻ 🗂️ HD Document

───────────────

💌 *Reply 1 - 6*

${botfooter}
`;

            const sentMsg = await conn.sendMessage(from, {
                image: { url: tt.cover },
                caption
            }, { quoted: mek });

            const timeout = setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

            const listener = async (msgUpdate) => {

                try {

                    const msg = msgUpdate.messages[0];

                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                    if (!isReply) return;

                    let media;

                    await conn.sendMessage(from, {
                        react: { text: '⬇️', key: msg.key }
                    });

                    // 🌸 VIDEO CAPTION
                    const videoCaption = `
╭────♡◉◉◉♡────⌬
🎬 *TikTok Downloaded*
✨ *${botname} Successfully Sent*
╰────♡◉◉◉♡────⌬

📌 ${tt.title || 'TikTok Video'}

${botfooter}
`;

                    switch (text) {

                        case '1':
                            media = {
                                video: { url: tt.nowm },
                                caption: videoCaption
                            };
                            break;

                        case '2':
                            media = {
                                video: { url: tt.hd },
                                caption: videoCaption
                            };
                            break;

                        case '3':
                            media = {
                                video: { url: tt.wm },
                                caption: videoCaption
                            };
                            break;

                        case '4':
                            media = {
                                audio: { url: tt.music },
                                mimetype: 'audio/mpeg'
                            };
                            break;

                        case '5':
                            media = {
                                document: { url: tt.nowm },
                                mimetype: 'video/mp4',
                                fileName: 'tiktok-nowm.mp4'
                            };
                            break;

                        case '6':
                            media = {
                                document: { url: tt.hd },
                                mimetype: 'video/mp4',
                                fileName: 'tiktok-hd.mp4'
                            };
                            break;

                        default:
                            return conn.sendMessage(from, {
                                text: '❌ Please reply only with numbers 1 - 6'
                            }, { quoted: msg });
                    }

                    clearTimeout(timeout);

                    await conn.sendMessage(from, media, { quoted: msg });

                    await conn.sendMessage(from, {
                        react: { text: '✅', key: msg.key }
                    });

                    conn.ev.off('messages.upsert', listener);

                } catch (err) {

                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        text: `❌ Error: ${err.message}`
                    }, { quoted: mek });
                }
            };

            conn.ev.on('messages.upsert', listener);

        } catch (error) {

            await conn.sendMessage(from, {
                text: `❌ Failed To Download TikTok Video\n\nReason: ${error.message}`
            }, { quoted: mek });
        }
    }
};
