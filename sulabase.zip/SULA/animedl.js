const axios = require('axios');
const { ReadData } = require('../database');

const API = 'https://animedl-thenux.netlify.app/.netlify/functions/animost';

const headers = {
    'User-Agent': 'Mozilla/5.0',
    'Accept': '*/*',
    'Referer': 'https://animostlk.blogspot.com/'
};

module.exports = {
    name: 'animost',
    alias: ['animostlk', 'sinhalanime'],

    run: async ({ conn, mek, from, q }) => {
        if (!q) {
            return conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
⚠️ Missing Query
╰────♡◉◉◉♡────⌬

🔎 Search:
➤ .animost naruto

🔗 Direct:
➤ .animost https://animostlk.blogspot.com/...`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, { react: { text: '⏳', key: mek.key } });

        try {
            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'THENUX BOT';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© THENUX';

            if (q.startsWith('http')) {
                return await showDetails(conn, mek, from, q, botname, botfooter);
            }

            const results = await searchAnime(q);
            if (!results.length) throw new Error('No anime results found');

            const list = results.slice(0, 10).map((r, i) =>
                `❰ ${i + 1} ❱ *${r.title}*`
            ).join('\n\n');

            const caption = `╭────♡◉◉◉♡────⌬
🎬 *ANIME SEARCH RESULTS*
╰────♡◉◉◉♡────⌬

🔎 *Query:* ${q}
📦 *Results:* ${results.length}

${list}

───────────────
💌 *Reply:* 1 - ${Math.min(results.length, 10)}

${botfooter}`;

            const sentMsg = await conn.sendMessage(from,
                results[0]?.thumbnail
                    ? { image: { url: results[0].thumbnail }, caption }
                    : { text: caption },
                { quoted: mek }
            );

            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];

                try {
                    if (!msg.message) return;

                    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                    const isReply = msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;
                    if (!isReply) return;

                    const index = parseInt(text) - 1;
                    if (isNaN(index) || !results[index]) {
                        return conn.sendMessage(from, { text: '❌ Reply with valid number' }, { quoted: msg });
                    }

                    conn.ev.off('messages.upsert', listener);
                    await conn.sendMessage(from, { react: { text: '📥', key: msg.key } });

                    await showDetails(conn, msg, from, results[index].url, botname, botfooter);

                } catch (err) {
                    conn.ev.off('messages.upsert', listener);
                    await conn.sendMessage(from, {
                        text: `╭─❌ *ANIME SELECT ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
                    }, { quoted: msg });
                }
            };

            conn.ev.on('messages.upsert', listener);
            setTimeout(() => conn.ev.off('messages.upsert', listener), 60000);

        } catch (err) {
            await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
            await conn.sendMessage(from, {
                text: `╭─❌ *ANIMEDL ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
            }, { quoted: mek });
        }
    }
};

async function searchAnime(q) {
    const searchUrl = `https://animostlk.blogspot.com/feeds/posts/default?alt=json&q=${encodeURIComponent(q)}`;

    const { data } = await axios.get(searchUrl, {
        timeout: 60000,
        headers: { ...headers, Accept: 'application/json' }
    });

    const entries = data?.feed?.entry || [];

    return entries.map(entry => {
        const title = entry?.title?.$t?.trim() || 'No Title';
        const altLink = entry?.link?.find(l => l.rel === 'alternate');
        const url = altLink?.href || '';
        const thumbnail = cleanUrl(entry?.media$thumbnail?.url || '');
        return { title, url, thumbnail };
    }).filter(x => x.url);
}

async function showDetails(conn, quotedMsg, from, postUrl, botname, botfooter) {
    const { data } = await axios.get(`${API}?url=${encodeURIComponent(postUrl)}`, {
        timeout: 120000,
        headers
    });

    if (!data?.success) throw new Error(data?.error || 'API failed');

    let streams = (data.streams || []).filter(s => s.download_page);

    if (!streams.length) throw new Error('No download streams found');

    streams = streams.map((s, i) => ({
        quality: String(s.quality || `link-${i + 1}`).toUpperCase(),
        download: s.download_page,
        watch: s.watch_page
    }));

    const list = streams.map((s, i) =>
        `❰ ${i + 1} ❱ *${s.quality}*`
    ).join('\n');

    const caption = `╭────♡◉◉◉♡────⌬
🎬 *ANIME FOUND*
╰────♡◉◉◉♡────⌬

📌 *Title:*
${data.title || 'Anime Video'}

📝 *Description:*
${(data.description || '').slice(0, 350)}${data.description?.length > 350 ? '...' : ''}

───────────────
📥 *Select Quality:*

${list}

───────────────
💌 *Reply:* 1 - ${streams.length}

${botfooter}`;

    const sentMsg = await conn.sendMessage(from,
        data.image
            ? { image: { url: data.image }, caption }
            : { text: caption },
        { quoted: quotedMsg }
    );

    const listener = async (msgUpdate) => {
        const msg = msgUpdate.messages[0];

        try {
            if (!msg.message) return;

            const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
            const isReply = msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;
            if (!isReply) return;

            const index = parseInt(text) - 1;
            if (isNaN(index) || !streams[index]) {
                return conn.sendMessage(from, { text: '❌ Reply with valid quality number' }, { quoted: msg });
            }

            conn.ev.off('messages.upsert', listener);

            await showDocumentMenu(conn, msg, from, {
                title: data.title || 'Anime Video',
                image: data.image || '',
                quality: streams[index].quality,
                download: streams[index].download,
                watch: streams[index].watch,
                botname,
                botfooter
            });

        } catch (err) {
            conn.ev.off('messages.upsert', listener);
            await conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
❌ Quality Error
╰────♡◉◉◉♡────⌬

⚠️ ${err.message}

💌 Select Again`
            }, { quoted: msg });
        }
    };

    conn.ev.on('messages.upsert', listener);
    setTimeout(() => conn.ev.off('messages.upsert', listener), 60000);
}

async function showDocumentMenu(conn, quotedMsg, from, info) {
    const caption = `╭────♡◉◉◉♡────⌬
📥 *DOCUMENT DOWNLOAD READY*
╰────♡◉◉◉♡────⌬

📌 *Title:* ${info.title}
💎 *Quality:* ${info.quality}

───────────────
❶ 📁 Send as Document
❷ 🔗 Send Direct Link
❸ 👁️ Watch Page

💌 *Reply:* 1 / 2 / 3

${info.botfooter}`;

    const sentMsg = await conn.sendMessage(from,
        info.image ? { image: { url: info.image }, caption } : { text: caption },
        { quoted: quotedMsg }
    );

    const listener = async (msgUpdate) => {
        const msg = msgUpdate.messages[0];

        try {
            if (!msg.message) return;

            const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
            const isReply = msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;
            if (!isReply) return;

            conn.ev.off('messages.upsert', listener);

            if (!['1', '2', '3'].includes(text)) {
                return conn.sendMessage(from, { text: '❌ Reply only with 1 / 2 / 3' }, { quoted: msg });
            }

            await conn.sendMessage(from, { react: { text: '⬇️', key: msg.key } });

            const fileName = `${sanitizeFileName(info.title)}_${info.quality}.mp4`;

            const doneCaption = `╭────♡◉◉◉♡────⌬
✅ *ANIME DOCUMENT*
🎬 *${info.botname}*
╰────♡◉◉◉♡────⌬

📌 ${info.title}
💎 *Quality:* ${info.quality}

${info.botfooter}`;

            if (text === '1') {
                await conn.sendMessage(from, {
                    document: { url: info.download },
                    mimetype: 'video/mp4',
                    fileName,
                    caption: doneCaption
                }, { quoted: msg });
            }

            if (text === '2') {
                await conn.sendMessage(from, {
                    text: `${doneCaption}\n\n🔗 *Direct Download:*\n${info.download}`
                }, { quoted: msg });
            }

            if (text === '3') {
                await conn.sendMessage(from, {
                    text: `${doneCaption}\n\n👁️ *Watch Page:*\n${info.watch}`
                }, { quoted: msg });
            }

            await conn.sendMessage(from, { react: { text: '✅', key: msg.key } });

        } catch (err) {
            conn.ev.off('messages.upsert', listener);
            await conn.sendMessage(from, {
                text: `╭─❌ *DOCUMENT SEND ERROR*
│
│ *Reason:* ${err.message}
│
│ Use option 2 direct link if WhatsApp upload fails.
╰───────────────`
            }, { quoted: msg });
        }
    };

    conn.ev.on('messages.upsert', listener);
    setTimeout(() => conn.ev.off('messages.upsert', listener), 60000);
}

function cleanUrl(str = '') {
    return String(str)
        .replace(/\\\//g, '/')
        .replace(/&amp;/g, '&')
        .replace(/\\u003d/g, '=')
        .replace(/\\u0026/g, '&')
        .trim();
}

function sanitizeFileName(name = 'anime_video') {
    return String(name)
        .replace(/[\\/:*?"<>|]/g, '')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 80) || 'anime_video';
}
