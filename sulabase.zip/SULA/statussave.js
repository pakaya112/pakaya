module.exports = {
    name: 'save',
    alias: ['s'],
    run: async ({ conn, mek, from }) => {

        const {
    default: makeWASocket,
    useMultiFileAuthState,
    delay,
    makeCacheableSignalKeyStore,
    Browsers,
    downloadContentFromMessage,
    jidNormalizedUser,
    proto,
    prepareWAMessageMedia,
    downloadMediaMessage,
    generateForwardMessageContent,
    generateWAMessageFromContent
} = await import('baileys');

        try {

            const quoted =
                mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;

            if (!quoted) {
                return await conn.sendMessage(
                    from,
                    {
                        text: '❌ Please reply to a media message!'
                    },
                    { quoted: mek }
                );
            }

            const mtype = Object.keys(quoted)[0];

            const validTypes = [
                'imageMessage',
                'videoMessage',
                'audioMessage',
                'documentMessage'
            ];

            if (!validTypes.includes(mtype)) {
                return await conn.sendMessage(
                    from,
                    {
                        text: '❌ Only Image, Video, Audio & Documents are supported!'
                    },
                    { quoted: mek }
                );
            }

            const stream = await downloadContentFromMessage(
                quoted[mtype],
                mtype.replace('Message', '')
            );

            const chunks = [];

            for await (const chunk of stream) {
                chunks.push(chunk);
            }

            const buffer = Buffer.concat(chunks);

            let media = {};

            if (mtype === 'imageMessage') {
                media = {
                    image: buffer,
                    caption:
                        quoted.imageMessage?.caption ||
                        '🖼️ Saved Image'
                };
            }

            else if (mtype === 'videoMessage') {
                media = {
                    video: buffer,
                    caption:
                        quoted.videoMessage?.caption ||
                        '🎬 Saved Video'
                };
            }

            else if (mtype === 'audioMessage') {
                media = {
                    audio: buffer,
                    mimetype:
                        quoted.audioMessage?.mimetype ||
                        'audio/mp4',
                    ptt:
                        quoted.audioMessage?.ptt ||
                        false
                };
            }

            else if (mtype === 'documentMessage') {
                media = {
                    document: buffer,
                    mimetype:
                        quoted.documentMessage?.mimetype ||
                        'application/octet-stream',
                    fileName:
                        quoted.documentMessage?.fileName ||
                        'file'
                };
            }

            await conn.sendMessage(
                from,
                media,
                { quoted: mek }
            );

            await conn.sendMessage(
                from,
                {
                    react: {
                        text: '💾',
                        key: mek.key
                    }
                }
            );

        } catch (err) {

            console.error('Save Error:', err);

            await conn.sendMessage(
                from,
                {
                    text: `❌ Error Saving Media!\n\n${err.message}`
                },
                { quoted: mek }
            );
        }
    }
};
