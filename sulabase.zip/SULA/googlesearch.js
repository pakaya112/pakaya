const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'googlesearch',
    alias: ['gsearch', 'google'],

    run: async ({ conn, mek, from, q }) => {

        try {

            const number = conn.user.id.split(':')[0];

            const botname =
                await ReadData(number, 'BOT_NAME');

            const botfooter =
                await ReadData(number, 'BOT_FOOTER');

            // DATABASE IMAGE
            const Images =
                await ReadData(number, 'SULA_IMAGE_PATH');

            if (!q) {

                return await conn.sendMessage(from, {
                    text:
`╭────♡◉◉◉♡────⌬
🔎 *GOOGLE SEARCH PANEL*
🌸 *${botname} Search Engine*
╰────♡◉◉◉♡────⌬

❌ *Please enter a search query*

📌 *Example:*
➤ .google whatsapp

${botfooter}`
                }, { quoted: mek });

            }

            await conn.sendMessage(from, {
                react: {
                    text: '🔍',
                    key: mek.key
                }
            });

            const api =
`https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(q)}&key=AIzaSyDMbI3nvmQUrfjoCJYLS69Lej1hSXQjnWI&cx=baf9bdb0c631236e5`;

            const { data } = await axios.get(api);

            if (!data.items || !data.items.length) {

                return await conn.sendMessage(from, {
                    text:
`╭────♡◉◉◉♡────⌬
❌ *NO RESULTS FOUND*
╰────♡◉◉◉♡────⌬

🔎 Search:
➤ ${q}

${botfooter}`
                }, { quoted: mek });

            }

            const results = data.items.slice(0, 10);

            let caption =
`╭────♡◉◉◉♡────⌬
🌐 *GOOGLE SEARCH RESULTS*
✨ *${botname} Search Engine*
╰────♡◉◉◉♡────⌬

🔎 *Search Query*
➤ ${q}

📦 *Results Found*
➤ ${data.searchInformation.formattedTotalResults}

────────────────\n`;

            results.forEach((item, index) => {

                caption +=
`*${index + 1} • ${item.title}*

🔗 ${item.link}

📝 ${item.snippet}

────────────────\n`;

            });

            caption += `\n${botfooter}`;

            await conn.sendMessage(from, {

                image: {
                    url: Images
                },

                caption

            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: {
                    text: '✅',
                    key: mek.key
                }
            });

        } catch (err) {

            console.log(err);

            await conn.sendMessage(from, {
                text:
`╭────♡◉◉◉♡────⌬
❌ *GOOGLE SEARCH FAILED*
╰────♡◉◉◉♡────⌬

📌 Reason:
➤ ${err.message}

> © SULA MD`
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: {
                    text: '❌',
                    key: mek.key
                }
            });

        }

    }
};
