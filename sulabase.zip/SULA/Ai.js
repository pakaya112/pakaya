const axios = require('axios');

module.exports = {
    name: 'ai',
    run: async ({ conn, mek, from, q }) => {

        try {
            if (!q || q.trim() === '') {
                return conn.sendMessage(from, {
                    text: "🤖 ඔව් කියපන් බන්... මම SULA AI 😎"
                }, { quoted: mek });
            }

            await conn.sendMessage(from, {
                react: { text: '🧠', key: mek.key }
            });

            const apiUrl = `https://sula-ai-three.vercel.app/api/chat?prompt=${encodeURIComponent(q)}`;
            const { data } = await axios.get(apiUrl);

            const aiReply = data?.data || "❌ AI reply එකක් නැහැ.";

            await conn.sendMessage(from, {
                text: aiReply
            }, { quoted: mek });

        } catch (err) {
        //    console.error("AI Error:", err.message || err);

            await conn.sendMessage(from, {
                text: "❌ AI එකට connect වෙන්න බැරි උනා 😢"
            }, { quoted: mek });
        }
    }
};
