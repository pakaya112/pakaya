const axios = require('axios');
const { ReadData } = require('../database');

const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Referer': 'https://pastpapers.wiki/'
};

module.exports = {
    name: 'pastpapers',
    alias: ['paper', 'papers', 'pastpaper'],
    run: async ({ conn, mek, from, q }) => {

        if (!q) {
            return conn.sendMessage(from, {
                text: `╭─❌ *MISSING QUERY*
│
│ Search:
│ .pastpapers maths 2023
│ .pastpapers biology
│
│ Direct:
│ .pastpapers https://pastpapers.wiki/...
╰───────────────`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '📚', key: mek.key }
        });

        try {
            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'THENUX BOT';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© THENUX';

            if (q.startsWith('http')) {
                return await handlePost(conn, mek, from, q, botname, botfooter);
            }

            const searchData = await searchPastPapers(q);
            const results = searchData.results || [];

            if (!results.length) throw new Error('No past papers found');

            const list = results.slice(0, 10).map((r, i) =>
                `❰ ${i + 1} ❱ *${r.title}*`
            ).join('\n\n');

            const caption = `╭────♡◉◉◉♡────⌬
📚 *PAST PAPERS SEARCH*
╰────♡◉◉◉♡────⌬

🔎 *Query:* ${q}
📦 *Results:* ${results.length}

${list}

───────────────
💌 *Reply:* 1 - ${Math.min(results.length, 10)}

${botfooter}`;

            const msgData = results[0]?.thumbnail
                ? { image: { url: results[0].thumbnail }, caption }
                : { text: caption };

            const sentMsg = await conn.sendMessage(from, msgData, { quoted: mek });

            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];

                try {
                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                    if (!isReply) return;

                    const index = parseInt(text) - 1;

                    if (isNaN(index) || !results[index]) {
                        return conn.sendMessage(from, {
                            text: '❌ Reply with valid number'
                        }, { quoted: msg });
                    }

                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        react: { text: '⬇️', key: msg.key }
                    });

                    await handlePost(conn, msg, from, results[index].url, botname, botfooter);

                } catch (err) {
                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        text: `╭─❌ *PAST PAPER ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
                    }, { quoted: msg });
                }
            };

            conn.ev.on('messages.upsert', listener);

            setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (err) {
            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });

            await conn.sendMessage(from, {
                text: `╭─❌ *PAST PAPERS ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
            }, { quoted: mek });
        }
    }
};

async function searchPastPapers(q) {
    const searchUrl = `https://pastpapers.wiki/?s=${encodeURIComponent(q)}`;

    const { data: html } = await axios.get(searchUrl, {
        timeout: 60000,
        headers
    });

    const results = [];
    const seen = new Set();

    const titleRegex = /class="jeg_post_title"[^>]*>\s*<a href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    let match;

    while ((match = titleRegex.exec(html)) !== null) {
        const url = cleanHtml(match[1]);
        const title = cleanHtml(match[2]);

        if (!seen.has(url)) {
            seen.add(url);
            results.push({ title, url });
        }
    }

    const thumbnails = [];
    const thumbnailRegex = /"thumbnailUrl"\s*:\s*"([^"]+)"/gi;

    while ((match = thumbnailRegex.exec(html)) !== null) {
        thumbnails.push(cleanHtml(match[1]));
    }

    for (let i = 0; i < results.length && i < thumbnails.length; i++) {
        results[i].thumbnail = thumbnails[i];
    }

    return { results };
}

async function handlePost(conn, quotedMsg, from, postUrl, botname, botfooter) {
    const data = await scrapePost(postUrl);

    const title = data.videoname || 'Past Paper';
    const desc = data.desc || title;
    const thumbnail = data.thumbnail || '';
    const entries = Object.entries(data.links || {});

    if (!entries.length) throw new Error('No download links found');

    const list = entries.slice(0, 10).map(([label], i) =>
        `❰ ${i + 1} ❱ *${label}*`
    ).join('\n');

    const caption = `╭────♡◉◉◉♡────⌬
📄 *PAST PAPER FOUND*
╰────♡◉◉◉♡────⌬

📌 *Title:*
${title}

📝 *Description:*
${desc.slice(0, 250)}${desc.length > 250 ? '...' : ''}

───────────────
${list}

───────────────
💌 *Reply:* 1 - ${Math.min(entries.length, 10)}

${botfooter}`;

    const msgData = thumbnail
        ? { image: { url: thumbnail }, caption }
        : { text: caption };

    const sentMsg = await conn.sendMessage(from, msgData, { quoted: quotedMsg });

    const listener = async (msgUpdate) => {
        const msg = msgUpdate.messages[0];

        try {
            if (!msg.message) return;

            const text =
                msg.message.conversation ||
                msg.message.extendedTextMessage?.text;

            const isReply =
                msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

            if (!isReply) return;

            const index = parseInt(text) - 1;

            if (isNaN(index) || !entries[index]) {
                return conn.sendMessage(from, {
                    text: '❌ Reply with valid number'
                }, { quoted: msg });
            }

            conn.ev.off('messages.upsert', listener);

            const [label, url] = entries[index];

            await conn.sendMessage(from, {
                react: { text: '📥', key: msg.key }
            });

            const fileName = `${sanitizeFileName(title)}.pdf`;

            if (url.toLowerCase().includes('.pdf') || url.includes('cdn.pastpapers.wiki')) {
                await conn.sendMessage(from, {
                    document: { url },
                    mimetype: 'application/pdf',
                    fileName,
                    caption: `╭────♡◉◉◉♡────⌬
✅ *PAST PAPER PDF*
📚 *${botname}*
╰────♡◉◉◉♡────⌬

📌 ${title}
📄 *File:* ${label}

${botfooter}`
                }, { quoted: msg });
            } else {
                await conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬
✅ *PAST PAPER LINK*
╰────♡◉◉◉♡────⌬

📌 *${title}*
📄 *${label}:*
${url}

${botfooter}`
                }, { quoted: msg });
            }

            await conn.sendMessage(from, {
                react: { text: '✅', key: msg.key }
            });

        } catch (err) {
            conn.ev.off('messages.upsert', listener);

            await conn.sendMessage(from, {
                text: `╭─❌ *DOWNLOAD ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
            }, { quoted: msg });
        }
    };

    conn.ev.on('messages.upsert', listener);

    setTimeout(() => {
        conn.ev.off('messages.upsert', listener);
    }, 60000);
}

async function scrapePost(postUrl) {
    const { data: html } = await axios.get(postUrl, {
        timeout: 60000,
        headers
    });

    const titleMatch =
        html.match(/<h1 class="[^"]*jeg_post_title[^"]*">([^<]+)<\/h1>/i) ||
        html.match(/<title>([^<]+)<\/title>/i);

    const videoname = titleMatch
        ? cleanHtml(titleMatch[1]).replace(' - Past Papers WiKi', '').trim()
        : 'Past Paper';

    const thumbMatch = html.match(/<meta\s+property="og:image"\s+content="([^"]+)"/i);
    const thumbnail = thumbMatch ? cleanHtml(thumbMatch[1]) : '';

    const descMatch = html.match(/<meta\s+property="og:description"\s+content="([^"]+)"/i);
    const desc = descMatch ? cleanHtml(descMatch[1]) : videoname;

    const resolvePromises = [];
    const aTagRegex = /<a\b([^>]*)\bhref=["']([^"']+)["']([^>]*)>([\s\S]*?)<\/a>/gi;
    let match;

    while ((match = aTagRegex.exec(html)) !== null) {
        const attrsBefore = match[1];
        const url = cleanHtml(match[2]);
        const attrsAfter = match[3];
        const innerHtml = match[4];

        const allAttrs = attrsBefore + ' ' + attrsAfter;
        const titleAttrMatch = allAttrs.match(/title=["']([^"']+)["']/i);

        let label = titleAttrMatch ? cleanHtml(titleAttrMatch[1]) : '';

        if (!label) {
            label = cleanHtml(innerHtml);
        }

        const isDownloadUrl = url.includes('pastpapers.wiki/download/');
        const isExternalUrl =
            url.includes('drive.google.com') ||
            url.includes('docs.google.com') ||
            url.includes('mega.nz') ||
            url.includes('mediafire.com') ||
            url.includes('dropbox.com') ||
            url.endsWith('.pdf') ||
            url.endsWith('.zip');

        if (isDownloadUrl) {
            resolvePromises.push(
                resolveDownloadUrl(url).then(cdnUrl => ({
                    label: label || 'Download',
                    url: cdnUrl
                }))
            );
        } else if (isExternalUrl) {
            resolvePromises.push(Promise.resolve({
                label: label || 'External Link',
                url
            }));
        }
    }

    const resolved = await Promise.all(resolvePromises);
    const links = {};
    const seenUrls = new Set();
    let count = 1;

    for (const item of resolved) {
        if (!seenUrls.has(item.url)) {
            seenUrls.add(item.url);

            const label = item.label || `File ${count}`;
            const finalLabel = links[label] ? `${label} ${count}` : label;

            links[finalLabel] = item.url;
            count++;
        }
    }

    if (Object.keys(links).length === 0) {
        links.Fallback = postUrl;
    }

    return {
        videoname,
        desc,
        thumbnail,
        links
    };
}

async function resolveDownloadUrl(downloadUrl) {
    try {
        const res = await axios.get(downloadUrl, {
            timeout: 30000,
            maxRedirects: 0,
            validateStatus: s => s >= 200 && s < 400,
            headers
        });

        return cleanHtml(res.headers.location || downloadUrl);

    } catch (err) {
        if (err.response?.headers?.location) {
            return cleanHtml(err.response.headers.location);
        }

        return cleanHtml(downloadUrl);
    }
}

function cleanHtml(str = '') {
    return String(str)
        .replace(/\\\//g, '/')
        .replace(/<[^>]+>/g, ' ')
        .replace(/&amp;/g, '&')
        .replace(/&#8211;/g, '–')
        .replace(/&#8217;/g, "'")
        .replace(/&quot;/g, '"')
        .replace(/&#038;/g, '&')
        .replace(/\s+/g, ' ')
        .trim();
}

function sanitizeFileName(name = 'pastpaper') {
    return String(name)
        .replace(/[\\/:*?"<>|]/g, '')
        .trim()
        .slice(0, 80) || 'pastpaper';
}
