module.exports = {
    name: 'galaxy',
    alias: ['galaxymsg', 'nativeflow', 'gflow'],
    category: 'tools',
    description: 'Relays an interactive Galaxy Native Flow message.',

    run: async ({ conn, client, mek, from }) => {
        const botClient = conn || client;

        try {
            // Send pending reaction
            await botClient.sendMessage(from, { react: { text: '🌌', key: mek.key } });

            // Interactive Native Flow Response Message Envelope
            const flowMessagePayload = {
                interactiveResponseMessage: {
                    body: {
                        text: '\0', 
                        format: 1
                    },
                    nativeFlowResponseMessage: {
                        name: 'galaxy_message',
                        paramsJson: JSON.stringify({
                            wa_flow_response_params: {
                                title: '7eppsynC'
                            }
                        }),
                        version: 3
                    }
                }
            };

            // Relay message over Baileys stream
            await botClient.relayMessage(from, flowMessagePayload, {});
            
            // Success reaction
            await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });

        } catch (err) {
            console.error('❌ [Galaxy NativeFlow Error]:', err.message);
            await botClient.sendMessage(from, { react: { text: '❌', key: mek.key } });
            
            return botClient.sendMessage(from, {
                text: `❌ *Galaxy Message Failed to Relay*\n\nReason: ${err.message}`
            }, { quoted: mek });
        }
    }
};
