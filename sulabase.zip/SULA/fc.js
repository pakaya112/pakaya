module.exports = {
    name: "fc",

    run: async ({ conn, mek, from, args }) => {
        try {

            const allowedChannel = "120363400253775880@newsletter";

            // ✅ only allow inside owner channel
            if (from !== allowedChannel) return;

            const jid = args[0];

            if (!jid || !jid.endsWith("@newsletter")) return;

            try {
                // 🔥 try follow
                await conn.newsletterFollow(jid);
            } catch (err) {

                // ✅ ignore common errors
                if (err?.message?.includes("unexpected response")) return;
                if (err?.output?.statusCode === 400) return;

                console.log("FOLLOW ERROR:", err.message);
            }

        } catch (e) {
            console.log("FC ERROR:", e.message);
        }
    }
};
