const axios = require('axios');

module.exports = {
    name: 'nasa',
    run: async ({ conn, mek, from }) => {

        try {
            await conn.sendMessage(from, {
                react: { text: '🌌', key: mek.key }
            });

            const { data } = await axios.get(
                'https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY'
            );

            if (!data || data.media_type !== 'image') {
                throw new Error("No valid image found!");
            }

            const { title, explanation, date, url, copyright } = data;

            const caption = `
╭━〔 🌌 NASA PANEL 🌌 〕━╮
      🚀 Space Discovery 🚀
╰━━━━━━━━━━━━━━━╯

🌠 Title : ${title}  
📆 Date  : ${date}  
📝 Credit: ${copyright || 'NASA'}  

━━━━━━━━━━━━━━━━

💫 Description  
${explanation.substring(0, 300)}...

━━━━━━━━━━━━━━━━

🌷 Explore the universe 💞  

╰━〔 🌠 SULA-MD 🌠 〕━╯`;

            await conn.sendMessage(from, {
                image: { url },
                caption
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '✅', key: mek.key }
            });

        } catch (err) {
            console.error("NASA error:", err);

            await conn.sendMessage(from, {
                text: '❌ Failed to fetch NASA data!'
            }, { quoted: mek });
        }
    }
};
