const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('ffmpeg-static');
const { ReadData } = require('../database');

ffmpeg.setFfmpegPath(ffmpegPath);

module.exports = {
    name: 'mp4',
    alias: ['ytmp4', 'ytv', 'video'],
    run: async ({ conn, mek, from, q }) => {

        if (!q || !q.startsWith('http')) {
            return conn.sendMessage(from, {
                text: `╭─❌ *INVALID YOUTUBE URL*
│ Example:
│ .mp4 https://youtu.be/0EFcErjg8Gc
╰───────────────`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, { react: { text: '⏳', key: mek.key } });

        let rawPath, fixedPath;

        try {
            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'THENUX BOT';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© THENUX';

            const apiUrl = `https://ytdl-api-thenux.netlify.app/api/ytmp4?url=${encodeURIComponent(q)}`;

            const { data } = await axios.get(apiUrl, {
                timeout: 180000,
                headers: {
                    'User-Agent': 'Mozilla/5.0',
                    'Accept': 'application/json'
                }
            });

            if (!data?.success || !data?.result?.download) {
                throw new Error(data?.error || 'Download link not found');
            }

            const result = data.result;
            const title = result.title || 'youtube_video';

            const cleanName = title
                .replace(/[\\/:*?"<>|]/g, '')
                .trim()
                .slice(0, 60) || 'youtube_video';

            const caption = `
╭────♡◉◉◉♡────⌬
🎬 *YOUTUBE MP4 READY*
╰────♡◉◉◉♡────⌬

📌 *Title:*
${title}

👤 *Author:* ${result.author || 'Unknown'}

───────────────

📥 *Choose Quality:*

❶ 📱 360P Fast
❷ 🎬 480P SD
❸ 💎 720P HD
❹ 🚀 1080P Full HD
❺ 📁 Document

───────────────

💌 *Reply:* 1 / 2 / 3 / 4 / 5

${botfooter}
`;

            const sentMsg = await conn.sendMessage(from, {
                image: { url: result.thumbnail || '' },
                caption
            }, { quoted: mek });

            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];

                try {
                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                    if (!isReply) return;

                    conn.ev.off('messages.upsert', listener);

                    if (!['1', '2', '3', '4', '5'].includes(text)) {
                        return conn.sendMessage(from, {
                            text: '❌ Reply only with 1 / 2 / 3 / 4 / 5'
                        }, { quoted: msg });
                    }

                    const fakeQuality = {
                        '1': '360p',
                        '2': '480p',
                        '3': '720p',
                        '4': '1080p',
                        '5': 'Document'
                    }[text];

                    await conn.sendMessage(from, {
                        react: { text: '⬇️', key: msg.key }
                    });

                    await conn.sendMessage(from, {
                        text: `╭────♡◉◉◉♡────⌬
⬇️ *DOWNLOADING VIDEO...*
╰────♡◉◉◉♡────⌬

💎 *Selected:* ${fakeQuality}
🔗 *Resolving real video link...*
🛠️ *Fixing for WhatsApp...*`
                    }, { quoted: msg });

                    rawPath = path.join(os.tmpdir(), `${Date.now()}_${cleanName}_raw.mp4`);
                    fixedPath = path.join(os.tmpdir(), `${Date.now()}_${cleanName}_fixed.mp4`);

                    await downloadVideo(result.download, rawPath);

                    await fixVideo(rawPath, fixedPath);

                    const videoCaption = `
╭────♡◉◉◉♡────⌬
✅ *YOUTUBE VIDEO DOWNLOADED*
🎬 *${botname} MP4*
╰────♡◉◉◉♡────⌬

📌 ${title}
💎 *Selected:* ${fakeQuality}

${botfooter}
`;

                    const buffer = fs.readFileSync(fixedPath);

                    if (text === '5') {
                        await conn.sendMessage(from, {
                            document: buffer,
                            mimetype: 'video/mp4',
                            fileName: `${cleanName}.mp4`,
                            caption: videoCaption
                        }, { quoted: msg });
                    } else {
                        await conn.sendMessage(from, {
                            video: buffer,
                            mimetype: 'video/mp4',
                            fileName: `${cleanName}.mp4`,
                            caption: videoCaption
                        }, { quoted: msg });
                    }

                    await conn.sendMessage(from, {
                        react: { text: '✅', key: msg.key }
                    });

                    cleanup(rawPath, fixedPath);

                } catch (err) {
                    cleanup(rawPath, fixedPath);

                    await conn.sendMessage(from, {
                        text: `╭─❌ *MP4 DOWNLOAD ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
                    }, { quoted: msg });
                }
            };

            conn.ev.on('messages.upsert', listener);

            setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (err) {
            cleanup(rawPath, fixedPath);

            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });

            await conn.sendMessage(from, {
                text: `╭─❌ *YTMP4 ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
            }, { quoted: mek });
        }
    }
};

async function downloadVideo(url, output) {
    let finalUrl = url;

    for (let i = 0; i < 5; i++) {
        const res = await axios({
            method: 'GET',
            url: finalUrl,
            responseType: 'stream',
            timeout: 300000,
            maxRedirects: 20,
            validateStatus: () => true,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122 Safari/537.36',
                'Accept': 'video/mp4,video/*,*/*',
                'Accept-Language': 'en-US,en;q=0.9',
                'Connection': 'keep-alive'
            }
        });

        const type = res.headers['content-type'] || '';

        if (res.status !== 200) {
            throw new Error(`Download status ${res.status}`);
        }

        if (type.includes('text/plain') || type.includes('text/html')) {
            const chunks = [];

            for await (const chunk of res.data) {
                chunks.push(chunk);
            }

            const body = Buffer.concat(chunks).toString('utf8').trim();
            const foundUrl = body.match(/https?:\/\/[^\s"'<>]+/i)?.[0];

            if (!foundUrl) {
                throw new Error(`No video URL in text response: ${body.slice(0, 120)}`);
            }

            finalUrl = foundUrl;
            continue;
        }

        if (!type.includes('video') && !type.includes('octet-stream')) {
            throw new Error(`Not video file: ${type}`);
        }

        await new Promise((resolve, reject) => {
            const writer = fs.createWriteStream(output);
            res.data.pipe(writer);
            writer.on('finish', resolve);
            writer.on('error', reject);
        });

        if (!fs.existsSync(output) || fs.statSync(output).size < 50000) {
            throw new Error('Downloaded file is empty or invalid');
        }

        return;
    }

    throw new Error('Could not resolve final video file');
}

function fixVideo(input, output) {
    return new Promise((resolve, reject) => {
        ffmpeg(input)
            .videoCodec('libx264')
            .audioCodec('aac')
            .outputOptions([
                '-preset ultrafast',
                '-pix_fmt yuv420p',
                '-movflags +faststart',
                '-profile:v baseline',
                '-level 3.0'
            ])
            .save(output)
            .on('end', () => {
                if (!fs.existsSync(output) || fs.statSync(output).size < 50000) {
                    return reject(new Error('Fixed MP4 invalid'));
                }
                resolve();
            })
            .on('error', reject);
    });
}

function cleanup(...files) {
    for (const file of files) {
        try {
            if (file && fs.existsSync(file)) fs.unlinkSync(file);
        } catch {}
    }
}
