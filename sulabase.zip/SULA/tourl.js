const fs = require("fs");
const path = require("path");
const axios = require("axios");
const FormData = require("form-data");

const {
    downloadContentFromMessage
} = require("baileys");

const { ReadData } = require("../database");

module.exports = {
    name: "tourl",
    alias: ["imgurl", "imglink"],
    category: "tools",
    description: "Upload image and get URL.",

    run: async ({ conn, mek, from }) => {

        try {

            // 📥 BOT DATA
            const number =
                conn.user.id.split(':')[0];

            const botname =
                await ReadData(number, "BOT_NAME");

            const botfooter =
                await ReadData(number, "BOT_FOOTER");

            // 📎 REACT
            await conn.sendMessage(from, {
                react: { text: "📎", key: mek.key }
            });

            // 🖼️ GET QUOTED IMAGE
            const quoted =
                mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;

            // ❌ NO IMAGE
            if (!quoted?.imageMessage) {

                return conn.sendMessage(from, {
                    text: `
╭────♡◉◉◉♡────⌬
🌐 *IMAGE TO URL PANEL*  
🌸 *${botname} Image Uploader* ✨  
╰────♡◉◉◉♡────⌬

❌ *Please reply to an image*

📌 *Example:*  
➤ Reply image + .tourl

───────────────

💖 Instantly convert image into direct URL.

${botfooter}
`
                }, { quoted: mek });

            }

            // 🔑 IMGBB API
            const apiKey =
                "fc3d92594ef266ded7ad1229590cb191";

            // 📥 DOWNLOAD IMAGE
            const stream =
                await downloadContentFromMessage(
                    quoted.imageMessage,
                    "image"
                );

            let buffer = Buffer.from([]);

            for await (const chunk of stream) {

                buffer = Buffer.concat([buffer, chunk]);

            }

            // 💾 TEMP FILE
            const tempFile =
                path.join(
                    __dirname,
                    `tourl_${Date.now()}.jpg`
                );

            fs.writeFileSync(tempFile, buffer);

            // 📤 UPLOAD
            const form =
                new FormData();

            form.append(
                "image",
                fs.createReadStream(tempFile)
            );

            const res =
                await axios.post(

                    `https://api.imgbb.com/1/upload?key=${apiKey}`,

                    form,

                    {
                        headers: form.getHeaders()
                    }

                );

            // 🗑️ DELETE TEMP
            fs.unlinkSync(tempFile);

            // ✅ SUCCESS
            if (res.data?.success) {

                const imageUrl =
                    res.data.data.url;

                await conn.sendMessage(from, {

                    text: `
╭────♡◉◉◉♡────⌬
🌐 *IMAGE UPLOADED*  
✨ *${botname} generated your URL*  
╰────♡◉◉◉♡────⌬

📎 *DIRECT IMAGE URL*

${imageUrl}

───────────────

💖 Your image is now accessible online.

${botfooter}
`

                }, { quoted: mek });

                // ✅ REACT
                await conn.sendMessage(from, {
                    react: { text: "✅", key: mek.key }
                });

            } else {

                // ❌ FAIL
                await conn.sendMessage(from, {
                    text: `
╭────♡◉◉◉♡────⌬
❌ *UPLOAD FAILED*  
╰────♡◉◉◉♡────⌬

📌 ImgBB upload failed.

${botfooter}
`
                }, { quoted: mek });

            }

        } catch (err) {

            console.error("TOURL ERROR:", err);

            // ❌ ERROR
            await conn.sendMessage(from, {
                text: `
╭────♡◉◉◉♡────⌬
❌ *IMAGE TO URL ERROR*  
╰────♡◉◉◉♡────⌬

📌 Reason:
➤ ${err.message}

💖 Please try again later.

${botfooter || ""}
`
            }, { quoted: mek });

        }
    }
};
