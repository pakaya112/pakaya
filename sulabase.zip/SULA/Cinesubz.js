const axios = require('axios');
const { ReadData } = require('../database');

const SEARCH_API = 'https://cz-dnuz.vercel.app/search';
const INFO_API = 'https://cz-dnuz.vercel.app/info';
const MOVIEDL_API = 'https://cz-dnuz.vercel.app/movidl';
const DOWNLOAD_API = 'https://cz-dnuz.vercel.app/download';
const CAT_API = 'https://cz.dnuz.top/categories';
const BROWSE_API = 'https://cz.dnuz.top/browse';

const DEFAULT_IMAGE = 'https://raw.githubusercontent.com/sulamadara1147/data/main/file_00000000097071fabaedacd96b9efefc.png';

module.exports = {
    name: 'cinesubz',
    alias: ['cs', 'sinhalasub'],

    run: async ({ conn, mek, from, q }) => {
        try {
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.\n\nWant access to this feature?\n\nCreate your own bot:\n🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'SULA MD';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© SULA MD';

            // ---- 📂 FEATURE 1: NO QUERY PROVIDED -> SHOW CATEGORIES ----
            if (!q) {
                await conn.sendMessage(from, { react: { text: '📂', key: mek.key } });
                const { data } = await axios.get(CAT_API);
                
                if (!data.success || !data.categories?.length) {
                    throw new Error('Failed to load movie categories.');
                }

                const usefulCats = data.categories.slice(0, 20);
                const catListText = usefulCats.map((cat, i) => `❱ *${i + 1}* ➜ ${cat.replace('genre_', '🎭 ').replace('year_', '📅 ').replace('collection_', '🏆 ')}`).join('\n');

                const sentCatMsg = await conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬\n🎬 *CineSubz Movie Portal*\n╰────♡◉◉◉♡────⌬\n\n💡 *Tip:* Search any movie by typing: \n*.cinesubz bad newz*\n\nOr reply with a number below to browse categories:\n\n${catListText}\n\n${botfooter}`
                }, { quoted: mek });

                const catListener = async (msgUpdate) => {
                    const msg = msgUpdate.messages[0];
                    if (!msg.message) return;

                    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                    const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentCatMsg.key.id;

                    if (!isReply) return;

                    const idx = parseInt(text) - 1;
                    if (isNaN(idx) || !usefulCats[idx]) {
                        return conn.sendMessage(from, { text: '❌ Invalid Category Choice' }, { quoted: msg });
                    }

                    conn.ev.off('messages.upsert', catListener);
                    await conn.sendMessage(from, { react: { text: '⏳', key: msg.key } });

                    return await browseCategory(conn, msg, from, usefulCats[idx], botname, botfooter);
                };

                conn.ev.on('messages.upsert', catListener);
                setTimeout(() => { conn.ev.off('messages.upsert', catListener); }, 60000);
                return;
            }

            // ---- 🔍 FEATURE 2: QUERY PROVIDED -> SEARCH MOVIES ----
            const args = q.trim().split(' ');
            let targetJid = null;
            let searchQuery = q;
            let isCustomTarget = false;

            if (args[0]?.includes('@s.whatsapp.net') || args[0]?.includes('@g.us') || args[0]?.includes('@lid')) {
                targetJid = args[0];
                searchQuery = args.slice(1).join(' ');
                isCustomTarget = true;
            }

            await conn.sendMessage(from, { react: { text: '⏳', key: mek.key } });

            const { data } = await axios.get(`${SEARCH_API}?q=${encodeURIComponent(searchQuery)}`);

            if (!data.success || !data.result?.length) {
                throw new Error('No movies or series found with Sinhala Subtitles.');
            }

            const results = data.result.slice(0, 10);
            const list = results.map((x, i) => `❰ ${i + 1} ❱ *${x.title}*\n📅 Year: ${x.date || 'N/A'} | ⭐ IMDB: ${x.imdb || 'N/A'}`).join('\n\n');

            const sentSearchMsg = await conn.sendMessage(from, {
                image: { url: results[0].img || DEFAULT_IMAGE },
                caption: `╭────♡◉◉◉♡────⌬\n🎬 *CineSubz Sinhala Sub Results*\n╰────♡◉◉◉♡────⌬\n\n${list}\n\n───────────────\n\nReply: 1 - ${results.length} to select.\n\n${botfooter}`
            }, { quoted: mek });

            const movieListener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];
                if (!msg.message) return;

                const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentSearchMsg.key.id;

                if (!isReply) return;

                const index = parseInt(text) - 1;
                if (isNaN(index) || !results[index]) {
                    return conn.sendMessage(from, { text: '❌ Invalid Movie Selection' }, { quoted: msg });
                }

                conn.ev.off('messages.upsert', movieListener);
                await conn.sendMessage(from, { react: { text: '📥', key: msg.key } });

                // මෙතනදී සර්ච් ලිස්ට් එකෙන් එන සැබෑ නම (results[index].title) ඉස්සරහට පාස් කරනවා
                return await showMovieInfo(conn, msg, from, targetJid, isCustomTarget, results[index].url, results[index].title, botname, botfooter);
            };

            conn.ev.on('messages.upsert', movieListener);
            setTimeout(() => { conn.ev.off('messages.upsert', movieListener); }, 60000);

        } catch (err) {
            return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: mek });
        }
    }
};

// 📂 Sub Function: Browse Selected Category
async function browseCategory(conn, quotedMsg, from, categoryName, botname, botfooter) {
    try {
        const { data } = await axios.get(`${BROWSE_API}?category=${categoryName}`);
        
        if (!data.success || !data.result?.length) {
            throw new Error('No items found in this category.');
        }

        const results = data.result.slice(0, 10);
        const list = results.map((x, i) => `❰ ${i + 1} ❱ *${x.title}*\n⭐ IMDB: ${x.imdb || 'N/A'} | 🎬 Quality: ${x.quality || 'WEB-DL'}`).join('\n\n');

        const sentBrowseMsg = await conn.sendMessage(from, {
            image: { url: results[0].img || DEFAULT_IMAGE },
            caption: `╭────♡◉◉◉♡────⌬\n📂 Category: *${categoryName.toUpperCase()}*\n╰────♡◉◉◉♡────⌬\n\n${list}\n\n───────────────\n\nReply: 1 - ${results.length} to fetch details.\n\n${botfooter}`
        }, { quoted: quotedMsg });

        const browseListener = async (msgUpdate) => {
            const msg = msgUpdate.messages[0];
            if (!msg.message) return;

            const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
            const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentBrowseMsg.key.id;

            if (!isReply) return;

            const index = parseInt(text) - 1;
            if (isNaN(index) || !results[index]) {
                return conn.sendMessage(from, { text: '❌ Invalid Selection' }, { quoted: msg });
            }

            conn.ev.off('messages.upsert', browseListener);
            await conn.sendMessage(from, { react: { text: '📥', key: msg.key } });

            // කැටගරි බ්‍රවුස් එකෙන් එන සැබෑ නම (results[index].title) ඉස්සරහට පාස් කරනවා
            return await showMovieInfo(conn, msg, from, null, false, results[index].url, results[index].title, botname, botfooter);
        };

        conn.ev.on('messages.upsert', browseListener);
        setTimeout(() => { conn.ev.off('messages.upsert', browseListener); }, 60000);

    } catch (err) {
        return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: quotedMsg });
    }
}

// ℹ️ Sub Function: Show Movie Info and Quality List
async function showMovieInfo(conn, quotedMsg, from, targetJid, isCustomTarget, movieUrl, backupTitle, botname, botfooter) {
    try {
        const infoReq = await axios.get(`${INFO_API}?url=${encodeURIComponent(movieUrl)}`);
        
        if (!infoReq.data.success || !infoReq.data.result) {
            throw new Error('Could not fetch movie detailed profile.');
        }

        const movie = infoReq.data.result;

        const dlReq = await axios.get(`${MOVIEDL_API}?url=${encodeURIComponent(movieUrl)}`);
        
        if (!dlReq.data.success || !dlReq.data.result?.downloads?.length) {
            throw new Error('Sinhala subtitle download links are currently empty for this title.');
        }

        const downloads = dlReq.data.result.downloads;
        const qListText = downloads.map((x, i) => `❰ ${i + 1} ❱ ${x.meta || x.label}`).join('\n');

        const cleanDesc = movie.description ? (movie.description.length > 250 ? movie.description.slice(0, 250) + '...' : movie.description) : 'No description found.';

        // API එකෙන් දෙන නම අවුල් නම් සර්ච් එකෙන් ආපු backupTitle එක ගන්නවා
        const realTitle = movie.title || backupTitle || 'Movie';

        const sentInfoMsg = await conn.sendMessage(from, {
            image: { url: movie.poster || DEFAULT_IMAGE },
            caption: `╭────♡◉◉◉♡────⌬\n🇱🇰 *${realTitle}*\n╰────♡◉◉◉♡────⌬\n\n🗓️ Year: ${movie.year || 'N/A'}\n⏱️ Time: ${movie.duration || 'N/A'}\n⭐ IMDB: ${movie.imdb || 'N/A'} (${movie.imdbVotes || '0'})\n✍️ Subtitle: ${movie.subtitleBy || 'CineSubz Team'}\n\n📖 *Story:* ${cleanDesc}\n\n*Available Video Qualities:*\n${qListText}\n\n───────────────\n\nReply with Quality Number (e.g: 1)\n\n${botfooter}`
        }, { quoted: quotedMsg });

        const qualityListener = async (msgUpdate) => {
            const msg = msgUpdate.messages[0];
            if (!msg.message) return;

            const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
            const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentInfoMsg.key.id;

            if (!isReply) return;

            const index = parseInt(text) - 1;
            if (isNaN(index) || !downloads[index]) {
                return conn.sendMessage(from, { text: '❌ Invalid Quality Choice.' }, { quoted: msg });
            }

            conn.ev.off('messages.upsert', qualityListener);
            await conn.sendMessage(from, { react: { text: '⬇️', key: msg.key } });

            // මෙතනට අපි සැබෑ නම (realTitle) බලෙන්ම පාස් කරනවා අන්තිම පියවරට
            return await processFinalDelivery(conn, msg, from, targetJid, isCustomTarget, downloads[index], realTitle, botname);
        };

        conn.ev.on('messages.upsert', qualityListener);
        setTimeout(() => { conn.ev.off('messages.upsert', qualityListener); }, 60000);

    } catch (err) {
        return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: quotedMsg });
    }
}

// 🚀 Final Function: Fetch Direct Link and Send File (With Absolute API Bypass Logic)
async function processFinalDelivery(conn, quotedMsg, from, targetJid, isCustomTarget, selectedDl, movieTitle, botname) {
    try {
        const finalReq = await axios.get(`${DOWNLOAD_API}?url=${encodeURIComponent(selectedDl.resolvedUrl)}`);

        if (!finalReq.data.success || !finalReq.data.result?.downloadUrls?.length) {
            throw new Error('Direct server links are broken or expired.');
        }

        const linkData = finalReq.data.result;
        const directDownloadUrl = linkData.downloadUrls[1]?.url || linkData.downloadUrls[0]?.url;

        if (!directDownloadUrl) {
            throw new Error('Direct file download routing failed.');
        }

        // 👑 🛡️ API BYPASS LOGIC:
        // අවුල් ගිය API එකෙන් එන නම සම්පූර්ණයෙන්ම ප්‍රතික්ෂේප කර, මුලින් ආපු සැබෑ නම (movieTitle) පාවිච්චි කිරීම
        let cleanName = movieTitle ? movieTitle.replace(/[\\/:*?"<>|]/g, '').trim() : 'Movie';
        const safeFileName = `${cleanName}.mp4`;

        // සයිස් එකටත් API එක ගණන් ගන්නේ නැතුව, selectedDl.meta එකෙන් එන පිරිසිදු සයිස් එක වෙන් කර ගැනීම (e.g. "1.4 GB")
        let rawSizeText = selectedDl.meta || 'N/A';
        if (rawSizeText.includes('•')) {
            // "WEBDL 720p • 1.6 GB • Hindi" වගේ එකකින් මැද තියෙන සයිස් එක විතරක් කඩා ගැනීම
            const parts = rawSizeText.split('•');
            if (parts[1]) rawSizeText = parts[1].trim();
        }

        // ---- 🛡️ 2GB FILE SIZE BLOCKER LOGIC ----
        const rawSizeUpper = rawSizeText.toUpperCase();
        const isGB = rawSizeUpper.includes('GB');
        const sizeNum = parseFloat(rawSizeText);

        if (isGB && sizeNum >= 2.0) {
            const largeFileCaption = `⚠️ *File Size Limit Exceeded! (2GB+)*\n\nසමාවන්න! මෙම චිත්‍රපටයේ ප්‍රමාණය *${rawSizeText}* කි. WhatsApp සීමාවන් නිසා 2GB වලට වඩා විශාල ගොනු (Files) සෘජුවම බොට් හරහා යැවීමට නොහැක.\n\nපහත සබැඳිය (Link) මඟින් ඔබට මෙම චිත්‍රපටය බ්‍රවුසරය හරහා අධිවේගයෙන් සෘජුවම ඩවුන්ලෝඩ් කරගත හැක:\n\n🔗 *Direct Download Link:*\n${directDownloadUrl}\n\n━━━━━━━━━━━━━━━\n🍿 Enjoy your movie time!\n🌸 Powered By https://sulaofc.store`;

            await conn.sendMessage(from, { text: largeFileCaption }, { quoted: quotedMsg });
            await conn.sendMessage(from, { react: { text: '⚠️', key: quotedMsg.key } });
            return;
        }
        // ----------------------------------------

        // ---- 📝 CAPTION OUTPUT FIXED FOR GOOD ----
        const doneCaption = `\n╭──〔 🎬 CineSubz Delivery 〕──⬣\n\nඔන්න ඔයා ඉල්ලපු සිංහල උපසිරැසි ගැන්වූ චිත්‍රපටය ලෑස්තියි! 🇱🇰🎉\n\n🎞️ *File:* ${cleanName}\n📦 *Size:* ${rawSizeText}\n\n━━━━━━━━━━━━━━━\n\n🍿 Enjoy your movie time!\n\n🌸 Thanks for using ${botname}\n\n🌐 Powered By https://sulaofc.store\n\n━━━━━━━━━━━━━━━`;

        await conn.sendMessage(targetJid || from, {
            document: { url: directDownloadUrl },
            mimetype: 'video/mp4',
            fileName: safeFileName,
            caption: doneCaption
        }, { quoted: quotedMsg });

        if (isCustomTarget && targetJid) {
            await conn.sendMessage(from, {
                text: `✅ Movie Successfully Delivered to Target JID!\n\n📤 To: ${targetJid}`
            }, { quoted: quotedMsg });
        }

        await conn.sendMessage(from, { react: { text: '✅', key: quotedMsg.key } });

    } catch (err) {
        return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: quotedMsg });
    }
}
