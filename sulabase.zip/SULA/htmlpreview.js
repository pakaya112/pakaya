const crypto = require('crypto');
const { ReadData } = require('../database');

module.exports = {
    name: 'htmlpreview',
    alias: ['previewhtml', 'renderhtml', 'htmlview', 'viewhtml'],
    category: 'tools',
    description: 'Renders raw HTML/CSS/JS code directly as an interactive preview inside WhatsApp.',

    run: async ({ conn, client, mek, from, q }) => {
        const botClient = conn || client;
        const number = (botClient.user?.id || '').split(':')[0];

        // 1. Fetch Dynamic Bot Configuration from Database
        let botname = '𝐒𝚄𝙻𝙰 𝐌𝙳 𝐌𝙸𝙽𝙸';
        let botfooter = '> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃';

        try {
            const dbBotName = await ReadData(number, 'BOT_NAME');
            if (dbBotName) botname = dbBotName;

            const dbBotFooter = await ReadData(number, 'BOT_FOOTER');
            if (dbBotFooter) botfooter = dbBotFooter;
        } catch (e) {
            console.warn('Database Read Error:', e.message);
        }

        // 2. Extract HTML content (either from command arguments or quoted message)
        let htmlInput = q ? q.trim() : '';

        const quotedMsg = mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const quotedText = quotedMsg?.conversation || 
                           quotedMsg?.extendedTextMessage?.text || '';

        if (!htmlInput && quotedText) {
            htmlInput = quotedText.trim();
        }

        // Strip markdown codeblock backticks if user wrapped in ```html ... ```
        if (htmlInput.startsWith('```')) {
            htmlInput = htmlInput.replace(/^```[a-zA-Z]*\n?/, '').replace(/```$/, '').trim();
        }

        if (!htmlInput) {
            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
🌐 *${botname} HTML PREVIEW ENGINE*
╰───────────♡◉◉◉♡───────────⌬

❌ *Please provide HTML code to preview!*

*Usage:*
• \`.htmlpreview <your html code>\`
• Reply to any message containing HTML code with \`.htmlpreview\`

*Example:*
\`\`\`html
.htmlpreview <div style="background:#0f172a;padding:20px;border-radius:15px;color:#38bdf8;text-align:center;">
  <h2>Hello World 🚀</h2>
  <p>Rendered live on WhatsApp!</p>
</div>
\`\`\`

${botfooter}`
            }, { quoted: mek });
        }

        await botClient.sendMessage(from, { react: { text: '🌐', key: mek.key } });

        try {
            // 3. Ensure responsive meta viewport wrapper so mobile rendering is crisp
            let finalHtml = htmlInput;
            if (!finalHtml.toLowerCase().includes('<meta name="viewport"')) {
                finalHtml = `<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">\n<style>*{-webkit-tap-highlight-color:transparent;box-sizing:border-box;}</style>\n` + finalHtml;
            }

            // 4. Send using native sendHTML helper if implemented on your Baileys client
            if (typeof botClient.sendHTML === 'function') {
                await botClient.sendHTML(from, finalHtml, {
                    title: `${botname} HTML Preview`,
                    trustedSources: ['thenuxofc.store', 'nixel.dev']
                });
            } else {
                // 5. Fallback: Full WhatsApp Native Meta AI Primitive Envelope
                const response_id = crypto.randomUUID();
                const botResponseId = crypto.randomUUID();

                const previewEnvelope = {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2,
                        botMetadata: {
                            messageDisclaimerText: "",
                            botResponseId: botResponseId,
                            verificationMetadata: {
                                proofs: [
                                    {
                                        version: 1,
                                        useCase: 1,
                                        signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                        certificateChain: [
                                            "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                            "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                        ]
                                    }
                                ]
                            }
                        }
                    },
                    botForwardedMessage: {
                        message: {
                            richResponseMessage: {
                                messageType: 1,
                                submessages: [{ messageType: 2, messageText: "HTML Code Preview" }],
                                unifiedResponse: {
                                    data: Buffer.from(JSON.stringify({
                                        response_id,
                                        sections: [
                                            {
                                                view_model: {
                                                    primitive: {
                                                        __typename: "GenAIaeacdsnwHtmlPrimitive",
                                                        payload: finalHtml,
                                                        trusted_sources: ["thenuxofc.store", "nixel.dev"]
                                                    },
                                                    __typename: "GenAISingleLayoutViewModel"
                                                }
                                            }
                                        ]
                                    })).toString('base64')
                                },
                                contextInfo: {
                                    forwardingScore: 1,
                                    isForwarded: true,
                                    forwardedAiBotMessageInfo: { botJid: "867051314767696@bot" },
                                    forwardOrigin: 4
                                }
                            }
                        }
                    }
                };

                await botClient.relayMessage(from, previewEnvelope, {});
            }

            await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });

        } catch (err) {
            console.error('❌ [HTML Preview Relay Error]:', err.message);
            await botClient.sendMessage(from, { react: { text: '❌', key: mek.key } });

            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
❌ *HTML PREVIEW FAILED*
╰───────────♡◉◉◉♡───────────⌬

📌 *Reason:* ${err.message}

${botfooter}`
            }, { quoted: mek });
        }
    }
};
