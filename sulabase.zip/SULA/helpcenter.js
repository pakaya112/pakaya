module.exports = {
    name: 'helpcenter',
    alias: ['help'],

    run: async ({ conn, mek, from }) => {

        try {

            const BOT_NAME = '𝐒𝚄𝙻𝙰 𝐌𝙳 𝐌𝙸𝙽𝙸';

            const BOT_FOOTER =
                '> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃';

            const IMAGE =
                'https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg';

            // ================= MAIN PANEL =================

            const caption = `
👋 𝑊𝑒𝑙𝑐𝑜𝑚𝑒 𝑡𝑜 ${BOT_NAME} 𝐻𝑒𝑙𝑝 𝐶𝑒𝑛𝑡𝑒𝑟! 💬

⮞⮞⮞ [ Help Center / උපකාර මධ්‍යස්ථානය ] ⮜⮜⮜

➤ කරුණාකර භාෂාවක් තෝරන්න:
➤ Please select a language to continue:

❶ 🇱🇰 Sinhala Support
❷ 🇬🇧 English Support

━━━━━━━━━━━━━━━

🤖 *${BOT_NAME} SYSTEM*

➤ WhatsApp Multi Device Bot
➤ Fast & Stable Connection
➤ Auto AI Features
➤ Downloader System
➤ Security Protection
➤ Web Settings Panel

━━━━━━━━━━━━━━━

🌐 Official Website
https://sulaofc.store

📢 Official Channel
https://whatsapp.com/channel/0029Vb79RGG3WHTRUxAwqX2v

💬 Support Group
https://chat.whatsapp.com/JoOoFt3SkhN80ITMDjKm80

━━━━━━━━━━━━━━━

💌 Reply With Number

${BOT_FOOTER}
`;

            const sent = await conn.sendMessage(from, {
                image: { url: IMAGE },
                caption
            }, { quoted: mek });

            const listener = async (msgUpdate) => {

                try {

                    const msg = msgUpdate.messages[0];

                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message.extendedTextMessage?.contextInfo?.stanzaId === sent.key.id;

                    if (!isReply) return;

                    // ================= SINHALA =================

                    if (text === '1') {

                        conn.ev.off('messages.upsert', listener);

                        const siCaption = `
👋 ${BOT_NAME} Help Center වෙත සාදරයෙන් පිළිගනිමු! 💬

✦✦✦ ${BOT_NAME} HELP CENTER ✦✦✦

✦━━━━━━━━━━━━━━━✦

❶ ❓ සාමාන්‍ය උපකාරය
❷ ⚙️ Settings Guide
❸ 📋 නිති පැන
❹ 🤖 Bot Features
❺ 🌐 Website & Panels
❻ 📞 Contact & Support
❼ 📜 Commands List
❽ 🛡️ Security Features

✦━━━━━━━━━━━━━━━✦

💌 Reply With Number

${BOT_FOOTER}
`;

                        const siMsg = await conn.sendMessage(from, {
                            image: { url: IMAGE },
                            caption: siCaption
                        }, { quoted: msg });

                        const siListener = async (up) => {

                            try {

                                const m = up.messages[0];

                                if (!m.message) return;

                                const txt =
                                    m.message.conversation ||
                                    m.message.extendedTextMessage?.text;

                                const replied =
                                    m.message.extendedTextMessage?.contextInfo?.stanzaId === siMsg.key.id;

                                if (!replied) return;

                                conn.ev.off('messages.upsert', siListener);

                                // ================= GENERAL HELP =================

                                if (txt === '1') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
❓ සාමාන්‍ය උපකාරය

⮞⮞⮞ [ සාමාන්‍ය උපකාරය ] ⮜⮜⮜

➤ Commands භාවිතා කරන්න . එකෙන්.

උදා:
.menu

➤ සියලු Commands බලන්න:
.menu

➤ Owner Contact:
.owner

➤ Bot Settings වෙනස් කරන්න:
.setting

━━━━━━━━━━━━━━━

🌐 WEB SETTINGS PANEL

➤ .setting command එකෙන් Password එක copy කරන්න

➤ Website එකට යන්න:
https://sulaofc.store/bot-settings

➤ Bot Number එකයි Password එකයි දාලා Login වෙන්න

➤ Settings Save කරාම Auto Apply වෙනවා ❤️

━━━━━━━━━━━━━━━

⚙️ Change කරන්න පුලුවන් Settings

✅ Auto AI
✅ Auto Reply
✅ Auto React
✅ Auto Voice
✅ Auto Typing
✅ Auto Recording
✅ Anti Delete
✅ Anti Link
✅ Anti Call
✅ Anti Tag
✅ Anti Command
✅ Status Seen
✅ Status React
✅ Public / Private Mode
✅ Always Offline Mode
✅ React Emojis
✅ Status Emojis

━━━━━━━━━━━━━━━

📢 Official Channel
https://whatsapp.com/channel/0029Vb79RGG3WHTRUxAwqX2v

💬 Support Group
https://chat.whatsapp.com/JoOoFt3SkhN80ITMDjKm80

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                // ================= SETTINGS =================

                                } else if (txt === '2') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
⚙️ Settings Guide

⮞⮞⮞ [ SETTINGS SYSTEM ] ⮜⮜⮜

➤ .setting command එක භාවිතා කරන්න

➤ Password එක Copy කරන්න

➤ Login Here:
https://sulaofc.store/bot-settings

━━━━━━━━━━━━━━━

⚙️ Change කරන්න පුලුවන් Settings

✅ Auto AI
✅ Auto Reply
✅ Auto React
✅ Auto Voice
✅ Auto Typing
✅ Auto Recording
✅ Anti Delete
✅ Anti Link
✅ Anti Call
✅ Anti Tag
✅ Anti Command
✅ Status Seen
✅ Status React
✅ Public / Private Mode
✅ Always Offline Mode

━━━━━━━━━━━━━━━

💡 Save කරාම Settings Auto Update වෙනවා ❤️

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                // ================= FAQ =================

                                } else if (txt === '3') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
📋 නිති පැන

⮞⮞⮞ [ ${BOT_NAME} FAQ ] ⮜⮜⮜

❓ ${BOT_NAME} යනු?
WhatsApp Multi Device Bot System එකක්.

❓ Free ද?
ඔව් ❤️ 100% Free.

❓ Connect කරන්නේ කොහොමද?
Website එකෙන් Pair Code ගන්න.

❓ Settings වෙනස් කරන්නේ?
.setting command එක භාවිතා කරන්න.

❓ Login කරන්නේ?
.setting Password එකෙන් Login වෙන්න.

🌐 https://sulaofc.store/bot-settings

❓ Error report කරන්නේ?
.owner command එක භාවිතා කරන්න.

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                // ================= FEATURES =================

                                } else if (txt === '4') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
🤖 Bot Features

⮞⮞⮞ [ ${BOT_NAME} FEATURES ] ⮜⮜⮜

✅ Auto AI Chat
✅ Auto Reply
✅ Auto React
✅ Auto Voice
✅ Auto Typing
✅ Auto Recording
✅ Anti Delete
✅ Anti Link
✅ Anti Call
✅ Group Management
✅ Downloader Commands
✅ Search Commands
✅ Web Settings Panel

━━━━━━━━━━━━━━━

📥 Downloaders

🎬 TikTok
📘 Facebook
📸 Instagram
🎵 YouTube Song
📹 YouTube Video

━━━━━━━━━━━━━━━

💡 Fast • Stable • Powerful ❤️

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                // ================= WEBSITE =================

                                } else if (txt === '5') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
🌐 Website & Panels

⮞⮞⮞ [ WEB SYSTEM ] ⮜⮜⮜

🌍 Official Website
https://sulaofc.store

⚙️ Bot Settings Panel
https://sulaofc.store/bot-settings

📢 WhatsApp Channel
https://whatsapp.com/channel/0029Vb79RGG3WHTRUxAwqX2v

💬 Support Group
https://chat.whatsapp.com/JoOoFt3SkhN80ITMDjKm80

━━━━━━━━━━━━━━━

💡 Website එකෙන්:

✅ Pair Bot
✅ Login Bot
✅ Manage Settings
✅ Change Features

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                // ================= CONTACT =================

                                } else if (txt === '6') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
📞 අප හා සම්බන්ධ වන්න

⮞⮞⮞ [ CONTACT PANEL ] ⮜⮜⮜

📱 WhatsApp
+94 70 326 6859

✉️ Email
support@sulaofc.store

🌐 Facebook
https://www.facebook.com/profile.php?id=61580784301118

💼 Linkedin
https://www.linkedin.com/in/sulaksha-madara

💬 WhatsApp Group
https://chat.whatsapp.com/JoOoFt3SkhN80ITMDjKm80

📢 WhatsApp Channel
https://whatsapp.com/channel/0029Vb79RGG3WHTRUxAwqX2v

🌍 Official Website
https://sulaofc.store

━━━━━━━━━━━━━━━

❤️ Thanks For Using ${BOT_NAME}

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                // ================= MENU =================

                                } else if (txt === '7') {

                                    await conn.sendMessage(from, {
                                        text: '.menu'
                                    }, { quoted: m });

                                // ================= SECURITY =================

                                } else if (txt === '8') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
🛡️ Security Features

⮞⮞⮞ [ SECURITY SYSTEM ] ⮜⮜⮜

✅ Anti Delete
✅ Anti Link
✅ Anti Call
✅ Anti Tag
✅ Anti Command

━━━━━━━━━━━━━━━

⚙️ Manage Security Settings

Use:
.setting

Then Login Here:
https://sulaofc.store/bot-settings

━━━━━━━━━━━━━━━

💡 Keep Your Groups Safe ❤️

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                }

                            } catch (err) {

                                conn.ev.off('messages.upsert', siListener);

                            }
                        };

                        conn.ev.on('messages.upsert', siListener);

                    }

                    // ================= ENGLISH =================

                    else if (text === '2') {

                        conn.ev.off('messages.upsert', listener);

                        const enCaption = `
👋 Welcome to the ${BOT_NAME} Help Center! 💬

✦✦✦ ${BOT_NAME} HELP CENTER ✦✦✦

✦━━━━━━━━━━━━━━━✦

❶ ❓ General Help
❷ ⚙️ Settings Guide
❸ 📋 FAQ
❹ 🤖 Bot Features
❺ 🌐 Website & Panels
❻ 📞 Contact & Support
❼ 📜 Commands List
❽ 🛡️ Security Features

✦━━━━━━━━━━━━━━━✦

💌 Reply With Number

${BOT_FOOTER}
`;

                        const enMsg = await conn.sendMessage(from, {
                            image: { url: IMAGE },
                            caption: enCaption
                        }, { quoted: msg });

                        const enListener = async (up) => {

                            try {

                                const m = up.messages[0];

                                if (!m.message) return;

                                const txt =
                                    m.message.conversation ||
                                    m.message.extendedTextMessage?.text;

                                const replied =
                                    m.message.extendedTextMessage?.contextInfo?.stanzaId === enMsg.key.id;

                                if (!replied) return;

                                conn.ev.off('messages.upsert', enListener);

                                // ================= GENERAL HELP =================

                                if (txt === '1') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
❓ General Help

⮞⮞⮞ [ General Help ] ⮜⮜⮜

➤ Start commands using .

Example:
.menu

➤ View all commands:
.menu

➤ Contact owner:
.owner

➤ Change settings:
.setting

━━━━━━━━━━━━━━━

🌐 WEB SETTINGS PANEL

➤ Copy password from .setting

➤ Login Here:
https://sulaofc.store/bot-settings

━━━━━━━━━━━━━━━

⚙️ Settings You Can Control

✅ Auto AI
✅ Auto Reply
✅ Auto React
✅ Auto Voice
✅ Auto Typing
✅ Auto Recording
✅ Anti Delete
✅ Anti Link
✅ Anti Call
✅ Anti Tag
✅ Anti Command
✅ Status Seen
✅ Status React
✅ Public / Private Mode
✅ Always Offline Mode

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                // ================= SETTINGS =================

                                } else if (txt === '2') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
⚙️ Settings Guide

⮞⮞⮞ [ SETTINGS SYSTEM ] ⮜⮜⮜

➤ Use:
.setting

➤ Copy your password

➤ Login Here:
https://sulaofc.store/bot-settings

━━━━━━━━━━━━━━━

⚙️ Available Settings

✅ Auto AI
✅ Auto Reply
✅ Auto React
✅ Auto Voice
✅ Auto Typing
✅ Auto Recording
✅ Anti Delete
✅ Anti Link
✅ Anti Call
✅ Anti Tag
✅ Anti Command
✅ Status Seen
✅ Status React
✅ Public / Private Mode
✅ Always Offline Mode

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                // ================= FAQ =================

                                } else if (txt === '3') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
📋 FAQ

⮞⮞⮞ [ ${BOT_NAME} FAQ ] ⮜⮜⮜

❓ What is ${BOT_NAME}?
WhatsApp Multi Device Bot System.

❓ Is it free?
Yes ❤️ 100% Free.

❓ How to connect?
Get Pair Code from the website.

❓ How to change settings?
Use the .setting command.

❓ How to login?
Use password from .setting.

🌐 https://sulaofc.store/bot-settings

❓ How to report errors?
Use .owner command.

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                // ================= FEATURES =================

                                } else if (txt === '4') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
🤖 Bot Features

⮞⮞⮞ [ ${BOT_NAME} FEATURES ] ⮜⮜⮜

✅ Auto AI Chat
✅ Auto Reply
✅ Auto React
✅ Auto Voice
✅ Auto Typing
✅ Auto Recording
✅ Anti Delete
✅ Anti Link
✅ Anti Call
✅ Group Management
✅ Downloader Commands
✅ Search Commands
✅ Web Settings Panel

━━━━━━━━━━━━━━━

📥 Downloaders

🎬 TikTok
📘 Facebook
📸 Instagram
🎵 YouTube Song
📹 YouTube Video

━━━━━━━━━━━━━━━

💡 Fast • Stable • Powerful ❤️

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                // ================= WEBSITE =================

                                } else if (txt === '5') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
🌐 Website & Panels

⮞⮞⮞ [ WEB SYSTEM ] ⮜⮜⮜

🌍 Official Website
https://sulaofc.store

⚙️ Bot Settings Panel
https://sulaofc.store/bot-settings

📢 WhatsApp Channel
https://whatsapp.com/channel/0029Vb79RGG3WHTRUxAwqX2v

💬 Support Group
https://chat.whatsapp.com/JoOoFt3SkhN80ITMDjKm80

━━━━━━━━━━━━━━━

💡 Website Features

✅ Pair Bot
✅ Login Bot
✅ Manage Settings
✅ Change Features

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                // ================= CONTACT =================

                                } else if (txt === '6') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
📞 Contact Us

⮞⮞⮞ [ CONTACT PANEL ] ⮜⮜⮜

📱 WhatsApp
+94 70 326 6859

✉️ Email
support@sulaofc.store

🌐 Facebook
https://www.facebook.com/profile.php?id=61580784301118

💼 Linkedin
https://www.linkedin.com/in/sulaksha-madara

💬 WhatsApp Group
https://chat.whatsapp.com/JoOoFt3SkhN80ITMDjKm80

📢 WhatsApp Channel
https://whatsapp.com/channel/0029Vb79RGG3WHTRUxAwqX2v

🌍 Official Website
https://sulaofc.store

━━━━━━━━━━━━━━━

❤️ Thanks For Using ${BOT_NAME}

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                // ================= MENU =================

                                } else if (txt === '7') {

                                    await conn.sendMessage(from, {
                                        text: '.menu'
                                    }, { quoted: m });

                                // ================= SECURITY =================

                                } else if (txt === '8') {

                                    await conn.sendMessage(from, {
                                        image: { url: IMAGE },
                                        caption: `
🛡️ Security Features

⮞⮞⮞ [ SECURITY SYSTEM ] ⮜⮜⮜

✅ Anti Delete
✅ Anti Link
✅ Anti Call
✅ Anti Tag
✅ Anti Command

━━━━━━━━━━━━━━━

⚙️ Manage Security Settings

Use:
.setting

Then Login Here:
https://sulaofc.store/bot-settings

━━━━━━━━━━━━━━━

💡 Keep Your Groups Safe ❤️

${BOT_FOOTER}
`
                                    }, { quoted: m });

                                }

                            } catch (err) {

                                conn.ev.off('messages.upsert', enListener);

                            }
                        };

                        conn.ev.on('messages.upsert', enListener);

                    }

                } catch (err) {

                    conn.ev.off('messages.upsert', listener);

                }
            };

            conn.ev.on('messages.upsert', listener);

        } catch (err) {

            await conn.sendMessage(from, {
                text: `❌ Helpcenter Error!\n\n${err.message}`
            }, { quoted: mek });
        }
    }
};
