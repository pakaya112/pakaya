module.exports = {
    name: "groupinfo",

    run: async ({ conn, mek, from, isGroup }) => {

        try {

            if (!isGroup) {
                return conn.sendMessage(from, {
                    text: "❌ Group only!"
                }, { quoted: mek });
            }

            const metadata = await conn.groupMetadata(from);

            const name = metadata.subject;
            const id = metadata.id;
            const owner = metadata.owner || "Unknown";
            const desc = metadata.desc || "No description";
            const participants = metadata.participants.length;

            await conn.sendMessage(from, {
                text: `
         📊 *GROUP INFO*

📛 Name: ${name}
🆔 ID: ${id}
👥 Members: ${participants}

📝 Description:
${desc}`
            }, { quoted: mek });

        } catch (err) {
           // console.error(err);

            await conn.sendMessage(from, {
                text: "❌ Failed to get group info"
            }, { quoted: mek });
        }
    }
};
