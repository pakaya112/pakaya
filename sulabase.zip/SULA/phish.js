const axios = require("axios");
const { ReadData } = require("../database");

module.exports = {
  name: "phish",
  alias: ["phishing", "urlcheck", "linkcheck"],

  run: async ({ conn, mek, from, args, q }) => {
    const input = args?.length ? args.join(" ") : q;

    if (!input || !input.startsWith("http")) {
      return conn.sendMessage(from, {
        text: `╭─❌ *PHISHING CHECK*
│
│ Please provide a valid URL.
│
│ Example:
│ .phish https://example.com
╰───────────────`
      }, { quoted: mek });
    }

    await conn.sendMessage(from, {
      react: { text: "🔎", key: mek.key }
    });

    try {
      const number = conn.user.id.split(":")[0];
      const botname = await ReadData(number, "BOT_NAME");
      const botfooter = await ReadData(number, "BOT_FOOTER");

      const url = new URL(input);
      const host = url.hostname.replace("www.", "").toLowerCase();

      let score = 0;
      let reasons = [];

      const trustedDomains = [
        "google.com", "youtube.com", "facebook.com", "instagram.com",
        "whatsapp.com", "microsoft.com", "apple.com", "paypal.com",
        "github.com", "netlify.app", "vercel.app"
      ];

      const shortLinks = [
        "bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd",
        "cutt.ly", "shorturl.at", "rebrand.ly"
      ];

      const fakeBrandWords = [
        "paypal", "google", "facebook", "instagram", "whatsapp",
        "microsoft", "apple", "bank", "login", "verify",
        "secure", "account", "wallet", "gift", "free"
      ];

      if (trustedDomains.includes(host)) {
        score -= 20;
        reasons.push("Trusted domain detected");
      }

      if (shortLinks.includes(host)) {
        score += 30;
        reasons.push("Shortened URL detected");
      }

      if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) {
        score += 40;
        reasons.push("URL uses IP address instead of domain");
      }

      if (host.split(".").length > 3) {
        score += 15;
        reasons.push("Too many subdomains");
      }

      if (host.includes("-")) {
        score += 10;
        reasons.push("Hyphen found in domain");
      }

      if (input.length > 120) {
        score += 15;
        reasons.push("Very long URL");
      }

      if (url.protocol !== "https:") {
        score += 20;
        reasons.push("Not using HTTPS");
      }

      fakeBrandWords.forEach(word => {
        if (host.includes(word) && !trustedDomains.includes(host)) {
          score += 10;
          reasons.push(`Brand/sensitive word in domain: ${word}`);
        }
      });

      if (/%|@|=|redirect|login|verify|token|session|auth/i.test(input)) {
        score += 15;
        reasons.push("Suspicious URL parameters or keywords");
      }

      let websiteStatus = "Unknown";
      try {
        const res = await axios.get(input, {
          timeout: 8000,
          maxRedirects: 3,
          validateStatus: () => true,
          headers: {
            "User-Agent": "Mozilla/5.0 ThenuxBot Security Checker"
          }
        });

        websiteStatus = `Online / HTTP ${res.status}`;

        if (res.request?.res?.responseUrl && res.request.res.responseUrl !== input) {
          score += 10;
          reasons.push("URL redirects to another page");
        }

      } catch {
        websiteStatus = "Not reachable or blocked";
        score += 10;
        reasons.push("Website not reachable or blocked");
      }

      if (score < 0) score = 0;
      if (score > 100) score = 100;

      let result = "✅ SAFE / LOW RISK";
      let emoji = "✅";

      if (score >= 70) {
        result = "❌ HIGH RISK PHISHING";
        emoji = "🚨";
      } else if (score >= 40) {
        result = "⚠️ SUSPICIOUS LINK";
        emoji = "⚠️";
      } else if (score >= 20) {
        result = "🟡 MEDIUM RISK";
        emoji = "🟡";
      }

      const reply = `
╭━━━━━〔 *PHISHING LINK CHECKER* 〕━━━━━⬣
┃
┃ ${emoji} *Result:* ${result}
┃ 📊 *Risk Score:* ${score}/100
┃ 🌐 *Domain:* ${host}
┃ 🔐 *Protocol:* ${url.protocol}
┃ 📡 *Status:* ${websiteStatus}
┃ 🤖 *Bot:* ${botname}
┃
┣━━━━━━━━━━━━━━━━━━━━⬣
┃ *Checked URL:*
┃ ${input}
┃
┣━━━━━━━━━━━━━━━━━━━━⬣
┃ *Detected Reasons:*
${reasons.length ? reasons.slice(0, 10).map(r => `┃ ➤ ${r}`).join("\n") : "┃ ➤ No strong phishing signs detected"}
┃
┣━━━━━━━━━━━━━━━━━━━━⬣
┃ *Advice:*
┃ Do not enter passwords, OTPs,
┃ card details, or bank info unless
┃ you trust the website 100%.
╰━━━━━━━━━━━━━━━━━━━━⬣

${botfooter}`;

      await conn.sendMessage(from, {
        text: reply
      }, { quoted: mek });

      await conn.sendMessage(from, {
        react: { text: "✅", key: mek.key }
      });

    } catch (err) {
      await conn.sendMessage(from, {
        text: `╭─❌ *PHISH CHECK ERROR*
│
│ ${err.message}
╰───────────────`
      }, { quoted: mek });
    }
  }
};
