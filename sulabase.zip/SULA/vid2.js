const axios = require('axios');

module.exports = {
    name: 'vid2',
    alias: ['text2video', 't2v', 'genvid'],
    category: 'ai',
    description: 'Generate video with Aspect Ratio and AI Sound selection',

    run: async ({ conn, client, mek, from, q }) => {
        const botClient = conn || client;
        const botfooter = '> Thenux • www.thenuxofc.store';

        try {
            let prompt = q ? q.trim() : '';
            let ratio = 'auto';
            let sound = 'false';
            let readyToGenerate = false;

            // 1. Get quoted message (to check if user is replying to our settings menu)
            const quotedMsg = mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const quotedText = quotedMsg?.conversation || quotedMsg?.extendedTextMessage?.text || '';

            // 2. CHECK: Is the user replying to the Bot's configuration menu?
            if (quotedText.includes('⚙️ *Video Settings Required*')) {
                // Extract the original prompt from the bot's previous message
                const promptMatch = quotedText.match(/You requested: _(.*)_/);
                if (promptMatch && promptMatch[1]) {
                    prompt = promptMatch[1];
                    readyToGenerate = true;
                    
                    // The user replied with their settings (e.g., "16:9 | yes")
                    const parts = q.split('|').map(s => s.trim().toLowerCase());
                    ratio = parts[0] || 'auto';
                    
                    // Parse sound setting
                    const soundInput = parts[1] || 'no';
                    sound = (soundInput === 'yes' || soundInput === 'true') ? 'true' : 'false';
                }
            } 
            // 3. CHECK: Did the user provide everything in one line? (e.g., .vid2 dog | 1:1 | yes)
            else if (q.includes('|')) {
                const parts = q.split('|').map(s => s.trim());
                prompt = parts[0];
                ratio = parts[1]?.toLowerCase() || 'auto';
                
                const soundInput = (parts[2] || '').toLowerCase();
                sound = (soundInput === 'yes' || soundInput === 'true') ? 'true' : 'false';
                readyToGenerate = true;
            }

            // 4. If there's NO prompt at all, ask for one.
            if (!prompt) {
                return botClient.sendMessage(from, {
                    text: `❌ *Missing Prompt*\n\nPlease describe what you want to create.\n\n*Example:* \`.vid2 a cat walking on the beach at sunset\`\n\n${botfooter}`
                }, { quoted: mek });
            }

            // 5. INTERACTIVE MENU: If prompt exists but settings aren't chosen yet, ask the user!
            if (!readyToGenerate) {
                const menuText = `⚙️ *Video Settings Required*\n\nYou requested: _${prompt}_\n\nPlease *reply to this message* to configure your video.\n\n*Format to reply:*\n\`.vid2 <ratio> | <sound>\`\n\n*Options:*\n📐 *Ratio:* auto, 1:1, 16:9, 9:16\n🔊 *Sound:* yes, no\n\n*Example reply:*\n\`.vid2 16:9 | yes\`\n\n${botfooter}`;
                
                return botClient.sendMessage(from, { text: menuText }, { quoted: mek });
            }

            // ============================================================
            // 6. GENERATION PHASE (Settings are confirmed)
            // ============================================================
            
            // Validate ratio to prevent API errors
            const validRatios = ['auto', '1:1', '16:9', '9:16'];
            if (!validRatios.includes(ratio)) ratio = 'auto';

            await botClient.sendMessage(from, { react: { text: '🎬', key: mek.key } });
            
            const waitMsg = await botClient.sendMessage(from, { 
                text: `🎬 *Rendering Video...*\n\n📌 *Prompt:* _${prompt}_\n📐 *Ratio:* ${ratio}\n🔊 *Sound:* ${sound === 'true' ? 'Yes' : 'No'}\n\n⏳ _Please wait, this can take 1-2 minutes..._\n\n${botfooter}` 
            }, { quoted: mek });

            // Build API URL with the user's chosen settings
            const apiUrl = `https://apis.davidcyriltech.my.id/ai/txt2vid?prompt=${encodeURIComponent(prompt)}&aspect_ratio=${encodeURIComponent(ratio)}&ai_sound=${sound}`;
            
            // 2-minute timeout since video generation takes a while
            const response = await axios.get(apiUrl, { timeout: 120000 }); 

            // Parse response and send video
            if (response.data && response.data.success && response.data.result?.url) {
                const videoUrl = response.data.result.url;

                await botClient.sendMessage(from, {
                    video: { url: videoUrl },
                    mimetype: 'video/mp4',
                    caption: `🎬 *AI Video Generated*\n\n📌 *Prompt:* _${response.data.result.prompt || prompt}_\n📐 *Ratio:* ${response.data.result.aspect_ratio || ratio}\n🔊 *Sound:* ${response.data.result.ai_sound ? 'Yes' : 'No'}\n\n${botfooter}`
                }, { quoted: mek });

                await botClient.sendMessage(from, { delete: waitMsg.key }).catch(() => {});
                return await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });

            } else {
                throw new Error("The API did not return a valid video URL.");
            }

        } catch (err) {
            console.error("vid2 Command Error:", err);
            await botClient.sendMessage(from, { react: { text: '❌', key: mek.key } });
            
            let errorMessage = err.message;
            if (err.response?.data?.message) {
                errorMessage = err.response.data.message;
            } else if (err.code === 'ECONNABORTED') {
                errorMessage = "Request timed out. The AI server took too long to generate the video.";
            }

            return botClient.sendMessage(from, {
                text: `❌ *Generation Failed*\n\n${errorMessage}\n\n${botfooter}`
            }, { quoted: mek });
        }
    }
};
