module.exports = {
    name: "add",
    description: "Add a member to the group.",
    category: "group",

    run: async ({ conn, mek, from, args, isGroup, isAdmin, isBotAdmins }) => {
        try {
          
            if (!isGroup) {
                return conn.sendMessage(from, { text: "❌ This command can only be used in groups!" }, { quoted: mek });
            }
          
            if (!isBotAdmins) {
                return conn.sendMessage(from, { text: "❌ I need Admin privileges to add users!" }, { quoted: mek });
            }

            if (!isAdmin) {
                return conn.sendMessage(from, { text: "❌ Only group admins can use this command!" }, { quoted: mek });
            }

            if (!args[0]) {
                return conn.sendMessage(from, { text: "⚠️ Please provide a phone number with country code!\n\nExample: .add 947xxxxxxxx" }, { quoted: mek });
            }

            const phoneNumber = args[0].replace(/[^0-9]/g, '');
            const userJid = phoneNumber + "@s.whatsapp.net";

            const response = await conn.groupParticipantsUpdate(from, [userJid], "add");

            if (response[0]?.status === 200) {
                return conn.sendMessage(from, { text: "✅ User added successfully!" }, { quoted: mek });
            } 
            else if (response[0]?.status === 403) {
                
                const inviteCode = await conn.groupInviteCode(from);
                return conn.sendMessage(from, { 
                    text: `❌ Could not add user due to their Privacy Settings.\n\n🔗 I have sent an invite link to the group instead:\nhttps://chat.whatsapp.com/${inviteCode}` 
                }, { quoted: mek });
            } 
            else {
                return conn.sendMessage(from, { text: "❌ Failed to add user. They might have left recently or provided an invalid number." }, { quoted: mek });
            }

        } catch (err) {
            // console.error("ADD COMMAND ERROR:", err);
            await conn.sendMessage(from, { text: "❌ An error occurred while trying to add the user." }, { quoted: mek });
        }
    }
};
