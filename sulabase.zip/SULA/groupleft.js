module.exports = {
    name: 'leave',
    alias: ['leavegroup'],

    run: async ({
        conn,
        mek,
        from,
        isGroup
    }) => {

        try {

            // ✅ OWNER ONLY
            const ownerNumber = conn.user.id.split(':')[0];

            const senderNumber =
                (mek.key.participant || mek.key.remoteJid)
                .split('@')[0];

            if (senderNumber !== ownerNumber && !mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: "❌ Owner only command!"
                }, { quoted: mek });
            }

            // ✅ GROUP ONLY
            if (!isGroup) {
                return conn.sendMessage(from, {
                    text: '❌ This command only works in groups!'
                }, { quoted: mek });
            }

            await conn.sendMessage(from, {
                text: '👋 Bye Everyone... Leaving Group!'
            }, { quoted: mek });

            setTimeout(async () => {
                await conn.groupLeave(from);
            }, 2000);

        } catch (err) {

            await conn.sendMessage(from, {
                text: `❌ Error:\n${err.message}`
            }, { quoted: mek });
        }
    }
};
