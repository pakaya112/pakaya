const axios = require("axios");
const { ReadData } = require('../database');

module.exports = {
    name: "xnxx",
    alias: ["xvideo", "xv", "xn"],
    category: "nsfw",
    description: "Search and download XNXX/XVideo content.",
    run: async ({ conn, mek, from, q }) => {
        try {

            if (!q.trim()) {
                return conn.sendMessage(from, {
                    text: '🩷 *Hey baby~*\n\n✨ Send *title / keyword / link* 💕'
                }, { quoted: mek });
            }

    
            await conn.sendMessage(from, {
                react: { text: "🔍", key: mek.key }
            });

            let videoUrl = q;

            // 🔍 SEARCH IF NOT A DIRECT LINK
            if (!q.includes('xnxx.com') && !q.includes('xvideos.com')) {
                const search = await axios.get(
                    `https://apis.prexzyvilla.site/nsfw/xnxx-search?query=${encodeURIComponent(q)}`
                ).then(r => r.data).catch(() => null);

                if (!search?.status || !search.videos?.length) {
                    return conn.sendMessage(from, {
                        text: '🥺 *No results found baby* 💔'
                    }, { quoted: mek });
                }

                videoUrl = search.videos[0].link;
            }

            const data = await axios.get(
                `https://apis.prexzyvilla.site/nsfw/xnxx-dl?url=${encodeURIComponent(videoUrl)}`
            ).then(r => r.data).catch(() => null);

            if (!data?.status) {
                return conn.sendMessage(from, {
                    text: '💔 *Failed to fetch video info baby*'
                }, { quoted: mek });
            }

            const high = data.files?.high;
            const low = data.files?.low;
            if (!high) throw new Error('No video file found');

            const Images = await ReadData(number, "SULA_IMAGE_PATH");
            const botname = await ReadData(number, "BOT_NAME");
            const botfooter = await ReadData(number, "BOT_FOOTER");

            const caption = `🩷 *XNXX DOWNLOADER* 🩷

╭─❥
│ 🎀 *Title* : ${data.title}
│ ⏱️ *Duration* : ${data.duration}
│ 🎞️ *Quality* : HD
╰────────♡

💗 *Reply with number baby~*
1️⃣ ║ Download Video 🎥
2️⃣ ║ Video Note 🎙️
3️⃣ ║ Document 📁

${botfooter}`;

        
            const sentMsg = await conn.sendMessage(from, {
                image: { url: data.image },
                caption: caption
            }, { quoted: mek });

            const messageID = sentMsg.key.id;

            const handler = async ({ messages }) => {
                const rmek = messages[0];
                if (!rmek?.message) return;

                const text = rmek.message.conversation || rmek.message.extendedTextMessage?.text;
                const contextInfo = rmek.message?.extendedTextMessage?.contextInfo;
                
                if (contextInfo?.stanzaId !== messageID) return;

                const choice = text?.trim();
                if (!['1', '2', '3'].includes(choice)) return;

                await conn.sendMessage(from, {
                    react: { text: '⬇️', key: rmek.key }
                });

                try {
                    if (choice === '1') {
                        await conn.sendMessage(from, {
                            video: { url: high },
                            mimetype: 'video/mp4',
                            caption: '🩷 Enjoy baby 🎥\n\nhttps://sulaofc.store'
                        }, { quoted: rmek });
                    }

                    if (choice === '2') {
                        await conn.sendMessage(from, {
                            video: { url: low || high },
                            mimetype: 'video/mp4',
                            ptv: true 
                        }, { quoted: rmek });
                    }

                    if (choice === '3') {
                        await conn.sendMessage(from, {
                            document: { url: high },
                            mimetype: 'video/mp4',
                            fileName: `${data.title}.mp4`,
                            caption: '🩷 Saved for you baby 📁\n\nhttps://sulaofc.store'
                        }, { quoted: rmek });
                    }

                    conn.ev.off('messages.upsert', handler);

                } catch (err) {
                  //  console.error("DL ERROR:", err);
                    conn.sendMessage(from, { text: '❌ *Download failed baby*' }, { quoted: rmek });
                    conn.ev.off('messages.upsert', handler);
                }
            };

            conn.ev.on('messages.upsert', handler);

            setTimeout(() => {
                conn.ev.off('messages.upsert', handler);
            }, 120000);

        } catch (e) {
           // console.error("XNXX ERROR:", e.message);
            conn.sendMessage(from, {
                text: '❌ *Something went wrong baby*'
            }, { quoted: mek });
        }
    }
};
