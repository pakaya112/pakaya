const axios = require('axios');

module.exports = {
    name: 'gpt4',
    alias: ['ai4', 'chatgpt4'],
    run: async ({ conn, mek, from, q }) => {

        if (!q) {
            return conn.sendMessage(from, {
                text: `╭─❌ *GPT-4*
│
│ Please ask something.
│
│ Example:
│ .gpt4 Hello
╰───────────────`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '🤖', key: mek.key }
        });

        try {
            const apiUrl = `https://thenuxai-gpt.vercel.app/api/gpt?q=${encodeURIComponent(q)}&model=gpt4`;
            const { data } = await axios.get(apiUrl);

            if (!data?.response) throw new Error('No response from GPT-4');

            const reply = `
╭━━━━━〔 *GPT-4 AI* 〕━━━━━⬣
┃
┃ 🧠 *Model:* ${data.model || 'GPT4'}
┃ 👑 *Owner:* ${data.owner || '@thenux-ai'}
┃
┣━━━━━━━━━━━━━━━━━━━━⬣
┃ 💬 *Question:*
┃ ${q}
┃
┣━━━━━━━━━━━━━━━━━━━━⬣
┃ 🤖 *Answer:*
┃ ${data.response}
╰━━━━━━━━━━━━━━━━━━━━⬣
`;

            await conn.sendMessage(from, {
                text: reply
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '✅', key: mek.key }
            });

        } catch (err) {
            await conn.sendMessage(from, {
                text: `╭─❌ *GPT-4 ERROR*
│
│ ${err.message}
╰───────────────`
            }, { quoted: mek });
        }
    }
};
