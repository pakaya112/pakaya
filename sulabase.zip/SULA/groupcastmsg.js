const { ReadData } = require('../database');

module.exports = {
    name: 'groupcast',
    alias: ['gcast', 'gcall'],

    run: async ({ conn, mek, from, q }) => {

        try {

            // ✅ OWNER ONLY
            const ownerNumber = conn.user.id.split(':')[0];

            const senderNumber =
                (mek.key.participant || mek.key.remoteJid)
                .split('@')[0];

            if (senderNumber !== ownerNumber && !mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: "❌ Owner only command!"
                }, { quoted: mek });
            }

            // ✅ CHECK MESSAGE
            if (!q) {
                return conn.sendMessage(from, {
                    text:
`❌ Please provide a message!

Example:
.groupcast Hello Everyone`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, {
                react: {
                    text: '📢',
                    key: mek.key
                }
            });

            const number = conn.user.id.split(':')[0];

            const BOT_NAME =
                await ReadData(number, "BOT_NAME");

            const BOT_FOOTER =
                await ReadData(number, "BOT_FOOTER");

            // ✅ FETCH GROUPS
            const groups = await conn.groupFetchAllParticipating();

            const groupIds = Object.keys(groups);

            if (!groupIds.length) {
                return conn.sendMessage(from, {
                    text: `❌ No groups found!`
                }, { quoted: mek });
            }

            let success = 0;
            let failed = 0;

            // ✅ MESSAGE
            const caption = `
📢 *GROUP BROADCAST*

${q}

───────────────

🤖 ${BOT_NAME}

${BOT_FOOTER}
`;

            // ✅ SEND TO ALL GROUPS
            for (const jid of groupIds) {

                try {

                    await conn.sendMessage(jid, {
                        text: caption
                    });

                    success++;

                    await new Promise(resolve =>
                        setTimeout(resolve, 1500)
                    );

                } catch (err) {

                    failed++;
                }
            }

            // ✅ DONE REACTION
            await conn.sendMessage(from, {
                react: {
                    text: '✅',
                    key: mek.key
                }
            });

            // ✅ RESULT
            return conn.sendMessage(from, {
                text:
`✅ *GROUP BROADCAST COMPLETED*

📤 Success : ${success}
❌ Failed : ${failed}
👥 Total Groups : ${groupIds.length}

${BOT_FOOTER}`
            }, { quoted: mek });

        } catch (err) {

            console.log("GROUPCAST ERROR:", err);

            return conn.sendMessage(from, {
                text:
`❌ Group Broadcast Error!

${err.message}`
            }, { quoted: mek });
        }
    }
};
