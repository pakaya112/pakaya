const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('ffmpeg-static');
const { ReadData } = require('../database');

ffmpeg.setFfmpegPath(ffmpegPath);

module.exports = {
    name: 'ytv',
    alias: ['ytmp4', 'ytvideo', 'video'],
    run: async ({ conn, mek, from, q }) => {

        if (!q || !q.startsWith('http')) {
            return conn.sendMessage(from, {
                text: `╭─❌ *INVALID YOUTUBE URL*
│
│ Example:
│ .ytmp4 https://youtu.be/xxxx
╰───────────────`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '⏳', key: mek.key }
        });

        const number = conn.user.id.split(':')[0];
        const botname = await ReadData(number, 'BOT_NAME') || 'THENUX BOT';
        const botfooter = await ReadData(number, 'BOT_FOOTER') || '© THENUX';

        let filePath;
        let fixedPath;

        const downloadFile = async (url, output) => {
            const res = await axios({
                method: 'GET',
                url,
                responseType: 'stream',
                timeout: 300000,
                maxRedirects: 10,
                headers: {
                    'User-Agent': 'Mozilla/5.0',
                    'Accept': '*/*'
                }
            });

            await new Promise((resolve, reject) => {
                const writer = fs.createWriteStream(output);
                res.data.pipe(writer);
                writer.on('finish', resolve);
                writer.on('error', reject);
            });
        };

        const fixMp4 = (input, output) => {
            return new Promise((resolve, reject) => {
                ffmpeg(input)
                    .outputOptions([
                        '-c copy',
                        '-movflags +faststart'
                    ])
                    .save(output)
                    .on('end', resolve)
                    .on('error', reject);
            });
        };

        try {
            const metaApi = `https://ytmp4-api.netlify.app/api/ytmp4?url=${encodeURIComponent(q)}&quality=360p&meta=true`;

            const { data } = await axios.get(metaApi, {
                timeout: 180000,
                headers: { 'User-Agent': 'Mozilla/5.0' }
            });

            if (!data?.success) throw new Error(data?.error || 'API failed');

            const meta = data.metadata?.data || {};
            const title = meta.title || data.title || 'YouTube Video';
            const thumb = meta.thumbnail || '';
            const duration = meta.durationFormatted || 'N/A';
            const uploader = meta.uploader || 'Unknown';

            const caption = `
╭────♡◉◉◉♡────⌬
🎬 *YOUTUBE VIDEO READY!*  
🌸 *${botname} prepared your video ✨*
╰────♡◉◉◉♡────⌬

📌 *Title:*  
➤ ${title}

👤 *Uploader:* ${uploader}
⏱️ *Duration:* ${duration}

───────────────

📥 *Choose Quality:*

❶ 🚀 360P Fast
❷ 📱 480P SD
❸ 🎬 720P HD
❹ 💎 1080P Full HD

───────────────

💌 *Reply:* 1 / 2 / 3 / 4

${botfooter}
`;

            const sentMsg = await conn.sendMessage(from, {
                image: { url: thumb },
                caption
            }, { quoted: mek });

            let timeout;

            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];

                try {
                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                    if (!isReply) return;

                    let quality;

                    if (text === '1') quality = '360p';
                    else if (text === '2') quality = '480p';
                    else if (text === '3') quality = '720p';
                    else if (text === '4') quality = '1080p';
                    else {
                        return conn.sendMessage(from, {
                            text: '❌ Reply only with 1 / 2 / 3 / 4'
                        }, { quoted: msg });
                    }

                    clearTimeout(timeout);
                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        react: { text: '⬇️', key: msg.key }
                    });

                    await conn.sendMessage(from, {
                        text: `╭────♡◉◉◉♡────⌬
⬇️ *DOWNLOADING VIDEO...*
╰────♡◉◉◉♡────⌬

💎 *Quality:* ${quality}
🛠️ *Fixing video for WhatsApp...*

Please wait...`
                    }, { quoted: msg });

                    const directUrl = `https://ytmp4-api.netlify.app/api/ytmp4?url=${encodeURIComponent(q)}&quality=${quality}&direct=true`;

                    const cleanName = title
                        .replace(/[\\/:*?"<>|]/g, '')
                        .trim()
                        .slice(0, 60) || 'youtube_video';

                    filePath = path.join(os.tmpdir(), `${Date.now()}_${cleanName}.mp4`);
                    fixedPath = path.join(os.tmpdir(), `${Date.now()}_${cleanName}_fixed.mp4`);

                    await downloadFile(directUrl, filePath);

                    if (!fs.existsSync(filePath) || fs.statSync(filePath).size < 100000) {
                        throw new Error('Downloaded file is empty or invalid');
                    }

                    await fixMp4(filePath, fixedPath);

                    if (!fs.existsSync(fixedPath) || fs.statSync(fixedPath).size < 100000) {
                        throw new Error('Fixed MP4 invalid');
                    }

                    const videoCaption = `
╭────♡◉◉◉♡────⌬
✅ *DOWNLOAD COMPLETE*
🎬 *${botname} YTMP4*
╰────♡◉◉◉♡────⌬

📌 ${title}
💎 *Quality:* ${quality}

${botfooter}
`;

                    await conn.sendMessage(from, {
                        video: fs.readFileSync(fixedPath),
                        mimetype: 'video/mp4',
                        fileName: `${cleanName}.mp4`,
                        caption: videoCaption
                    }, { quoted: msg });

                    await conn.sendMessage(from, {
                        react: { text: '✅', key: msg.key }
                    });

                    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
                    if (fs.existsSync(fixedPath)) fs.unlinkSync(fixedPath);

                } catch (err) {
                    conn.ev.off('messages.upsert', listener);

                    if (filePath && fs.existsSync(filePath)) fs.unlinkSync(filePath);
                    if (fixedPath && fs.existsSync(fixedPath)) fs.unlinkSync(fixedPath);

                    await conn.sendMessage(from, {
                        text: `╭─❌ *DOWNLOAD ERROR*
│
│ *Reason:* ${err.message}
│
│ Try 360p fast option.
╰───────────────`
                    }, { quoted: msg });
                }
            };

            timeout = setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

            conn.ev.on('messages.upsert', listener);

        } catch (err) {
            if (filePath && fs.existsSync(filePath)) fs.unlinkSync(filePath);
            if (fixedPath && fs.existsSync(fixedPath)) fs.unlinkSync(fixedPath);

            await conn.sendMessage(from, {
                text: `╭─❌ *YTMP4 ERROR*
│
│ *Reason:* ${err.message}
╰───────────────`
            }, { quoted: mek });

            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });
        }
    }
};
