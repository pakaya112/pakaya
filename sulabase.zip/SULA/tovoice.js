module.exports = {
    name: 'tovoice',
    alias: ['opus', 'ptt'],

    run: async ({ conn, mek, from, q }) => {

        if (!q) {
            return conn.sendMessage(
                from,
                {
                    text: `❌ Need MP3 URL

Example:

.tovoice https://example.com/song.mp3`
                },
                { quoted: mek }
            );
        }

        try {

            await conn.sendMessage(
                from,
                {
                    react: {
                        text: '⏳',
                        key: mek.key
                    }
                }
            );

            const voiceUrl =
                `https://opus-converter-be4a9c2381cd.herokuapp.com/convert?url=${encodeURIComponent(q)}`;

            await conn.sendMessage(
                from,
                {
                    audio: {
                        url: voiceUrl
                    },
                    mimetype: 'audio/ogg; codecs=opus',
                    ptt: true
                },
                { quoted: mek }
            );

            await conn.sendMessage(
                from,
                {
                    react: {
                        text: '✅',
                        key: mek.key
                    }
                }
            );

        } catch (err) {

            console.log(err);

            await conn.sendMessage(
                from,
                {
                    text: `❌ Error

${err.message}`
                },
                { quoted: mek }
            );

        }

    }
};
