const axios = require('axios');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { ReadData, WriteData } = require('../database');

const API_KEY = 'tnx_live_63bc16c096f2e4652372789dea5247b9173776f442ea89d7';
const BASE_URL = 'https://thenux-kyrex-ai.scieovlogs12345.workers.dev';

// Helper: Read user chat ID
async function getUserChatId(userKey) {
    try {
        const dbId = await ReadData(userKey, 'AI2_CHAT_ID');
        if (dbId && typeof dbId === 'string' && dbId.trim() !== '') return dbId.trim();
    } catch (e) {}

    try {
        const filePath = path.join(process.cwd(), 'SETTINGS', 'ai2_sessions.json');
        if (fs.existsSync(filePath)) {
            const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
            if (data[userKey]) return data[userKey];
        }
    } catch (e) {}

    return null;
}

// Helper: Save user chat ID
async function saveUserChatId(userKey, chatId) {
    try {
        if (typeof WriteData === 'function') {
            await WriteData(userKey, 'AI2_CHAT_ID', chatId);
        }
    } catch (e) {}

    try {
        const folderPath = path.join(process.cwd(), 'SETTINGS');
        if (!fs.existsSync(folderPath)) fs.mkdirSync(folderPath, { recursive: true });
        const filePath = path.join(folderPath, 'ai2_sessions.json');
        let data = {};
        if (fs.existsSync(filePath)) {
            data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        }
        if (chatId) {
            data[userKey] = chatId;
        } else {
            delete data[userKey];
        }
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {}
}

// Helper: Ensure Chat Session exists
async function getOrCreateChatId(userKey, model = 'T-Nex 1.0') {
    let chatId = await getUserChatId(userKey);
    if (chatId) return chatId;

    try {
        const newChatRes = await axios.post(`${BASE_URL}/api/chats`, {
            title: `WhatsApp User ${userKey}`,
            model: model
        }, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`
            },
            timeout: 10000
        });

        if (newChatRes.data?.chat?.id) {
            chatId = newChatRes.data.chat.id;
            await saveUserChatId(userKey, chatId);
            return chatId;
        }
    } catch (e) {
        console.warn('[AI2] Failed to create cloud session, using local fallback ID:', e.message);
    }

    // Fallback deterministic session ID
    chatId = `session_wa_${userKey}_${Date.now().toString(36)}`;
    await saveUserChatId(userKey, chatId);
    return chatId;
}

// Helper: Send message to Session Stream and collect full response
async function streamSessionChat(chatId, message, model) {
    const res = await axios.post(`${BASE_URL}/api/chats/${chatId}/messages/stream`, {
        message: message,
        model: model
    }, {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${API_KEY}`
        },
        responseType: 'text',
        timeout: 120000
    });

    const rawData = res.data || '';
    const lines = rawData.split('\n');
    let fullText = '';

    for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data:')) continue;
        const jsonStr = trimmed.replace(/^data:\s*/, '');
        if (jsonStr === '[DONE]') break;

        try {
            const parsed = JSON.parse(jsonStr);
            if (parsed.response) {
                fullText += parsed.response;
            } else if (parsed.text) {
                fullText += parsed.text;
            }
        } catch (err) {}
    }

    // Fallback if returned standard JSON instead of SSE stream
    if (!fullText && typeof rawData === 'string' && rawData.startsWith('{')) {
        try {
            const parsed = JSON.parse(rawData);
            fullText = parsed.response || parsed.message || '';
        } catch (e) {}
    }

    return fullText.trim();
}

module.exports = {
    name: 'ai2',
    alias: ['thenux2', 't2', 'omni2'],
    category: 'ai',
    description: 'Thenux AI 2.0 with persistent per-user semantic memory and live HTML execution.',

    run: async ({ conn, client, mek, from, q }) => {
        const botClient = conn || client;
        const number = (botClient.user?.id || '').split(':')[0];
        
        const sender = mek.key.participant || mek.key.remoteJid;
        const userSessionKey = sender.replace(/[^0-9]/g, '');

        let botname = '𝐒𝚄𝙻𝙰 𝐌𝙳 𝐌𝙸𝙽𝙸';
        let botfooter = '> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃';

        try {
            const dbBotName = await ReadData(number, 'BOT_NAME');
            if (dbBotName) botname = dbBotName;

            const dbBotFooter = await ReadData(number, 'BOT_FOOTER');
            if (dbBotFooter) botfooter = dbBotFooter;
        } catch (e) {}

        const userPrompt = q ? q.trim() : '';

        if (!userPrompt) {
            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
🤖 *${botname} AI 2.0 (Persistent Memory)*
╰───────────♡◉◉◉♡───────────⌬

✨ *Usage:*
• \`.ai2 <prompt>\` ➔ Chat with AI (Remembers context & facts automatically)
• \`.ai2 set <fact>\` ➔ Save a specific fact to memory (e.g. \`.ai2 set my name is Thenula\`)
• \`.ai2 memory\` ➔ View all stored facts for your session
• \`.ai2 reset\` ➔ Clear memory and start a fresh session

${botfooter}`
            }, { quoted: mek });
        }

        const lowerPrompt = userPrompt.toLowerCase();

        // 1. Reset Session
        if (lowerPrompt === 'reset') {
            const currentChatId = await getUserChatId(userSessionKey);
            if (currentChatId) {
                try {
                    await axios.delete(`${BASE_URL}/api/chats/${currentChatId}/memory`, {
                        headers: { 'Authorization': `Bearer ${API_KEY}` }
                    });
                } catch (e) {}
            }
            await saveUserChatId(userSessionKey, null);
            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
🔄 *SESSION & MEMORY RESET*
╰───────────♡◉◉◉♡───────────⌬

Your memory session has been cleared. Your next message will start a brand new memory context!

${botfooter}`
            }, { quoted: mek });
        }

        // Ensure user has a valid active Chat ID
        const chatId = await getOrCreateChatId(userSessionKey);

        // 2. Explicit Memory Injection (.ai2 set ...)
        if (lowerPrompt.startsWith('set ')) {
            const factToRemember = userPrompt.slice(4).trim();
            if (!factToRemember) {
                return botClient.sendMessage(from, { text: '❌ Please specify what to remember. Example: `.ai2 set my name is Thenula`' }, { quoted: mek });
            }

            await botClient.sendMessage(from, { react: { text: '⏳', key: mek.key } });

            try {
                await axios.post(`${BASE_URL}/api/chats/${chatId}/memory`, {
                    content: factToRemember,
                    type: 'user_fact'
                }, {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${API_KEY}`
                    },
                    timeout: 10000
                });

                await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });
                return botClient.sendMessage(from, {
                    text: `╭───────────♡◉◉◉♡───────────⌬
🧠 *MEMORY SAVED*
╰───────────♡◉◉◉♡───────────⌬

Saved fact to session \`${chatId}\`:
📝 _"${factToRemember}"_

${botfooter}`
                }, { quoted: mek });
            } catch (err) {
                return botClient.sendMessage(from, {
                    text: `❌ *Failed to store memory:* ${err.response?.data?.error || err.message}\n\n${botfooter}`
                }, { quoted: mek });
            }
        }

        // 3. Inspect Memory (.ai2 memory)
        if (lowerPrompt === 'memory') {
            await botClient.sendMessage(from, { react: { text: '🧠', key: mek.key } });
            try {
                const memRes = await axios.get(`${BASE_URL}/api/chats/${chatId}/memory`, {
                    headers: { 'Authorization': `Bearer ${API_KEY}` },
                    timeout: 10000
                });

                const memories = memRes.data?.memory || [];
                let memoryText = '';

                if (Array.isArray(memories) && memories.length > 0) {
                    memories.forEach((m, idx) => {
                        const content = typeof m === 'object' ? (m.content || JSON.stringify(m)) : m;
                        memoryText += `\n[${idx + 1}] 💡 ${content}`;
                    });
                } else {
                    memoryText = '\n_No facts recorded in memory yet. Chat with me or use .ai2 set to teach me facts!_';
                }

                return botClient.sendMessage(from, {
                    text: `╭───────────♡◉◉◉♡───────────⌬
🧠 *STORED SESSION MEMORIES (${memories.length})*
╰───────────♡◉◉◉♡───────────⌬

🆔 *Session ID:* \`${chatId}\`
${memoryText}

${botfooter}`
                }, { quoted: mek });
            } catch (err) {
                return botClient.sendMessage(from, {
                    text: `❌ *Failed to inspect memory:* ${err.response?.data?.error || err.message}\n\n${botfooter}`
                }, { quoted: mek });
            }
        }

        // 4. Multi-Turn Conversational Chat with Persistent Context & Auto-Memory Extraction
        await botClient.sendMessage(from, { react: { text: '⏳', key: mek.key } });

        try {
            let chosenModel = 'T-Nex 1.0';
            if (userPrompt.includes('code') || userPrompt.includes('html') || userPrompt.includes('script') || userPrompt.includes('function')) {
                chosenModel = 'Blackbox AI';
            } else if (userPrompt.includes('think') || userPrompt.includes('reason') || userPrompt.includes('solve')) {
                chosenModel = 'Gemini 2.5 Thinking';
            }

            // Execute through session endpoint to engage KV memory & conversation history
            const rawAiText = await streamSessionChat(chatId, userPrompt, chosenModel);

            if (!rawAiText) {
                throw new Error('No valid response returned from THENUX engine.');
            }

            // Fetch memory count to display badge
            let memoryCount = 0;
            try {
                const memCheck = await axios.get(`${BASE_URL}/api/chats/${chatId}/memory`, {
                    headers: { 'Authorization': `Bearer ${API_KEY}` },
                    timeout: 5000
                });
                memoryCount = (memCheck.data?.memory || []).length;
            } catch (e) {}

            // Handle HTML preview blocks
            const htmlMatch = rawAiText.match(/```html\s*([\s\S]*?)\s*```/i);
            if (htmlMatch && htmlMatch[1]) {
                const extractedHtml = htmlMatch[1].trim();

                if (typeof botClient.sendHTML === 'function') {
                    await botClient.sendHTML(from, extractedHtml, {
                        title: `${botname} Live HTML Preview`,
                        trustedSources: ['thenuxofc.store', 'nixel.dev']
                    });
                } else {
                    const response_id = crypto.randomUUID();
                    const htmlEnvelope = {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2,
                            botMetadata: {
                                messageDisclaimerText: "",
                                botResponseId: "b2e40280-433c-45d8-9c1a-270bec558860"
                            }
                        },
                        botForwardedMessage: {
                            message: {
                                richResponseMessage: {
                                    messageType: 1,
                                    submessages: [{ messageType: 2, messageText: "Live HTML Preview" }],
                                    unifiedResponse: {
                                        data: Buffer.from(JSON.stringify({
                                            response_id,
                                            sections: [
                                                {
                                                    view_model: {
                                                        primitive: {
                                                            __typename: "GenAIaeacdsnwHtmlPrimitive",
                                                            payload: extractedHtml,
                                                            trusted_sources: ["thenuxofc.store", "nixel.dev"]
                                                        },
                                                        __typename: "GenAISingleLayoutViewModel"
                                                    }
                                                }
                                            ]
                                        })).toString('base64')
                                    }
                                }
                            }
                        }
                    };
                    await botClient.relayMessage(from, htmlEnvelope, {}).catch(() => {});
                }
            }

            const memoryNotice = memoryCount > 0 ? `\n\n🧠 _Memory Active: ${memoryCount} facts remembered across sessions_` : '';

            const resultCaption = `╭───────────♡◉◉◉♡───────────⌬
🤖 *${botname} AI 2.0*
╰───────────♡◉◉◉♡───────────⌬

${rawAiText}${memoryNotice}

──────────────────────
🛰️ *Model:* \`${chosenModel}\`
🆔 *Session:* \`${chatId}\`
${botfooter}`;

            await botClient.sendMessage(from, { text: resultCaption }, { quoted: mek });
            await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });

        } catch (err) {
            console.error('❌ [AI 2.0 Error]:', err.message);
            await botClient.sendMessage(from, { react: { text: '❌', key: mek.key } });

            const errorMsg = err.response?.data?.error || err.message;
            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
❌ *AI 2.0 FAILED*
╰───────────♡◉◉◉♡───────────⌬

📌 *Reason:* ${errorMsg}

${botfooter}`
            }, { quoted: mek });
        }
    }
};
