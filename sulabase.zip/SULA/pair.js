const axios = require("axios");

module.exports = {
  name: "pair",

  run: async ({ conn, mek, from, args }) => {
    try {

      const number = args.join("").trim();

      if (!number) {
        return await conn.sendMessage(from, {
          text: "📌 Usage:\n.pair 947XXXXXXXX"
        }, { quoted: mek });
      }

      await conn.sendMessage(from, {
        react: { text: "⏳", key: mek.key }
      });

      // 🔑 GET CODE
      const pairApi = `https://sula-pair-site-16685def78d6.herokuapp.com/pair?number=${number}&token=sulamd`;
      const pairRes = await axios.get(pairApi);

      if (!pairRes.data?.code) {
        throw new Error("Pair code not received");
      }

      const code = pairRes.data.code;

      await conn.sendMessage(from, {
        text: `
${code}
`
      }, { quoted: mek });

      await new Promise(r => setTimeout(r, 1200));

      const qrRes = await axios.get(
        "https://sula-pair-site-16685def78d6.herokuapp.com/qr?token=sulamd",
        { responseType: "arraybuffer" }
      );

      const qrBuffer = Buffer.from(qrRes.data);

      const caption = `
𝐒𝚄𝙻𝙰 𝐌𝙳 𝐌𝙸𝙽𝙸 𝐁𝙾𝚃 - 𝐐𝚁 𝐏𝙰𝙽𝙴𝙻

📱 *Number:* ${number}

📋 Code:
➤ ${code}

───────────────

📌 *Connect Steps*

1️⃣ Copy code  
2️⃣ WhatsApp open  
3️⃣ 3 dots → Linked Devices  
4️⃣ Link with phone number  
5️⃣ Paste code  

───────────────

📲 *OR*

Scan this QR code

> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃
`;

      await conn.sendMessage(from, {
        image: qrBuffer,
        caption: caption
      }, { quoted: mek });

    } catch (err) {
      await conn.sendMessage(from, {
        text: `❌ Pair Failed\n${err.message}`
      }, { quoted: mek });
    }
  }
};
