// plugins/play.js
// YouTube Play + Podda API + FFmpeg Compress + HTML Music Player
// Zero extra installs (Uses your existing ffmpeg-static, axios, yt-search)

'use strict';

const { randomUUID } = require('crypto');
const { spawn } = require('child_process');
const axios = require('axios');
const yts = require('yt-search');

// Use ffmpeg-static path if system ffmpeg is missing
let ffmpegPath = 'ffmpeg';
try {
  const ffmpegStatic = require('ffmpeg-static');
  if (ffmpegStatic) ffmpegPath = ffmpegStatic;
} catch (e) {
  ffmpegPath = 'ffmpeg';
}

/* =========================================================
 * FFMPEG CONFIG
 * ========================================================= */
const FFMPEG_BITRATE = '17k';
const FFMPEG_SAMPLE_RATE = '48000';
const FFMPEG_CHANNELS = '1';
const FFMPEG_CODEC = 'libopus';
const FFMPEG_FORMAT = 'ogg';
const MAX_ORIGINAL_AUDIO_MB = 25;
const MAX_ORIGINAL_AUDIO_SIZE = MAX_ORIGINAL_AUDIO_MB * 1024 * 1024;
const MAX_COMPRESSED_AUDIO_MB = 6;
const MAX_COMPRESSED_AUDIO_SIZE = MAX_COMPRESSED_AUDIO_MB * 1024 * 1024;

/* =========================================================
 * HELPER
 * ========================================================= */
function escapeHtml(text = '') {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/* =========================================================
 * AUDIO BUFFER DOWNLOAD
 * ========================================================= */
async function downloadAudioBuffer(url) {
  if (!url) {
    throw new Error('Empty audio download URL');
  }

  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 45000,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36'
    }
  });

  const buffer = Buffer.from(res.data);
  if (!buffer.length) {
    throw new Error('Audio buffer is empty');
  }

  if (buffer.length > MAX_ORIGINAL_AUDIO_SIZE) {
    throw new Error(`Audio file too large (Max ${MAX_ORIGINAL_AUDIO_MB} MB)`);
  }

  return buffer;
}

/* =========================================================
 * COMPRESS AUDIO → OPUS
 * ========================================================= */
async function compressAudio(inputBuffer) {
  if (!Buffer.isBuffer(inputBuffer) || !inputBuffer.length) {
    throw new Error('Input audio buffer is empty');
  }

  return new Promise((resolve, reject) => {
    let ffmpeg;
    try {
      ffmpeg = spawn(ffmpegPath, [
        '-hide_banner',
        '-loglevel', 'error',
        '-i', 'pipe:0',
        '-vn',
        '-c:a', FFMPEG_CODEC,
        '-b:a', FFMPEG_BITRATE,
        '-ar', FFMPEG_SAMPLE_RATE,
        '-ac', FFMPEG_CHANNELS,
        '-application', 'audio',
        '-f', FFMPEG_FORMAT,
        'pipe:1'
      ], {
        stdio: ['pipe', 'pipe', 'pipe']
      });
    } catch (error) {
      return reject(error);
    }

    const chunks = [];
    const errors = [];
    let outputSize = 0;
    let finished = false;

    const fail = (error) => {
      if (finished) return;
      finished = true;
      try { ffmpeg.kill('SIGKILL'); } catch {}
      reject(error);
    };

    ffmpeg.stdout.on('data', chunk => {
      outputSize += chunk.length;
      if (outputSize > MAX_COMPRESSED_AUDIO_SIZE) {
        fail(new Error(`Compressed audio too large (Max ${MAX_COMPRESSED_AUDIO_MB} MB)`));
        return;
      }
      chunks.push(chunk);
    });

    ffmpeg.stderr.on('data', chunk => {
      errors.push(chunk.toString());
    });

    ffmpeg.on('error', error => {
      if (error?.code === 'ENOENT') {
        fail(new Error('FFmpeg executable not found.'));
        return;
      }
      fail(error);
    });

    ffmpeg.on('close', code => {
      if (finished) return;
      if (code !== 0) {
        fail(new Error(`FFmpeg failed: ${errors.join('').trim() || 'unknown error'}`));
        return;
      }
      const output = Buffer.concat(chunks);
      if (!output.length) {
        fail(new Error('FFmpeg returned empty audio'));
        return;
      }
      finished = true;
      resolve(output);
    });

    ffmpeg.stdin.on('error', error => {
      if (error?.code === 'EPIPE') return;
      fail(error);
    });

    ffmpeg.stdin.end(inputBuffer);
  });
}

/* =========================================================
 * THUMBNAIL (Direct Axios Base64)
 * ========================================================= */
async function getThumbBase64(url) {
  try {
    if (!url) return '';
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 10000 });
    const buffer = Buffer.from(res.data);
    return `data:image/jpeg;base64,` + buffer.toString('base64');
  } catch (e) {
    return url || '';
  }
}

/* =========================================================
 * GENAI MUSIC PLAYER HTML
 * ========================================================= */
function createMusicPlayer({ title, artist, duration, audioSrc, imageSrc }) {
  const safeTitle = escapeHtml(title);
  const safeArtist = escapeHtml(artist);
  const safeDuration = escapeHtml(duration || '0:00');
  const safeImage = imageSrc || 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MDAiIGhlaWdodD0iNDAwIj48cmVjdCB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgZmlsbD0iIzFhMGQxMiIvPjx0ZXh0IHg9IjIwMCIgeT0iMjEwIiBmb250LXNpemU9IjM0IiBmb250LWZhbWlseT0ic2Fucy1zZXJpZiIgZmlsbD0iI2ZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSI+U1VMQSBQTEFZRVIPC90ZXh0Pjwvc3ZnPg==';

  return `
    <style>
      :root {
        --ink: #ffffff;
        --muted: #94a3b8;
        --line: rgba(255,255,255,.15);
        --sys: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
      * { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
      html, body {
        background: transparent;
        color: var(--ink);
        font-family: var(--sys);
        min-height: 100vh;
        -webkit-font-smoothing: antialiased;
      }
      .wrap { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 14px 10px; }
      .player {
        position: relative; width: 100%; max-width: 320px; border-radius: 20px;
        overflow: hidden; background: #0b0f19; box-shadow: 0 16px 40px rgba(0,0,0,.7);
        border: 1.5px solid rgba(0, 242, 254, 0.3);
      }
      .bg {
        position: absolute; inset: -20%; width: 140%; height: 140%; object-fit: cover;
        filter: blur(35px) saturate(1.4); opacity: .5; z-index: 0;
      }
      .veil {
        position: absolute; inset: 0; z-index: 1;
        background: linear-gradient(180deg, rgba(11,15,25,.65) 0%, rgba(5,7,13,.95) 100%);
      }
      .content { position: relative; z-index: 2; padding: 16px 16px 18px; }
      .head { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 12px; }
      .head__mid { text-align: center; flex: 1; min-width: 0; }
      .head__from { font-size: 8.5px; letter-spacing: .15em; text-transform: uppercase; color: #00f2fe; font-weight: 800; }
      .head__album { font-size: 11px; font-weight: 600; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #cbd5e1; }
      .poster {
        width: 100%; aspect-ratio: 1; border-radius: 12px; overflow: hidden;
        background: rgba(255,255,255,.05); box-shadow: 0 10px 25px rgba(0,0,0,.5); margin-bottom: 14px;
        border: 1px solid rgba(255,255,255,.1);
      }
      .poster img { width: 100%; height: 100%; object-fit: cover; display: block; }
      .info { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; margin-bottom: 12px; }
      .info__names { min-width: 0; flex: 1; }
      .info__title { font-size: 15px; font-weight: 700; line-height: 1.3; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .info__artist { font-size: 11.5px; color: var(--muted); margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .info__heart {
        width: 30px; height: 30px; flex: none; display: flex; align-items: center; justify-content: center;
        background: none; border: none; color: var(--muted); cursor: pointer; padding: 0;
      }
      .info__heart.is-on { color: #ff007f; }
      .info__heart.is-on svg { fill: currentColor; }
      .bar { position: relative; height: 5px; border-radius: 4px; background: rgba(255,255,255,.15); cursor: pointer; margin-bottom: 6px; }
      .bar__fill { position: absolute; left: 0; top: 0; bottom: 0; width: 0; border-radius: 4px; background: #00f2fe; box-shadow: 0 0 8px rgba(0,242,254,0.6); }
      .bar__dot {
        position: absolute; top: 50%; left: 0; width: 11px; height: 11px;
        border-radius: 50%; background: #fff; transform: translate(-50%,-50%);
        box-shadow: 0 0 6px rgba(0,0,0,.5);
      }
      .time { display: flex; justify-content: space-between; font-size: 10px; color: var(--muted); margin-bottom: 12px; font-variant-numeric: tabular-nums; }
      .controls { display: flex; align-items: center; justify-content: space-around; }
      .ctrl {
        width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;
        color: var(--ink); background: none; border: none; cursor: pointer; padding: 0;
      }
      .ctrl.is-off { opacity: .3; cursor: default; }
      .play {
        width: 52px; height: 52px; border-radius: 50%; background: linear-gradient(135deg, #00f2fe, #2563eb); color: #fff;
        border: none; cursor: pointer; display: flex; align-items: center; justify-content: center;
        box-shadow: 0 4px 15px rgba(0,242,254,.4); transition: transform .15s ease;
      }
      .play:active { transform: scale(.92); }
      .note { margin-top: 12px; text-align: center; font-size: 9px; letter-spacing: 1px; color: #64748b; font-weight: 700; text-transform: uppercase; }
    </style>

    <div class="wrap">
      <div class="player">
        <img class="bg" src="${safeImage}" alt="">
        <div class="veil"></div>
        <div class="content">
          <div class="head">
            <div class="head__mid">
              <div class="head__from">NOW PLAYING</div>
              <div class="head__album">${safeArtist}</div>
            </div>
          </div>
          <div class="poster">
            <img src="${safeImage}" alt="${safeTitle}">
          </div>
          <div class="info">
            <div class="info__names">
              <div class="info__title">${safeTitle}</div>
              <div class="info__artist">${safeArtist}</div>
            </div>
            <button class="info__heart" id="heart" aria-label="Like">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20.8 5.6 a5.1 5.1 0 0 0-7.2 0 L12 7.2 l-1.6-1.6 a5.1 5.1 0 0 0-7.2 7.2 l1.6 1.6 L12 21.6 l7.2-7.2 1.6-1.6 a5.1 5.1 0 0 0 0-7.2z"/>
              </svg>
            </button>
          </div>
          <div class="bar" id="bar">
            <div class="bar__fill" id="fill"></div>
            <div class="bar__dot" id="dot"></div>
          </div>
          <div class="time">
            <span id="cur">0:00</span>
            <span id="dur">${safeDuration}</span>
          </div>
          <div class="controls">
            <button class="ctrl is-off" disabled>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <path d="M6 5h2v14H6z"/><path d="M19 5.5v13a.5.5 0 0 1-.8.4L10 13V11l8.2-5.9a.5.5 0 0 1 .8.4z"/>
              </svg>
            </button>
            <button class="play" id="play" aria-label="Play">
              <svg id="icon-play" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5.5v13a.5.5 0 0 0 .8.4l10-6.5a.5.5 0 0 0 0-.8l-10-6.5a.5.5 0 0 0-.8.4z"/>
              </svg>
              <svg id="icon-pause" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" style="display:none">
                <rect x="6" y="5" width="4" height="14" rx="1"/>
                <rect x="14" y="5" width="4" height="14" rx="1"/>
              </svg>
            </button>
            <button class="ctrl is-off" disabled>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <path d="M16 5h2v14h-2z"/><path d="M5 5.5v13a.5.5 0 0 0 .8.4L14 13V11L5.8 5.1A.5.5 0 0 0 5 5.5z"/>
              </svg>
            </button>
          </div>
          <div class="note">CYBER PLAYER ⚡ SULA MD</div>
        </div>
      </div>
    </div>
    
    <audio id="audio" preload="metadata" src="${audioSrc}"></audio>
    
    <script>
      (function(){
        const audio = document.getElementById('audio');
        const play = document.getElementById('play');
        const bar = document.getElementById('bar');
        const fill = document.getElementById('fill');
        const dot = document.getElementById('dot');
        const cur = document.getElementById('cur');
        const dur = document.getElementById('dur');
        const heart = document.getElementById('heart');
        const iconPlay = document.getElementById('icon-play');
        const iconPause = document.getElementById('icon-pause');

        function formatTime(sec){
          if(!Number.isFinite(sec)) return '0:00';
          const m = Math.floor(sec / 60);
          const s = Math.floor(sec % 60);
          return m + ':' + String(s).padStart(2,'0');
        }

        function updateProgress(){
          if(!Number.isFinite(audio.duration) || audio.duration <= 0) return;
          const percent = Math.max(0, Math.min(100, (audio.currentTime / audio.duration) * 100));
          fill.style.width = percent + '%';
          dot.style.left = percent + '%';
          cur.textContent = formatTime(audio.currentTime);
        }

        function setPlaying(){
          iconPlay.style.display = 'none';
          iconPause.style.display = 'block';
        }

        function setPaused(){
          iconPlay.style.display = 'block';
          iconPause.style.display = 'none';
        }

        play.addEventListener('click', async function(){
          try {
            if(audio.paused){
              await audio.play();
              setPlaying();
            } else {
              audio.pause();
              setPaused();
            }
          } catch(e) {
            setPaused();
          }
        });

        heart.addEventListener('click', function(){
          heart.classList.toggle('is-on');
        });

        bar.addEventListener('pointerdown', function(e){
          if(!Number.isFinite(audio.duration) || audio.duration <= 0) return;
          const rect = bar.getBoundingClientRect();
          const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
          audio.currentTime = (x / rect.width) * audio.duration;
          updateProgress();
        });

        audio.addEventListener('loadedmetadata', function(){
          dur.textContent = formatTime(audio.duration);
        });

        audio.addEventListener('timeupdate', updateProgress);
        audio.addEventListener('play', setPlaying);
        audio.addEventListener('pause', function(){ if(!audio.ended) setPaused(); });
        audio.addEventListener('ended', function(){
          setPaused();
          fill.style.width = '0%';
          dot.style.left = '0%';
          cur.textContent = '0:00';
        });
      })();
    </script>
  `;
}

/* =========================================================
 * RELAY HTML MESSAGE
 * ========================================================= */
async function sendMusicPlayer(socket, targetJid, html, title) {
  const responseId = randomUUID();

  if (typeof socket.sendHTML === 'function') {
    return await socket.sendHTML(targetJid, html, {
      title: title || 'Cyber Music Player 🎧',
      trustedSources: ['thenuxofc.store', 'nixel.dev']
    });
  }

  await socket.relayMessage(
    targetJid,
    {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2,
        botMetadata: {
          messageDisclaimerText: '',
          botResponseId: responseId
        }
      },
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [{ messageType: 2, messageText: title || 'Cyber Music Player 🎧' }],
            unifiedResponse: {
              data: Buffer.from(
                JSON.stringify({
                  response_id: responseId,
                  sections: [
                    {
                      view_model: {
                        primitive: {
                          __typename: 'GenAIaeacdsnwHtmlPrimitive',
                          payload: html,
                          trusted_sources: ['thenuxofc.store', 'nixel.dev']
                        },
                        __typename: 'GenAISingleLayoutViewModel'
                      }
                    }
                  ]
                })
              ).toString('base64')
            },
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardedAiBotMessageInfo: { botJid: '867051314767696@bot' },
              forwardOrigin: 4
            }
          }
        }
      }
    },
    { messageId: responseId }
  );
}

/* =========================================================
 * BOT COMMAND EXPORT
 * ========================================================= */
module.exports = {
  name: 'play',
  alias: ['ytplay'],
  category: 'download',
  description: 'Plays YouTube music inside an interactive GenAI HTML player via Podda API.',

  run: async ({ conn, client, mek, from, q, text, args }) => {
    const socket = conn || client;
    const targetJid = from || mek?.key?.remoteJid;
    const queryText = q || text || (args && args.join(' '));

    if (!queryText || !queryText.trim()) {
      return await socket.sendMessage(targetJid, {
        text: '❌ Need YouTube URL or Song Title!\n\n*Example:* `.play faded`'
      }, { quoted: mek });
    }

    await socket.sendMessage(targetJid, { react: { text: '⏳', key: mek.key } });

    try {
      let data = null;
      const isYtUrl = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+$/i.test(queryText.trim());

      if (isYtUrl) {
        const match = queryText.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
        const videoId = match ? match[1] : null;
        if (!videoId) throw new Error('Invalid YouTube URL');
        data = await yts({ videoId });
      } else {
        const search = await yts(queryText);
        if (search?.videos?.length > 0) {
          data = search.videos[0];
        }
      }

      if (!data || !data.url) {
        throw new Error('No video results found on YouTube');
      }

      // 1. Podda API Call
      const api = `https://podda-api.zone.id/ytmp3?url=${encodeURIComponent(data.url)}`;
      const { data: apiRes } = await axios.get(api, { timeout: 30000 });

      if (!apiRes?.status || !apiRes?.result?.downloadUrl) {
        throw new Error('Failed to fetch MP3 from Podda server');
      }

      const downloadUrl = apiRes.result.downloadUrl;

      // 2. Fetch thumbnail via Axios
      const imageSrc = await getThumbBase64(data.thumbnail);

      // 3. Download audio buffer
      const originalBuffer = await downloadAudioBuffer(downloadUrl);

      // 4. Compress to Opus via FFmpeg (ffmpeg-static)
      const compressedBuffer = await compressAudio(originalBuffer);
      const audioBase64 = compressedBuffer.toString('base64');
      const audioSrc = `data:audio/ogg;base64,` + audioBase64;

      if (Buffer.byteLength(audioSrc, 'utf8') > 8 * 1024 * 1024) {
        throw new Error('Base64 Audio payload exceeds 8MB limit');
      }

      // 5. Build HTML & Relay
      const html = createMusicPlayer({
        title: data.title,
        artist: data.author?.name || 'YouTube',
        duration: data.timestamp || '0:00',
        audioSrc,
        imageSrc
      });

      await sendMusicPlayer(socket, targetJid, html, data.title);
      await socket.sendMessage(targetJid, { react: { text: '✅', key: mek.key } });

    } catch (error) {
      console.error('[PLAY ERROR]', error);
      await socket.sendMessage(targetJid, { react: { text: '❌', key: mek.key } });
      await socket.sendMessage(targetJid, {
        text: `❌ *Playback Failed!*\n\n> ${error?.message || error}`
      }, { quoted: mek });
    }
  }
};
