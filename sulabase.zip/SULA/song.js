const axios = require('axios');
const yts = require('yt-search');
const { ReadData } = require('../database');

module.exports = {
    name: 'song',
    alias: ['ytmp3', 'music'],

    run: async ({ conn, mek, from, q }) => {
        try {
            if (!q || !q.trim()) {
                return conn.sendMessage(from, {
                    text: '❌ Need YouTube URL or Song Title!\n\nExample: .song faded'
                }, { quoted: mek });
            }

            const isValidYouTubeUrl = (url) => {
                return /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+$/i.test(url);
            };

            const cleanFileName = (name) => {
                return String(name || 'song')
                    .replace(/[\\/:*?"<>|]/g, '')
                    .trim()
                    .slice(0, 80) || 'song';
            };

            await conn.sendMessage(from, {
                react: { text: '⏳', key: mek.key }
            });

            let data = null;

            if (isValidYouTubeUrl(q)) {
                const match = q.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
                const videoId = match ? match[1] : null;

                if (!videoId) {
                    return conn.sendMessage(from, { text: '❌ Invalid YouTube URL!' }, { quoted: mek });
                }

                data = await yts({ videoId });
            } else {
                const search = await yts(q);
                if (search && search.videos.length > 0) {
                    data = search.videos[0];
                }
            }

            if (!data || !data.url) {
                return conn.sendMessage(from, { text: '❌ No results found!' }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, "BOT_NAME") || 'SULA MD';
            const botfooter = await ReadData(number, "BOT_FOOTER") || '© SULA MD';

            const caption = `
╭────♡◉◉◉♡────⌬
💖 *Song Ready!*  
🌸 *${botname} prepared your music ✨*  
╰────♡◉◉◉♡────⌬

🎵 *Title:*  
➤ ${data.title}

👤 *Artist:*  
➤ ${data.author?.name || 'Unknown'}

⏱ *Duration:*  
➤ ${data.timestamp}

👁 *Views:*  
➤ ${data.views?.toLocaleString() || '0'}

🎧 *Format:*  
➤ MP3

───────────────

📥 *Choose Type:*  

❶ 🎧 Audio  
❷ 📁 Document  

───────────────

💌 *Reply:* 1 / 2  

${botfooter}
`;

            const sentMsg = await conn.sendMessage(from, {
                image: { url: data.thumbnail },
                caption
            }, { quoted: mek });

            let timer;
            const listener = async (msgUpdate) => {
                try {
                    const msg = msgUpdate.messages[0];
                    if (!msg?.message) return;

                    const text = (msg.message.conversation || msg.message.extendedTextMessage?.text || '').trim();
                    const context = msg.message.extendedTextMessage?.contextInfo;

                    if (context?.stanzaId !== sentMsg.key.id) return;
                    if (!['1', '2'].includes(text)) return;

                    clearTimeout(timer);
                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        react: { text: '⬇️', key: msg.key }
                    });

                    // 🎧 Direct Podda API Call
                    const api = `https://podda-api.zone.id/ytmp3?url=${encodeURIComponent(data.url)}`;
                    const { data: apiRes } = await axios.get(api, { timeout: 30000 });

                    if (!apiRes?.status || !apiRes?.result?.downloadUrl) {
                        return await conn.sendMessage(from, {
                            text: '❌ Failed to fetch MP3 from server!'
                        }, { quoted: msg });
                    }

                    const downloadUrl = apiRes.result.downloadUrl;
                    const fileName = `${cleanFileName(data.title)}.mp3`;

                    if (text === '1') {
                        await conn.sendMessage(from, {
                            audio: { url: downloadUrl },
                            mimetype: 'audio/mpeg',
                            fileName,
                            ptt: false
                        }, { quoted: msg });

                    } else if (text === '2') {
                        await conn.sendMessage(from, {
                            document: { url: downloadUrl },
                            mimetype: 'audio/mpeg',
                            fileName,
                            caption: `🎵 *${data.title}*\n👤 ${data.author?.name || 'Unknown'}\n\n${botfooter}`
                        }, { quoted: msg });
                    }

                    await conn.sendMessage(from, {
                        react: { text: '✅', key: msg.key }
                    });

                } catch (err) {
                    console.error(err);
                    await conn.sendMessage(from, {
                        text: `❌ Error: ${err.message || 'Download failed'}`
                    }, { quoted: mek });
                }
            };

            conn.ev.on('messages.upsert', listener);
            timer = setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (error) {
            console.error(error);
            await conn.sendMessage(from, {
                text: `❌ Error: ${error.message || error}`
            }, { quoted: mek });
        }
    }
};
