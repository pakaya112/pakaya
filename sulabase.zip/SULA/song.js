const axios = require('axios');
const yts = require('yt-search');
const { ReadData } = require('../database');

module.exports = {
    name: 'song',

    run: async ({ conn, mek, from, q }) => {

        if (!q) {
            return conn.sendMessage(from, {
                text: '❌ Need YouTube URL or Song Title!\n\nExample: .song faded'
            }, { quoted: mek });
        }

        const isValidYouTubeUrl = (url) => {
            return /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+$/i.test(url);
        };

        const cleanFileName = (name) => {
            return String(name || 'song')
                .replace(/[\\/:*?"<>|]/g, '')
                .trim()
                .slice(0, 80) || 'song';
        };

        const getBestThumb = async (videoId, fallback) => {
            const urls = [
                videoId ? `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg` : null,
                videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : null,
                videoId ? `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg` : null,
                fallback
            ].filter(Boolean);

            for (const url of urls) {
                try {
                    const res = await axios.get(url, {
                        responseType: 'arraybuffer',
                        timeout: 30000,
                        validateStatus: s => s >= 200 && s < 300,
                        headers: {
                            'User-Agent': 'Mozilla/5.0',
                            'Accept': 'image/jpeg,image/png,image/webp,image/*,*/*'
                        }
                    });

                    const buffer = Buffer.from(res.data);

                    if (buffer.length > 5000) {
                        return { url, buffer };
                    }
                } catch {}
            }

            return { url: fallback || '', buffer: null };
        };

        const getContextInfo = async (songData) => {
            const thumb = songData.thumbBuffer || null;

            return {
                forwardingScore: 999,
                isForwarded: true,
                externalAdReply: {
                    title: `🎵 ${songData.title}`,
                    body: `👤 ${songData.author} | ⏱️ ${songData.duration}`,
                    thumbnail: thumb,
                    thumbnailUrl: songData.thumbnail,
                    sourceUrl: songData.url,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    showAdAttribution: false
                }
            };
        };

        await conn.sendMessage(from, {
            react: { text: '⏳', key: mek.key }
        });

        try {
            let videoUrl = q;
            let title = 'Unknown Song';
            let thumb = null;
            let thumbBuffer = null;
            let duration = 'Unknown';
            let views = '0';
            let author = 'Unknown';

            if (!isValidYouTubeUrl(q)) {
                const search = await yts(q);
                const data = search.videos[0];

                if (!data) {
                    return conn.sendMessage(from, {
                        text: '❌ No results found!'
                    }, { quoted: mek });
                }

                videoUrl = data.url;
                title = data.title;
                duration = data.timestamp;
                views = data.views?.toLocaleString() || '0';
                author = data.author?.name || 'Unknown';

                const bestThumb = await getBestThumb(data.videoId, data.thumbnail);
                thumb = bestThumb.url;
                thumbBuffer = bestThumb.buffer;

            } else {
                const match = videoUrl.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
                const videoId = match ? match[1] : null;

                if (!videoId) {
                    return conn.sendMessage(from, {
                        text: '❌ Invalid YouTube URL!'
                    }, { quoted: mek });
                }

                const data = await yts({ videoId });

                title = data.title || 'Unknown Song';
                duration = data.timestamp || 'Unknown';
                views = data.views?.toLocaleString() || '0';
                author = data.author?.name || 'Unknown';

                const bestThumb = await getBestThumb(videoId, data.thumbnail);
                thumb = bestThumb.url;
                thumbBuffer = bestThumb.buffer;
            }

            const api =
                `https://ytmp3-thenux.netlify.app/api/ytmp3?url=${encodeURIComponent(videoUrl)}`;

            const response = await axios({
                method: 'GET',
                url: api,
                maxRedirects: 10,
                timeout: 180000,
                headers: {
                    'User-Agent': 'Mozilla/5.0',
                    'Accept': 'application/json'
                },
                validateStatus: function (status) {
                    return status >= 200 && status < 400;
                }
            });

            if (response.status >= 400) {
                return conn.sendMessage(from, {
                    text: `❌ API Error: ${response.status}`
                }, { quoted: mek });
            }

            const apiRes = response.data;

            if (!apiRes || apiRes.success !== true) {
                return conn.sendMessage(from, {
                    text: '❌ Failed to fetch MP3!'
                }, { quoted: mek });
            }

            const download =
                apiRes.direct_download ||
                apiRes.download_url ||
                apiRes?.audio?.url ||
                apiRes?.links?.download;

            if (!download) {
                return conn.sendMessage(from, {
                    text: '❌ Download URL not found!'
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];

            const botname =
                await ReadData(number, "BOT_NAME") || 'THENUX BOT';

            const botfooter =
                await ReadData(number, "BOT_FOOTER") || '© THENUX';

            const songData = {
                title,
                author,
                duration,
                thumbnail: thumb,
                thumbBuffer,
                url: videoUrl
            };

            const contextInfo = await getContextInfo(songData);

            const caption = `
╭────♡◉◉◉♡────⌬
💖 *Song Ready!*  
🌸 *${botname} prepared your music ✨*  
╰────♡◉◉◉♡────⌬

🎵 *Title:*  
➤ ${title}

👤 *Artist:*  
➤ ${author}

⏱ *Duration:*  
➤ ${duration}

👁 *Views:*  
➤ ${views}

🎧 *Format:*  
➤ MP3

───────────────

📥 *Choose Type:*  

❶ 🎧 Audio  
❷ 📁 Document  

───────────────

💌 *Reply:* 1 / 2  

${botfooter}
`;

            const sentMsg = await conn.sendMessage(from, {
                image: thumbBuffer || { url: thumb },
                caption,
                contextInfo
            }, { quoted: mek });

            const timeout = setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

            const listener = async (msgUpdate) => {
                try {
                    const msg = msgUpdate.messages[0];
                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const context =
                        msg.message.extendedTextMessage?.contextInfo;

                    const repliedMsgId =
                        context?.stanzaId;

                    if (repliedMsgId !== sentMsg.key.id) return;

                    await conn.sendMessage(from, {
                        react: { text: '⬇️', key: msg.key }
                    });

                    const audioResponse = await axios.get(download, {
                        responseType: 'arraybuffer',
                        timeout: 180000,
                        maxRedirects: 10,
                        headers: {
                            'User-Agent': 'Mozilla/5.0',
                            'Accept': 'audio/mpeg,audio/*,*/*'
                        }
                    });

                    const audioBuffer = Buffer.from(audioResponse.data);
                    const fileName = `${cleanFileName(title)}.mp3`;

                    if (text === '1') {
                        await conn.sendMessage(from, {
                            audio: audioBuffer,
                            mimetype: 'audio/mpeg',
                            fileName,
                            ptt: false,
                            contextInfo
                        }, { quoted: msg });

                    } else if (text === '2') {
                        await conn.sendMessage(from, {
                            document: audioBuffer,
                            mimetype: 'audio/mpeg',
                            fileName,
                            caption: `🎵 *${title}*\n👤 ${author}\n\n${botfooter}`,
                            contextInfo
                        }, { quoted: msg });

                    } else {
                        return conn.sendMessage(from, {
                            text: '❌ Reply only with 1 or 2'
                        }, { quoted: msg });
                    }

                    await conn.sendMessage(from, {
                        react: { text: '✅', key: msg.key }
                    });

                    clearTimeout(timeout);
                    conn.ev.off('messages.upsert', listener);

                } catch (err) {
                    console.log(err);
                    conn.ev.off('messages.upsert', listener);

                    await conn.sendMessage(from, {
                        text: `❌ Error: ${err.message || err}`
                    }, { quoted: mek });
                }
            };

            conn.ev.on('messages.upsert', listener);

        } catch (error) {
            console.log(error);

            await conn.sendMessage(from, {
                text: `❌ Error: ${error.message || error}`
            }, { quoted: mek });
        }
    }
};
