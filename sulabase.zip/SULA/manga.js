const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'mangadl',
    alias: ['manhwa', 'toonily', 'manga'],

    run: async ({ conn, mek, from, q }) => {

        const number = conn.user.id.split(':')[0];

        const botname =
            await ReadData(number, 'BOT_NAME');

        const botfooter =
            await ReadData(number, 'BOT_FOOTER');

        // ❌ NO QUERY
        if (!q) {

            return conn.sendMessage(from, {
                text: `
╭────♡◉◉◉♡────⌬
❌ *Missing Query*
✨ *${botname} Manga System*
╰────♡◉◉◉♡────⌬

🔎 *Search Example:*  
➤ .mangadl solo leveling

📚 *Direct Manga:*  
➤ .mangadl https://toonily.com/...

📖 *Direct Chapter:*  
➤ .mangadl https://toonily.com/.../chapter-1/

───────────────

💌 *Please Enter Query*

${botfooter}
`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '⏳', key: mek.key }
        });

        try {

            const apiUrl = q.startsWith('http')
                ? `https://thenuxanime-dl.netlify.app/api/toonily?url=${encodeURIComponent(q)}`
                : `https://thenuxanime-dl.netlify.app/api/toonily?q=${encodeURIComponent(q)}`;

            const { data } = await axios.get(apiUrl, {
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0'
                }
            });

            if (!data?.success) {
                throw new Error(data?.error || 'Manga not found');
            }

            // ================= SEARCH =================

            if (data.type === 'search') {

                return await handleSearch(
                    conn,
                    mek,
                    from,
                    data,
                    botname,
                    botfooter
                );
            }

            // ================= MANGA =================

            if (data.type === 'manga' || data.chapters) {

                return await handleManga(
                    conn,
                    mek,
                    from,
                    data,
                    botname,
                    botfooter
                );
            }

            // ================= CHAPTER =================

            if (data.type === 'chapter' || data.pages) {

                return await sendChapterPages(
                    conn,
                    mek,
                    from,
                    data,
                    botname,
                    botfooter
                );
            }

            throw new Error('Unsupported API response');

        } catch (err) {

            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });

            await conn.sendMessage(from, {
                text: `
╭────♡◉◉◉♡────⌬
❌ *Manga Error*
✨ *${botname} System*
╰────♡◉◉◉♡────⌬

📌 *Reason:*  
➤ ${err.message}

${botfooter}
`
            }, { quoted: mek });
        }
    }
};

// ================= SEARCH =================

async function handleSearch(
    conn,
    mek,
    from,
    data,
    botname,
    botfooter
) {

    const results = data.results || [];

    // ❌ NO RESULT
    if (!results.length) {

        return conn.sendMessage(from, {
            text: `
╭────♡◉◉◉♡────⌬
❌ *No Results Found*
✨ *${botname} Search System*
╰────♡◉◉◉♡────⌬

🔎 *Query:*  
➤ ${data.query || 'Search'}

📦 *Results:*  
➤ 0

───────────────

💌 *Try Another Search*

${botfooter}
`
        }, { quoted: mek });
    }

    const list = results
        .slice(0, 10)
        .map((r, i) => {
            return `❰ ${i + 1} ❱ *${r.title}*
⭐ Rating: ${r.rating || 'N/A'}
👁️ Views: ${r.views || 'N/A'}`;
        })
        .join('\n\n');

    const caption = `
╭────♡◉◉◉♡────⌬
📚 *Manga Search Panel*
✨ *${botname} Search Results*
╰────♡◉◉◉♡────⌬

🔎 *Query:*  
➤ ${data.query || 'Search'}

📦 *Results Found:*  
➤ ${results.length}

───────────────

${list}

───────────────

💌 *Reply 1 - ${Math.min(results.length, 10)}*

${botfooter}
`;

    const sentMsg = await conn.sendMessage(from, {
        image: { url: results[0]?.image || '' },
        caption
    }, { quoted: mek });

    const listener = async (msgUpdate) => {

        const msg = msgUpdate.messages[0];

        try {

            if (!msg.message) return;

            const text =
                msg.message.conversation ||
                msg.message.extendedTextMessage?.text;

            const isReply =
                msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

            if (!isReply) return;

            const index = parseInt(text) - 1;

            // ❌ INVALID REPLY
            if (isNaN(index) || !results[index]) {

                return conn.sendMessage(from, {
                    text: `
╭────♡◉◉◉♡────⌬
❌ *Invalid Reply*
✨ *${botname} Manga System*
╰────♡◉◉◉♡────⌬

💌 *Reply With Valid Number*

${botfooter}
`
                }, { quoted: msg });
            }

            conn.ev.off('messages.upsert', listener);

            await conn.sendMessage(from, {
                react: { text: '📖', key: msg.key }
            });

            const mangaApi =
                `https://thenuxanime-dl.netlify.app/api/toonily?url=${encodeURIComponent(results[index].url)}`;

            const { data: mangaData } = await axios.get(mangaApi, {
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0'
                }
            });

            if (!mangaData?.success) {
                throw new Error('Failed to fetch manga');
            }

            await handleManga(
                conn,
                msg,
                from,
                mangaData,
                botname,
                botfooter
            );

        } catch (err) {

            conn.ev.off('messages.upsert', listener);

            await conn.sendMessage(from, {
                text: `
╭────♡◉◉◉♡────⌬
❌ *Selection Error*
✨ *${botname} Manga System*
╰────♡◉◉◉♡────⌬

📌 *Reason:*  
➤ ${err.message}

${botfooter}
`
            }, { quoted: msg });
        }
    };

    conn.ev.on('messages.upsert', listener);

    setTimeout(() => {
        conn.ev.off('messages.upsert', listener);
    }, 60000);
}

// ================= MANGA DETAILS =================

async function handleManga(
    conn,
    mek,
    from,
    data,
    botname,
    botfooter
) {

    const chapters = data.chapters || [];

    if (!chapters.length) {
        throw new Error('No chapters found');
    }

    const firstChapters = chapters.slice(0, 20);

    const list = firstChapters
        .map((c, i) => {
            return `❰ ${i + 1} ❱ *${c.title}*
📅 ${c.release_date || 'N/A'}`;
        })
        .join('\n\n');

    const caption = `
╭────♡◉◉◉♡────⌬
📚 *Manga Details Panel*
✨ *${botname} Ready*
╰────♡◉◉◉♡────⌬

📌 *Title:*  
➤ ${data.title || 'Unknown'}

⭐ *Rating:*  
➤ ${data.rating || 'N/A'}

👁️ *Views:*  
➤ ${data.views || 'N/A'}

✍️ *Writer:*  
➤ ${data.writer || 'Unknown'}

🎨 *Artist:*  
➤ ${data.artist || 'Unknown'}

📖 *Status:*  
➤ ${data.status || 'Unknown'}

📦 *Chapters:*  
➤ ${data.total_chapters || chapters.length}

───────────────

${list}

───────────────

💌 *Reply 1 - ${firstChapters.length}*

${botfooter}
`;

    const sentMsg = await conn.sendMessage(from, {
        image: {
            url: data.image || ''
        },
        caption
    }, { quoted: mek });

    const listener = async (msgUpdate) => {

        const msg = msgUpdate.messages[0];

        try {

            if (!msg.message) return;

            const text =
                msg.message.conversation ||
                msg.message.extendedTextMessage?.text;

            const isReply =
                msg.message.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

            if (!isReply) return;

            const index = parseInt(text) - 1;

            if (isNaN(index) || !firstChapters[index]) {

                return conn.sendMessage(from, {
                    text: `
╭────♡◉◉◉♡────⌬
❌ *Invalid Chapter*
✨ *${botname} Manga System*
╰────♡◉◉◉♡────⌬

💌 *Reply With Valid Chapter Number*

${botfooter}
`
                }, { quoted: msg });
            }

            conn.ev.off('messages.upsert', listener);

            await conn.sendMessage(from, {
                react: { text: '📥', key: msg.key }
            });

            const chapterApi =
                `https://thenuxanime-dl.netlify.app/api/toonily?url=${encodeURIComponent(firstChapters[index].url)}`;

            const { data: chapterData } = await axios.get(chapterApi, {
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0'
                }
            });

            if (!chapterData?.success) {
                throw new Error('Failed to fetch chapter');
            }

            await sendChapterPages(
                conn,
                msg,
                from,
                chapterData,
                botname,
                botfooter
            );

        } catch (err) {

            conn.ev.off('messages.upsert', listener);

            await conn.sendMessage(from, {
                text: `
╭────♡◉◉◉♡────⌬
❌ *Chapter Error*
✨ *${botname} Manga System*
╰────♡◉◉◉♡────⌬

📌 *Reason:*  
➤ ${err.message}

${botfooter}
`
            }, { quoted: msg });
        }
    };

    conn.ev.on('messages.upsert', listener);

    setTimeout(() => {
        conn.ev.off('messages.upsert', listener);
    }, 60000);
}

// ================= SEND PAGES =================

async function sendChapterPages(
    conn,
    mek,
    from,
    data,
    botname,
    botfooter
) {

    const pages = data.pages || [];

    if (!pages.length) {
        throw new Error('No pages found');
    }

    await conn.sendMessage(from, {
        text: `
╭────♡◉◉◉♡────⌬
📖 *Chapter Ready*
✨ *${botname} Sending Pages*
╰────♡◉◉◉♡────⌬

📌 *Title:*  
➤ ${data.title || 'Unknown'}

📄 *Pages:*  
➤ ${pages.length}

───────────────

📥 *Sending All Pages...*

${botfooter}
`
    }, { quoted: mek });

    for (const page of pages) {

        try {

            const proxyImage =
                `https://thenuxanime-dl.netlify.app/api/toonily-image?url=${encodeURIComponent(page.image)}`;

            await conn.sendMessage(from, {
                image: {
                    url: proxyImage
                },
                caption: `
╭────♡◉◉◉♡────⌬
📖 *${data.title || 'Manga Chapter'}*
✨ *Page ${page.page}/${pages.length}*
╰────♡◉◉◉♡────⌬

📚 *${botname} Manga Reader*

${botfooter}
`
            }, { quoted: mek });

            await delay(1200);

        } catch (err) {

            await conn.sendMessage(from, {
                text: `
╭────♡◉◉◉♡────⌬
❌ *Page Failed*
✨ *${botname} Manga System*
╰────♡◉◉◉♡────⌬

📄 Failed Page: ${page.page}

${botfooter}
`
            }, { quoted: mek });
        }
    }

    await conn.sendMessage(from, {
        react: { text: '✅', key: mek.key }
    });
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
