const axios = require('axios');
const crypto = require('crypto');
const { ReadData } = require('../database');

module.exports = {
    name: 'turboseek',
    alias: ['tseek', 'deepsearch', 'seekai', 'webai'],
    category: 'ai',
    description: 'AI-powered deep web search engine with interactive HTML source preview card.',

    run: async ({ conn, client, mek, from, q }) => {
        const botClient = conn || client;
        const number = (botClient.user?.id || '').split(':')[0];

        // 1. Fetch Dynamic Bot Configuration from Database
        let botname = '𝐒𝚄𝙻𝙰 𝐌𝙳 𝐌𝙸𝙽𝙸';
        let botfooter = '> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃';

        try {
            const dbBotName = await ReadData(number, 'BOT_NAME');
            if (dbBotName) botname = dbBotName;

            const dbBotFooter = await ReadData(number, 'BOT_FOOTER');
            if (dbBotFooter) botfooter = dbBotFooter;
        } catch (e) {
            console.warn('Database Read Error for bot branding:', e.message);
        }

        const API_KEY = 'freeApikey';
        const userPrompt = q ? q.trim() : '';

        if (!userPrompt) {
            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
🔍 *${botname} TURBOSEEK AI*
╰───────────♡◉◉◉♡───────────⌬

❌ *Please provide a search query!*

*Usage:*
• \`.turboseek <your question/query>\`

*Example:*
\`.turboseek who is current president in sri lanka\`

${botfooter}`
            }, { quoted: mek });
        }

        try {
            await botClient.sendMessage(from, { react: { text: '🔍', key: mek.key } });

            // 2. Fetch Deep Search Results from TurboSeek API
            const apiUrl = `https://anabot.my.id/api/ai/turboseek?prompt=${encodeURIComponent(userPrompt)}&apikey=${API_KEY}`;
            const response = await axios.get(apiUrl, {
                headers: { 'accept': 'application/json' },
                timeout: 90000
            });

            if (!response.data || !response.data.success || !response.data.data?.result) {
                throw new Error(response.data?.message || 'TurboSeek search returned no usable results.');
            }

            const resultObj = response.data.data.result;
            const answerText = resultObj.message || 'No direct answer retrieved.';
            const sourcesList = Array.isArray(resultObj.sources) ? resultObj.sources : [];
            const similarQs = Array.isArray(resultObj.similarQuestions) ? resultObj.similarQuestions : [];

            // 3. Build Sources HTML Elements
            let sourcesHtml = '';
            sourcesList.slice(0, 6).forEach((srcUrl, idx) => {
                let domain = '';
                try {
                    domain = new URL(srcUrl).hostname.replace('www.', '');
                } catch(e) {
                    domain = srcUrl.substring(0, 24) + '...';
                }
                sourcesHtml += `
                <a href="${srcUrl}" target="_blank" class="source-pill">
                  <span class="source-idx">${idx + 1}</span>
                  <span class="source-domain">${domain}</span>
                </a>`;
            });

            if (!sourcesHtml) {
                sourcesHtml = '<div style="font-size:11px;color:#64748b;">No direct web source references logged.</div>';
            }

            // 4. Build Interactive HTML Search Card
            const htmlPayload = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>TurboSeek AI Search</title>
<style>
* { -webkit-tap-highlight-color: transparent; -webkit-user-select: none; user-select: none; box-sizing: border-box; margin: 0; padding: 0; }
body { margin: 0; background: #07090e; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #f1f5f9; }
.wrapper { width: 100%; max-width: 500px; margin: auto; padding: 14px 10px 10px; }

.card { 
  background: linear-gradient(180deg, #0d1322, #07090e); 
  border: 1.5px solid #00f2fe; 
  border-radius: 20px; 
  box-shadow: 0 0 25px rgba(0, 242, 254, 0.2), 0 16px 40px rgba(0,0,0,0.85); 
  padding: 16px 14px 12px; 
  position: relative; 
}

.badge {
  position: absolute;
  top: -11px;
  left: 50%;
  transform: translateX(-50%);
  background: #07090e;
  border: 1.5px solid #00f2fe;
  border-radius: 20px;
  padding: 2px 14px;
  font-size: 9px;
  font-weight: 900;
  letter-spacing: 1.8px;
  color: #00f2fe;
  box-shadow: 0 0 14px rgba(0, 242, 254, 0.5);
  text-transform: uppercase;
  white-space: nowrap;
}

.header { display: flex; justify-content: space-between; align-items: center; margin-top: 2px; margin-bottom: 12px; }
.title { font-size: 10px; letter-spacing: 1.5px; color: #00f2fe; font-weight: 800; text-transform: uppercase; }
.status-pill { background: rgba(0, 242, 254, 0.1); border: 1px solid rgba(0, 242, 254, 0.25); border-radius: 20px; padding: 3px 10px; font-size: 10px; font-weight: 800; color: #00f2fe; }

.query-box {
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 12px;
  padding: 10px 12px;
  margin-bottom: 12px;
  font-size: 12px;
  color: #94a3b8;
}
.query-box strong { color: #f8fafc; font-size: 13px; display: block; margin-top: 2px; }

.answer-box {
  background: linear-gradient(135deg, rgba(0, 242, 254, 0.04), rgba(255, 0, 127, 0.02));
  border: 1px solid rgba(0, 242, 254, 0.15);
  border-radius: 14px;
  padding: 14px;
  font-size: 14px;
  line-height: 1.6;
  color: #e2e8f0;
  margin-bottom: 14px;
}

.section-label { font-size: 10px; font-weight: 800; letter-spacing: 1px; color: #64748b; text-transform: uppercase; margin-bottom: 8px; }

.sources-grid { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px; }
.source-pill {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 8px;
  padding: 6px 10px;
  font-size: 11px;
  color: #38bdf8;
  text-decoration: none;
  font-weight: 700;
}
.source-idx { background: rgba(56, 189, 248, 0.2); border-radius: 4px; padding: 1px 5px; font-size: 9px; }

.footer-credit {
  margin-top: 10px;
  text-align: center;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 1.5px;
  color: #64748b;
  text-transform: uppercase;
  border-top: 1px dashed rgba(255,255,255,0.08);
  padding-top: 8px;
}
.footer-credit span { color: #00f2fe; text-shadow: 0 0 8px rgba(0,242,254,0.5); }
</style>
</head>
<body>
<div class="wrapper">
  <div class="card">
    <div class="badge">TURBOSEEK AI MATRIX</div>

    <div class="header">
      <div>
        <div class="title">REAL-TIME WEB SEARCH</div>
        <h2 style="font-size: 16px; font-weight: 900; color: #fff; margin-top: 2px;">Intelligence Hub</h2>
      </div>
      <div class="status-pill">SEARCH SYNCED ⚡</div>
    </div>

    <div class="query-box">
      <span>Query Requested:</span>
      <strong>"${userPrompt}"</strong>
    </div>

    <div class="answer-box">
      ${answerText.replace(/\\n/g, '<br>')}
    </div>

    <div class="section-label">Verified Source Citations (${sourcesList.length}):</div>
    <div class="sources-grid">
      ${sourcesHtml}
    </div>

    <div class="footer-credit">
      <span>© 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃</span> ⚡
    </div>
  </div>
</div>
</body>
</html>`;

            // 5. Send Interactive HTML Card (or fallback relay)
            if (typeof botClient.sendHTML === 'function') {
                await botClient.sendHTML(from, htmlPayload, {
                    title: `TurboSeek: ${userPrompt.substring(0, 24)}...`,
                    trustedSources: ['thenuxofc.store', 'nixel.dev']
                });
            } else {
                const response_id = crypto.randomUUID();
                const messageEnvelope = {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2,
                        botMetadata: {
                            messageDisclaimerText: "",
                            botResponseId: "b2e40280-433c-45d8-9c1a-270bec558860",
                            verificationMetadata: {
                                proofs: [
                                    {
                                        version: 1,
                                        useCase: 1,
                                        signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                        certificateChain: [
                                            "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                            "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                        ]
                                    }
                                ]
                            }
                        }
                    },
                    botForwardedMessage: {
                        message: {
                            richResponseMessage: {
                                messageType: 1,
                                submessages: [{ messageType: 2, messageText: `TurboSeek: ${userPrompt}` }],
                                unifiedResponse: {
                                    data: Buffer.from(JSON.stringify({
                                        response_id,
                                        sections: [
                                            {
                                                view_model: {
                                                    primitive: {
                                                        __typename: "GenAIaeacdsnwHtmlPrimitive",
                                                        payload: htmlPayload,
                                                        trusted_sources: ["thenuxofc.store", "nixel.dev"]
                                                    },
                                                    __typename: "GenAISingleLayoutViewModel"
                                                }
                                            }
                                        ]
                                    })).toString('base64')
                                },
                                contextInfo: {
                                    forwardingScore: 1,
                                    isForwarded: true,
                                    forwardedAiBotMessageInfo: { botJid: "867051314767696@bot" },
                                    forwardOrigin: 4
                                }
                            }
                        }
                    }
                };
                await botClient.relayMessage(from, messageEnvelope, {});
            }

       /*     // 6. Text Summary Output
            let sourcesText = '';
            if (sourcesList.length > 0) {
                sourcesText = '\n\n🌐 *Top Sources:*\n' + sourcesList.slice(0, 4).map((s, i) => `[${i + 1}] ${s}`).join('\n');
            }

            const textCaption = `╭───────────♡◉◉◉♡───────────⌬
🔍 *${botname} TURBOSEEK RESULT*
╰───────────♡◉◉◉♡───────────⌬

📌 *Query:* _${userPrompt}_

${answerText}${sourcesText}

──────────────────────
${botfooter}`;

            await botClient.sendMessage(from, { text: textCaption }, { quoted: mek }); */
            await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });

        } catch (err) {
            console.error('❌ [TurboSeek Error]:', err.message);
            await botClient.sendMessage(from, { react: { text: '❌', key: mek.key } });

            let errorMsg = err.message;
            if (err.response?.data?.message) errorMsg = err.response.data.message;

            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
❌ *TURBOSEEK SEARCH FAILED*
╰───────────♡◉◉◉♡───────────⌬

📌 *Reason:* ${errorMsg}

${botfooter}`
            }, { quoted: mek });
        }
    }
};
