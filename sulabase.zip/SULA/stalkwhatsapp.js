module.exports = {
    name: "winfo",

    run: async ({ conn, mek, from, args }) => {

        try {

            if (!args[0]) {
                return await conn.sendMessage(from, {
                    text: "❌ Give a number\nExample: .winfo +947XXXXXXXX"
                }, { quoted: mek });
            }

            const num = args[0].replace(/[^0-9]/g, "");
            const target = num + "@s.whatsapp.net";

            await conn.sendMessage(from, {
                react: { text: "🔍", key: mek.key }
            });

            const check = await conn.onWhatsApp(target);

            if (!check || !check[0]?.exists) {
                return await conn.sendMessage(from, {
                    text: "❌ This number is not on WhatsApp!"
                }, { quoted: mek });
            }

            const number = target.split("@")[0];

            let name = check[0]?.notify || "No name";

            let bio = "Not available";
            try {
                const status = await conn.fetchStatus(target);
                bio = status?.status || "No bio";
            } catch {}

            let pp = null;
            try {
                pp = await conn.profilePictureUrl(target, "image");
            } catch {}

            
            const msg = `
🔍 *WhatsApp User Info*

👤 Number: ${number}
`;

            if (pp) {
                await conn.sendMessage(from, {
                    image: { url: pp },
                    caption: msg
                }, { quoted: mek });
            } else {
                await conn.sendMessage(from, {
                    text: msg
                }, { quoted: mek });
            }

        } catch (err) {
            console.log("WINFO ERROR:", err);

            await conn.sendMessage(from, {
                text: "❌ Failed to get info!"
            }, { quoted: mek });
        }
    }
};
