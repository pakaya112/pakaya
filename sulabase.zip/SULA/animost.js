const axios = require('axios');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { ReadData } = require('../database');

// --- Temp Folder Configuration ---
const TEMP_DIR = path.join(__dirname, 'temp_anime');
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}
process.env.TMPDIR = TEMP_DIR;
os.tmpdir = () => TEMP_DIR;

// AnimostLK API Base URL
const API_BASE_URL = 'https://vortex-animostlk.vercel.app/api';
const DEFAULT_IMAGE = 'https://raw.githubusercontent.com/sulamadara1147/data/main/file_00000000097071fabaedacd96b9efefc.png';

// Helper: Convert KB/Bytes to Clean Formatted MB/GB
function formatFileSize(sizeStr) {
    if (!sizeStr || sizeStr === 'N/A') return 'N/A';
    const str = String(sizeStr).trim();

    if (/kb$/i.test(str)) {
        const kb = parseFloat(str.replace(/kb/i, '').trim());
        if (isNaN(kb)) return sizeStr;
        const mb = kb / 1024;
        return mb >= 1024 ? `${(mb / 1024).toFixed(2)} GB` : `${mb.toFixed(2)} MB`;
    }

    if (/^\d+$/.test(str)) {
        const bytes = parseInt(str);
        const mb = bytes / (1024 * 1024);
        return mb >= 1024 ? `${(mb / 1024).toFixed(2)} GB` : `${mb.toFixed(2)} MB`;
    }

    return sizeStr;
}

// 1. API Call Function (With Retries)
async function apiCallWithRetry(url, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await axios.get(url, { timeout: 25000 });
            if (!response.data || !response.data.success) {
                throw new Error(response.data?.error || 'API returned success: false');
            }
            return response.data;
        } catch (error) {
            if (i === retries - 1) {
                let errMsg = error.response?.data?.error || error.message;
                if (typeof errMsg === 'object') errMsg = errMsg.message || JSON.stringify(errMsg);
                throw new Error(errMsg);
            }
            await new Promise(res => setTimeout(res, 2000));
        }
    }
}

// 2. Stream File Download Function (RAM Overflow Prevention)
async function downloadWithRetry(url, destPath, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            const { data } = await axios({
                url: url,
                method: 'GET',
                responseType: 'stream',
                timeout: 300000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
                }
            });

            const writer = fs.createWriteStream(destPath);
            data.pipe(writer);

            await new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', (err) => {
                    writer.close();
                    reject(err);
                });
                data.on('error', (err) => {
                    writer.close();
                    reject(err);
                });
            });

            return true;
        } catch (error) {
            if (fs.existsSync(destPath)) {
                try { fs.unlinkSync(destPath); } catch (e) {}
            }
            if (i === retries - 1) throw error;
            await new Promise(res => setTimeout(res, 2000));
        }
    }
}

module.exports = {
    name: 'animost',
    alias: ['an', 'animedl'],

    run: async ({ conn, mek, from, q }) => {
        try {
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.\n\nWant access to this feature?\n\nCreate your own bot:\n🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'SULA MD';

            if (!q) {
                return await conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬\n🌸 *Anime Search*\n╰────♡◉◉◉♡────⌬\n\n📌 *Examples:* \n.animost Your Name\n.animost 9476xxxxxxx@s.whatsapp.net A Whisker Away`
                }, { quoted: mek });
            }

            const args = q.trim().split(' ');
            let targetJid = null;
            let searchQuery = q.trim();
            let isCustomTarget = false;

            if (args[0]?.includes('@s.whatsapp.net') || args[0]?.includes('@g.us') || args[0]?.includes('@lid')) {
                targetJid = args[0];
                searchQuery = args.slice(1).join(' ').trim();
                isCustomTarget = true;
            }

            await conn.sendMessage(from, { react: { text: '⏳', key: mek.key } });

            const searchData = await apiCallWithRetry(`${API_BASE_URL}/search?q=${encodeURIComponent(searchQuery)}`, 3);

            if (!searchData.results || searchData.results.length === 0) {
                return await conn.sendMessage(from, { text: `❌ *No results found for:* ${searchQuery}` }, { quoted: mek });
            }

            const top = searchData.results.slice(0, 10);
            const list = top.map((r, i) => `❰ ${i + 1} ❱ *${r.title}*`).join('\n\n');

            const caption = `╭────♡◉◉◉♡────⌬\n🌸 *Anime Search Results*\n✨ *${botname} Ready*\n╰────♡◉◉◉♡────⌬\n\n🔍 *Query:* ${searchQuery}\n\n${list}\n\n───────────────\n\nReply with a number: 1 - ${top.length}`;

            const sentMsg = await conn.sendMessage(from, {
                image: { url: top[0]?.image || DEFAULT_IMAGE },
                caption
            }, { quoted: mek });

            const timeoutTimer = setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];
                if (!msg.message) return;

                const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                if (!isReply) return;

                const index = parseInt(text?.trim()) - 1;
                if (isNaN(index) || !top[index]) {
                    clearTimeout(timeoutTimer);
                    conn.ev.off('messages.upsert', listener);
                    return conn.sendMessage(from, { text: '❌ Invalid Selection. Please run the command again.' }, { quoted: msg });
                }

                clearTimeout(timeoutTimer);
                conn.ev.off('messages.upsert', listener);
                await conn.sendMessage(from, { react: { text: '📥', key: msg.key } });

                const selected = top[index];

                let detailData;
                try {
                    detailData = await apiCallWithRetry(`${API_BASE_URL}/movie?url=${encodeURIComponent(selected.url)}`, 3);
                } catch (apiErr) {
                    return await conn.sendMessage(from, { text: `❌ *API Error:* ${apiErr.message}` }, { quoted: msg });
                }

                const details = detailData.details;
                if (!details || !details.downloads || !details.downloads.length) {
                    return await conn.sendMessage(from, { text: '❌ No download links found for this title.' }, { quoted: msg });
                }

                // Filter out Telegram links
                const filteredDownloads = details.downloads.filter(
                    (d) => !/telegram/i.test(d.source) && !/t\.me\//i.test(d.url)
                );

                if (filteredDownloads.length === 0) {
                    return await conn.sendMessage(from, { text: '❌ No direct download links found for this movie!' }, { quoted: msg });
                }

                const dlList = filteredDownloads.map((d, i) =>
                    `❰ ${i + 1} ❱ *${d.quality}* - (${formatFileSize(d.size)}) [${d.type.toUpperCase()}]`
                ).join('\n');

                const dlCaption = `╭────♡◉◉◉♡────⌬\n🎥 *${details.title}*\n╰────♡◉◉◉♡────⌬\n\n*Available Download Qualities:*\n\n${dlList}\n\n───────────────\n\nReply with Quality Number (1 - ${filteredDownloads.length})`;

                const dlMsg = await conn.sendMessage(from, {
                    image: { url: details.poster || DEFAULT_IMAGE },
                    caption: dlCaption
                }, { quoted: msg });

                const dlTimeoutTimer = setTimeout(() => {
                    conn.ev.off('messages.upsert', dlListener);
                }, 60000);

                const dlListener = async (dlUpdate) => {
                    const dlReply = dlUpdate.messages[0];
                    if (!dlReply?.message) return;

                    const dlText = dlReply.message.conversation || dlReply.message.extendedTextMessage?.text;
                    const isIt = dlReply.message?.extendedTextMessage?.contextInfo?.stanzaId === dlMsg.key.id;

                    if (!isIt) return;

                    const dlNum = parseInt(dlText?.trim()) - 1;
                    if (isNaN(dlNum) || !filteredDownloads[dlNum]) {
                        clearTimeout(dlTimeoutTimer);
                        conn.ev.off('messages.upsert', dlListener);
                        return conn.sendMessage(from, { text: '❌ Invalid Choice.' }, { quoted: dlReply });
                    }

                    clearTimeout(dlTimeoutTimer);
                    conn.ev.off('messages.upsert', dlListener);
                    const selectedDl = filteredDownloads[dlNum];

                    await showDownloadMenu(conn, dlReply, from, targetJid, isCustomTarget, {
                        title: details.title,
                        poster: details.poster,
                        quality: selectedDl.quality,
                        size: formatFileSize(selectedDl.size),
                        type: selectedDl.type || 'mp4',
                        downloadUrl: selectedDl.downloadUrl || selectedDl.videoUrl || selectedDl.url,
                        botname
                    });
                };

                conn.ev.on('messages.upsert', dlListener);
            };

            conn.ev.on('messages.upsert', listener);

        } catch (err) {
            console.error('Anime Command Error:', err.message);
            await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
            await conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬\n❌ *Anime Error*\n╰────♡◉◉◉♡────⌬\n\n⚠️ ${err.message}`
            }, { quoted: mek });
        }
    }
};

// ==========================================
// 🚀 DOWNLOAD & FILE SEND DISPATCHER
// ==========================================
async function showDownloadMenu(conn, quotedMsg, from, targetJid, isCustomTarget, info) {
    const caption = `╭────♡◉◉◉♡────⌬\n📥 *Download Options*\n✨ *${info.botname}*\n╰────♡◉◉◉♡────⌬\n\n🎬 *Title:* ${info.title}\n💎 *Quality:* ${info.quality}\n📦 *Size:* ${info.size}\n\n───────────────\n\n📁 ❶ Send as File\n🔗 ❷ Direct Download Link\n\n───────────────\n\nReply: 1 / 2`;

    const sentMsg = await conn.sendMessage(from, {
        image: { url: info.poster || DEFAULT_IMAGE },
        caption
    }, { quoted: quotedMsg });

    const timeoutTimer = setTimeout(() => {
        conn.ev.off('messages.upsert', listener);
    }, 60000);

    const listener = async (msgUpdate) => {
        const msg = msgUpdate.messages[0];
        if (!msg.message) return;

        const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
        const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

        if (!isReply) return;

        clearTimeout(timeoutTimer);
        conn.ev.off('messages.upsert', listener);

        const chosenOption = text?.trim();

        if (!['1', '2'].includes(chosenOption)) {
            return conn.sendMessage(from, { text: '❌ Invalid Option. Please choose 1 or 2.' }, { quoted: msg });
        }

        await conn.sendMessage(from, { react: { text: '⏳', key: msg.key } });

        let tempFilePath = null;

        try {
            const rawSize = String(info.size).toUpperCase();
            const sizeNum = parseFloat(rawSize);
            const isOver2GB = rawSize.includes('GB') && sizeNum >= 2.0;

            // 🛡️ 2GB File Size Limit Check
            if (chosenOption === '1' && isOver2GB) {
                await conn.sendMessage(from, { react: { text: '⚠️', key: msg.key } });
                return await conn.sendMessage(from, {
                    text: `⚠️ *File Size Limit Exceeded! (2GB+)*\n\nThe file size is *${info.size}*. Due to WhatsApp file size limitations, files over 2GB cannot be sent directly as documents.\n\n🔗 *Direct Download Link:*\n${info.downloadUrl}`
                }, { quoted: msg });
            }

            const fileName = `${info.title.replace(/[^a-zA-Z0-9._-]/g, '_')}_${info.quality}.${info.type}`;

            // 🌸 Requested Anime Delivery Caption Style 🌸
            const doneCaption = `╭──〔 🌸 Anime Movie Delivery 🌸 〕──⬣\n\n` +
                                `૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა Your anime is ready~ 💕\n\n` +
                                `🎬 Title ➜ ${info.title}\n` +
                                `💎 Quality ➜ ${info.quality}\n` +
                                `📦 Size ➜ ${info.size}\n\n` +
                                `━━━━━━━━━━━━━━━\n\n` +
                                `🍿 Enjoy your watch time!\n\n` +
                                `🌸 Thanks for using ${info.botname}\n\n` +
                                `♡ Powered By 🌐 https://sulaofc.store\n\n` +
                                `anime • movies • series • updates\n\n` +
                                `━━━━━━━━━━━━━━━`;

            if (chosenOption === '1') {
                tempFilePath = path.join(TEMP_DIR, `${Date.now()}_${fileName}`);

                await conn.sendMessage(from, {
                    text: `⏳ *Downloading file to server...*\n\n📄 *File:* ${fileName}\n📦 *Size:* ${info.size}\n\n*(Please wait, sending file shortly...)*`
                }, { quoted: msg });

                await downloadWithRetry(info.downloadUrl, tempFilePath, 3);

                await conn.sendMessage(from, { react: { text: '📤', key: msg.key } });

                const mimetype = info.type === 'mkv' ? 'video/x-matroska' : 'video/mp4';

                await conn.sendMessage(targetJid || from, {
                    document: { stream: fs.createReadStream(tempFilePath) },
                    mimetype: mimetype,
                    fileName: fileName,
                    caption: doneCaption
                }, { quoted: msg });

                if (isCustomTarget && targetJid) {
                    await conn.sendMessage(from, {
                        text: `✅ Successfully Delivered!\n\n📤 To: ${targetJid}`
                    }, { quoted: msg });
                }

                await conn.sendMessage(from, { react: { text: '✅', key: msg.key } });

            } else {
                await conn.sendMessage(from, {
                    text: `${doneCaption}\n\n🔗 *Direct Download Link:*\n${info.downloadUrl}`
                }, { quoted: msg });
                await conn.sendMessage(from, { react: { text: '✅', key: msg.key } });
            }

        } catch (err) {
            console.error('Download/Send Error:', err);
            await conn.sendMessage(from, { react: { text: '❌', key: msg.key } });
            await conn.sendMessage(from, {
                text: `❌ *Download Failed:*\n${err.message}\n\n🔗 *Direct Link:*\n${info.downloadUrl}`
            }, { quoted: msg });
        } finally {
            try {
                if (tempFilePath && fs.existsSync(tempFilePath)) {
                    fs.unlinkSync(tempFilePath);
                }
            } catch (cleanupErr) {
                console.error('Temp cleanup error:', cleanupErr);
            }
        }
    };

    conn.ev.on('messages.upsert', listener);
}
