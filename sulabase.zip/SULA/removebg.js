const fs = require('fs');
const path = require('path');
const axios = require('axios');
const FormData = require('form-data');
const { downloadContentFromMessage } = require('baileys');
const { ReadData } = require('../database');

module.exports = {
    name: 'rmbg',
    alias: ['removebg', 'nobg'],
    category: 'tools',
    description: 'Remove image background.',

    run: async ({ conn, mek, from }) => {

        try {

            // 📥 BOT DATA
            const number = conn.user.id.split(':')[0];

            const botname =
                await ReadData(number, "BOT_NAME");

            const botfooter =
                await ReadData(number, "BOT_FOOTER");

            // 🔑 REMOVE.BG API
            const REMOVE_BG_API =
                'https://api.remove.bg/v1.0/removebg';

            const REMOVE_BG_KEY =
                'V5KAVwDGrbDBiE27dQLJDfEX';

            // 🖼️ GET IMAGE
            const quoted =
                mek.quoted
                ? mek.quoted
                : mek.message?.extendedTextMessage?.contextInfo?.quotedMessage
                ? { message: mek.message.extendedTextMessage.contextInfo.quotedMessage }
                : null;

            if (!quoted?.message?.imageMessage){

                return conn.sendMessage(from,{
                    text: `
╭────♡◉◉◉♡────⌬
🖼️ *REMOVE BACKGROUND PANEL*  
🌸 *${botname} AI Editor* ✨  
╰────♡◉◉◉♡────⌬

❌ *Please reply to an image*

📌 *Example:*  
➤ Reply image + .rmbg

${botfooter}
`
                }, { quoted: mek });

            }

            // ⏳ REACT
            await conn.sendMessage(from,{
                react:{ text:"✂️", key: mek.key }
            });

            // 📥 DOWNLOAD IMAGE
            const stream =
                await downloadContentFromMessage(
                    quoted.message.imageMessage,
                    'image'
                );

            let buffer = Buffer.from([]);

            for await (const chunk of stream){

                buffer = Buffer.concat([buffer, chunk]);

            }

            // 💾 SAVE TEMP IMAGE
            const tempFile =
                path.resolve(`rmbg_${Date.now()}.jpg`);

            fs.writeFileSync(tempFile, buffer);

            // 🌐 UPLOAD TO IMGBB
            const formData =
                new FormData();

            formData.append(
                'image',
                fs.createReadStream(tempFile)
            );

            const upload =
                await axios.post(

                    'https://api.imgbb.com/1/upload?key=62e2c40fddb8396567e99419e4a1ae1d',

                    formData,

                    {
                        headers: formData.getHeaders()
                    }

                );

            // 🗑️ DELETE TEMP
            fs.unlinkSync(tempFile);

            // ❌ UPLOAD FAIL
            if (!upload.data.success){

                throw new Error('ImgBB upload failed');

            }

            // 🌐 IMAGE URL
            const imageUrl =
                upload.data.data.url;

            // ✂️ REMOVE BACKGROUND
            const removeForm =
                new FormData();

            removeForm.append(
                'image_url',
                imageUrl
            );

            removeForm.append(
                'size',
                'auto'
            );

            const remove =
                await axios.post(

                    REMOVE_BG_API,

                    removeForm,

                    {

                        responseType: 'arraybuffer',

                        headers: {

                            ...removeForm.getHeaders(),

                            'X-API-Key': REMOVE_BG_KEY

                        }

                    }

                );

            // 💾 SAVE RESULT
            const output =
                path.resolve(`no-bg_${Date.now()}.png`);

            fs.writeFileSync(
                output,
                Buffer.from(remove.data)
            );

            // 💖 SEND RESULT
            await conn.sendMessage(from,{

                image:{ url: output },

                caption: `
╭────♡◉◉◉♡────⌬
🖼️ *BACKGROUND REMOVED*  
✨ *${botname} processed your image*  
╰────♡◉◉◉♡────⌬

🌸 *Your transparent image is ready*

💌 Thank you for using ${botname}

${botfooter}
`

            }, { quoted: mek });

            // 🗑️ DELETE OUTPUT
            fs.unlinkSync(output);

            // ✅ REACT
            await conn.sendMessage(from,{
                react:{ text:"✅", key: mek.key }
            });

        } catch(err){

            console.log(
                'REMOVE BG ERROR:',
                err.response?.data || err
            );

            // ❌ ERROR
            conn.sendMessage(from,{

                text: `
╭────♡◉◉◉♡────⌬
❌ *REMOVE BACKGROUND FAILED*  
╰────♡◉◉◉♡────⌬

💖 Please try again later.

${botfooter || ""}
`

            }, { quoted: mek });

        }
    }
};
