module.exports = {
    name: 'support',
    run: async ({ conn, mek, from }) => {

        const contacts = [
            { name: 'Thanux', number: '94757096717' },
            { name: 'Vima', number: '94752762056' },
            { name: 'Ud Modz', number: '94704638406' },
            { name: 'Danuzz', number: '94766911711' },
            { name: 'Dila', number: '94728839446' },
            { name: 'Dina', number: '94725329411' },
            { name: 'Mizta', number: '94785124764' }
        ];

        try {

            const vcards = contacts.map(contact => ({
                vcard: `BEGIN:VCARD
VERSION:3.0
FN:${contact.name}
ORG:SULA-MD SUPPORT TEAM;
TEL;type=CELL;type=VOICE;waid=${contact.number}:${contact.number}
END:VCARD`
            }));

            await conn.sendMessage(from, {
                contacts: {
                    displayName: 'SULA-MD SUPPORT TEAM',
                    contacts: vcards
                }
            }, { quoted: mek });

            const caption = `
🛠️ SUPPORT TEAM
🌸 Official Support Contacts

Special thanks to everyone who contributed, tested, supported, and helped make this project a success. ❤️✨

> © SULA MD SUPPORT TEAM
`;

            await conn.sendMessage(from, {
                text: caption
            }, { quoted: mek });

        } catch (err) {
            console.error('Support command error:', err);

            await conn.sendMessage(from, {
                text: '❌ Error sending support contacts!'
            }, { quoted: mek });
        }
    }
};
