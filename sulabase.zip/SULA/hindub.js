const axios = require('axios');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { ReadData } = require('../database');

// Temp Directory Setup
const TEMP_DIR = path.join(__dirname, 'temp_movie');
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}
process.env.TMPDIR = TEMP_DIR;
os.tmpdir = () => TEMP_DIR;

// Helper: API Call with Retry
async function apiCallWithRetry(url, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            const response = await axios.get(url, { timeout: 20000 });
            if (!response.data) throw new Error('API returned empty response');
            return response.data;
        } catch (error) {
            console.log(`[API ATTEMPT ${i + 1} FAILED] ${url} - ${error.message}`);
            if (i === retries - 1) throw error;
            await new Promise(res => setTimeout(res, 2000));
        }
    }
}

// Helper: Stream File Download
async function downloadWithRetry(url, destPath, retries = 3) {
    for (let i = 0; i < retries; i++) {
        let writer;
        try {
            const { data } = await axios({
                url: url,
                method: 'GET',
                responseType: 'stream',
                timeout: 60000
            });

            writer = fs.createWriteStream(destPath);
            data.pipe(writer);

            await new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', reject);
            });

            return true;
        } catch (error) {
            if (writer) writer.destroy();
            if (fs.existsSync(destPath)) try { fs.unlinkSync(destPath); } catch (e) {}
            if (i === retries - 1) throw error;
            await new Promise(res => setTimeout(res, 3000));
        }
    }
}

// Helper: Quality Label Parser from URL
function getQualityLabel(url) {
    if (!url) return 'HD Quality';
    const decoded = decodeURIComponent(url);
    if (/1080p/i.test(decoded)) return /HEVC/i.test(decoded) ? '1080p (HEVC x265)' : '1080p Full HD';
    if (/720p/i.test(decoded)) return /HEVC/i.test(decoded) ? '720p (HEVC x265)' : '720p HD';
    if (/480p/i.test(decoded)) return '480p SD';
    return 'HD Quality';
}

module.exports = {
    name: 'hindub',
    alias: ['cinepix', 'hindidubmovie'],
    category: 'movie',
    description: 'Search and Download Hindi Dubbed Movies',

    run: async ({ conn, mek, from, q, prefix }) => {
        try {
            // 🔒 1. OWNER ONLY CHECK
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.

Want access to this feature?

Create your own bot:
🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || '𝐒𝚄𝙻𝙰 𝐌𝙳 𝐌𝙸𝙽𝙸';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '> © 𝚂𝚄𝙻𝙰 𝙼𝙳 𝙼𝙸𝙽𝙸 𝙱𝙾𝚃';

            if (!q || !q.trim()) {
                return await conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬
🎬 *HINDI DUBBED MOVIE SEARCH*
╰────♡◉◉◉♡────⌬

*Usage:*
➤ ${prefix || '.'}hindub <movie name>

*Example:*
➤ ${prefix || '.'}hindub Avengers Infinity War

${botfooter}`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, { react: { text: '🔍', key: mek.key } });

            // 1. Search via API
            const searchApiUrl = `https://vortex-hindubmv.vercel.app/api/search?keyword=${encodeURIComponent(q.trim())}`;
            let searchData;
            try {
                searchData = await apiCallWithRetry(searchApiUrl, 3);
            } catch (err) {
                return await conn.sendMessage(from, { text: `❌ *Search API Error:* ${err.message}` }, { quoted: mek });
            }

            const rawResults = Array.isArray(searchData) ? searchData : (searchData?.results || searchData?.data || searchData?.result || []);

            if (!rawResults || rawResults.length === 0) {
                return await conn.sendMessage(from, { text: `❌ *No results found for:* ${q}` }, { quoted: mek });
            }

            const top = rawResults.slice(0, 5);
            const resultList = top.map((r, i) => `❰ ${i + 1} ❱ *${r.title || r.name}*`).join('\n\n');

            const caption = `╭────♡◉◉◉♡────⌬
🎬 *${botname} | HINDI MOVIES*
╰────♡◉◉◉♡────⌬

🔍 *Query:* ${q}

${resultList}

───────────────
Reply: 1 - ${top.length}

${botfooter}`;

            const firstImage = top[0]?.image || top[0]?.poster || top[0]?.thumbnail;
            let sentMsg;
            if (firstImage) {
                sentMsg = await conn.sendMessage(from, { image: { url: firstImage }, caption }, { quoted: mek });
            } else {
                sentMsg = await conn.sendMessage(from, { text: caption }, { quoted: mek });
            }

            const searchMsgId = sentMsg.key.id;

            // 2. Movie Selection Handler
            const searchHandler = async (msgUpdate) => {
                const reply = msgUpdate.messages[0];
                if (!reply?.message || !reply.key.fromMe) return;

                const isReply = reply.message?.extendedTextMessage?.contextInfo?.stanzaId === searchMsgId;
                if (!isReply) return;

                const replyText = (reply.message.conversation || reply.message.extendedTextMessage?.text || '').trim();
                const selNum = parseInt(replyText);

                if (isNaN(selNum) || selNum < 1 || selNum > top.length) {
                    return await conn.sendMessage(from, { text: `❌ *Invalid choice!* Reply between 1 and ${top.length}` }, { quoted: reply });
                }

                conn.ev.off('messages.upsert', searchHandler);
                const selected = top[selNum - 1];
                const selectedUrl = selected.link || selected.url;

                await conn.sendMessage(from, { react: { text: '⏳', key: reply.key } });

                // 3. Details API Call
                const detailsApiUrl = `https://vortex-hindubmv.vercel.app/api/details?url=${encodeURIComponent(selectedUrl)}`;
                let detailsData;
                try {
                    detailsData = await apiCallWithRetry(detailsApiUrl, 3);
                } catch (err) {
                    return await conn.sendMessage(from, { text: `❌ *Failed to fetch movie details!*` }, { quoted: reply });
                }

                if (!detailsData || !detailsData.downloads) {
                    return await conn.sendMessage(from, { text: `❌ *No download options found for this movie!*` }, { quoted: reply });
                }

                const validDownloads = detailsData.downloads.filter(d => d && d.downloadUrl);

                if (validDownloads.length === 0) {
                    return await conn.sendMessage(from, { text: `❌ *All download links are currently unavailable for this movie.*` }, { quoted: reply });
                }

                const dlList = validDownloads.map((d, i) => {
                    const quality = getQualityLabel(d.downloadUrl);
                    return `❰ ${i + 1} ❱ 📥 *${quality}*`;
                }).join('\n\n');

                const dlCaption = `╭────♡◉◉◉♡────⌬
🎬 *${botname} | QUALITIES*
╰────♡◉◉◉♡────⌬

📽️ *Title:* ${detailsData.title || selected.title}

${dlList}

───────────────
Reply: 1 - ${validDownloads.length}

${botfooter}`;

                const posterImage = detailsData.image || selected.image;
                let dlMsg;
                if (posterImage) {
                    dlMsg = await conn.sendMessage(from, { image: { url: posterImage }, caption: dlCaption }, { quoted: reply });
                } else {
                    dlMsg = await conn.sendMessage(from, { text: dlCaption }, { quoted: reply });
                }

                const dlMsgId = dlMsg.key.id;

                // 4. Download & Send Handler
                const dlHandler = async (dlUpdate) => {
                    const dlReply = dlUpdate.messages[0];
                    if (!dlReply?.message || !dlReply.key.fromMe) return;

                    const isIt = dlReply.message?.extendedTextMessage?.contextInfo?.stanzaId === dlMsgId;
                    if (!isIt) return;

                    const dlText = (dlReply.message.conversation || dlReply.message.extendedTextMessage?.text || '').trim();
                    const dlNum = parseInt(dlText);

                    if (isNaN(dlNum) || dlNum < 1 || dlNum > validDownloads.length) {
                        return await conn.sendMessage(from, { text: `❌ *Invalid quality choice!*` }, { quoted: dlReply });
                    }

                    conn.ev.off('messages.upsert', dlHandler);
                    const selectedOption = validDownloads[dlNum - 1];
                    const directLink = selectedOption.downloadUrl;

                    await conn.sendMessage(from, { react: { text: '⬇️', key: dlReply.key } });

                    let tempFilePath = '';
                    try {
                        let cleanTitle = (detailsData.title || selected.title).replace(/[^a-zA-Z0-9]/g, '_').substring(0, 40);
                        let fileName = `${cleanTitle}_${Date.now()}.mkv`;
                        tempFilePath = path.join(TEMP_DIR, fileName);

                        await conn.sendMessage(from, {
                            text: `╭────♡◉◉◉♡────⌬
📥 *DOWNLOADING MOVIE*
╰────♡◉◉◉♡────⌬

🎬 *Title:* ${detailsData.title || selected.title}
🎥 *Quality:* ${getQualityLabel(directLink)}

⏳ වීඩියෝව සර්වර් එකට බාගත වෙමින් පවතී, කරුණාකර රැඳී සිටින්න...

${botfooter}`
                        }, { quoted: dlReply });

                        await downloadWithRetry(directLink, tempFilePath, 3);

                        await conn.sendMessage(from, { react: { text: '📤', key: dlReply.key } });

                        const doneCaption = `
╭──〔 🎬 Movie Delivery 🌸 〕──⬣

૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა Your movie is ready~ 💕

🎬 Title ➜ ${detailsData.title || selected.title}
🎥 Quality ➜ ${getQualityLabel(directLink)}

━━━━━━━━━━━━━━━

🍿 Enjoy your watch time!

🌸 Thanks for using ${botname}

♡ Powered By 🌐 https://sulaofc.store

━━━━━━━━━━━━━━━`;

                        await conn.sendMessage(from, {
                            document: { url: tempFilePath },
                            mimetype: 'video/x-matroska',
                            fileName: `${cleanTitle}.mkv`,
                            caption: doneCaption
                        }, { quoted: dlReply });

                        await conn.sendMessage(from, { react: { text: '✅', key: dlReply.key } });

                    } catch (e) {
                        console.error('Hindi Download Error:', e);
                        await conn.sendMessage(from, { react: { text: '❌', key: dlReply.key } });
                        await conn.sendMessage(from, { text: `❌ *Download Failed:* ${e.message}` }, { quoted: dlReply });
                    } finally {
                        try {
                            if (tempFilePath && fs.existsSync(tempFilePath)) {
                                fs.unlinkSync(tempFilePath);
                            }
                        } catch (err) {}
                    }
                };

                conn.ev.on('messages.upsert', dlHandler);
                setTimeout(() => conn.ev.off('messages.upsert', dlHandler), 10 * 60 * 1000);
            };

            conn.ev.on('messages.upsert', searchHandler);
            setTimeout(() => conn.ev.off('messages.upsert', searchHandler), 5 * 60 * 1000);

        } catch (err) {
            console.error('Hindi Movie Plugin Error:', err.message);
            await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
            await conn.sendMessage(from, { text: `❌ *System Error:* ${err.message}` }, { quoted: mek });
        }
    }
};
