const axios = require('axios');
const yts = require('yt-search');
const { ReadData } = require('../database');

const API_BASE = 'https://vortex-api-theta.vercel.app/download/ytmp4';
const QUALITIES = ['144', '240', '360', '480', '720', '1080'];

async function downloadYT(url, quality) {
    const { data } = await axios.get(`${API_BASE}?url=${encodeURIComponent(url)}&quality=${quality}`, { timeout: 60000 });
    if (!data.status || !data.result?.dl_link) throw new Error(`${quality}p සඳහා Download Link එක ලබා ගැනීමට නොහැකි විය.`);
    return data.result;
}

module.exports = {
    name: 'video',
    alias: ['yt', 'ytdl', 'youtube', 'ytmp4', 'ytv'],
    description: 'Download YouTube Videos with Quality Selection',

    run: async ({ conn, mek, from, q, prefix }) => {
        try {
            if (!q) {
                return await conn.sendMessage(from, {
                    text: `
╭────♡◉◉◉♡────⌬
❌ *මාතෘකාවක් හෝ YouTube Link එකක් ලබා දෙන්න!*  
💔 *Please provide a search query or valid link*  
╰────♡◉◉◉♡────⌬

🔗 *Examples:*  
➤ .video https://youtu.be/xxxx
➤ .video Alan Walker Faded

───────────────
`
                }, { quoted: mek });
            }

            await conn.sendMessage(from, { react: { text: '🔍', key: mek.key } });

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'SULA MD';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© SULA MD';

            const isUrl = /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|shorts\/))([\w-]+)/.test(q);
            let videoUrl, ytdata;

            if (isUrl) {
                videoUrl = q.split('&')[0];
                const searchRes = await yts({ videoId: videoUrl.match(/(?:youtu\.be\/|v=)([\w-]+)/)?.[1] }).catch(() => null);
                
                if (searchRes) {
                    ytdata = searchRes;
                } else {
                    ytdata = {
                        title: 'YouTube Video',
                        url: videoUrl,
                        thumbnail: null,
                        author: { name: 'YouTube' },
                        views: 'N/A',
                        timestamp: 'N/A',
                        ago: 'N/A'
                    };
                }
            } else {
                const searchResults = await yts(q);
                if (!searchResults || !searchResults.videos || searchResults.videos.length === 0) {
                    return await conn.sendMessage(from, {
                        text: `❌ *වීඩියෝව සොයා ගැනීමට නොහැකි විය!*`
                    }, { quoted: mek });
                }
                ytdata = searchResults.videos[0];
                videoUrl = ytdata.url;
            }

            const menuCaption = `
╭────♡◉◉◉♡────⌬
🎬 *${botname} VIDEO DOWNLOADER*
╰────♡◉◉◉♡────⌬

📌 *Title:* ${ytdata.title}
🎬 *Channel:* ${ytdata.author?.name || 'YouTube'}
👁️ *Views:* ${ytdata.views || 'N/A'}
⏱️ *Duration:* ${ytdata.timestamp || 'N/A'}
🕒 *Uploaded:* ${ytdata.ago || 'N/A'}
🔗 *Link:* ${videoUrl}

━━━━━━━━━━━━━━━━━━━━━━
🔢 *Select Quality & Format:*

🎥 *Video Formats*
 1.1 | 144p
 1.2 | 240p
 1.3 | 360p
 1.4 | 480p
 1.5 | 720p
 1.6 | 1080p

📁 *Document Formats*
 2.1 | 144p
 2.2 | 240p
 2.3 | 360p
 2.4 | 480p
 2.5 | 720p
 2.6 | 1080p

💬 *Reply with the number to download.*

${botfooter}
`;

            const thumb = ytdata.thumbnail || ytdata.image;
            let menuMsg;

            if (thumb) {
                menuMsg = await conn.sendMessage(from, {
                    image: { url: thumb },
                    caption: menuCaption
                }, { quoted: mek });
            } else {
                menuMsg = await conn.sendMessage(from, {
                    text: menuCaption
                }, { quoted: mek });
            }

            const menuMsgId = menuMsg.key.id;

            const replyHandler = async ({ messages }) => {
                const reply = messages[0];
                if (!reply?.message) return;

                const isReply = reply.message?.extendedTextMessage?.contextInfo?.stanzaId === menuMsgId;
                if (!isReply) return;

                const replyText = (reply.message.conversation || reply.message.extendedTextMessage?.text || '').trim();
                const match = replyText.match(/^([12])\.([1-6])$/);

                if (!match) {
                    return await conn.sendMessage(from, {
                        text: `❌ *Invalid Option!*\n\nකරුණාකර අංකයක් තෝරන්න:\n➤ *1.1 - 1.6* (Video)\n➤ *2.1 - 2.6* (Document)`
                    }, { quoted: reply });
                }

                conn.ev.off('messages.upsert', replyHandler);

                const formatType = match[1];
                const qualityIndex = parseInt(match[2]) - 1;
                const quality = QUALITIES[qualityIndex];
                const isVideo = formatType === '1';

                await conn.sendMessage(from, { react: { text: '⏳', key: reply.key } });
                await conn.sendMessage(from, {
                    text: `⬇️ *Downloading ${quality}p ${isVideo ? 'Video' : 'Document'}...*`
                }, { quoted: reply });

                try {
                    const result = await downloadYT(videoUrl, quality);
                    const dlUrl = result.dl_link;
                    const title = result.title || ytdata.title;

                    const caption = `
╭────♡◉◉◉♡────⌬
🎬 *YOUTUBE DOWNLOAD COMPLETED*
🌸 *${botname}*
╰────♡◉◉◉♡────⌬

📌 *Title:* ${title}
🎬 *Quality:* ${quality}p
📁 *Format:* ${isVideo ? 'Video' : 'Document'}

${botfooter}
`;

                    const cleanFileName = title.replace(/[^a-zA-Z0-9\s]/g, '').trim().replace(/\s+/g, '_') + `_${quality}p.mp4`;

                    if (isVideo) {
                        await conn.sendMessage(from, {
                            video: { url: dlUrl },
                            mimetype: 'video/mp4',
                            fileName: cleanFileName,
                            caption: caption
                        }, { quoted: reply });
                    } else {
                        await conn.sendMessage(from, {
                            document: { url: dlUrl },
                            mimetype: 'video/mp4',
                            fileName: cleanFileName,
                            caption: caption
                        }, { quoted: reply });
                    }

                    await conn.sendMessage(from, { react: { text: '✅', key: reply.key } });

                } catch (e) {
                    await conn.sendMessage(from, {
                        text: `❌ *Download Failed:* ${e.message}\n\n🔄 කරුණාකර වෙනත් Quality එකක් උත්සාහ කරන්න.`
                    }, { quoted: reply });
                    await conn.sendMessage(from, { react: { text: '❌', key: reply.key } });
                }
            };

            conn.ev.on('messages.upsert', replyHandler);
            setTimeout(() => conn.ev.off('messages.upsert', replyHandler), 5 * 60 * 1000);

        } catch (err) {
            await conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
            await conn.sendMessage(from, {
                text: `❌ *Error:* ${err.message}`
            }, { quoted: mek });
        }
    }
};

