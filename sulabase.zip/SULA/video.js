const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('ffmpeg-static');
const { ReadData } = require('../database');

ffmpeg.setFfmpegPath(ffmpegPath);

module.exports = {
    name: 'video',
    alias: ['ytmp4', 'ytvideo', 'ytv'],

    run: async ({ conn, mek, from, q }) => {

        try {

            // 📌 CHECK URL
            if (!q || !q.startsWith('http')) {

                return conn.sendMessage(from, {
                    text: `
╭────♡◉◉◉♡────⌬
❌ *Invalid YouTube URL!*  
💔 *Please provide a valid YouTube link*  
╰────♡◉◉◉♡────⌬

🔗 *Example:*  
➤ .video https://youtu.be/xxxx

───────────────

✨ Supported:
• YouTube Videos
• Shorts
• Music Videos

───────────────
`
                }, { quoted: mek });

            }

            // 📌 REACT
            await conn.sendMessage(from, {
                react: { text: '⏳', key: mek.key }
            });

            // 📌 BOT DATA
            const number = conn.user.id.split(':')[0];

            const botname =
                await ReadData(number, 'BOT_NAME') || 'SULA MD';

            const botfooter =
                await ReadData(number, 'BOT_FOOTER') || '© SULA MD';

            // 📌 TEMP FILES
            let filePath;
            let fixedPath;

            // 📌 DOWNLOAD FUNCTION
            const downloadFile = async (url, output) => {

                const res = await axios({
                    method: 'GET',
                    url,
                    responseType: 'stream',
                    timeout: 300000,
                    maxRedirects: 10,
                    headers: {
                        'User-Agent': 'Mozilla/5.0',
                        'Accept': '*/*'
                    }
                });

                await new Promise((resolve, reject) => {

                    const writer = fs.createWriteStream(output);

                    res.data.pipe(writer);

                    writer.on('finish', resolve);
                    writer.on('error', reject);

                });

            };

            // 📌 FIX MP4
            const fixMp4 = (input, output) => {

                return new Promise((resolve, reject) => {

                    ffmpeg(input)
                        .outputOptions([
                            '-c copy',
                            '-movflags +faststart'
                        ])
                        .save(output)
                        .on('end', resolve)
                        .on('error', reject);

                });

            };

            // 📌 API
            const metaApi =
                `https://ytmp4-api.netlify.app/api/ytmp4?url=${encodeURIComponent(q)}&quality=360p&meta=true`;

            const { data } = await axios.get(metaApi, {
                timeout: 180000,
                headers: {
                    'User-Agent': 'Mozilla/5.0'
                }
            });

            // 📌 CHECK API
            if (!data?.success) {

                throw new Error(data?.error || 'API failed');

            }

            // 📌 META
            const meta = data.metadata?.data || {};

            const title =
                meta.title || data.title || 'YouTube Video';

            const thumb =
                meta.thumbnail || '';

            const duration =
                meta.durationFormatted || 'N/A';

            const uploader =
                meta.uploader || 'Unknown';

            // 📌 PANEL
            const caption = `
╭────♡◉◉◉♡────⌬
🎬 *YOUTUBE VIDEO READY!*  
🌸 *${botname} prepared your video ✨*
╰────♡◉◉◉♡────⌬

📌 *Title:*  
➤ ${title}

👤 *Uploader:* ${uploader}
⏱️ *Duration:* ${duration}

───────────────

📥 *Choose Quality:*

❶ 🚀 360P Fast  
❷ 📱 480P SD  
❸ 🎬 720P HD  
❹ 💎 1080P Full HD

───────────────

💌 *Reply:* 1 / 2 / 3 / 4

${botfooter}
`;

            // 📌 SEND PANEL
            const sentMsg = await conn.sendMessage(from, {
                image: { url: thumb },
                caption
            }, { quoted: mek });

            let timeout;

            // 📌 LISTENER
            const listener = async (msgUpdate) => {

                const msg = msgUpdate.messages[0];

                try {

                    if (!msg.message) return;

                    const text =
                        msg.message.conversation ||
                        msg.message.extendedTextMessage?.text;

                    const isReply =
                        msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                    if (!isReply) return;

                    let quality;

                    // 📌 QUALITY
                    if (text === '1') quality = '360p';
                    else if (text === '2') quality = '480p';
                    else if (text === '3') quality = '720p';
                    else if (text === '4') quality = '1080p';

                    else {

                        return conn.sendMessage(from, {
                            text: `
╭────♡◉◉◉♡────⌬
❌ *Invalid Reply!*  
💔 *Please choose a valid option*  
╰────♡◉◉◉♡────⌬

📌 Reply only with:

➤ 1 = 360P  
➤ 2 = 480P  
➤ 3 = 720P  
➤ 4 = 1080P

───────────────

${botfooter}
`
                        }, { quoted: msg });

                    }

                    clearTimeout(timeout);

                    conn.ev.off('messages.upsert', listener);

                    // 📌 REACT
                    await conn.sendMessage(from, {
                        react: { text: '⬇️', key: msg.key }
                    });

                    // 📌 DIRECT URL
                    const directUrl =
                        `https://ytmp4-api.netlify.app/api/ytmp4?url=${encodeURIComponent(q)}&quality=${quality}&direct=true`;

                    // 📌 CLEAN FILE NAME
                    const cleanName = title
                        .replace(/[\\/:*?"<>|]/g, '')
                        .trim()
                        .slice(0, 60) || 'youtube_video';

                    // 📌 TEMP PATHS
                    filePath = path.join(
                        os.tmpdir(),
                        `${Date.now()}_${cleanName}.mp4`
                    );

                    fixedPath = path.join(
                        os.tmpdir(),
                        `${Date.now()}_${cleanName}_fixed.mp4`
                    );

                    // 📌 DOWNLOAD
                    await downloadFile(directUrl, filePath);

                    // 📌 CHECK FILE
                    if (
                        !fs.existsSync(filePath) ||
                        fs.statSync(filePath).size < 100000
                    ) {

                        throw new Error(
                            'Downloaded file is empty or invalid'
                        );

                    }

                    // 📌 FIX VIDEO
                    await fixMp4(filePath, fixedPath);

                    // 📌 CHECK FIXED FILE
                    if (
                        !fs.existsSync(fixedPath) ||
                        fs.statSync(fixedPath).size < 100000
                    ) {

                        throw new Error(
                            'Fixed MP4 invalid'
                        );

                    }

                    // 📌 SUCCESS CAPTION
                    const videoCaption = `
╭────♡◉◉◉♡────⌬
✅ *DOWNLOAD COMPLETE*
🎬 *${botname} YTMP4*
╰────♡◉◉◉♡────⌬

📌 ${title}
💎 *Quality:* ${quality}

${botfooter}
`;

                    // 📌 SEND VIDEO
                    await conn.sendMessage(from, {
                        video: fs.readFileSync(fixedPath),
                        mimetype: 'video/mp4',
                        fileName: `${cleanName}.mp4`,
                        caption: videoCaption,
                        ptv: false
                    }, { quoted: msg });

                    // 📌 SUCCESS REACT
                    await conn.sendMessage(from, {
                        react: { text: '✅', key: msg.key }
                    });

                    // 📌 DELETE FILES
                    if (fs.existsSync(filePath)) {
                        fs.unlinkSync(filePath);
                    }

                    if (fs.existsSync(fixedPath)) {
                        fs.unlinkSync(fixedPath);
                    }

                } catch (err) {

                    conn.ev.off('messages.upsert', listener);

                    // 📌 DELETE FILES
                    if (filePath && fs.existsSync(filePath)) {
                        fs.unlinkSync(filePath);
                    }

                    if (fixedPath && fs.existsSync(fixedPath)) {
                        fs.unlinkSync(fixedPath);
                    }

                    // ❌ ERROR MESSAGE
                    await conn.sendMessage(from, {
                        text: `
╭────♡◉◉◉♡────⌬
❌ *Download Failed!*  
💔 *${botname} couldn't process your video*  
╰────♡◉◉◉♡────⌬

⚠️ *Reason:*  
➤ ${err.message}

───────────────

📌 *Possible Causes:*  
• Video too large  
• Unsupported quality  
• API temporarily down  
• Slow internet/server issue  

───────────────

🔄 *Try 360P Fast option.*

${botfooter}
`
                    }, { quoted: msg });

                }
            };

            timeout = setTimeout(() => {

                conn.ev.off('messages.upsert', listener);

            }, 60000);

            conn.ev.on('messages.upsert', listener);

        } catch (err) {

            await conn.sendMessage(from, {
                text: `
╭────♡◉◉◉♡────⌬
❌ *YTMP4 Download Failed!*  
💔 *Unable to fetch YouTube video*  
╰────♡◉◉◉♡────⌬

⚠️ *Reason:*  
➤ ${err.message}

───────────────

📌 *Possible Causes:*  
• Invalid YouTube link  
• Video unavailable  
• API temporarily down  
• Unsupported video  

───────────────

🔄 *Please try again later.*

${botfooter}
`
            }, { quoted: mek });

            // ❌ REACT
            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });

        }
    }
};
