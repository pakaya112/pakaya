const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'tvseries',
    alias: ['series', 'tv'],

    run: async ({ conn, mek, from, q }) => {

        if (!mek.key.fromMe) {
            return await conn.sendMessage(from, {
                text: `❌ You are not allowed to use this command.

Want access to this feature?

Create your own bot:
🌐 https://sulaofc.store/bots`
            }, { quoted: mek });
        }

        const number = conn.user.id.split(':')[0];
        const botname = await ReadData(number, 'BOT_NAME') || 'SULA MD';
        const botfooter = await ReadData(number, 'BOT_FOOTER') || '© SULA MD';

        if (!q) {
            return conn.sendMessage(from, {
                text: `╭────♡◉◉◉♡────⌬
📺 *TV Series Search*
╰────♡◉◉◉♡────⌬

Example:

.tvseries batman

.tvseries 9476xxxxxxx@s.whatsapp.net batman

${botfooter}`
            }, { quoted: mek });
        }

        const args = q.trim().split(' ');
        let targetJid = null;
        let searchQuery = q;
        let isCustomTarget = false;

        if (
            args[0]?.includes('@s.whatsapp.net') ||
            args[0]?.includes('@g.us') ||
            args[0]?.includes('@lid')
        ) {
            targetJid = args[0];
            searchQuery = args.slice(1).join(' ');
            isCustomTarget = true;
        }

        await conn.sendMessage(from, {
            react: { text: '🔍', key: mek.key }
        });

        try {
            const searchApi = `https://apis.davidcyriltech.my.id/movies/search?q=${encodeURIComponent(searchQuery)}&limit=10`;
            const { data: searchData } = await axios.get(searchApi, { timeout: 15000 });

            if (!searchData.success || !searchData.results?.length) {
                throw new Error('No results found for: ' + searchQuery);
            }

            const results = searchData.results;
            const list = results.map((r, i) => {
                const eps = r.downloadLinks?.length || 0;
                return `❰ ${i + 1} ❱ *${r.title}*\n🎞️ ${eps} episodes | 📅 ${r.date || 'N/A'}`;
            }).join('\n\n');

            const caption = `╭────♡◉◉◉♡────⌬
📺 *TV Series Search Results*
╰────♡◉◉◉♡────⌬

${list}

───────────────

Reply: 1 - ${results.length}

${botfooter}`;

            const sentMsg = await conn.sendMessage(
                from,
                {
                    image: { url: results[0]?.thumbnail || 'https://raw.githubusercontent.com/sulamadara1147/data/main/sula.jpg' },
                    caption
                },
                { quoted: mek }
            );

            let timer;
            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];
                if (!msg.message) return;

                const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                if (!isReply) return;

                const index = parseInt(text) - 1;
                if (isNaN(index) || !results[index]) {
                    return conn.sendMessage(from, { text: '❌ Invalid Selection' }, { quoted: msg });
                }

                clearTimeout(timer);
                conn.ev.off('messages.upsert', listener);

                const selected = results[index];
                await conn.sendMessage(from, { react: { text: '📥', key: msg.key } });

                return await showSeriesDetails(conn, msg, from, targetJid, isCustomTarget, selected, botname, botfooter);
            };

            conn.ev.on('messages.upsert', listener);
            timer = setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (err) {
            return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: mek });
        }
    }
};

async function showSeriesDetails(conn, quotedMsg, from, targetJid, isCustomTarget, selected, botname, botfooter) {
    try {
        const infoApi = `https://apis.davidcyriltech.my.id/movies/info?url=${encodeURIComponent(selected.url)}`;
        const { data: info } = await axios.get(infoApi, { timeout: 15000 });

        if (!info.success || !info.result) {
            throw new Error('Failed to load series details');
        }

        const result = info.result;
        const links = result.downloadLinks || selected.downloadLinks || [];

        if (links.length === 0) {
            throw new Error('No episodes found');
        }

        const epList = links.slice(0, 30).map((link, i) => {
            const raw = link.split('/').pop().replace('.html', '');
            const clean = raw.replace(/\.(THENKIRI|NKIRI)\.COM\./gi, '.').replace(/\(.*?\)/g, '').trim();
            return `❰ ${i + 1} ❱ ${clean}`;
        }).join('\n');

        const seriesTitle = result.title || selected.title;
        const thumb = result.thumbnail || selected.thumbnail;

        const sentMsg = await conn.sendMessage(
            from,
            {
                image: { url: thumb },
                caption: `╭────♡◉◉◉♡────⌬
📺 *${seriesTitle}*
╰────♡◉◉◉♡────⌬

📅 Date: ${result.date || selected.date || 'N/A'}
🎞️ Episodes: ${links.length}

${epList}

───────────────

Reply: 1 - ${links.length > 30 ? 30 : links.length}

${botfooter}`
            },
            { quoted: quotedMsg }
        );

        let timer;
        const listener = async (msgUpdate) => {
            const msg = msgUpdate.messages[0];
            if (!msg.message) return;

            const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
            const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

            if (!isReply) return;

            const index = parseInt(text) - 1;
            if (isNaN(index) || !links[index]) {
                return conn.sendMessage(from, { text: '❌ Invalid Episode Number' }, { quoted: msg });
            }

            clearTimeout(timer);
            conn.ev.off('messages.upsert', listener);

            const epUrl = links[index];
            await conn.sendMessage(from, { react: { text: '⬇️', key: msg.key } });

            await downloadAndSendEpisode(conn, msg, from, targetJid, isCustomTarget, epUrl, seriesTitle, index + 1, botname);
        };

        conn.ev.on('messages.upsert', listener);
        timer = setTimeout(() => conn.ev.off('messages.upsert', listener), 60000);

    } catch (err) {
        return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: quotedMsg });
    }
}

async function downloadAndSendEpisode(conn, quotedMsg, from, targetJid, isCustomTarget, epUrl, seriesTitle, epNum, botname) {
    try {
        const dlApi = `https://apis.davidcyriltech.my.id/nkiri/download?url=${encodeURIComponent(epUrl)}`;
        const { data: dl } = await axios.get(dlApi, { timeout: 30000 });

        if (!dl.success || !dl.download_url) {
            throw new Error('Failed to get download link. Try again.');
        }

        const doneCaption = `
╭──〔 🌸 TV Series Delivery 🌸 〕──⬣

૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა Your episode is ready~ 💕

🎬 Series ➜ ${seriesTitle}
🎞️ Episode ➜ ${epNum}
💾 Size ➜ ${dl.size || 'N/A'}

━━━━━━━━━━━━━━━

🍿 Enjoy your watch time!

🌸 Thanks for using ${botname}

♡ Powered By 🌐 https://sulaofc.store

movies • series • updates

━━━━━━━━━━━━━━━`;

        const fileName = (dl.filename || `${seriesTitle}_EP${epNum}.mkv`)
            .replace(/[\\/:*?"<>|]/g, '')
            .trim();

        await conn.sendMessage(
            targetJid || from,
            {
                document: { url: dl.download_url },
                mimetype: 'video/x-matroska',
                fileName,
                caption: doneCaption
            },
            { quoted: quotedMsg }
        );

        if (isCustomTarget && targetJid) {
            await conn.sendMessage(
                from,
                {
                    text: `✅ Successfully Sent\n\n📤 To:\n${targetJid}`
                },
                { quoted: quotedMsg }
            );
        }

        await conn.sendMessage(from, { react: { text: '✅', key: quotedMsg.key } });

    } catch (err) {
        return conn.sendMessage(from, { text: `❌ ${err.message}` }, { quoted: quotedMsg });
    }
}
