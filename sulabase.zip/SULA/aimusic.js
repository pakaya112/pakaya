const axios = require('axios');
const { ReadData, WriteData } = require('../database');

const API_BASE = 'https://apis.davidcyriltech.my.id/ai/music/remusic';
const DAILY_LIMIT = 5;

module.exports = {
    name: 'aimusic',
    alias: ['musicia', 'songgen', 'remusic', 'genmusic'],
    category: 'ai',
    description: 'Generates AI music tracks with custom lyrics, styles, and a daily rate limit.',

    run: async ({ conn, client, mek, from, q }) => {
        const botClient = conn || client;
        const botfooter = 'Thenux - www.thenuxofc.store';

        // 1. Resolve User Identifier & Today's Date
        const senderJid = mek.key.participant || from;
        const senderNumber = senderJid.split('@')[0];
        const todayDate = new Date().toISOString().slice(0, 10); // YYYY-MM-DD format

        // 2. Check Daily Limit from Database
        const userUsageKey = `AIMUSIC_USAGE_${senderNumber}`;
        let usageData = { date: todayDate, count: 0 };

        try {
            const rawStored = await ReadData(senderNumber, userUsageKey);
            if (rawStored) {
                const parsed = typeof rawStored === 'string' ? JSON.parse(rawStored) : rawStored;
                // If the stored record is from today, retain the count; otherwise reset to 0
                if (parsed.date === todayDate) {
                    usageData = parsed;
                }
            }
        } catch (e) {
            usageData = { date: todayDate, count: 0 };
        }

        if (usageData.count >= DAILY_LIMIT) {
            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
🚫 *DAILY LIMIT REACHED*
╰───────────♡◉◉◉♡───────────⌬

You have used all of your daily music generations.

📊 *Usage Tracker:*
• *Daily Limit:* ${DAILY_LIMIT} / ${DAILY_LIMIT} used
• *Reset Time:* Midnight (00:00 UTC)

Please come back tomorrow to generate more music!

${botfooter}`
            }, { quoted: mek });
        }

        // 3. Display Help Menu If No Prompt is Provided
        if (!q || !q.trim()) {
            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
🎵 *SULA MD | AI MUSIC STUDIO*
╰───────────♡◉◉◉♡───────────⌬

Create full studio-grade songs with custom vocals, styles, and instruments.

📊 *Daily Quota:* \`${DAILY_LIMIT - usageData.count} / ${DAILY_LIMIT} remaining today\`

✨ *Usage Formats:*
• *Simple Prompt:*
  ➤ \`.aimusic quiet night\`

• *With Custom Lyrics & Style:*
  ➤ \`.aimusic quiet night | Lo-fi, Chill | Stars shine bright in the quiet night...\`

• *View Supported Styles:*
  ➤ \`.aimusic --styles\`

${botfooter}`
            }, { quoted: mek });
        }

        const cleanInput = q.trim();

        // 4. Styles & Genres Catalog
        if (cleanInput.toLowerCase() === '--styles' || cleanInput.toLowerCase() === 'styles') {
            await botClient.sendMessage(from, { react: { text: '📜', key: mek.key } });

            const stylesList = `╭───────────♡◉◉◉♡───────────⌬
🎼 *AVAILABLE REMUSIC STYLES*
╰───────────♡◉◉◉♡───────────⌬

🎸 *Popular Genres:*
Pop, Rock, Hip-Hop, R&B, Jazz, EDM, Lo-fi, Ambient, Reggae, Metal, Blues, Funk, Soul, Synthwave, Acoustic, Bossa Nova.

✨ *Moods:*
Calm, Happy, Sad, Energetic, Romantic, Epic, Dark, Dreamy, Melancholic, Chill, Peaceful, Nostalgic.

🎙️ *Vocals:*
Male Vocal, Female Vocal, Duet, Choir, Soft Vocal, Powerful Vocal, Rap, Whisper.

⚡ *Tempo:*
Slow, Mid-tempo, Upbeat, Fast.

${botfooter}`;
            return botClient.sendMessage(from, { text: stylesList }, { quoted: mek });
        }

        // 5. Parse Parameters (Title/Prompt | Styles | Custom Lyrics)
        let songTitle = 'quiet night';
        let promptText = 'quiet night';
        let styleTags = 'Lo-fi, Chill';
        let customLyrics = '';

        if (cleanInput.includes('|')) {
            const parts = cleanInput.split('|').map(p => p.trim());
            promptText = parts[0] || 'quiet night';
            songTitle = parts[0] || 'quiet night';
            styleTags = parts[1] || 'Lo-fi, Chill';
            customLyrics = parts[2] || '';
        } else if (cleanInput.includes('\n')) {
            const lines = cleanInput.split('\n').filter(l => l.trim().length > 0);
            promptText = lines[0] || 'quiet night';
            songTitle = lines[0] || 'quiet night';
            customLyrics = lines.join('\n');
            styleTags = 'Lo-fi, Chill';
        } else {
            promptText = cleanInput;
            songTitle = cleanInput;
        }

        await botClient.sendMessage(from, { react: { text: '🎵', key: mek.key } });

        // 6. Initial Progress Notification
        const queueNotice = `╭───────────♡◉◉◉♡───────────⌬
🎧 *STUDIO COMPOSER INITIALIZED*
╰───────────♡◉◉◉♡───────────⌬

🏷️ *Title:* *${songTitle}*
🎼 *Prompt:* _${promptText}_
🎨 *Styles:* \`${styleTags}\`
📊 *Quota Left:* \`${DAILY_LIMIT - usageData.count - 1} / ${DAILY_LIMIT}\`
${customLyrics ? `📜 *Custom Lyrics:* \`Attached (${customLyrics.split('\n').length} lines)\`\n` : ''}
⏳ *Status:* Rendering audio stems & vocal track (~2-4 mins).
Please hold on, your audio file will be delivered directly when complete.

⚡ *Engine:* \`ai.thenuxofc.store Studio\`
${botfooter}`;

        await botClient.sendMessage(from, { text: queueNotice }, { quoted: mek });

        try {
            // Build query parameters
            const queryParams = {
                prompt: promptText,
                styles: styleTags,
                title: songTitle
            };
            if (customLyrics) {
                queryParams.lyrics = customLyrics;
            }

            const res = await axios.get(API_BASE, {
                params: queryParams,
                timeout: 360000 // 6-minute timeout
            });

            const data = res.data;
            if (!data || !data.success || !data.result) {
                throw new Error(data?.message || 'Music API did not return a valid result payload.');
            }

            const result = data.result;
            let audioUrl = result.audio_url || result.songs?.[0]?.audio;
            let coverImage = result.image_url || result.songs?.[0]?.image || 'https://files.catbox.moe/xiy0uc.jpg';
            let title = result.title || result.songs?.[0]?.title || songTitle;
            let lyrics = result.lyrics || result.songs?.[0]?.lyrics || customLyrics || 'In the quiet night, stars are shining bright...';
            let tags = result.tags || styleTags;
            let songId = result.songs?.[0]?.id;

            // Status Polling Handler
            if (!audioUrl && songId) {
                const statusEndpoint = `https://apis.davidcyriltech.my.id/ai/music/remusic/status/${songId}`;
                for (let attempt = 0; attempt < 24; attempt++) {
                    await new Promise(resolve => setTimeout(resolve, 10000));
                    try {
                        const statusCheck = await axios.get(statusEndpoint, { timeout: 20000 });
                        if (statusCheck.data?.success && statusCheck.data?.result) {
                            const pollRes = statusCheck.data.result;
                            const foundAudio = pollRes.audio_url || pollRes.songs?.[0]?.audio || (pollRes.status === 'success' ? pollRes.audio : null);
                            if (foundAudio) {
                                audioUrl = foundAudio;
                                if (pollRes.image_url || pollRes.songs?.[0]?.image) {
                                    coverImage = pollRes.image_url || pollRes.songs?.[0]?.image;
                                }
                                break;
                            }
                        }
                    } catch (pollErr) {
                        console.warn(`Polling attempt ${attempt + 1} skipped:`, pollErr.message);
                    }
                }
            }

            if (!audioUrl) {
                throw new Error('Song composition timed out. Please try again with shorter lyrics or simpler style tags.');
            }

            // 7. Increment and Save Usage Count After Successful Generation
            usageData.count += 1;
            try {
                if (typeof WriteData === 'function') {
                    await WriteData(senderNumber, userUsageKey, JSON.stringify(usageData));
                }
            } catch (saveErr) {
                console.warn('Could not save usage count:', saveErr.message);
            }

            const displayLyrics = lyrics.length > 400 ? lyrics.substring(0, 400) + '\n...[Full lyrics in audio track]' : lyrics;

            const releaseCard = `╭───────────♡◉◉◉♡───────────⌬
🎶 *SULA MD | MUSIC STUDIO RELEASE*
╰───────────♡◉◉◉♡───────────⌬

🏷️ *Title:* *${title}*
🎨 *Style Tags:* \`${tags}\`
📊 *Remaining Today:* \`${DAILY_LIMIT - usageData.count} / ${DAILY_LIMIT}\`

📜 *Lyrics Snapshot:*
\`\`\`
${displayLyrics}
\`\`\`

───────────────
🎧 *Audio track is attached below...*
👑 *Creator:* Thenux
${botfooter}`;

            // Send Cover Image
            await botClient.sendMessage(from, {
                image: { url: coverImage },
                caption: releaseCard
            }, { quoted: mek });

            // Send Audio File
            await botClient.sendMessage(from, {
                audio: { url: audioUrl },
                mimetype: 'audio/mp4',
                fileName: `${title.replace(/[^a-zA-Z0-9 ]/g, '')}.mp3`,
                ptt: false
            }, { quoted: mek });

            await botClient.sendMessage(from, { react: { text: '✅', key: mek.key } });

        } catch (err) {
            console.error('❌ [AIMUSIC Error]:', err);
            await botClient.sendMessage(from, { react: { text: '❌', key: mek.key } });

            return botClient.sendMessage(from, {
                text: `╭───────────♡◉◉◉♡───────────⌬
❌ *MUSIC GENERATION FAILED*
╰───────────♡◉◉◉♡───────────⌬

📌 *Reason:* 
➤ ${err.message}

💡 *Note:* Failed generations do not consume your daily quota.

${botfooter}`
            }, { quoted: mek });
        }
    }
};
