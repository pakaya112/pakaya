const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'xvideo',
    alias: ['xvd', 'xvdl'],
    category: 'nsfw',
    description: 'Search and download XVideos content.',

    run: async ({ conn, mek, from, q }) => {
        try {
            if (!mek.key.fromMe) {
                return await conn.sendMessage(from, {
                    text: `❌ You are not allowed to use this command.\n\nWant access to this feature?\n\nCreate your own bot:\n🌐 https://sulaofc.store/bots`
                }, { quoted: mek });
            }

            const number = conn.user.id.split(':')[0];
            const botname = await ReadData(number, 'BOT_NAME') || 'SULA MD';
            const botfooter = await ReadData(number, 'BOT_FOOTER') || '© SULA MD';

            if (!q || !q.trim()) {
                return conn.sendMessage(from, {
                    text: `╭────♡◉◉◉♡────⌬
🔞 *XVideos Search*
╰────♡◉◉◉♡────⌬

Example:
.xvideo japan

${botfooter}`
                }, { quoted: mek });
            }

            const args = q.trim().split(' ');
            let targetJid = null;
            let searchQuery = q;
            let isCustomTarget = false;

            if (
                args[0]?.includes('@s.whatsapp.net') ||
                args[0]?.includes('@g.us') ||
                args[0]?.includes('@lid')
            ) {
                targetJid = args[0];
                searchQuery = args.slice(1).join(' ');
                isCustomTarget = true;
            }

            await conn.sendMessage(from, {
                react: { text: '🔍', key: mek.key }
            });

            const searchApi = `https://apis.davidcyriltech.my.id/search/xvideo?text=${encodeURIComponent(searchQuery)}`;
            const { data } = await axios.get(searchApi, { timeout: 15000 });

            if (!data.success || !data.result || data.result.length === 0) {
                return await conn.sendMessage(from, {
                    text: `❌ *No results found for:* ${searchQuery}`
                }, { quoted: mek });
            }

            const results = data.result.slice(0, 10);
            const list = results.map((v, i) =>
                `❰ ${i + 1} ❱ *${v.title}*\n⏱️ Duration: ${v.duration || 'N/A'}`
            ).join('\n\n');

            const caption = `╭────♡◉◉◉♡────⌬
🔞 *XVideos Search Results*
╰────♡◉◉◉♡────⌬

${list}

───────────────

Reply: 1 - ${results.length}

${botfooter}`;

            const sentMsg = await conn.sendMessage(
                from,
                {
                    image: { url: results[0]?.thumbnail || 'https://raw.githubusercontent.com/sulamadara1147/data/main/file_00000000097071fabaedacd96b9efefc.png' },
                    caption
                },
                { quoted: mek }
            );

            let timer;
            const listener = async (msgUpdate) => {
                const msg = msgUpdate.messages[0];
                if (!msg.message) return;

                const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
                const isReply = msg.message?.extendedTextMessage?.contextInfo?.stanzaId === sentMsg.key.id;

                if (!isReply) return;

                const index = parseInt(text) - 1;
                if (isNaN(index) || !results[index]) {
                    return conn.sendMessage(from, { text: '❌ Invalid Selection' }, { quoted: msg });
                }

                clearTimeout(timer);
                conn.ev.off('messages.upsert', listener);

                const selectedVideo = results[index];

                await conn.sendMessage(from, {
                    react: { text: '📥', key: msg.key }
                });

                try {
                    const dlApi = `https://apis.davidcyriltech.my.id/xvideo?url=${encodeURIComponent(selectedVideo.url)}`;
                    const { data: dlData } = await axios.get(dlApi, { timeout: 30000 });

                    if (!dlData?.download_url) {
                        return await conn.sendMessage(from, {
                            text: '❌ *Failed to fetch download link. Try again.*'
                        }, { quoted: msg });
                    }

                    const doneCaption = `
╭──〔 🔞 Video Delivery 🌸 〕──⬣

૮₍ ˶ᵔ ᵕ ᵔ˶ ₎ა Your video is ready~ 💕

🎬 Title ➜ ${dlData.title || selectedVideo.title}
⏱️ Duration ➜ ${selectedVideo.duration || 'N/A'}

━━━━━━━━━━━━━━━

🍿 Enjoy your watch time!

🌸 Thanks for using ${botname}

♡ Powered By 🌐 https://sulaofc.store

━━━━━━━━━━━━━━━`;

                    const cleanTitle = (dlData.title || selectedVideo.title || 'video')
                        .replace(/[\\/:*?"<>|]/g, '')
                        .trim();

                    await conn.sendMessage(
                        targetJid || from,
                        {
                            document: { url: dlData.download_url },
                            mimetype: 'video/mp4',
                            fileName: `${cleanTitle}.mp4`,
                            caption: doneCaption
                        },
                        { quoted: msg }
                    );

                    if (isCustomTarget && targetJid) {
                        await conn.sendMessage(
                            from,
                            {
                                text: `✅ Successfully Sent\n\n📤 To:\n${targetJid}`
                            },
                            { quoted: msg }
                        );
                    }

                    await conn.sendMessage(from, {
                        react: { text: '✅', key: msg.key }
                    });

                } catch (dlErr) {
                    await conn.sendMessage(from, {
                        text: `❌ *Download Error:* ${dlErr.message}`
                    }, { quoted: msg });
                }
            };

            conn.ev.on('messages.upsert', listener);
            timer = setTimeout(() => {
                conn.ev.off('messages.upsert', listener);
            }, 60000);

        } catch (err) {
            await conn.sendMessage(from, {
                text: `❌ ${err.message || 'Error fetching video!'}`
            }, { quoted: mek });
        }
    }
};
