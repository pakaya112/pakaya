const axios = require('axios');
const { ReadData } = require('../database');

module.exports = {
    name: 'comicdl',
    alias: ['comic', 'animedl'],
    run: async ({ conn, mek, from, q }) => {

        const number = conn.user.id.split(':')[0];

        const botname =
            await ReadData(number, 'BOT_NAME');

        const botfooter =
            await ReadData(number, 'BOT_FOOTER');

        // ❌ NO QUERY
        if (!q) {

            return conn.sendMessage(from, {
                text: `
╭────♡◉◉◉♡────⌬
❌ *Missing Query*
✨ *${botname} Comic System*
╰────♡◉◉◉♡────⌬

📚 *Search Example:*  
➤ .comic Spider Man

🔗 *Direct Link:*  
➤ .comic https://xxxx.com

───────────────

💌 *Please Enter A Query*

${botfooter}
`
            }, { quoted: mek });
        }

        await conn.sendMessage(from, {
            react: { text: '⏳', key: mek.key }
        });

        try {

            const isUrl = q.startsWith('http');

            const apiUrl = isUrl
                ? `https://thenuxanime-dl.netlify.app/api/anime?url=${encodeURIComponent(q)}`
                : `https://thenuxanime-dl.netlify.app/api/anime?q=${encodeURIComponent(q)}`;

            const { data } = await axios.get(apiUrl, {
                timeout: 120000,
                headers: {
                    'User-Agent': 'Mozilla/5.0'
                }
            });

            // ❌ NO RESULT
            if (!data?.success) {

                return conn.sendMessage(from, {
                    react: { text: '❌', key: mek.key }
                });

            }

            // ================= SEARCH MODE =================

            if (data.type === 'search') {

                const results = data.results || [];

                // ❌ EMPTY RESULTS
                if (!results.length) {

                    return conn.sendMessage(from, {
                        text: `
╭────♡◉◉◉♡────⌬
❌ *No Results Found*
✨ *${botname} Search System*
╰────♡◉◉◉♡────⌬

🔎 *Query:*  
➤ ${q}

📦 *Results:*  
➤ 0

───────────────

💌 *Try Another Search*

${botfooter}
`
                    }, { quoted: mek });
                }

                const list = results
                    .slice(0, 10)
                    .map((r, i) =>
                        `❰ ${i + 1} ❱ *${r.title}*\n➤ ${r.description || 'No Description'}`
                    )
                    .join('\n\n');

                const caption = `
╭────♡◉◉◉♡────⌬
📚 *Comic Search Panel*
✨ *${botname} Search Results*
╰────♡◉◉◉♡────⌬

🔎 *Query:*  
➤ ${q}

📦 *Results Found:*  
➤ ${results.length}

───────────────

${list}

───────────────

💌 *Reply 1 - ${Math.min(results.length, 10)}*

${botfooter}
`;

                const sentMsg = await conn.sendMessage(from, {
                    image: {
                        url: results[0]?.image || ''
                    },
                    caption
                }, { quoted: mek });

                const listener = async (msgUpdate) => {

                    try {

                        const msg = msgUpdate.messages[0];

                        if (!msg.message) return;

                        const text =
                            msg.message.conversation ||
                            msg.message.extendedTextMessage?.text;

                        const isReply =
                            msg.message.extendedTextMessage
                                ?.contextInfo?.stanzaId === sentMsg.key.id;

                        if (!isReply) return;

                        const index = parseInt(text) - 1;

                        // ❌ INVALID REPLY
                        if (isNaN(index) || !results[index]) {

                            return conn.sendMessage(from, {
                                text: `
╭────♡◉◉◉♡────⌬
❌ *Invalid Reply*
✨ *${botname} Comic System*
╰────♡◉◉◉♡────⌬

💌 *Reply Only:*  
➤ 1 - ${Math.min(results.length, 10)}

${botfooter}
`
                            }, { quoted: msg });
                        }

                        conn.ev.off('messages.upsert', listener);

                        await conn.sendMessage(from, {
                            react: { text: '📥', key: msg.key }
                        });

                        await handlePost(
                            conn,
                            msg,
                            from,
                            results[index].url,
                            botname,
                            botfooter
                        );

                    } catch (err) {

                        conn.ev.off('messages.upsert', listener);

                        await conn.sendMessage(from, {
                            text: `
╭────♡◉◉◉♡────⌬
❌ *Download Failed*
✨ *${botname} Comic System*
╰────♡◉◉◉♡────⌬

📌 *Reason:*  
➤ ${err.message}

${botfooter}
`
                        }, { quoted: mek });
                    }
                };

                conn.ev.on('messages.upsert', listener);

                setTimeout(() => {
                    conn.ev.off('messages.upsert', listener);
                }, 60000);

                return;
            }

            // ================= DIRECT MODE =================

            await handlePost(
                conn,
                mek,
                from,
                q,
                botname,
                botfooter
            );

        } catch (err) {

            await conn.sendMessage(from, {
                react: { text: '❌', key: mek.key }
            });

            await conn.sendMessage(from, {
                text: `
╭────♡◉◉◉♡────⌬
❌ *Comic API Error*
✨ *${botname} System*
╰────♡◉◉◉♡────⌬

📌 *Reason:*  
➤ ${err.message}

${botfooter}
`
            }, { quoted: mek });
        }
    }
};

async function handlePost(
    conn,
    quotedMsg,
    from,
    postUrl,
    botname,
    botfooter
) {

    const postApi =
        `https://thenuxanime-dl.netlify.app/api/anime?url=${encodeURIComponent(postUrl)}`;

    const { data } = await axios.get(postApi, {
        timeout: 120000,
        headers: {
            'User-Agent': 'Mozilla/5.0'
        }
    });

    if (!data?.success) {
        throw new Error('Comic Not Found');
    }

    const meta = data.metadata || {};
    const folder = data.drive_folders?.[0];

    if (!folder?.url) {
        throw new Error('Google Drive Folder Not Found');
    }

    const postCaption = `
╭────♡◉◉◉♡────⌬
📚 *Comic Found*
✨ *${botname} Ready*
╰────♡◉◉◉♡────⌬

📌 *Title:*  
➤ ${meta.title || 'Unknown'}

✍️ *Writer:*  
➤ ${meta.writer || 'Unknown'}

🎨 *Artist:*  
➤ ${meta.artist || 'Unknown'}

🏷️ *Genre:*  
➤ ${meta.genre || 'Unknown'}

───────────────

📥 *Fetching PDF File...*

${botfooter}
`;

    await conn.sendMessage(from, {
        image: {
            url: meta.cover || meta.image || ''
        },
        caption: postCaption
    }, { quoted: quotedMsg });

    // ================= DRIVE API =================

    const gdriveApi =
        `https://thenuxgdrive.netlify.app/api/gdrive?url=${encodeURIComponent(folder.url)}`;

    const driveRes = await axios.get(gdriveApi, {
        timeout: 120000,
        headers: {
            'User-Agent': 'Mozilla/5.0'
        }
    });

    const drive = driveRes.data;

    if (!drive?.success || !drive.files?.length) {
        throw new Error('No PDF Files Found');
    }

    const pdf =
        drive.files.find(
            f => f.mimeType === 'application/pdf'
        ) || drive.files[0];

    if (!pdf?.download_url) {
        throw new Error('PDF Download URL Not Found');
    }

    // ================= SEND PDF =================

    await conn.sendMessage(from, {
        document: {
            url: pdf.download_url
        },
        mimetype:
            pdf.mimeType || 'application/pdf',

        fileName:
            pdf.name ||
            `${meta.title || 'comic'}.pdf`,

        caption: `
╭────♡◉◉◉♡────⌬
📄 *Comic PDF Ready*
✨ *${botname} Downloaded*
╰────♡◉◉◉♡────⌬

📚 *File:*  
➤ ${pdf.name}

📦 *Size:*  
➤ ${pdf.size_formatted || 'Unknown'}

───────────────

💌 *Enjoy Your Comic 🎀*

${botfooter}
`
    }, { quoted: quotedMsg });

    await conn.sendMessage(from, {
        react: {
            text: '✅',
            key: quotedMsg.key
        }
    });
}
