const axios = require("axios");
const { ReadData } = require("../database");

module.exports = {
    name: "imggen",

    run: async ({ conn, mek, from, args }) => {
        try {

            const number = conn.user.id.split(':')[0];
            const image = await ReadData(number, "SULA_IMAGE_PATH");
            const botname = await ReadData(number, "BOT_NAME");
            const footer = await ReadData(number, "BOT_FOOTER");

            if (!args.length) {
                return await conn.sendMessage(from, {
                    image: { url: image },
                    caption: "📌 Usage:\n.imggen women"
                }, { quoted: mek });
            }

            const prompt = args.join(" ");

            await conn.sendMessage(from, {
                react: { text: "🎨", key: mek.key }
            });

            const api = `https://thenuximg.netlify.app/api/image?prompt=${encodeURIComponent(prompt)}`;

            // 🔥 get image as buffer
            const res = await axios.get(api, {
                responseType: "arraybuffer"
            });

            const buffer = Buffer.from(res.data);

            await conn.sendMessage(from, {
                image: buffer,
                caption: `
🎨 Prompt: ${prompt}

${footer}
`
            }, { quoted: mek });

        } catch (err) {
            console.log("IMG ERROR:", err.message);

            await conn.sendMessage(from, {
                text: "❌ Image generate error!"
            }, { quoted: mek });
        }
    }
};
