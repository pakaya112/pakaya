const { ReadData } = require('../database');
const axios = require("axios");
const fs = require("fs");
const path = require("path");

module.exports = {
    name: 'alive',

    run: async ({ conn, mek, from, sender }) => {

        try {

            const userSender =
                sender ||
                mek?.key?.participant ||
                mek?.key?.remoteJid ||
                'unknown@s.whatsapp.net';

            const date = new Date().toLocaleDateString('en-GB', {
                timeZone: 'Asia/Colombo'
            });

            const time = new Date().toLocaleTimeString('en-GB', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                timeZone: 'Asia/Colombo'
            });

            const number = conn.user.id.split(':')[0];
            const Images = await ReadData(number, "SULA_IMAGE_PATH");
            const botname = await ReadData(number, "BOT_NAME");
            const botfooter = await ReadData(number, "BOT_FOOTER");
            const mode = await ReadData(number, "MODE");

            const caption = `
╭────♡◉◉◉♡────⌬
💖 *Hey I Am Alive Now...!*  
🌸 *I’m ${botname}, your lovely assistant — alive and sparkling now!*  
╰────♡◉◉◉♡────⌬

📅 *Date:* ${date}  
⌚ *Time:* ${time}  
───────────────

📱 *Number:* ${number}  
🎀 *Mode:* ${mode}  

───────────────
🌐 *SULA-MD Mini Bot Web:*  

> https://sulaofc.store

┊      .ೃ࿔*:･🌷
┊   ✧･ﾟ: ✧･ﾟ: 💖

${botfooter}
`;

            const sulafdQuoted = {
    key: {
        fromMe: false,
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast",
        id: Math.random().toString(36).substring(2, 15)
    },
    message: {
        conversation: `🕒 𝐃𝙰𝚃𝙴 ${new Date().toISOString().split('T')[0]}`
    },
    messageTimestamp: Math.floor(Date.now() / 1000) - 3600
};

            const fpay = {
  key: {
    remoteJid: '0@s.whatsapp.net',
    fromMe: false,
    id: 'B826873620DD5947E518F6F15EAA57D4',
    participant: '0@s.whatsapp.net'
  },
  message: {
    requestPaymentMessage: {
      currencyCodeIso4217: 'LKR',
      amount1000: 500000,
      requestFrom: '0@s.whatsapp.net',
      noteMessage: {
        extendedTextMessage: {
          text: 'SULA-MD PAYMENT'
        }
      },
      expiryTimestamp: 999999999,
      paymentAttachment: {}
    }
  }
};
            
            const ftroli = {
    key: {
        remoteJid: '0@s.whatsapp.net',
        fromMe: false,
        id: '3B64558F20D8B1D3A56BA',
        participant: '0@s.whatsapp.net'
    },
    message: {
        orderMessage: {
            orderId: '547637845452318',
            thumbnail: Buffer.from(''),
            itemCount: 999,
            status: 1,
            surface: 1,
            message: '🔖 SULA-MD ORDER',
            orderTitle: 'Premium Bot Service',
            sellerJid: '0@s.whatsapp.net',
            token: 'ARBITRARY_TOKEN',
            totalAmount1000: 500000,
            currencyCodeIso4217: 'LKR'
        }
    }
};

            const qcontact = {
    key: {
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast"
    },
    message: {
        contactMessage: {
            displayName: "SULA-MD",
            vcard: `BEGIN:VCARD
VERSION:3.0
N:SULA-MD;;;;
FN:SULA-MD
TEL;type=CELL;type=VOICE;waid=94703266859:+94 70 326 6859
END:VCARD`,
            jpegThumbnail: null,
            sendEphemeral: true
        }
    }
};

            
            
            await conn.sendMessage(from, {
    image: {
        url: Images
    },
    caption
}, { quoted: qcontact });

await conn.sendMessage(from, {
    audio: {
        url: 'https://raw.githubusercontent.com/sulamadara1147/data/main/sulavoice.opus'
    },
    mimetype: 'audio/ogg; codecs=opus',
    ptt: true
}, { quoted: qcontact });

} catch (err) {
    console.log("ALIVE ERROR:", err);

    await conn.sendMessage(from, {
        text: "❌ Alive command error!"
    }, { quoted: mek });
}
    }
};
