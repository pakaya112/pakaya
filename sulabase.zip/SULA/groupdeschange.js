const { ReadData } = require('../database');

module.exports = {
    name: 'setgdesc',

    run: async ({
        conn,
        mek,
        from,
        q,
        isGroup,
        isAdmin,
        isBotAdmins
    }) => {

        try {

            if (!isGroup) {
                return conn.sendMessage(from, {
                    text: '❌ This command only works in groups!'
                }, { quoted: mek });
            }

            if (!isAdmin) {
                return conn.sendMessage(from, {
                    text: '❌ Only admins can use this command!'
                }, { quoted: mek });
            }

            if (!isBotAdmins) {
                return conn.sendMessage(from, {
                    text: '❌ Bot must be admin first!'
                }, { quoted: mek });
            }

            if (!q) {
                return conn.sendMessage(from, {
                    text: '❌ Give new group description!'
                }, { quoted: mek });
            }

            await conn.groupUpdateDescription(from, q);

            await conn.sendMessage(from, {
                text: '✅ Group description updated successfully!'
            }, { quoted: mek });

        } catch (err) {

            await conn.sendMessage(from, {
                text: `❌ Error:\n${err.message}`
            }, { quoted: mek });
        }
    }
};
