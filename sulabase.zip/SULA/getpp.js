module.exports = {
    name: "getpp",
    alias: ["getdp"],

    run: async ({ conn, mek, from }) => {

        try {
            const target =
                mek.message?.extendedTextMessage?.contextInfo?.participant ||
                mek.key.participant ||
                mek.key.remoteJid;

            if (!target) {
                return await conn.sendMessage(from, {
                    text: "⚠️ Reply to a message or use in chat!"
                }, { quoted: mek });
            }
            
            await conn.sendMessage(from, {
                react: { text: "🖼️", key: mek.key }
            });

            const pp = await conn.profilePictureUrl(target, "image")
                .catch(() => null);

            if (!pp) {
                return await conn.sendMessage(from, {
                    text: "❌ No profile picture found!"
                }, { quoted: mek });
            }

            const number = target.split("@")[0];

            // 💎 UI message
            const caption = `
     🖼️ PROFILE PICTURE 

✨ Profile picture fetched successfully!
`;

            await conn.sendMessage(from, {
                image: { url: pp },
                caption: caption
            }, { quoted: mek });

        } catch (err) {
           // console.log("GETPP ERROR:", err);

            await conn.sendMessage(from, {
                text: "❌ Failed to get profile picture!"
            }, { quoted: mek });
        }
    }
};
